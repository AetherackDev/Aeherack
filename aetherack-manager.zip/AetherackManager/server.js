'use strict';
// Aetherack Manager — โปรแกรมคุม Chrome หลายตัว (1 Chrome = 1 IP = ไม่เกิน 3 จอ) + หน้ารวมสถานะตัวละครจากสคริปต์ Aetherack
// ไม่ต้องติดตั้งแพ็กเกจเพิ่ม: ใช้ Node.js 22 ขึ้นไป (มี WebSocket/fetch ในตัว) · เปิดเฉพาะในเครื่อง (127.0.0.1)
const http = require('node:http');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawn, execFile } = require('node:child_process');
const net = require('node:net');

const ROOT = __dirname;
// ✅ ต้องใช้ Node.js 22 ขึ้นไป (ใช้ WebSocket ในตัวคุม Chrome) — รุ่นเก่ากว่า: แจ้งเป็นหน้าต่าง Windows + เปิดหน้าดาวน์โหลด แล้วปิดโปรแกรม (ไม่เปิดแบบใช้งานได้ครึ่ง ๆ กลาง ๆ)
{
    const major = parseInt(String(process.versions.node).split('.')[0], 10) || 0;
    if (major < 22 || typeof WebSocket !== 'function') {
        const msg = `Aetherack Manager ต้องใช้ Node.js รุ่น 22 ขึ้นไป แต่เครื่องนี้เป็นรุ่น ${process.versions.node}\n\nกด OK เพื่อเปิดหน้าดาวน์โหลด Node.js (เลือกรุ่น LTS) ติดตั้งทับแล้วเปิดโปรแกรมใหม่`;
        console.error(msg);
        try { fs.appendFileSync(path.join(ROOT, 'manager.log'), `[${new Date().toISOString()}] ❌ ${msg.replace(/\n+/g, ' ')}\n`); } catch (e) { /* ignore */ }
        if (process.platform === 'win32' && !process.argv.includes('--guard')) {
            const ps = `Add-Type -AssemblyName PresentationFramework; if ([System.Windows.MessageBox]::Show('${msg.replace(/'/g, "''").split('\n').join("' + [char]10 + '")}','Aetherack Manager', 'OKCancel', 'Warning') -eq 'OK') { Start-Process 'https://nodejs.org/' }`;
            try { require('node:child_process').spawnSync('powershell', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true, timeout: 600000 }); } catch (e) { /* ignore */ }
        }
        process.exit(1);
    }
}
const CONFIG_FILE = path.join(ROOT, 'config.json');
const PUBLIC = path.join(ROOT, 'public');
const VERSION = '1.51.3';
const UPDATE_URL = 'https://raw.githubusercontent.com/AetherackDev/Aeherack/main/manifest.json';      // ที่ตรวจอัปเดตค่าเริ่มต้น (ช่อง ลิงก์ตรวจอัปเดต ว่าง = ใช้อันนี้)

// ---------------------------------------------------------------
// 🛡️ ตัวเฝ้า (โปรเซสแยกเล็ก ๆ): Manager หายไปโดยไม่ได้กดปิดเอง (โปรแกรมล่ม / หน่วยความจำเต็ม) → เปิด Manager ใหม่ให้เอง
// กด ⏻ ปิดโปรแกรม = ตัวเฝ้าเลิกเฝ้าแล้วปิดตาม · อัปเดต/รีสตาร์ท = รอตัวใหม่ขึ้นมาเอง · เปิดใหม่ไม่เกิน 5 ครั้ง/30 นาที (ล่มวนตอนเปิด = หยุด)
// ---------------------------------------------------------------
const GUARD_BEAT = path.join(ROOT, 'guard.beat'), QUIT_FLAG = path.join(ROOT, 'quit.flag');
if (process.argv.includes('--guard')) {
    let port = 17321; try { port = +JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')).port || port; } catch (e) { /* ค่าเริ่มต้น */ }
    const glog = (m) => { try { fs.appendFileSync(path.join(ROOT, 'manager.log'), `[${new Date().toLocaleString('th-TH', { hour12: false })}] 🛡️ ${m}\n`); } catch (e) { /* ignore */ } };
    const alive = () => new Promise((ok) => { const r = http.get({ host: '127.0.0.1', port, path: '/api/ver', headers: { 'X-Aeth': '1' }, timeout: 8000 }, (x) => { x.resume(); ok(x.statusCode < 500); }); r.on('error', () => ok(false)).on('timeout', () => { r.destroy(); ok(false); }); });
    const beat = () => { try { fs.writeFileSync(GUARD_BEAT, String(Date.now())); } catch (e) { /* ignore */ } };
    const bye = (m) => { if (m) glog(m); try { fs.unlinkSync(GUARD_BEAT); } catch (e) { /* ignore */ } process.exit(0); };
    let down = 0; const starts = [];
    beat();
    setInterval(async () => {
        beat();
        if (await alive()) { down = 0; return; }
        if (fs.existsSync(QUIT_FLAG)) bye('Manager ถูกปิดเอง — ตัวเฝ้าหยุดเฝ้า');
        if (++down < 3) return;      // ไม่ตอบ 3 รอบติด (~60 วิ) — เผื่อช่วงอัปเดต/รีสตาร์ท
        const now = Date.now(); while (starts.length && now - starts[0] > 1800000) starts.shift();
        if (starts.length >= 5) bye('Manager ล่มซ้ำ 5 ครั้งใน 30 นาที — หยุดเปิดใหม่ (ดู crash.log)');
        starts.push(now); down = 0; glog('Manager ไม่ตอบ (อาจล่ม) — เปิดใหม่ให้');
        let out = 'ignore'; try { out = fs.openSync(path.join(ROOT, 'manager.log'), 'a'); } catch (e) { /* ignore */ }
        spawn(process.execPath, [path.join(ROOT, 'server.js'), '--restarted', '--by-guard'], { cwd: ROOT, detached: true, stdio: ['ignore', out, out], windowsHide: true }).unref();
    }, 20000);
    return;      // โปรเซสตัวเฝ้า: ไม่รันส่วนอื่นของ Manager
}

// ---------------------------------------------------------------
// การตั้งค่า
// ---------------------------------------------------------------
// ค่าเริ่มต้นกลาง (ไม่มีข้อมูลส่วนตัว) · ค่าเฉพาะของเครื่อง/ผู้ใช้ (IP พร็อกซี, รหัส) ใส่ใน config.default.json ได้ — ใช้เมื่อยังไม่มี config.json
const DEFAULTS_FILE = path.join(ROOT, 'config.default.json');
function defaultConfig() {
    let own = {}; try { own = JSON.parse(fs.readFileSync(DEFAULTS_FILE, 'utf8')) || {}; } catch (e) { /* ไม่มีไฟล์ = ค่ากลาง */ }
    return Object.assign(baseConfig(), own);
}
function baseConfig() {
    return {
        port: 17321,
        chromePath: '',
        gameUrl: 'https://aetheria-online.in.th/play',
        maxPerIp: 3,
        startGapSec: 5,
        bypass: '*.google.com;*.googleapis.com;*.gvt1.com;*.googleusercontent.com;*.gstatic.com',
        perfFlags: '--disable-background-timer-throttling --disable-renderer-backgrounding --disable-backgrounding-occluded-windows',
        screen: { width: 1920, height: 1040, cols: 4 },
        proxyUser: '', proxyPass: '',      // รหัสพร็อกซี — ตั้งในหน้า ตั้งค่า
        updateUrl: '',      // ลิงก์ manifest.json ของเวอร์ชันใหม่ ({ version, url, sha256, notes }) — ว่าง = ใช้ UPDATE_URL (GitHub)
        autoPurge: true, purgeMin: 20,      // 🧹 คืน RAM ทุกจออัตโนมัติ
        ramGuard: true, ramLimitGB: 2.5, ramCooldownMin: 60, reloadEveryH: 12,      // 🧠 แรมต่อจอเกินกำหนด → รีโหลดตอนว่าง
        groups: [{ id: 'Home', name: 'บ้าน (เน็ตบ้าน)', proxy: '', dir: 'C:\\ChromeHome', debugPort: 9300 }],      // เพิ่มโปรไฟล์/IP ได้จากหน้าหลัก
    };
}
function loadConfig() {
    try { return Object.assign(defaultConfig(), JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'))); } catch (e) {
        const c = defaultConfig(); saveConfig(c); return c;
    }
}
function saveConfig(c) { fs.writeFileSync(CONFIG_FILE + '.tmp', JSON.stringify(c, null, 2)); fs.renameSync(CONFIG_FILE + '.tmp', CONFIG_FILE); }
let CFG = loadConfig();

// 🌐 Browser ที่รองรับ (ข้อ 27): ตระกูล Chromium ที่มีช่องควบคุม (remote debugging) + โหมดแอป + ติดตั้ง Tampermonkey จาก Chrome Web Store ได้
const PF = process.env['ProgramFiles'] || 'C:\\Program Files', PF86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', LAD = process.env.LOCALAPPDATA || '';
const BROWSERS = {
    chrome: { name: 'Google Chrome', exe: 'chrome.exe', paths: [path.join(PF, 'Google\\Chrome\\Application\\chrome.exe'), path.join(PF86, 'Google\\Chrome\\Application\\chrome.exe'), path.join(LAD, 'Google\\Chrome\\Application\\chrome.exe')] },
    edge: { name: 'Microsoft Edge', exe: 'msedge.exe', paths: [path.join(PF86, 'Microsoft\\Edge\\Application\\msedge.exe'), path.join(PF, 'Microsoft\\Edge\\Application\\msedge.exe')] },
    brave: { name: 'Brave', exe: 'brave.exe', paths: [path.join(PF, 'BraveSoftware\\Brave-Browser\\Application\\brave.exe'), path.join(PF86, 'BraveSoftware\\Brave-Browser\\Application\\brave.exe'), path.join(LAD, 'BraveSoftware\\Brave-Browser\\Application\\brave.exe')] },
};
const browserId = () => (BROWSERS[CFG.browser] ? CFG.browser : 'chrome');
const browserList = () => Object.entries(BROWSERS).map(([id, b]) => ({ id, name: b.name, path: b.paths.find((p) => p && fs.existsSync(p)) || '' }));
function findChrome() {
    if (CFG.chromePath && fs.existsSync(CFG.chromePath)) return CFG.chromePath;      // ที่อยู่ที่ใส่เอง (หน้า ตั้งค่า) ชนะเสมอ
    return BROWSERS[browserId()].paths.find((p) => p && fs.existsSync(p)) || '';
}
// โฟลเดอร์ข้อมูลของโปรไฟล์: Chrome ใช้โฟลเดอร์เดิม · Browser อื่นใช้โฟลเดอร์แยก (C:\ChromeG01-edge) — ไม่เปิดข้อมูล Chrome ด้วย Browser อื่น (กันข้อมูลถูกแปลง/เสีย)
const dirOf = (g) => (browserId() === 'chrome' || CFG.chromePath ? g.dir : `${g.dir}-${browserId()}`);

// ---------------------------------------------------------------
// สถานะ
// ---------------------------------------------------------------
const S = {
    groups: {},     // id -> { running, debug, outside, targets:[], ram, procs, err }
    peers: {},      // tab -> snapshot จากสคริปต์ + ts + group + targetId
    cmds: {},       // tab -> [{ id, cmd, at }]
    slog: {},       // tab -> Logs ล่าสุดจากสคริปต์ { at, entries }
    inv: {},        // tab -> ของในกระเป๋าล่าสุด (สคริปต์ส่งมาเมื่อกด 🎒 ดูกระเป๋า)
    log: [],        // ข้อความล่าสุด
    cpu: { pct: 0, prev: null },
    seq: 0,
};
// 🔒 ปิดข้อมูลลับก่อนแสดง Logs: Webhook Discord · ลิงก์ Google Apps Script · user:pass ในลิงก์พร็อกซี · token/key/password=…
const maskSecrets = (t) => String(t == null ? '' : t)
    .replace(/https:\/\/(?:ptb\.|canary\.)?discord(?:app)?\.com\/api\/webhooks\/\d+\/[\w-]+/gi, 'https://discord.com/api/webhooks/•••')
    .replace(/https:\/\/script\.google\.com\/macros\/s\/[\w-]+/gi, 'https://script.google.com/macros/s/•••')
    .replace(/(\/\/)[^\/\s:@]+:[^\/\s@]+@/g, '$1•••:•••@')
    .replace(/\b(token|apikey|api_key|secret|password|passwd|pass|auth)\b(["'\s:=]+)[^\s"',;&]{4,}/gi, '$1$2•••');
function say(msg) { const line = `[${new Date().toLocaleTimeString('th-TH', { hour12: false })}] ${msg}`; S.log.push(line); if (S.log.length > 200) S.log.shift(); console.log(line); }
const groupOf = (id) => CFG.groups.find((g) => g.id === id);
const isGame = (t) => t.type === 'page' && /aetheria-online\.in\.th\/play/i.test(t.url || '');

// ---------------------------------------------------------------
// Chrome DevTools Protocol (ช่องควบคุมของ Chrome · เปิดเฉพาะ 127.0.0.1)
// ---------------------------------------------------------------
async function jget(port, p, ms = 1200) {
    const r = await fetch(`http://127.0.0.1:${port}${p}`, { signal: AbortSignal.timeout(ms) });
    if (!r.ok) throw Error('HTTP ' + r.status);
    return r.json();
}
// เปิด WebSocket แล้วส่งหลายคำสั่งต่อกัน: fn(send) → ผลลัพธ์
function cdp(wsUrl, fn, ms = 10000) {
    return new Promise((resolve, reject) => {
        const ws = new WebSocket(wsUrl); let id = 0; const wait = new Map();
        const t = setTimeout(() => { try { ws.close(); } catch (e) { /* ignore */ } reject(Error('CDP หมดเวลา')); }, ms);
        const send = (method, params = {}) => new Promise((res, rej) => { const i = ++id; wait.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params })); });
        ws.onmessage = (ev) => { let m; try { m = JSON.parse(ev.data); } catch (e) { return; } const w = m.id && wait.get(m.id); if (!w) return; wait.delete(m.id); if (m.error) w.rej(Error(m.error.message)); else w.res(m.result); };
        ws.onerror = () => { clearTimeout(t); reject(Error('ต่อช่องควบคุมของ Chrome ไม่ได้')); };
        ws.onopen = async () => { try { const r = await fn(send); clearTimeout(t); ws.close(); resolve(r); } catch (e) { clearTimeout(t); try { ws.close(); } catch (er) { /* ignore */ } reject(e); } };
    });
}
// ⬛ พื้นดำ: ให้ Chrome ส่งภาพพื้นแผนที่ (/maps/*.webp ของเกม) เป็นภาพสีดำแทน ผ่านช่องควบคุมของ Chrome — ไม่แก้โค้ดเกม
// ตัวละคร มอน เอฟเฟกต์ ข้อมูลแผนที่ (ทางเดิน/กำแพง) ยังโหลดตามปกติ · ประหยัดแรม/การ์ดจอ (ภาพพื้นใหญ่ที่สุดในเกม) · เปิด/ปิดแล้วต้องรีโหลดหน้าเกม
const GROUND_PNG = 'iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAAFklEQVR4nGPg4uYlCTGMahjVMHw1AAATHCIBpWqbbgAAAABJRU5ErkJggg==';
const GH = new Map();      // targetId -> { ws }
function groundHook(t) {
    let ws; try { ws = new WebSocket(t.webSocketDebuggerUrl); } catch (e) { return; }
    let id = 0; const send = (method, params = {}) => { try { ws.send(JSON.stringify({ id: ++id, method, params })); } catch (e) { /* ignore */ } };
    ws.onopen = () => send('Fetch.enable', { patterns: [{ urlPattern: '*/maps/*', requestStage: 'Request' }] });
    ws.onmessage = (ev) => {
        let m; try { m = JSON.parse(ev.data); } catch (e) { return; } if (m.method !== 'Fetch.requestPaused') return;
        const u = (m.params.request || {}).url || '', rid = m.params.requestId;
        if (/\/maps\/[^?#]+\.(webp|png|jpe?g)(?:[?#]|$)/i.test(u)) send('Fetch.fulfillRequest', { requestId: rid, responseCode: 200, responseHeaders: [{ name: 'Content-Type', value: 'image/png' }, { name: 'Cache-Control', value: 'no-store' }, { name: 'Access-Control-Allow-Origin', value: '*' }], body: GROUND_PNG });
        else send('Fetch.continueRequest', { requestId: rid });      // ข้อมูลแผนที่ (.json) ปล่อยผ่านตามปกติ
    };
    ws.onclose = () => { if (GH.get(t.id) && GH.get(t.id).ws === ws) GH.delete(t.id); };
    ws.onerror = () => { /* ignore */ };
    GH.set(t.id, { ws });
}
function groundSync() {
    const on = !!CFG.groundOff, live = new Set();
    for (const g of CFG.groups) for (const t of ((S.groups[g.id] || {}).targets || []).filter(isGame)) { live.add(t.id); if (on && !GH.has(t.id) && t.webSocketDebuggerUrl) groundHook(t); }
    for (const [id, h] of GH) if (!on || !live.has(id)) { try { h.ws.close(); } catch (e) { /* ignore */ } GH.delete(id); }
}
setInterval(() => { try { groundSync(); } catch (e) { /* ignore */ } }, 2000);

// 💥 จอเกมแครช / Out of Memory ("Aw, Snap!" · "Not enough memory to open this page") → รีโหลดให้เอง 1 รอบ แล้วสคริปต์ล็อกอินกลับไปฟาร์มต่อ
//    ฟังเหตุการณ์แท็บแครช (Inspector.targetCrashed) + เช็คแท็บที่กลายเป็นหน้า error ของ Chrome · กันวนรีซ้ำ: ห่างกันอย่างน้อย 2 นาที และไม่เกิน 3 ครั้ง/30 นาทีต่อแท็บ
const CR = new Map();      // targetId -> { ws, g, url }
const CR_HIST = new Map(); // targetId -> [เวลาที่รีโหลด]
const CR_CAP = new Map();  // targetId -> เวลาที่แจ้งว่าหยุดรีโหลด (แจ้งครั้งเดียวต่อ 30 นาที)
function crashReload(t, g, why) {
    if (CFG.oomReload === false) return;
    const now = Date.now(), h = (CR_HIST.get(t.id) || []).filter((x) => now - x < 30 * 60000);
    if (h.length && now - h[h.length - 1] < 2 * 60000) return;
    if (h.length >= 3) { if (now - (CR_CAP.get(t.id) || 0) > 30 * 60000) { say(`💥 ${g.name}: จอเกมแครชซ้ำ ${h.length} ครั้งใน 30 นาที — หยุดรีโหลดอัตโนมัติ (หน่วยความจำ/VRAM น่าจะเต็ม ลองลดจำนวนจอ)`); CR_CAP.set(t.id, now); } return; }
    h.push(now); CR_HIST.set(t.id, h);
    say(`💥 ${g.name}: จอเกม${why} — รีโหลดให้อัตโนมัติ (ครั้งที่ ${h.length} ใน 30 นาที)`);
    setTimeout(() => { if (t.webSocketDebuggerUrl) cdp(t.webSocketDebuggerUrl, (send) => send('Page.reload', { ignoreCache: false })).catch(() => {}); }, 5000);
}
function crashHook(t, g) {
    let ws; try { ws = new WebSocket(t.webSocketDebuggerUrl); } catch (e) { return; }
    ws.onopen = () => { try { ws.send(JSON.stringify({ id: 1, method: 'Inspector.enable', params: {} })); } catch (e) { /* ignore */ } };
    ws.onmessage = (ev) => { let m; try { m = JSON.parse(ev.data); } catch (e) { return; } if (m.method === 'Inspector.targetCrashed') crashReload(t, g, 'แครช (Aw, Snap! / Out of Memory)'); };
    ws.onclose = () => { if (CR.get(t.id) && CR.get(t.id).ws === ws) CR.delete(t.id); };
    ws.onerror = () => { /* ignore */ };
    CR.set(t.id, { ws, g });
}
function crashSync() {
    const on = CFG.oomReload !== false, live = new Set();
    for (const g of CFG.groups) for (const t of ((S.groups[g.id] || {}).targets || [])) {
        if (t.type !== 'page') continue;
        if (isGame(t)) { live.add(t.id); if (on && !CR.has(t.id) && t.webSocketDebuggerUrl) crashHook(t, g); }
        else if (on && CR.has(t.id) && /^chrome-error:/i.test(t.url || '')) { live.add(t.id); crashReload(t, g, 'เปิดไม่ขึ้น (Not enough memory)'); }      // แท็บเกมเดิมที่กลายเป็นหน้า error
    }
    for (const [id, h] of CR) if (!on || !live.has(id)) { try { h.ws.close(); } catch (e) { /* ignore */ } CR.delete(id); }
}
setInterval(() => { try { crashSync(); } catch (e) { /* ignore */ } }, 5000);
async function browserWs(g) { const v = await jget(g.debugPort, '/json/version'); return v.webSocketDebuggerUrl; }

// 🎮 กันเกมหยุดเมื่อหน้าต่างถูกบัง/ย่อ (ทั้งหน้าต่างปกติและโหมดแอป): บังคับใส่ทุกครั้ง + รวม --disable-features ของผู้ใช้ไว้ในตัวเดียว
//   Windows มีระบบตรวจหน้าต่างที่ถูกบัง (CalculateNativeWinOcclusion) แยกจากธงอื่น → ถ้าไม่ปิด Chrome จะหยุดวาดภาพ/หยุดรอบเกมเมื่อมีโปรแกรมอื่นบัง
function keepAwakeFlags() {
    const user = String(CFG.perfFlags || '').split(/\s+/).filter(Boolean), feats = new Set(['CalculateNativeWinOcclusion', 'IntensiveWakeUpThrottling', 'Translate']), out = [];
    for (const f of user) { const m = /^--disable-features=(.*)$/.exec(f); if (m) m[1].split(',').filter(Boolean).forEach((x) => feats.add(x)); else out.push(f); }
    for (const f of ['--disable-background-timer-throttling', '--disable-renderer-backgrounding', '--disable-backgrounding-occluded-windows']) if (!out.includes(f)) out.push(f);
    out.push('--disable-features=' + [...feats].join(','));
    return out;
}
async function startGroup(g) {
    const info = S.groups[g.id] || {};
    if (info.debug) throw Error(`${g.id} เปิดอยู่แล้ว`);
    if (info.outside) throw Error(`${g.id} เปิดอยู่จากทางลัดเดิม (ไม่มีช่องควบคุม) — ปิด Chrome ตัวนั้นก่อน แล้วเปิดจากโปรแกรมนี้`);
    const exe = findChrome(); if (!exe) throw Error('ไม่พบ chrome.exe — ใส่ที่อยู่ในหน้า ตั้งค่า');
    const args = [`--user-data-dir=${dirOf(g)}`, `--remote-debugging-port=${g.debugPort}`, '--no-first-run', '--no-default-browser-check'].concat(keepAwakeFlags());
    if (g.proxy) { const rl = relayFor(g); args.push(`--proxy-server=${rl ? 'http://127.0.0.1:' + rl.port : proxyPlain(g.proxy)}`, `--proxy-bypass-list=${CFG.bypass}`); }
    const first = CFG.prepOnStart !== false ? `http://127.0.0.1:${CFG.port}/prep.html?g=${encodeURIComponent(g.id)}` : gameUrlFor(g);
    args.push(CFG.appMode ? `--app=${first}` : first);      // 🪟 โหมดแอป (ข้อ 25): ไม่มีแถบแท็บ/ช่อง URL/ปุ่มส่วนขยาย · ส่วนขยาย (Tampermonkey) ทำงานเหมือนเดิม      // หน้าเตรียมความพร้อม → เข้าเกมเองเมื่อพร้อม
    spawn(exe, args, { detached: true, stdio: 'ignore', windowsHide: false }).unref();
    if (CFG.prepOnStart !== false) setTimeout(() => { prepGroup(g, true).catch(() => {}); }, 1500);
    else if (CFG.autoAllow) setTimeout(() => { if ((S.groups[g.id] || {}).tm) allowUserScripts(g).catch((e) => say('⚠️ ' + e.message)); }, 10000);
    say(`🚀 เปิด Chrome ${g.id}${g.proxy ? ' ผ่าน ' + proxyPlain(g.proxy).replace(/^https?:\/\//, '') + (relayFor(g) ? ' (ใส่รหัสพร็อกซีให้อัตโนมัติ)' : '') : ' (เน็ตบ้าน)'}`);
}
// ---------------------------------------------------------------
// 🔑 ใส่รหัสพร็อกซีให้อัตโนมัติ: Chrome ใส่ user/pass ใน --proxy-server ไม่ได้ (จะเด้งหน้าต่าง Sign in ทุกครั้ง)
//    → โปรแกรมเปิดตัวกลางในเครื่อง (127.0.0.1:18xxx) ต่อกลุ่ม: Chrome ต่อตัวกลางแบบไม่ต้องใส่รหัส → ตัวกลางส่งต่อไปพร็อกซีจริงพร้อมรหัส
// ---------------------------------------------------------------
const RELAYS = new Map();      // group id -> { port, key, server }
// 🔑 แปลงพร็อกซีหลายรูปแบบ (แต่ละเจ้าให้มาไม่เหมือนกัน) → http://user:pass@IP:พอร์ต
//   IP · IP:พอร์ต · IP:พอร์ต:user:pass · user:pass@IP:พอร์ต · IP:พอร์ต@user:pass · user:pass:IP:พอร์ต · มี http:// / socks5:// นำหน้าได้
//   รหัสในช่องของโปรไฟล์ = ใช้กับโปรไฟล์นั้น (ไม่มี = ใช้รหัสกลางในหน้า ตั้งค่า)
function normProxy(raw) {
    let s = String(raw || '').trim(); if (!s) return '';
    let scheme = 'http'; const m0 = /^(https?|socks5h?|socks4):\/\//i.exec(s); if (m0) { scheme = m0[1].toLowerCase(); s = s.slice(m0[0].length); }
    s = s.replace(/\/+$/, '');
    const hostRe = /^(\d{1,3}(?:\.\d{1,3}){3}|[a-z0-9-]+(?:\.[a-z0-9-]+)*\.[a-z]{2,})$/i, isPort = (x) => /^\d{1,5}$/.test(x || '') && +x > 0 && +x < 65536;
    let host = '', port = '', user = '', pass = '', m;
    const bad = () => Error(`อ่านพร็อกซี "${String(raw).replace(/:[^:@]*@/, ':•••@').slice(0, 60)}" ไม่ได้ — ใช้แบบ IP:พอร์ต:user:pass หรือ user:pass@IP:พอร์ต`);
    if ((m = /^(.+)@([^@]+)$/.exec(s))) {
        const a = m[1].split(':'), b = m[2].split(':');
        if (hostRe.test(b[0])) { host = b[0]; port = b[1] || ''; user = a[0]; pass = a.slice(1).join(':'); }
        else if (hostRe.test(a[0])) { host = a[0]; port = a[1] || ''; user = b[0]; pass = b.slice(1).join(':'); }
        else throw bad();
    } else {
        const p = s.split(':');
        if (p.length === 1 && hostRe.test(p[0])) { host = p[0]; port = '50100'; }      // ใส่แค่ IP (พอร์ต 50100 ตาม Proxy-Seller)
        else if (p.length === 2 && hostRe.test(p[0])) { host = p[0]; port = p[1]; }
        else if (p.length >= 4 && hostRe.test(p[0]) && isPort(p[1])) { host = p[0]; port = p[1]; user = p[2]; pass = p.slice(3).join(':'); }
        else if (p.length >= 4 && hostRe.test(p[p.length - 2]) && isPort(p[p.length - 1])) { host = p[p.length - 2]; port = p[p.length - 1]; user = p[0]; pass = p.slice(1, -2).join(':'); }
        else throw bad();
    }
    if (!isPort(port)) throw Error(`พอร์ตพร็อกซี "${port}" ไม่ถูกต้อง`);
    if (user && /^socks/.test(scheme)) throw Error('Chrome ใช้ SOCKS ที่ต้องใส่รหัสไม่ได้ — ขอแบบ HTTP จากผู้ขาย หรือใช้แบบไม่มีรหัส (ผูก IP)');
    return `${scheme}://${user ? encodeURIComponent(user) + ':' + encodeURIComponent(pass) + '@' : ''}${host}:${port}`;
}
function proxyPlain(u) { try { const x = new URL(u); return `${x.protocol}//${x.host}`; } catch (e) { return u; } }
function proxyCreds(g) {
    try { const x = new URL(g.proxy); if (x.username) return { user: decodeURIComponent(x.username), pass: decodeURIComponent(x.password) }; } catch (e) { /* ignore */ }
    return CFG.proxyUser ? { user: CFG.proxyUser, pass: CFG.proxyPass || '' } : null;
}
function relayFor(g) {
    const cr = g.proxy && /^http:\/\//i.test(g.proxy) ? proxyCreds(g) : null;
    const old = RELAYS.get(g.id);
    if (!cr) { if (old) { old.server.close(); RELAYS.delete(g.id); } return null; }
    const up = new URL(g.proxy), key = `${up.hostname}:${up.port}:${cr.user}:${cr.pass}`;
    if (old && old.key === key) return old;
    if (old) { old.server.close(); RELAYS.delete(g.id); }
    const port = 18000 + (g.debugPort % 1000);
    const auth = 'Basic ' + Buffer.from(`${cr.user}:${cr.pass}`).toString('base64');
    const upPort = +up.port || 80, upHost = up.hostname;
    const st = { warned: false };
    const server = http.createServer((req, res) => {      // เว็บ http ธรรมดา (url เต็ม)
        const h = Object.assign({}, req.headers, { 'proxy-authorization': auth });
        const r = http.request({ host: upHost, port: upPort, method: req.method, path: req.url, headers: h }, (ur) => { res.writeHead(ur.statusCode || 502, ur.headers); ur.pipe(res); });
        r.on('error', () => { try { res.writeHead(502); res.end(); } catch (e) { /* ignore */ } });
        req.pipe(r);
    });
    server.on('connect', (req, sock, head) => {      // https / wss → อุโมงค์ผ่านพร็อกซีจริง
        const u = net.connect(upPort, upHost, () => { u.write(`CONNECT ${req.url} HTTP/1.1\r\nHost: ${req.url}\r\nProxy-Authorization: ${auth}\r\n\r\n`); });
        let buf = Buffer.alloc(0);
        const onData = (d) => {
            buf = Buffer.concat([buf, d]); const i = buf.indexOf('\r\n\r\n');
            if (i < 0) { if (buf.length > 16384) { sock.destroy(); u.destroy(); } return; }
            u.removeListener('data', onData);
            const code = +((/^HTTP\/\d(?:\.\d)?\s+(\d+)/.exec(buf.slice(0, i).toString()) || [])[1]);
            if (code !== 200) {
                if (code === 407 && !st.warned) { st.warned = true; say(`❌ ${g.id}: พร็อกซีไม่รับรหัส (407) — ตรวจชื่อผู้ใช้/รหัสผ่านในหน้า ตั้งค่า`); }
                sock.end(`HTTP/1.1 ${code || 502} Proxy Error\r\n\r\n`); u.destroy(); return;
            }
            sock.write('HTTP/1.1 200 Connection Established\r\n\r\n');
            const rest = buf.slice(i + 4); if (rest.length) sock.write(rest);
            if (head && head.length) u.write(head);
            u.pipe(sock); sock.pipe(u);
        };
        u.on('data', onData);
        u.on('error', () => sock.destroy()); sock.on('error', () => u.destroy());
        u.setTimeout(30000, () => { if (buf.length === 0) { sock.destroy(); u.destroy(); } });
    });
    server.on('error', (e) => say(`❌ ${g.id}: เปิดตัวกลางพร็อกซีที่พอร์ต ${port} ไม่ได้ (${e.code || e.message})`));
    server.listen(port, '127.0.0.1');
    const rl = { port, key, server }; RELAYS.set(g.id, rl);
    return rl;
}
function relaysSync() { for (const id of [...RELAYS.keys()]) if (!groupOf(id)) { RELAYS.get(id).server.close(); RELAYS.delete(id); } for (const g of CFG.groups) relayFor(g); }

async function stopGroup(g) {
    const ws = await browserWs(g).catch(() => null);
    if (ws) await cdp(ws, (send) => send('Browser.close')).catch(() => {});
    say(`⏹️ ปิด Chrome ${g.id}`);
    // ปิดแล้วแต่โปรเซสของโปรไฟล์นี้ยังค้าง (แท็บเกมค้าง/ไม่ตอบ) → รอ 10 วิ แล้วบังคับปิดที่เหลือ (ไม่งั้นขึ้น "เปิดนอกโปรแกรม" เปิดใหม่ไม่ได้)
    setTimeout(() => { killProfile(g).then((n) => { if (n) say(`🧹 ${g.id}: Chrome ปิดไม่หมด — บังคับปิดโปรเซสที่ค้าง ${n} ตัว`); scanProcs(); }).catch(() => {}); }, 10000);
}
// 🧹 บังคับปิดเฉพาะโปรเซส Chrome ของโปรไฟล์นี้ (จับจาก --user-data-dir เหมือนตอนวัดแรม) · ไม่แตะโปรไฟล์อื่น/Chrome ส่วนตัว
function killProfile(g) {
    return new Promise((ok) => {
        if (process.platform !== 'win32') return ok(0);
        const want = dirOf(g).toLowerCase().replace(/\\+$/, '');
        const ps = "Get-CimInstance Win32_Process -Filter \"Name='chrome.exe' OR Name='msedge.exe' OR Name='brave.exe'\" | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress";
        execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true, maxBuffer: 32 * 1024 * 1024, timeout: 20000 }, (err, out) => {
            if (err) return ok(0);
            let list = []; try { list = JSON.parse(out || '[]'); if (!Array.isArray(list)) list = [list]; } catch (e) { return ok(0); }
            let n = 0;
            for (const p of list) {
                const m = /--user-data-dir="?([^"]+?)"?(?:\s--|$)/i.exec(p.CommandLine || ''); if (!m || m[1].toLowerCase().replace(/\\+$/, '') !== want) continue;
                try { process.kill(+p.ProcessId); n++; } catch (e) { /* ปิดไปแล้ว */ }
            }
            ok(n);
        });
    });
}
const maxOf = (g) => Math.max(1, +g.maxScreens || +CFG.maxPerIp || 3);      // จอสูงสุดของโปรไฟล์ (ว่าง = ค่ากลางในหน้าตั้งค่า)
async function newGameWindow(g) {
    const info = S.groups[g.id] || {};
    if (!info.debug) throw Error(`${g.id} ยังไม่ได้เปิด`);
    const n = (info.targets || []).filter(isGame).length, max = maxOf(g);
    if (n >= max) throw Error(`${g.id} เปิดเกมครบ ${max} จอแล้ว (1 IP ได้ ${max} จอ)`);
    if (CFG.appMode) {      // โหมดแอป: เปิดหน้าต่างแอปใหม่ในโปรไฟล์เดิม (สั่ง Browser ตัวเดิมด้วย --app — ใช้ส่วนขยาย/ข้อมูลเดิม)
        const exe = findChrome(); if (!exe) throw Error('ไม่พบ Browser — ใส่ที่อยู่ในหน้า ตั้งค่า');
        spawn(exe, [`--user-data-dir=${dirOf(g)}`, `--remote-debugging-port=${g.debugPort}`].concat(keepAwakeFlags(), [`--app=${gameUrlFor(g)}`]), { detached: true, stdio: 'ignore', windowsHide: false }).unref();
    } else {
        const ws = await browserWs(g);
        await cdp(ws, (send) => send('Target.createTarget', { url: gameUrlFor(g), newWindow: true }));
    }
    say(`➕ เปิดจอเกมใหม่ใน ${g.id} (${n + 1}/${max})`);
}
// ดึงหน้าต่างขึ้นมาด้านหน้า: Windows ไม่ยอมให้โปรแกรมดึงหน้าต่างทับแอปอื่นตรง ๆ → ย่อแล้วคืนหน้าต่าง (Windows ยอมให้ขึ้นมาบนสุด) + Page.bringToFront ของแท็บนั้น
// 🪟 Windows ไม่ยอมให้โปรแกรมเบื้องหลังดึงหน้าต่างขึ้นหน้า (หน้าต่างแค่กะพริบในทาสก์บาร์) → ใช้ user32 ของ Windows หาหน้าต่าง Chrome ตามชื่อแท็บ
// แล้ว คืนจากย่อ + กด/ปล่อย Alt (ให้สิทธิ์ดึงหน้า) + SetForegroundWindow — ดึงขึ้นครั้งเดียวตอนสั่ง ไม่ได้ตั้งให้อยู่บนสุดตลอด
const FG_PS = `Add-Type @"
using System; using System.Text; using System.Runtime.InteropServices;
public class AethFg {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] public static extern void keybd_event(byte k, byte s, uint f, UIntPtr e);
  public static int Front(string t) {
    IntPtr hit = IntPtr.Zero;
    EnumWindows((h, l) => { if (!IsWindowVisible(h)) return true; var sb = new StringBuilder(512); GetWindowText(h, sb, 512); if (sb.ToString().StartsWith(t)) { hit = h; return false; } return true; }, IntPtr.Zero);
    if (hit == IntPtr.Zero) return 0;
    if (IsIconic(hit)) ShowWindow(hit, 9);
    keybd_event(0x12, 0, 0, UIntPtr.Zero); SetForegroundWindow(hit); BringWindowToTop(hit); keybd_event(0x12, 0, 2, UIntPtr.Zero);
    return 1;
  }
}
"@
[AethFg]::Front($env:AETH_T)`;
function winFront(title) {
    return new Promise((resolve) => {
        if (process.platform !== 'win32' || !title) { resolve(false); return; }
        execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', FG_PS], { windowsHide: true, timeout: 8000, env: Object.assign({}, process.env, { AETH_T: String(title).slice(0, 200) }) }, (err, out) => resolve(!err && /1/.test(String(out || ''))));
    });
}
async function focusTarget(g, targetId) {
    const ws = await browserWs(g);
    await cdp(ws, async (send) => {
        await send('Target.activateTarget', { targetId }).catch(() => {});
        try {
            const w = await send('Browser.getWindowForTarget', { targetId });
            const st = (w.bounds && w.bounds.windowState) || 'normal';
            if (st !== 'minimized') { await send('Browser.setWindowBounds', { windowId: w.windowId, bounds: { windowState: 'minimized' } }); await sleep(150); }
            await send('Browser.setWindowBounds', { windowId: w.windowId, bounds: { windowState: st === 'maximized' ? 'maximized' : 'normal' } });
        } catch (e) { /* ignore */ }
    });
    const t = ((S.groups[g.id] || {}).targets || []).find((x) => x.id === targetId);
    if (t && t.webSocketDebuggerUrl) await cdp(t.webSocketDebuggerUrl, (send) => send('Page.bringToFront')).catch(() => {});
    if (t && t.title) await winFront(t.title);      // ชื่อหน้าต่าง Chrome = ชื่อแท็บที่เปิดอยู่ (+ " - Google Chrome")
}
async function minimizeTarget(g, targetId) {
    const ws = await browserWs(g);
    await cdp(ws, async (send) => { const w = await send('Browser.getWindowForTarget', { targetId }); await send('Browser.setWindowBounds', { windowId: w.windowId, bounds: { windowState: 'minimized' } }); });
}
async function purgeTarget(g, targetId) {
    const t = (S.groups[g.id].targets || []).find((x) => x.id === targetId); if (!t || !t.webSocketDebuggerUrl) throw Error('ไม่พบแท็บ');
    await cdp(t.webSocketDebuggerUrl, async (send) => { await send('HeapProfiler.collectGarbage').catch(() => {}); await send('Memory.simulatePressureNotification', { level: 'critical' }).catch(() => {}); });
}
async function closeTarget(g, targetId) { await jget(g.debugPort, `/json/close/${targetId}`).catch(() => {}); }
// จัดเรียงหน้าต่างเกมทุก Chrome เป็นตาราง
async function arrangeAll(scr) {      // scr = ขนาดจอจริงจากหน้ารวม (ไม่ส่ง = ใช้ค่าในหน้า ตั้งค่า)
    const sc = CFG.screen || {}; const W = (scr && +scr.w) || +sc.width || 1920, H = (scr && +scr.h) || +sc.height || 1040, X0 = (scr && +scr.x) || 0, Y0 = (scr && +scr.y) || 0;
    const wins = [];
    for (const g of CFG.groups) {
        const info = S.groups[g.id]; if (!info || !info.debug) continue;
        const games = (info.targets || []).filter(isGame); if (!games.length) continue;
        try {
            const ws = await browserWs(g);
            await cdp(ws, async (send) => {
                const seen = new Set();
                for (const t of games) { try { const w = await send('Browser.getWindowForTarget', { targetId: t.id }); if (!seen.has(w.windowId)) { seen.add(w.windowId); wins.push({ g, windowId: w.windowId }); } } catch (e) { /* ignore */ } }
            });
        } catch (e) { /* ignore */ }
    }
    if (!wins.length) throw Error('ไม่มีหน้าต่างเกมให้จัด');
    const cols = Math.max(1, +sc.cols || Math.ceil(Math.sqrt(wins.length))), rows = Math.ceil(wins.length / cols);
    const w = Math.floor(W / cols), h = Math.floor(H / rows);
    const byG = new Map(); wins.forEach((x, i) => { (byG.get(x.g) || byG.set(x.g, []).get(x.g)).push({ windowId: x.windowId, i }); });
    let minW = 0, minH = 0, fails = 0;      // ขนาดที่ได้จริง (Chrome หน้าต่างปกติย่อกว้างได้ไม่ต่ำกว่า ~500px · โหมดแอปย่อได้เล็กกว่า)
    for (const [g, list] of byG) {
        const ws = await browserWs(g);
        await cdp(ws, async (send) => {
            for (const { windowId, i } of list) {      // ย่อแล้วคืน = Windows ยอมให้หน้าต่างขึ้นมาบนสุด (เห็นครบทุกจอ ไม่จมอยู่หลังโปรแกรมอื่น)
                await send('Browser.setWindowBounds', { windowId, bounds: { windowState: 'minimized' } }).catch(() => {}); await sleep(80);
                await send('Browser.setWindowBounds', { windowId, bounds: { windowState: 'normal' } }).catch(() => {});
                await send('Browser.setWindowBounds', { windowId, bounds: { left: X0 + (i % cols) * w, top: Y0 + Math.floor(i / cols) * h, width: w, height: h } }).catch(() => { fails++; });
                try { const r = await send('Browser.getWindowBounds', { windowId }); const bd = r.bounds || {}; if (bd.width > w + 8) minW = Math.max(minW, bd.width); if (bd.height > h + 8) minH = Math.max(minH, bd.height); } catch (e) { /* ignore */ }
            }
        }, 30000);
    }
    for (const g of byG.keys()) for (const t of ((S.groups[g.id] || {}).targets || []).filter(isGame)) if (t.webSocketDebuggerUrl) await cdp(t.webSocketDebuggerUrl, (send) => send('Page.bringToFront')).catch(() => {});
    const small = minW || minH ? `ขอ ${w}×${h} แต่หน้าต่างย่อได้เล็กสุด ${minW || w}×${minH || h}${CFG.appMode ? '' : ' (หน้าต่าง Chrome ปกติกว้างไม่ต่ำกว่า ~500px — เปิด \"โหมดแอป\" ในหน้า ตั้งค่า แล้วปิด/เปิด Chrome ใหม่ จะย่อได้เล็กกว่านี้ หรือลดจำนวนคอลัมน์)'}` : '';
    say(`🪟 จัดหน้าต่างเกม ${wins.length} หน้าต่าง (${cols} คอลัมน์ × ${rows} แถว · ${w}×${h})${small ? ' · ⚠️ ' + small : ''}${fails ? ` · ตั้งขนาดไม่สำเร็จ ${fails} หน้าต่าง` : ''}`);
    return { n: wins.length, cols, rows, w, h, small, fails };
}

// ---------------------------------------------------------------
// ตรวจสถานะเป็นระยะ
// ---------------------------------------------------------------
async function scanGroups() {
    await Promise.all(CFG.groups.map(async (g) => {
        const info = S.groups[g.id] || (S.groups[g.id] = {});
        try { const list = await jget(g.debugPort, '/json/list'); info.fails = 0; info.debug = true; info.targets = list.filter((t) => t.type === 'page'); info.tm = list.some((t) => String(t.url || '').startsWith('chrome-extension://' + TM_ID + '/'));
            // หน้าต้อนรับ/แจ้งอัปเดตที่ Tampermonkey เปิดเอง (tampermonkey.net/index.php?…updated=true, /installed) → ปิดให้ทุกครั้งที่เจอ
            for (const t of list) if (t.type === 'page' && TM_WELCOME.test(t.url || '')) { jget(g.debugPort, `/json/close/${t.id}`).catch(() => {}); say(`🧹 ${g.id}: ปิดหน้าแจ้งติดตั้ง/อัปเดตของ Tampermonkey`); }
        }
        catch (e) { info.fails = (info.fails || 0) + 1; if (info.fails >= 3 || !info.debug) { info.debug = false; info.targets = []; info.tm = null; } }      // พลาดครั้งเดียว (เครื่องหน่วง/หมดเวลา) ยังไม่ถือว่าปิด — กันสถานะกะพริบ
        info.running = info.debug || (info.procs || 0) > 0;
        info.outside = !info.debug && (info.procs || 0) > 0;
    }));
    // จับคู่ตัวละคร ↔ แท็บ: ชื่อแท็บที่สคริปต์ตั้ง ("ชื่อตัวละคร · แมพ · 3D …")
    const now = Date.now();
    for (const p of Object.values(S.peers)) {
        if (now - p.ts > 7 * 86400000) { delete S.peers[p.tab]; delete S.cmds[p.tab]; continue; }      // จำตัวละครที่เคยเล่นไว้ 7 วัน (ดูข้อมูลล่าสุดได้แม้ Chrome ปิด)
        if (now - p.ts > 180000) { delete S.cmds[p.tab]; continue; }      // ออฟไลน์: คงกลุ่มเดิมไว้ ไม่จับคู่แท็บใหม่
        p.group = p.grp && groupOf(p.grp) ? p.grp : ''; p.targetId = '';      // หน้าต่างที่เปิดจากโปรแกรม สคริปต์บอกกลุ่มมาเอง (#aeth=G01)
        for (const g of CFG.groups) {
            if (p.group && p.group !== g.id) continue;
            const t = ((S.groups[g.id] || {}).targets || []).find((x) => isGame(x) && ((p.ttl && x.title === p.ttl) || (x.title || '').split(' · ').some((part) => part.replace(/^\S+\s/, '') === p.name || part === p.name)));
            if (t) { p.group = g.id; p.targetId = t.id; break; }
        }
    }
}
// RAM ของ Chrome แต่ละตัว (รวมทุกโปรเซสที่มี --user-data-dir ของตัวนั้น) · Windows เท่านั้น
function scanProcs() {
    if (process.platform !== 'win32') return;
    const ps = "Get-CimInstance Win32_Process -Filter \"Name='chrome.exe' OR Name='msedge.exe' OR Name='brave.exe'\" | Select-Object WorkingSetSize,CommandLine | ConvertTo-Json -Compress";
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true, maxBuffer: 32 * 1024 * 1024, timeout: 20000 }, (err, out) => {
        if (err) return;
        let list = []; try { list = JSON.parse(out || '[]'); if (!Array.isArray(list)) list = [list]; } catch (e) { return; }
        const agg = {};
        for (const p of list) {
            const m = /--user-data-dir="?([^"]+?)"?(?:\s--|$)/i.exec(p.CommandLine || ''); if (!m) continue;
            const g = CFG.groups.find((x) => dirOf(x).toLowerCase().replace(/\\+$/, '') === m[1].toLowerCase().replace(/\\+$/, '')); if (!g) continue;
            const a = agg[g.id] || (agg[g.id] = { ram: 0, procs: 0 }); a.ram += +p.WorkingSetSize || 0; a.procs++;
        }
        for (const g of CFG.groups) { const info = S.groups[g.id] || (S.groups[g.id] = {}); const a = agg[g.id] || { ram: 0, procs: 0 }; info.ram = a.ram; info.procs = a.procs; }
    });
}
function scanCpu() {
    const t = os.cpus().reduce((a, c) => { const s = Object.values(c.times).reduce((x, y) => x + y, 0); a.total += s; a.idle += c.times.idle; return a; }, { total: 0, idle: 0 });
    if (S.cpu.prev) { const dt = t.total - S.cpu.prev.total, di = t.idle - S.cpu.prev.idle; if (dt > 0) S.cpu.pct = Math.round(100 * (1 - di / dt)); }
    S.cpu.prev = t;
}
setInterval(() => { scanGroups().catch(() => {}); }, 3000);
// เก็บตัวละครที่เคยเล่น (ข้อมูลล่าสุด + กระเป๋าล่าสุด) ลงไฟล์ → ปิด/เปิดโปรแกรมใหม่ก็ยังดูได้
const PEERS_FILE = path.join(ROOT, 'peers.json');
try {
    const saved = JSON.parse(fs.readFileSync(PEERS_FILE, 'utf8'));
    for (const p of saved.peers || []) if (p && p.tab && p.name) { p.targetId = ''; S.peers[p.tab] = p; }
    Object.assign(S.inv, saved.inv || {});
} catch (e) { /* ยังไม่มีไฟล์ */ }
setInterval(() => {
    try {
        const peers = Object.values(S.peers), tabs = new Set(peers.map((p) => p.tab));
        const inv = {}; for (const [t, v] of Object.entries(S.inv)) if (tabs.has(t)) inv[t] = v;
        fs.writeFileSync(PEERS_FILE + '.tmp', JSON.stringify({ peers, inv })); fs.renameSync(PEERS_FILE + '.tmp', PEERS_FILE);
    } catch (e) { /* ignore */ }
}, 30000);
// 🔗 ลิงก์ Google Sheets / Discord Webhook ที่ตั้งใน Manager → ส่งให้สคริปต์ทุกจอ (lk = ค่า hash ที่สคริปต์รายงาน ไว้ดูว่าจอไหนตรงแล้ว)
const djb = (t) => { let h = 5381; for (let i = 0; i < t.length; i++) h = ((h * 33) ^ t.charCodeAt(i)) >>> 0; return h.toString(36); };
const linkHash = (l, nv) => djb(`${(l && l.sheet) || ''}|${(l && l.discord) || ''}|${(l && l.ping) || ''}` + (nv ? `|${(l && l.dstatus) || ''}` : ''));      // nv = สคริปต์ 5.97.2+ (รวม Webhook ห้องสถานะ)
// 🔔 ประเภทการแจ้งเตือน Discord ที่ Manager คุม (ลำดับต้องตรงกับ DC_KEYS ในสคริปต์)
const DC_KEYS = ['death', 'town', 'warpback', 'lag', 'rare', 'captcha', 'jail', 'junk', 'stall', 'server', 'supply', 'bag', 'wish', 'chat', 'digest', 'boss', 'stuck', 'daily', 'premium', 'gamever', 'health'];
const dcHashSrv = (dc) => djb(DC_KEYS.filter((k) => dc.topics && dc.topics[k]).join(',') + '|' + (+dc.supplyMin || 0) + '|' + (+dc.stallMin || 0));
const linkPayload = (L, nv) => Object.assign({ sheet: L.sheet || '', discord: L.discord || '', ping: L.ping || '' }, nv ? { dstatus: L.dstatus || '' } : {}, nv && L.dc ? { dc: L.dc } : {});
const LK_AT = {};
// ⚙️ Config ตัวละคร: สำเนาล่าสุดจากสคริปต์ (คีย์ = โปรไฟล์|ชื่อตัวละคร) + งานที่รอใส่/ล้างตอนตัวนั้นออนไลน์ → cfgs.json
const CFGS_FILE = path.join(ROOT, 'cfgs.json');
const CFGS = { store: {}, pend: {}, res: {} }, CFG_Q = {};
try { const j = JSON.parse(fs.readFileSync(CFGS_FILE, 'utf8')); CFGS.store = j.store || {}; CFGS.pend = j.pend || {}; CFGS.res = j.res || {}; } catch (e) { /* ยังไม่มีไฟล์ */ }
let cfgsDirty = false;
setInterval(() => { if (!cfgsDirty) return; cfgsDirty = false; try { fs.writeFileSync(CFGS_FILE + '.tmp', JSON.stringify(CFGS)); fs.renameSync(CFGS_FILE + '.tmp', CFGS_FILE); } catch (e) { cfgsDirty = true; } }, 3000);
const cfgKey = (group, name) => `${group}|${name}`;
const cfgHas = (d) => !!(d && typeof d.at_opts === 'string' && d.at_opts.replace(/\s/g, '') !== '{}');
function cfgClean(d) {      // รับเฉพาะคีย์ at_* ที่เป็นข้อความ · ต้องมี at_opts ที่อ่านได้
    if (!d || typeof d !== 'object') throw Error('ไฟล์ Config ไม่ถูกต้อง');
    const o = {}; for (const [k, v] of Object.entries(d)) if (/^at_[\w]+$/.test(k) && typeof v === 'string' && v.length < 2e6) o[k] = v;
    if (typeof o.at_opts !== 'string') throw Error('ไฟล์ Config ไม่มีการตั้งค่าหลัก (at_opts)');
    try { JSON.parse(o.at_opts); } catch (e) { throw Error('ไฟล์ Config เสีย (อ่าน at_opts ไม่ได้)'); }
    return o;
}
function cfgBackup(k, why) {      // สำรองสำเนาเดิมก่อนเขียนทับ/ล้าง → backup/cfg/โปรไฟล์_ชื่อ_เวลา.json (เก็บล่าสุด 200 ไฟล์)
    const st = CFGS.store[k]; if (!st || !st.data) return;
    try {
        const dir = path.join(ROOT, 'backup', 'cfg'); fs.mkdirSync(dir, { recursive: true });
        const safe = (x) => String(x).replace(/[^\w\u0E00-\u0E7F-]+/g, '_').slice(0, 40);
        fs.writeFileSync(path.join(dir, `${safe(st.group)}_${safe(st.name)}_${new Date().toISOString().replace(/[:.]/g, '-')}.json`), JSON.stringify({ type: 'aetherack-config', v: 1, name: st.name, group: st.group, at: st.at, why, data: st.data }, null, 1));
        const fl = fs.readdirSync(dir).filter((f) => f.endsWith('.json')).sort(); for (const f of fl.slice(0, Math.max(0, fl.length - 200))) fs.unlinkSync(path.join(dir, f));
    } catch (e) { say('⚠️ สำรอง Config ไม่สำเร็จ: ' + e.message); }
}
function cfgTick(tab) {      // เรียกทุกครั้งที่สคริปต์ส่งสถานะ: มีงานรอ → ส่งคำสั่ง · Config เปลี่ยน → ขอสำเนาใหม่
    const pe = S.peers[tab]; if (!pe || !pe.group || !pe.name || verNum(pe.v || '0') < verNum('5.97.0') || Date.now() - (CFG_Q[tab] || 0) < 25000) return;
    const k = cfgKey(pe.group, pe.name), pd = CFGS.pend[k], st = CFGS.store[k];
    if (pd) { CFG_Q[tab] = Date.now(); queue(tab, pd.mode === 'clear' ? 'cfgclear' : 'cfgset', { name: pe.name, data: pd.data || null, from: pd.from || '', rq: pd.id }); }
    else if (pe.ch && (!st || st.h !== pe.ch)) { CFG_Q[tab] = Date.now(); queue(tab, 'cfgget', {}); }
}
function cfgList() {
    const m = new Map();
    for (const p of Object.values(S.peers)) if (p.group && p.name) m.set(cfgKey(p.group, p.name), { group: p.group, name: p.name, online: Date.now() - p.ts < 180000, cls: p.cls || '' });
    for (const k of new Set([...Object.keys(CFGS.store), ...Object.keys(CFGS.pend)])) if (!m.has(k)) { const i = k.indexOf('|'); m.set(k, { group: k.slice(0, i), name: k.slice(i + 1), online: false, cls: '' }); }
    return [...m.entries()].map(([key, x]) => { const st = CFGS.store[key], pd = CFGS.pend[key]; return Object.assign({ key }, x, { at: st ? st.at : 0, has: !!(st && cfgHas(st.data)), n: st ? Object.keys(st.data || {}).length : 0, pend: pd ? { mode: pd.mode, from: pd.from || '', at: pd.at } : null, res: CFGS.res[key] || null }); })
        .sort((a, b) => a.group.localeCompare(b.group) || a.name.localeCompare(b.name));
}

// 🪙 ราคา Token (ข้อ 8): ให้สคริปต์ 1 ตัวที่ออนไลน์+ว่าง อ่านหน้า "ตลาด Token" ของเกมทุก 10 นาที → token.json (ไม่สร้าง/เดาราคาเอง)
// 🔔 บันทึกเหตุการณ์ (ตาย / Captcha / กลับแมพเดิมสำเร็จ ฯลฯ) ที่สคริปต์ส่งมาทุกครั้งที่มีการแจ้งเตือน → events.json (เก็บ 1,000 รายการล่าสุด)
const EV_FILE = path.join(ROOT, 'events.json');
let EV = []; try { const j = JSON.parse(fs.readFileSync(EV_FILE, 'utf8')); if (Array.isArray(j)) EV = j.slice(-1000); } catch (e) { /* ยังไม่มีไฟล์ */ }
let evDirty = false;
const evFlush = () => { if (!evDirty) return; evDirty = false; try { fs.writeFileSync(EV_FILE + '.tmp', JSON.stringify(EV)); fs.renameSync(EV_FILE + '.tmp', EV_FILE); } catch (e) { /* ignore */ } };
setInterval(evFlush, 10000);
// 📢 ประกาศจากทีมงาน (กล่อง .gm-notice กลางบนจอเกม): ทุกจอเห็นพร้อมกัน → Manager รับไว้ที่เดียว แจ้งครั้งเดียว (ข้อความเดิมภายใน 10 นาที = ข้าม)
// บันทึกเหตุการณ์ + Discord (ช่องแจ้งเตือน) + มือถือ · ใช้หลายเครื่อง: เครื่องลูกส่งต่อให้เครื่องหลักแจ้งที่เดียว
const GMN = new Map();
async function gmNotice(b) {
    const text = maskSecrets(String(b.text || '').replace(/\s+/g, ' ').trim().slice(0, 500)); if (!text) return { sent: false };
    const l = lkCfg();
    if (l.role === 'sub' && !b.fwd) { try { const j = await lkCall('/link/fwd', { method: 'POST', p: '/api/gmnotice', b: { text, name: b.name, fwd: 1 } }, 15000); if (j && j.r && j.r.code === 200) return Object.assign({ via: 'main' }, j.r.body); } catch (e) { /* เครื่องหลักไม่ตอบ → แจ้งเอง */ } }
    const k = sha(text), now = Date.now();
    for (const [x, at] of GMN) if (now - at > 600000) GMN.delete(x);
    if (GMN.has(k)) return { sent: false, dup: true };
    GMN.set(k, now);
    const pe = S.peers[b.tab] || {};
    evAdd({ tab: b.tab, name: pe.name || b.name, topic: 'gm', title: '📢 ประกาศจากทีมงาน', desc: text });
    say(`📢 ประกาศจากทีมงาน: ${text}`);
    if (RM.push.gm) pushAll({ title: '📢 ประกาศจากทีมงาน', body: text.slice(0, 180), tag: 'gm' + k.slice(0, 8), kind: 'gm', url: RM.url || '/' }).catch(() => {});
    const L = CFG.links || {}, wh = L.discord;
    if (wh && !(L.dc && L.dc.gm === false)) httpsPost(wh, JSON.stringify({ username: 'Aetheria Tracker', allowed_mentions: { parse: [] }, embeds: [{ title: '📢 ประกาศจากทีมงาน', description: text, color: 0xef4444, timestamp: new Date().toISOString(), footer: { text: 'แจ้งครั้งเดียวจาก Aetherack Manager · v' + VERSION } }] }), { 'Content-Type': 'application/json' }).catch(() => {});
    return { sent: true };
}
function evAdd(b) {
    const pe = S.peers[b.tab] || {}, s = (v, n) => maskSecrets(String(v || '').slice(0, n));
    const e = { at: Date.now(), tab: String(b.tab || '').slice(0, 40), name: s(pe.name || b.name, 40), group: pe.group || '', topic: String(b.topic || '').replace(/\W/g, '').slice(0, 16), title: s(b.title, 120), desc: s(b.desc, 400),
        fields: Array.isArray(b.fields) ? b.fields.slice(0, 6).map((f) => ({ n: s(f && f.n, 40), v: s(f && f.v, 160) })) : [] };
    if (!e.title) return false;
    if (EV.slice(-30).some((x) => x.tab === e.tab && x.title === e.title && e.at - x.at < 15000)) return false;      // ซ้ำใน 15 วิ
    EV.push(e); if (EV.length > 1000) EV.splice(0, EV.length - 1000); evDirty = true; return true;
}
const TOKEN_FILE = path.join(ROOT, 'token.json');
const TOK = { last: null, hist: [], next: 0, asked: null };
try { const j = JSON.parse(fs.readFileSync(TOKEN_FILE, 'utf8')); TOK.last = j.last || null; TOK.hist = Array.isArray(j.hist) ? j.hist : []; } catch (e) { /* ยังไม่มีไฟล์ */ }
function tokSave() { try { fs.writeFileSync(TOKEN_FILE + '.tmp', JSON.stringify({ last: TOK.last, hist: TOK.hist })); fs.renameSync(TOKEN_FILE + '.tmp', TOKEN_FILE); } catch (e) { /* ignore */ } }
function tokAsk(force) {
    if (CFG.tokenOn === false && !force) return null;
    const live = Object.values(S.peers).filter((p) => Date.now() - p.ts < 45000 && verNum(p.v || '0') >= verNum('5.97.5') && !p.busy && !(p.kd && /captcha|dead/.test(p.kd.k || '')));
    if (!live.length) return null;
    const pe = live.find((p) => TOK.last && p.tab === TOK.last.tab) || live.sort((a, b) => a.name.localeCompare(b.name))[0];
    queue(pe.tab, 'tokscan', {}); TOK.asked = { tab: pe.tab, name: pe.name, at: Date.now() }; return pe;
}
setInterval(() => { if (Date.now() < TOK.next) return; TOK.next = Date.now() + 600000; if (!tokAsk(false)) TOK.next = Date.now() + 60000; }, 15000);

// 🎮 Discord Rich Presence (ข้อ 26) — ปิดเป็นค่าเริ่มต้น · แสดงได้ทีละ 1 ตัวละคร (เลือกเอง) · แสดงเฉพาะ เงินในกระเป๋า / เงินต่อชั่วโมง / เวลาเล่น
//   ไม่ส่งชื่อตัวละคร เลเวล อาชีพ CH แมพ ตำแหน่ง · ข้อมูลไหนไม่มี = ไม่แสดง (ไม่เดา) · ต่อกับ Discord ในเครื่องผ่าน IPC (ต้องเปิดแอป Discord ไว้ + ใส่ Application ID เอง)
const RPC_APP_ID = '1563137899250188319';      // Application ID หลักของ Aetherack (ผู้ใช้ไม่ต้องหาเอง · ใส่ของตัวเองแทนได้ในหน้า ตั้งค่า)
const rpcAppId = () => { const v = String((CFG.rpc || {}).clientId || '').trim(); return /^\d{15,25}$/.test(v) ? v : RPC_APP_ID; };
const RPC_INVITE = '🎮 มาเล่น Aetheria ด้วยกัน!';      // ข้อความประจำ แสดงตลอด (สั้นพอไม่ให้ Discord ตัด)
const RPC_BUTTONS = [{ label: 'เล่น Aetheria Online', url: 'https://aetheria-online.in.th/play' }];      // ข้อความใน Rich Presence กดไม่ได้ → ลิงก์ต้องเป็นปุ่ม (คนอื่นเห็น/กดได้ · Discord ไม่โชว์ปุ่มให้เจ้าของเห็นเอง)
const RPC = { sock: null, ready: false, connecting: false, last: '', sig: '', start: {}, err: '', at: 0, mq: 0 };
// ✍️ ข้อความของผู้ใช้ (บรรทัดล่าง) · ยาวเกินกล่อง + เปิดเลื่อน = ตัดเป็นช่วงแล้วขยับทีละ 3 ตัวอักษรทุก 5 วิ วนไปเรื่อย ๆ
//    Discord ไม่มีตัวหนังสือวิ่งจริง → อัปเดตสถานะเป็นช่วง ๆ (Discord จำกัด 5 ครั้ง/20 วิ) · ตัดตามตัวอักษรที่เห็น (สระ/วรรณยุกต์ไทยไม่หลุด)
const RPC_MQ_W = 28, RPC_MQ_STEP = 3, RPC_MQ_MS = 5000;
const graphemes = (t) => { try { return [...new Intl.Segmenter('th', { granularity: 'grapheme' }).segment(t)].map((x) => x.segment); } catch (e) { return [...t]; } };
function rpcMsg(R) {
    const t = String(R.msg || '').replace(/\s+/g, ' ').trim(); if (!t) return '';
    const g = graphemes(t); if (!R.scroll || g.length <= RPC_MQ_W) return g.slice(0, 120).join('');
    const loop = g.concat(graphemes('   ✦   ')), n = loop.length, o = (RPC.mq * RPC_MQ_STEP) % n;
    let out = ''; for (let i = 0; i < RPC_MQ_W; i++) out += loop[(o + i) % n];
    return out;
}
function rpcPaths() { const out = []; for (let i = 0; i < 10; i++) out.push(process.platform === 'win32' ? `\\\\?\\pipe\\discord-ipc-${i}` : path.join(process.env.XDG_RUNTIME_DIR || process.env.TMPDIR || '/tmp', `discord-ipc-${i}`)); return out; }
function rpcSend(op, obj) { if (!RPC.sock) return; const j = Buffer.from(JSON.stringify(obj)), h = Buffer.alloc(8); h.writeInt32LE(op, 0); h.writeInt32LE(j.length, 4); try { RPC.sock.write(Buffer.concat([h, j])); } catch (e) { /* ignore */ } }
function rpcClose(why) { if (RPC.sock) { try { RPC.sock.destroy(); } catch (e) { /* ignore */ } } RPC.sock = null; RPC.ready = false; RPC.connecting = false; RPC.sig = ''; if (why) RPC.err = why; }
function rpcConnect() {
    const id = rpcAppId(); if (RPC.connecting || RPC.sock) return;
    RPC.connecting = true; const paths = rpcPaths(); let i = 0;
    const tryNext = () => {
        if (i >= paths.length) { RPC.connecting = false; RPC.err = 'ไม่พบแอป Discord ในเครื่อง (เปิด Discord แบบโปรแกรมไว้ก่อน)'; return; }
        const s = net.createConnection(paths[i++]); let buf = Buffer.alloc(0);
        s.once('error', () => { try { s.destroy(); } catch (e) { /* ignore */ } if (RPC.sock === s) rpcClose('การเชื่อมต่อ Discord หลุด'); else tryNext(); });
        s.once('connect', () => { RPC.sock = s; RPC.connecting = false; rpcSend(0, { v: 1, client_id: id }); });
        s.on('data', (d) => {
            buf = Buffer.concat([buf, d]);
            while (buf.length >= 8) { const op = buf.readInt32LE(0), len = buf.readInt32LE(4); if (buf.length < 8 + len) break; let m = null; try { m = JSON.parse(buf.slice(8, 8 + len).toString('utf8')); } catch (e) { /* ignore */ } buf = buf.slice(8 + len);
                if (op === 2) { rpcClose('Discord ปฏิเสธ: ' + ((m && m.message) || 'Application ID ไม่ถูกต้อง')); return; }
                if (m && m.evt === 'READY') { RPC.ready = true; RPC.err = ''; }
                if (m && m.evt === 'ERROR') RPC.err = 'Discord: ' + ((m.data && m.data.message) || 'ผิดพลาด'); }
        });
        s.on('close', () => { if (RPC.sock === s) rpcClose(''); });
    };
    tryNext();
}
function rpcTick() {
    const R = CFG.rpc || {};
    if (!R.on || !R.who) { if (RPC.sock) { if (RPC.ready) rpcSend(1, { cmd: 'SET_ACTIVITY', args: { pid: process.pid, activity: null }, nonce: crypto.randomUUID() }); setTimeout(() => rpcClose(''), 500); } return; }
    if (!RPC.sock) { rpcConnect(); return; }
    if (!RPC.ready) return;
    const pe = Object.values(S.peers).find((p) => p.name === R.who && Date.now() - p.ts < 180000);
    if (!pe) { RPC.start[R.who] = 0; if (RPC.sig !== 'off') { RPC.sig = 'off'; rpcSend(1, { cmd: 'SET_ACTIVITY', args: { pid: process.pid, activity: null }, nonce: crypto.randomUUID() }); } return; }
    if (!RPC.start[R.who]) RPC.start[R.who] = Date.now();
    // บรรทัดบน = ข้อมูลที่ผู้ใช้เลือกแสดง (แต่ละอย่างเปิด/ปิดได้) · บรรทัดล่างสุด = ข้อความชวนเล่น (แสดงตลอด) · เวลาเล่นเป็นข้อความ (อัปเดตทุกนาที) เพื่อให้ข้อความชวนเล่นอยู่ล่างสุด
    const show = Object.assign({ zeny: true, zph: true, time: true }, R.show || {}), parts = [];
    const zn = String(pe.zn || '').trim(), zh = +pe.zh || 0, mins = Math.floor((Date.now() - RPC.start[R.who]) / 60000);
    // ตัวเลขแบบสั้น (526.6M) — กล่องสถานะในหน้าเพื่อน/รายชื่อสมาชิกแคบ ถ้ายาวจะโดนตัด
    const short = (n) => { n = +n || 0; const a = Math.abs(n); return a >= 1e9 ? (n / 1e9).toFixed(a >= 1e10 ? 1 : 2) + 'B' : a >= 1e6 ? (n / 1e6).toFixed(a >= 1e8 ? 1 : 2) + 'M' : a >= 1e3 ? (n / 1e3).toFixed(1) + 'K' : String(Math.round(n)); };
    const znum = +zn.replace(/[^\d]/g, '');
    if (show.zeny && /\d/.test(zn)) parts.push(`💰 ${short(znum)}`);      // เงินในกระเป๋า (ค่าจากเกม)
    if (show.zph && zh > 0) parts.push(`📈 ${short(zh)}/ชม.`);
    if (show.time) parts.push(`⏱️ ${mins >= 60 ? Math.floor(mins / 60) + 'ชม.' : ''}${mins % 60}น.`);
    const mine = rpcMsg(R); let st = mine || RPC_INVITE; if (st.length < 2) st += ' ·';
    const act = { state: st, buttons: RPC_BUTTONS, instance: false };
    if (parts.length) act.details = parts.join(' · ').slice(0, 128);
    const sig = JSON.stringify([act.details, act.state]); if (sig === RPC.sig) return;
    RPC.sig = sig; RPC.last = `${act.details || '(ไม่แสดงข้อมูล)'} ↵ ${act.state}`; RPC.at = Date.now();
    rpcSend(1, { cmd: 'SET_ACTIVITY', args: { pid: process.pid, activity: act }, nonce: crypto.randomUUID() });
}
setInterval(() => { try { rpcTick(); } catch (e) { /* ignore */ } }, 15000);
setInterval(() => {      // ขยับข้อความที่เลื่อน
    const R = CFG.rpc || {}; if (!R.on || !R.scroll || !R.msg || !RPC.ready || graphemes(String(R.msg).replace(/\s+/g, ' ').trim()).length <= RPC_MQ_W) return;
    RPC.mq++; try { rpcTick(); } catch (e) { /* ignore */ }
}, RPC_MQ_MS);

// 🎓 ข้อมูลอาชีพ/สกิลทั้งเกม (สคริปต์อ่านจากเซิร์ฟเวอร์เกมส่งมา) → classdata.json
const CD_FILE = path.join(ROOT, 'classdata.json');
S.cd = null; try { S.cd = JSON.parse(fs.readFileSync(CD_FILE, 'utf8')); } catch (e) { /* ยังไม่มี */ }
// 🏪 ตลาดกลาง (อ่านอย่างเดียว): ราคาล่าสุด + ประวัติราคาต่อไอเทม + รายการจับตา (แจ้งเตือนเมื่อราคาต่ำกว่าที่ตั้ง) · เก็บลง market.json
const MK_FILE = path.join(ROOT, 'market.json');
S.mk = { items: {}, watch: [], alerts: [], last: {}, every: 15, nextAt: 0 };
try { Object.assign(S.mk, JSON.parse(fs.readFileSync(MK_FILE, 'utf8')) || {}, { last: {} }); } catch (e) { /* ยังไม่มีไฟล์ */ }
let mkDirty = false;
setInterval(() => { if (!mkDirty) return; mkDirty = false; try { const { last, ...keep } = S.mk; fs.writeFileSync(MK_FILE + '.tmp', JSON.stringify(keep)); fs.renameSync(MK_FILE + '.tmp', MK_FILE); } catch (e) { /* ignore */ } }, 30000);
const mkKey = (n) => String(n || '').trim().toLowerCase();
function mkIngest(b) {
    const now = Date.now(), by = {};
    for (const r of (Array.isArray(b.rows) ? b.rows : []).slice(0, 200)) { if (!r || !r.n) continue; (by[mkKey(r.n)] || (by[mkKey(r.n)] = [])).push(r); }
    for (const [k, rows] of Object.entries(by)) {
        const it = S.mk.items[k] || (S.mk.items[k] = { n: rows[0].n, ic: '', hist: [], last: [], at: 0 });
        const buy = rows.filter((r) => !r.auc && r.unit > 0), auc = rows.filter((r) => r.auc && r.unit > 0);
        const minB = buy.length ? Math.min(...buy.map((r) => r.unit)) : 0, minA = auc.length ? Math.min(...auc.map((r) => r.unit)) : 0;
        it.ic = rows.find((r) => r.ic) ? rows.find((r) => r.ic).ic : it.ic; it.at = now; it.n = rows[0].n;
        it.last = rows.slice().sort((a, c) => a.unit - c.unit).slice(0, 40);
        const h = it.hist[it.hist.length - 1];
        if (!h || now - h[0] > 300000 || h[1] !== minB) { it.hist.push([now, minB, minA, rows.length, rows.reduce((a, r) => a + (+r.q || 0), 0)]); if (it.hist.length > 600) it.hist.splice(0, it.hist.length - 600); }
        for (const w of S.mk.watch) {      // 🔔 จับตา: ราคาต่อชิ้น (ซื้อทันที) ≤ ที่ตั้ง
            if (!w.on || mkKey(w.n) !== k || !minB || minB > +w.max) continue;
            const best = buy.find((r) => r.unit === minB);
            if (w.lastAlert && now - w.lastAlert < 1800000 && w.lastPrice === minB) continue;
            w.lastAlert = now; w.lastPrice = minB;
            S.mk.alerts.push({ at: now, n: it.n, unit: minB, q: best.q, seller: best.seller, max: +w.max, ic: it.ic });
            if (S.mk.alerts.length > 100) S.mk.alerts.splice(0, S.mk.alerts.length - 100);
            say(`🔔 ตลาด: ${it.n} ราคา ${minB.toLocaleString()} z/ชิ้น (≤ ${(+w.max).toLocaleString()}) · ${best.q} ชิ้น · ${best.seller}`);
        }
    }
    mkDirty = true;
}
function mkPickPeer(prefer) {      // ตัวที่ใช้ค้นตลาด: ที่เลือก > ตัวออนไลน์ที่ว่างและสคริปต์รองรับ
    const now = Date.now(), ok = (p) => p && now - p.ts < 30000 && verNum(p.v || '0') >= verNum('5.72.0');
    if (prefer && ok(S.peers[prefer])) return S.peers[prefer];
    const list = Object.values(S.peers).filter(ok).sort((a, c) => (a.busy ? 1 : 0) - (c.busy ? 1 : 0) || (S.mk.lastUse && S.mk.lastUse[a.tab] || 0) - (S.mk.lastUse && S.mk.lastUse[c.tab] || 0));
    return list[0] || null;
}
setInterval(() => {      // ⏱️ ค้นรายการจับตาตามรอบ (ทีละไอเทม ห่างกัน 45 วิ)
    try {
        const on = S.mk.watch.filter((w) => w.on); if (!on.length || Date.now() < (S.mk.nextAt || 0)) return;
        S.mk.nextAt = Date.now() + Math.max(5, +S.mk.every || 15) * 60000;
        on.forEach((w, i) => setTimeout(() => { const pe = mkPickPeer(); if (!pe) return; S.mk.lastUse = S.mk.lastUse || {}; S.mk.lastUse[pe.tab] = Date.now(); queue(pe.tab, 'mkscan', { q: w.n, pages: 1 }); }, i * 45000));
    } catch (e) { /* ignore */ }
}, 30000);
// 📊 Profit + สถิติของแต่ละตัวละคร (สคริปต์ส่งมาทุก 2 นาที) → หน้า สถิติ รวมรายตัว / รายโปรไฟล์ / ทั้งหมด · เก็บลงไฟล์
const STATS_FILE = path.join(ROOT, 'stats.json');
S.zone = {}; S.skill = {}; S.askill = {}; S.acfg = {}; S.junk = {}; S.stats = {};
const SKILL_FILE = path.join(ROOT, 'skills.json'); let skillDirty = false;
try { const j = JSON.parse(fs.readFileSync(SKILL_FILE, 'utf8')); Object.assign(S.skill, j.skill || {}); Object.assign(S.askill, j.askill || {}); } catch (e) { /* ยังไม่มีไฟล์ */ }
setInterval(() => { if (!skillDirty) return; skillDirty = false; try { fs.writeFileSync(SKILL_FILE + '.tmp', JSON.stringify({ skill: S.skill, askill: S.askill })); fs.renameSync(SKILL_FILE + '.tmp', SKILL_FILE); } catch (e) { /* ignore */ } }, 60000); try { S.stats = JSON.parse(fs.readFileSync(STATS_FILE, 'utf8')) || {}; } catch (e) { /* ยังไม่มีไฟล์ */ }
let statsDirty = false;
setInterval(() => {
    if (!statsDirty) return; statsDirty = false;
    try { fs.writeFileSync(STATS_FILE + '.tmp', JSON.stringify(S.stats)); fs.renameSync(STATS_FILE + '.tmp', STATS_FILE); } catch (e) { /* ignore */ }
}, 60000);
setInterval(scanProcs, 60000);      // วัดแรมด้วย PowerShell กินเครื่อง → นาทีละครั้งพอ (กราฟ/กันแรมเกินก็เก็บนาทีละจุด)
// 📈 ประวัติแรมของแต่ละ Chrome (ทุก 1 นาที · เก็บ 6 ชม.) + 🧹 คืน RAM อัตโนมัติ + 🧠 แรมเกิน → รีโหลดตอนว่าง
S.ramHist = {}; S.purgeAt = {}; S.guardAt = {};
setInterval(async () => {
    const now = Date.now();
    for (const g of CFG.groups) {
        const i = S.groups[g.id] || {}; const h = S.ramHist[g.id] || (S.ramHist[g.id] = []);
        if (i.running && i.ram) { h.push([now, Math.round(i.ram / 1048576)]); if (h.length > 360) h.splice(0, h.length - 360); }
        if (!i.debug) continue;
        const games = (i.targets || []).filter(isGame);
        if (CFG.autoPurge !== false && games.length && now - (S.purgeAt[g.id] || 0) > Math.max(5, +CFG.purgeMin || 20) * 60000) {
            S.purgeAt[g.id] = now; let n = 0;
            for (const t of games) {
                const pe = Object.values(S.peers).find((x) => x.targetId === t.id);
                if (pe && pe.busy) continue;      // กำลังวาร์ป/ซื้อของ/ทิ้งขยะ → ข้ามรอบนี้
                try { await purgeTarget(g, t.id); n++; } catch (e) { /* ignore */ }
                await sleep(1500);
            }
            if (n) say(`🧹 ${g.id}: คืน RAM อัตโนมัติ ${n} จอ`);
        }
        const lim = Math.max(0.5, +CFG.ramLimitGB || 2.5) * 1073741824;
        if (CFG.ramGuard !== false && games.length && i.ram > lim * games.length && now - (S.guardAt[g.id] || 0) > Math.max(10, +CFG.ramCooldownMin || 60) * 60000) {
            S.guardAt[g.id] = now;
            const ps = Object.values(S.peers).filter((x) => x.group === g.id && now - x.ts < 60000);
            ps.forEach((x, k) => setTimeout(() => queue(x.tab, 'reloadsafe', { why: `แรม ${g.id} สูง (${(i.ram / 1073741824).toFixed(1)} GB / ${games.length} จอ)` }), k * 20000));
            say(`🧠 ${g.id}: แรม ${(i.ram / 1073741824).toFixed(1)} GB เกิน ${CFG.ramLimitGB} GB/จอ — สั่งรีโหลด ${ps.length} จอตอนว่าง`);
        }
    }
}, 60000);
setInterval(scanCpu, 3000);
scanProcs(); scanCpu(); scanGroups().catch(() => {});

// ⏰ รีโหลดตามรอบ: เกมเก็บรูปแมพทุกแมพที่เคยเข้าไว้ไม่ลบ (แรมโตเรื่อยๆ จน Out of Memory) → ครบ X ชม. รีโหลดจอนั้นตอนว่าง
//    ทยอยทีละจอ ห่างกันอย่างน้อย 3 นาที (ทั้งเครื่อง) · ใช้คำสั่ง reloadsafe ของสคริปต์ (รอไม่ติดวาร์ป/ซื้อของ/เช็คผู้เล่น)
const PRL = { born: {}, seen: {}, lastAt: 0 };
setInterval(() => {
    try {
        const h = +CFG.reloadEveryH || 0, now = Date.now();
        for (const p of Object.values(S.peers)) {
            if (now - p.ts > 60000) { if (now - (PRL.seen[p.tab] || 0) > 5 * 60000) { delete PRL.born[p.tab]; delete PRL.seen[p.tab]; } continue; }
            PRL.seen[p.tab] = now; if (!PRL.born[p.tab]) PRL.born[p.tab] = now;
        }
        if (h <= 0 || now - PRL.lastAt < 3 * 60000) return;
        const due = Object.values(S.peers).filter((p) => now - p.ts < 60000 && now - PRL.born[p.tab] >= h * 3600000 && !p.busy && !(p.kd && /captcha|conn/.test(p.kd.k)))
            .sort((a, b) => PRL.born[a.tab] - PRL.born[b.tab]);
        const p = due[0]; if (!p) return;
        const hrs = ((now - PRL.born[p.tab]) / 3600000).toFixed(1);
        PRL.lastAt = now; PRL.born[p.tab] = now;
        queue(p.tab, 'reloadsafe', { why: `รีโหลดตามรอบ (เปิดมา ${hrs} ชม.)` });
        say(`⏰ ${p.name || p.tab}: รีโหลดตามรอบ (เปิดมา ${hrs} ชม. · ตั้งไว้ทุก ${h} ชม.) — ล้างรูปแมพเก่าที่สะสม`);
    } catch (e) { /* ignore */ }
}, 30000);

// ---------------------------------------------------------------
// คำสั่งให้ตัวละคร (สคริปต์มารับทุก ~3 วิ)
// ---------------------------------------------------------------
const SCRIPT_CMDS = new Set(['hudhide', 'hudshow', 'idlemin', 'idlemax', 'r3cap', 'convbuy', 'tokscan', 'partyset', 'partysummon', 'hotset', 'logs', 'cfgget', 'cfgset', 'cfgclear', 'r3off', 'r3on', 'pause', 'resume', 'farm', 'reload', 'send', 'ch', 'inv', 'maps', 'reloadsafe', 'lowgfx', 'lowgfxoff', 'equip', 'statset', 'statrun', 'zone', 'zoneset', 'drop', 'skills', 'skillset', 'skillrun', 'askills', 'askillset', 'wbset', 'junkget', 'junkset', 'mkscan', 'mkbuy', 'mkclaim', 'sell', 'sellset', 'jobgo', 'jobset', 'linkset', 'autocfg', 'autocfgset']);
// 🔄 โปรแกรมรีเฟรชหน้าเกมที่ยังใช้สคริปต์รุ่นเก่าให้เอง (เปิด "อัปเดตสคริปต์ทุกจอเอง" อยู่) — ไม่รอสคริปต์ในเกม
//    เห็นว่าเก่ามาแล้ว 60 วิ + ตัวละครไม่ได้ทำงานค้าง (วาร์ป/ซื้อ/ทิ้งของ) + ไม่ติด Captcha/ตาย → ทยอยรีโหลดทีละจอ (ห่าง 15 วิ) · จอเดิมไม่ซ้ำภายใน 5 นาที
const AUR = { old: {}, last: {}, tries: {}, any: 0 };
setInterval(() => {
    try {
        if (CFG.autoUpdate === false) { for (const p of Object.values(S.peers)) p.aurWhy = 'ปิด "อัปเดตสคริปต์ทุกจอเอง" อยู่ (ตั้งค่า → อัตโนมัติ)'; return; }
        const si = scriptInfo(); if (!si) return; const now = Date.now();
        for (const p of Object.values(S.peers)) {
            const old = now - p.ts < 30000 && p.v && verNum(p.v) < verNum(si.version);
            if (!old) { delete AUR.old[p.tab]; delete AUR.tries[p.tab]; delete p.aurWhy; continue; }
            if (!AUR.old[p.tab]) AUR.old[p.tab] = now;
            const k = p.kd && p.kd.k, tries = AUR.tries[p.tab] || 0, oldFor = now - AUR.old[p.tab];
            const why = oldFor < 60000 ? 'รอครบ 1 นาที' : k === 'captcha' ? 'รอตอบ Captcha' : k === 'dead' ? 'ตัวละครตายอยู่' : p.busy && oldFor < 600000 ? `รอ ${p.busy} เสร็จ (สูงสุด 10 นาที)` : now - (AUR.last[p.tab] || 0) < 300000 ? (tries ? `รีโหลดแล้ว ${tries} ครั้งแต่ยังได้ v${p.v} — ตัวโหลดใน Tampermonkey อาจโหลดสคริปต์ใหม่ไม่ทัน แล้วใช้ชุดที่จำไว้ · ลองใหม่ใน ${Math.ceil((300000 - (now - AUR.last[p.tab])) / 60000)} นาที` : 'เพิ่งสั่งรีโหลด') : now - AUR.any < 15000 ? 'รอคิวจอก่อนหน้า' : '';
            p.aurWhy = why || 'กำลังสั่งรีโหลด';
            if (why) continue;
            AUR.last[p.tab] = now; AUR.any = now; AUR.tries[p.tab] = tries + 1; queue(p.tab, 'reload');
            say(`🔄 รีเฟรช ${p.name} เพื่ออัปเดตสคริปต์ v${p.v} → v${si.version}${tries ? ` (ครั้งที่ ${tries + 1})` : ''}`);
        }
    } catch (e) { /* ignore */ }
}, 5000);
function queue(tab, cmd, extra) { (S.cmds[tab] || (S.cmds[tab] = [])).push(Object.assign({ id: ++S.seq, cmd, at: Date.now() }, extra || {})); }
async function peerCmd(p, cmd, extra) {
    if (SCRIPT_CMDS.has(cmd)) { queue(p.tab, cmd, extra); return; }
    const g = groupOf(p.group); if (!g || !p.targetId) throw Error(`ยังไม่รู้ว่า ${p.name} อยู่หน้าต่างไหน (เปิดชื่อแท็บในสคริปต์ไว้ และ Chrome ต้องเปิดจากโปรแกรมนี้)`);
    if (cmd === 'focus') return focusTarget(g, p.targetId);
    if (cmd === 'min') return minimizeTarget(g, p.targetId);
    if (cmd === 'purge') return purgeTarget(g, p.targetId);
    if (cmd === 'close') return closeTarget(g, p.targetId);
    throw Error('ไม่รู้จักคำสั่ง ' + cmd);
}

// ---------------------------------------------------------------
// 🧩 ติดตั้ง/อัปเดตสคริปต์จากโฟลเดอร์โปรแกรม (ผู้ใช้กดยืนยันเองในหน้าของ Tampermonkey)
// ---------------------------------------------------------------
const TM_ID = 'dhdgffkkebhmkfjojejmpbldmpobfkfo';
const TM_STORE = 'https://chromewebstore.google.com/detail/tampermonkey/' + TM_ID;
const verNum = (v) => String(v || '0').split('.').map((x) => parseInt(x, 10) || 0).reduce((a, x) => a * 1000 + x, 0);
// สคริปต์ล่าสุดในโฟลเดอร์โปรแกรม (ไฟล์ *.user.js ที่ @version สูงสุด) — วางไฟล์ใหม่เพิ่ม/ทับได้เลย
let CORE_GZ = null; const SI_CACHE = {};
function scriptInfo() {      // อ่านไฟล์เฉพาะตอนเปลี่ยน (เทียบเวลาแก้ไข) — ถูกเรียกถี่ทุกจอ
    let best = null;
    for (const f of fs.readdirSync(ROOT)) {
        if (!/\.user\.js$/i.test(f)) continue;
        let src = ''; try { const st = fs.statSync(path.join(ROOT, f)), c = SI_CACHE[f]; if (c && c.m === st.mtimeMs && c.z === st.size) src = c.src; else { src = fs.readFileSync(path.join(ROOT, f), 'utf8'); SI_CACHE[f] = { m: st.mtimeMs, z: st.size, src }; } } catch (e) { continue; }
        const head = /\/\/ ==UserScript==[\s\S]*?\/\/ ==\/UserScript==/.exec(src); if (!head) continue;
        const v = (/@version\s+(\S+)/.exec(head[0]) || [])[1] || '0';
        if (!best || verNum(v) > verNum(best.version)) best = { file: f, version: v, src, head: head[0] };
    }
    return best;
}
// ใส่ @updateURL/@downloadURL ชี้มาที่โปรแกรมนี้ → Tampermonkey ทุก Chrome เช็คอัปเดตจากในเครื่องเองตามรอบ
// 🔁 ตัวโหลด: ติดตั้งใน Tampermonkey ครั้งเดียว (ชื่อเดียวกับสคริปต์เดิม → แทนที่ของเดิม) · ทุกครั้งที่เปิด/รีโหลดหน้าเกมจะดึงสคริปต์ล่าสุดจากโปรแกรมนี้มารัน
//    โปรแกรมไม่ได้เปิด → ใช้โค้ดชุดล่าสุดที่จำไว้ใน Tampermonkey · วางไฟล์ .user.js ใหม่ + รีโหลดหน้าเกม = อัปเดตทันที ไม่ต้องกดอะไรใน Tampermonkey
const LOADER_VERSION = '6.0.0';      // เปลี่ยนเลขนี้เฉพาะตอนแก้ตัวโหลดเอง (สคริปต์ตัวจริงไม่เกี่ยว)
function loaderHead(si) {
    const base = `http://127.0.0.1:${CFG.port}`;
    return si.head.replace(/^\/\/ @(version|updateURL|downloadURL|run-at)\s.*\r?\n/gm, '')
        .replace(/^(\/\/ @namespace\s.*)$/m, `$1\n// @version      ${LOADER_VERSION}\n// @updateURL    ${base}/aetherack.meta.js\n// @downloadURL  ${base}/aetherack.user.js`);
}
function loaderSource(si) {
    const base = `http://127.0.0.1:${CFG.port}`;
    return `${loaderHead(si)}

// Aetherack — ตัวโหลด: ดึงสคริปต์ล่าสุดจาก Aetherack Manager (${base}) ทุกครั้งที่เปิดหน้าเกม · ติดต่อไม่ได้ = ใช้ชุดที่จำไว้
(function () {
    'use strict';
    const AETH_LOADER = '${LOADER_VERSION}';      // สคริปต์ตัวจริงอ่านค่านี้ → บอกโปรแกรมว่าอัปเดตเองได้
    const KEY = 'aeth_core';
    let done = false;
    const run = (code, from) => {
        if (done) return; done = true;
        try { eval(code); } catch (e) { console.error('[Aetherack ตัวโหลด] รันสคริปต์ไม่สำเร็จ (' + from + ')', e); }
    };
    const fallback = () => { const c = GM_getValue(KEY, null); if (c && c.code) run(c.code, 'ชุดที่จำไว้ v' + c.v); else console.warn('[Aetherack ตัวโหลด] ติดต่อโปรแกรมไม่ได้ และยังไม่มีชุดที่จำไว้ — เปิด Aetherack Manager แล้วรีโหลดหน้านี้'); };
    const timer = setTimeout(fallback, 3000);
    GM_xmlhttpRequest({
        method: 'GET', url: '${base}/aetherack.core.js?t=' + Date.now(), timeout: 3000,
        onload: (r) => {
            const code = r.responseText || '';
            if (r.status !== 200 || !/==UserScript==/.test(code)) { clearTimeout(timer); fallback(); return; }
            clearTimeout(timer);
            const v = (/@version\\s+(\\S+)/.exec(code) || [])[1] || '?';
            const c = GM_getValue(KEY, null); if (!c || c.v !== v || c.code.length !== code.length) GM_setValue(KEY, { v, code, at: Date.now() });
            run(code, 'v' + v);
        },
        onerror: () => { clearTimeout(timer); fallback(); }, ontimeout: () => { clearTimeout(timer); fallback(); },
    });
})();
`;
}
function withUpdateUrls(text) {
    const base = `http://127.0.0.1:${CFG.port}`;
    return text.replace(/^\/\/ @(updateURL|downloadURL)\s.*\r?\n/gm, '')
        .replace(/^(\/\/ @version\s.*)$/m, `$1\n// @updateURL    ${base}/aetherack.meta.js\n// @downloadURL  ${base}/aetherack.user.js`);
}
async function openTab(g, url) { const ws = await browserWs(g); const r = await cdp(ws, (send) => send('Target.createTarget', { url })); return r && r.targetId; }

// ---------------------------------------------------------------
// ⚙️ ตัวเลือกอัตโนมัติ (เปิดเองในหน้า ตั้งค่า): ติดตั้ง Tampermonkey ด้วยนโยบายของ Chrome · เปิด Allow User Scripts · กดยืนยันติดตั้งสคริปต์ให้เอง
// ---------------------------------------------------------------
const TM_FORCE = TM_ID + ';https://clients2.google.com/service/update2/crx';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// ข้อความผิดพลาดของ PowerShell ตอนรันแบบ -EncodedCommand ออกมาเป็น CLIXML (มีข้อความ "Preparing modules…" ปน) → ดึงเฉพาะบรรทัด Error
function psErr(raw) {
    const t = String(raw || '');
    if (!/#< CLIXML/.test(t)) return t.trim();
    const errs = [...t.matchAll(/<S S="Error">([\s\S]*?)<\/S>/g)].map((m) => m[1].replace(/_x000D_/g, '').replace(/_x000A_/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').trim()).filter(Boolean);
    return errs.join(' ').trim();
}
function ps(script, elevated) {
    return new Promise((resolve, reject) => {
        if (process.platform !== 'win32') { reject(Error('ใช้ได้เฉพาะ Windows')); return; }
        const enc = Buffer.from(`$ProgressPreference='SilentlyContinue'; $ErrorActionPreference='Stop'; ${script}`, 'utf16le').toString('base64');
        const args = elevated      // ทั้งเครื่อง (HKLM) ต้องใช้สิทธิ์ Admin → Windows ถาม UAC
            ? ['-NoProfile', '-NonInteractive', '-Command', `$ProgressPreference='SilentlyContinue'; try { $p = Start-Process powershell -Verb RunAs -Wait -PassThru -WindowStyle Hidden -ArgumentList '-NoProfile','-NonInteractive','-EncodedCommand','${enc}'; exit $p.ExitCode } catch { Write-Error 'ไม่ได้รับสิทธิ์ Admin (กดยกเลิกหน้าต่าง UAC)'; exit 1 }`]
            : ['-NoProfile', '-NonInteractive', '-EncodedCommand', enc];
        execFile('powershell.exe', args, { windowsHide: true, timeout: 120000 }, (err, out, errOut) => {
            if (err) { const msg = psErr(errOut) || (err.killed ? 'PowerShell ทำงานนานเกิน' : `PowerShell ล้มเหลว (รหัส ${err.code})`); reject(Error(msg.slice(0, 300))); }
            else resolve(String(out || '').trim());
        });
    });
}
const POLICY_KEYS = { user: 'HKCU:\\Software\\Policies\\Google\\Chrome\\ExtensionInstallForcelist', machine: 'HKLM:\\Software\\Policies\\Google\\Chrome\\ExtensionInstallForcelist' };
S.policy = { user: false, machine: false };
async function policyScan() {
    if (process.platform !== 'win32') return;
    for (const scope of ['user', 'machine']) {
        try { const out = await ps(`$k='${POLICY_KEYS[scope]}'; if (Test-Path $k) { @((Get-ItemProperty $k).PSObject.Properties | Where-Object { $_.Name -match '^\\d+$' -and "$($_.Value)" -like '${TM_ID}*' }).Count } else { 0 }`); S.policy[scope] = +out > 0; } catch (e) { /* ignore */ }
    }
}
async function policySet(scope, on) {
    const k = POLICY_KEYS[scope]; if (!k) throw Error('scope ไม่ถูกต้อง');
    const script = on
        ? `$k='${k}'; if (!(Test-Path $k)) { New-Item -Path $k -Force | Out-Null }; $p=@((Get-ItemProperty $k).PSObject.Properties | Where-Object { $_.Name -match '^\\d+$' }); if (-not ($p | Where-Object { "$($_.Value)" -like '${TM_ID}*' })) { $i=1; while ($p.Name -contains "$i") { $i++ }; New-ItemProperty -Path $k -Name "$i" -Value '${TM_FORCE}' -PropertyType String -Force | Out-Null }`
        : `$k='${k}'; if (Test-Path $k) { (Get-ItemProperty $k).PSObject.Properties | Where-Object { $_.Name -match '^\\d+$' -and "$($_.Value)" -like '${TM_ID}*' } | ForEach-Object { Remove-ItemProperty -Path $k -Name $_.Name } }`;
    await ps(script, scope === 'machine');
    await policyScan();
    const where = scope === 'machine' ? 'ทั้งเครื่อง' : 'ผู้ใช้ Windows นี้';
    say(on ? `🧩 ตั้งนโยบายให้ Chrome ติดตั้ง Tampermonkey เอง (${where}) — ปิด/เปิด Chrome ใหม่ 1 ครั้ง` : `🧩 ยกเลิกนโยบายติดตั้ง Tampermonkey (${where})`);
}
// รันโค้ดในแท็บใหม่ของ Chrome กลุ่มนั้น แล้วปิดแท็บ
async function evalInNewTab(g, url, expression, waitMs = 1500) {
    const targetId = await openTab(g, url);
    try {
        await sleep(waitMs);
        const t = (await jget(g.debugPort, '/json/list')).find((x) => x.id === targetId); if (!t) throw Error('ไม่พบแท็บที่เปิด');
        const r = await cdp(t.webSocketDebuggerUrl, (send) => send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true }));
        if (r.exceptionDetails) throw Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || 'สคริปต์ผิดพลาด');
        return r.result && r.result.value;
    } finally { await jget(g.debugPort, `/json/close/${targetId}`).catch(() => {}); }
}
// เปิดสวิตช์ "Allow User Scripts" ของ Tampermonkey (Chrome 138+) · Chrome รุ่นเก่ากว่าใช้โหมดนักพัฒนาแทน — สั่งผ่านหน้า chrome://extensions ของ Chrome เอง
async function allowUserScripts(g) {
    const expr = `(async () => {
        const d = chrome.developerPrivate, out = {};
        const call = (fn, ...a) => new Promise((res, rej) => { try { const r = fn.call(d, ...a, (v) => { const e = chrome.runtime && chrome.runtime.lastError; if (e) rej(Error(e.message)); else res(v); }); if (r && r.then) r.then(res, rej); } catch (e) { rej(e); } });
        let info = null; try { info = await call(d.getExtensionInfo, '${TM_ID}'); } catch (e) { return JSON.stringify({ installed: false }); }
        out.installed = !!info;
        if (info && 'userScriptsAccess' in info) {
            if (!info.userScriptsAccess) { try { await call(d.updateExtensionConfiguration, { extensionId: '${TM_ID}', userScriptsAccess: true }); } catch (e) { out.err = String(e.message || e); } }
            try { out.allowed = !!(await call(d.getExtensionInfo, '${TM_ID}')).userScriptsAccess; } catch (e) { /* ignore */ }
        } else {
            try { await call(d.updateProfileConfiguration, { inDeveloperMode: true }); out.allowed = true; out.dev = true; } catch (e) { out.err = String(e.message || e); }
        }
        return JSON.stringify(out);
    })()`;
    const r = JSON.parse((await evalInNewTab(g, 'chrome://extensions/?id=' + TM_ID, expr)) || '{}');
    if (!r.installed) throw Error(`${g.id}: ยังไม่มี Tampermonkey`);
    if (!r.allowed) throw Error(`${g.id}: เปิด Allow User Scripts ไม่สำเร็จ${r.err ? ' (' + r.err + ')' : ''} — กดเปิดเองที่หน้าตั้งค่า Tampermonkey`);
    say(`✅ ${g.id}: เปิด ${r.dev ? 'โหมดนักพัฒนา (Chrome รุ่นเก่า)' : 'Allow User Scripts'} ให้ Tampermonkey แล้ว`);
    return 'ok';
}
// ตรวจอย่างเดียว (ไม่เปลี่ยนอะไร): มี Tampermonkey ไหม / เปิดอยู่ไหม / อนุญาตสคริปต์ผู้ใช้แล้วหรือยัง
async function extStatus(g) {
    const expr = `(async () => {
        const d = chrome.developerPrivate;
        const call = (fn, ...a) => new Promise((res, rej) => { try { const r = fn.call(d, ...a, (v) => { const e = chrome.runtime && chrome.runtime.lastError; if (e) rej(Error(e.message)); else res(v); }); if (r && r.then) r.then(res, rej); } catch (e) { rej(e); } });
        let i = null; try { i = await call(d.getExtensionInfo, '${TM_ID}'); } catch (e) { return JSON.stringify({ installed: false }); }
        if (!i) return JSON.stringify({ installed: false });
        let allowed = null;
        if ('userScriptsAccess' in i) allowed = !!i.userScriptsAccess;
        else { try { allowed = !!(await call(d.getProfileConfiguration)).inDeveloperMode; } catch (e) { /* ignore */ } }
        return JSON.stringify({ installed: true, enabled: i.state === 'ENABLED', allowed, version: i.version || '' });
    })()`;
    const r = JSON.parse((await evalInNewTab(g, 'chrome://extensions/', expr, 1200)) || '{}');
    const info = S.groups[g.id] || (S.groups[g.id] = {});
    info.ext = Object.assign({}, r, { at: Date.now() });
    if (r.installed) info.tm = true;
    return r;
}
// 🧹 แท็บที่โปรแกรมเปิดให้ (ร้านค้า / หน้าตั้งค่าส่วนขยาย) → ปิดเองเมื่อทำขั้นนั้นเสร็จ · หน้าต้อนรับที่ Tampermonkey เปิดเองหลังติดตั้งก็ปิดให้ด้วย
async function closeTab(g, tid) { if (tid) await jget(g.debugPort, `/json/close/${tid}`).catch(() => {}); }
const TM_WELCOME = /^https?:\/\/(www\.)?tampermonkey\.net\/(installed|changelog|first|index\.php\?.*\b(updated|installed)=)/i;
async function closeTmWelcome(g) {
    const list = await jget(g.debugPort, '/json/list').catch(() => []);
    for (const t of list) if (t.type === 'page' && TM_WELCOME.test(t.url || '')) await closeTab(g, t.id);
}
function closeWhen(g, tid, cond, ms, every = 3000) {      // เฝ้าเบื้องหลัง: เงื่อนไขเป็นจริง → ปิดแท็บ (เลิกเฝ้าเมื่อผู้ใช้ปิดแท็บเอง / หมดเวลา)
    (async () => {
        const end = Date.now() + ms;
        while (Date.now() < end) {
            await sleep(every);
            const list = await jget(g.debugPort, '/json/list').catch(() => null); if (!list || !list.some((x) => x.id === tid)) return;
            try { if (await cond()) { await sleep(800); await closeTab(g, tid); await closeTmWelcome(g); return; } } catch (e) { /* ignore */ }
        }
    })();
}
async function waitFor(fn, ms, every) {
    const end = Date.now() + ms;
    while (Date.now() < end) { try { const v = await fn(); if (v) return v; } catch (e) { /* ignore */ } await sleep(every); }
    return null;
}
const gameUrlFor = (g) => `${String(CFG.gameUrl).replace(/#.*$/, '')}#aeth=${encodeURIComponent(g.id)}`;      // สคริปต์อ่าน #aeth= แล้วรู้ว่าอยู่ Chrome กลุ่มไหน
// สคริปต์ในเกมส่ง "hello" มาตอนเปิดหน้าเกม (ก่อนล็อกอินก็ส่ง) → รู้ว่ากลุ่มนี้ติดตั้งสคริปต์แล้ว รุ่นไหน
const scriptOk = (g, since) => { const sc = (S.groups[g.id] || {}).script; return sc && sc.at >= since ? sc : null; };
async function reloadGames(g) {
    for (const t of ((S.groups[g.id] || {}).targets || []).filter(isGame)) { await cdp(t.webSocketDebuggerUrl, (send) => send('Page.reload', { ignoreCache: true })).catch(() => {}); }
}
// 🧰 เตรียม Chrome ก่อนเข้าเกม: Tampermonkey → Allow User Scripts → (เข้าเกม) → สคริปต์ตอบ/ติดตั้งหรืออัปเดตสคริปต์
S.prep = {};
function stepSet(g, k, state, msg) {
    const p = S.prep[g.id] || (S.prep[g.id] = { steps: {} });
    p.steps[k] = state;
    if (msg && msg !== p.msg) { p.msg = msg; say(`🧰 ${g.id}: ${msg}`); }
}
// 📋 คัดลอกสคริปต์ใน Tampermonkey จากโปรไฟล์ที่ติดตั้งแล้ว → โปรไฟล์อื่น (ไม่ต้องกด Install ทีละ Chrome)
//    คัดลอกเฉพาะที่เก็บข้อมูลของ Tampermonkey (สคริปต์ + ค่าที่สคริปต์เก็บ) · โปรไฟล์ปลายทางต้องมี Tampermonkey อยู่แล้ว
//    ต้องปิด Chrome ทั้งต้นทางและปลายทางก่อน (ไฟล์ถูกล็อกตอนเปิด) → ปิดให้เอง แล้วเปิดคืนตัวที่เปิดอยู่เดิม · ของเดิมสำรองไว้ใน backup
const TM_DATA = ['Local Extension Settings/' + TM_ID, 'Sync Extension Settings/' + TM_ID, `IndexedDB/chrome-extension_${TM_ID}_0.indexeddb.leveldb`, `IndexedDB/chrome-extension_${TM_ID}_0.indexeddb.blob`];
const tmInstalledOnDisk = (g) => fs.existsSync(path.join(dirOf(g), 'Default', 'Extensions', TM_ID));
const tmHasData = (g) => fs.existsSync(path.join(dirOf(g), 'Default', TM_DATA[0]));
let cloning = false;
async function tmClone(from, toIds) {
    if (cloning) throw Error('กำลังคัดลอกอยู่');
    const src = groupOf(from); if (!src) throw Error('ไม่พบโปรไฟล์ต้นทาง');
    if (!tmHasData(src)) throw Error(`${src.id} ยังไม่มี Tampermonkey/สคริปต์ — ติดตั้งในโปรไฟล์นี้ก่อน 1 ครั้ง`);
    const dst = (toIds && toIds.length ? toIds.map(groupOf) : CFG.groups).filter((g) => g && g.id !== src.id && g.dir);
    const ok = dst.filter(tmInstalledOnDisk), noTm = dst.filter((g) => !tmInstalledOnDisk(g));
    if (!ok.length) throw Error(noTm.length ? `โปรไฟล์ปลายทางยังไม่มี Tampermonkey (${noTm.map((g) => g.id).join(', ')}) — ติดตั้ง Tampermonkey ก่อน` : 'ไม่มีโปรไฟล์ปลายทาง');
    cloning = true;
    try {
        const all = [src, ...ok], wasOn = all.filter((g) => { const i = S.groups[g.id] || {}; return i.running || i.debug; });
        if (wasOn.some((g) => (S.groups[g.id] || {}).outside)) throw Error('มี Chrome ที่เปิดจากทางลัดเดิม (โปรแกรมปิดให้ไม่ได้) — ปิดเองก่อน');
        if (wasOn.length) {
            say(`📋 ปิด Chrome ${wasOn.map((g) => g.id).join(', ')} ชั่วคราวเพื่อคัดลอกสคริปต์…`);
            for (const g of wasOn) await stopGroup(g).catch(() => {});
            const off = await waitFor(() => wasOn.every((g) => { const i = S.groups[g.id] || {}; return !i.running && !i.debug; }), 60000, 1000);
            if (!off) throw Error('ปิด Chrome ไม่หมดภายใน 1 นาที — ปิดเองแล้วลองใหม่');
            await sleep(2500);
        }
        const stamp = Date.now(), done = [];
        for (const g of ok) {
            const bdir = path.join(ROOT, 'backup', `tm-${g.id}-${stamp}`);
            for (const rel of TM_DATA) {
                const a = path.join(dirOf(src), 'Default', rel), b = path.join(dirOf(g), 'Default', rel);
                if (fs.existsSync(b)) { fs.mkdirSync(path.dirname(path.join(bdir, rel)), { recursive: true }); fs.cpSync(b, path.join(bdir, rel), { recursive: true }); fs.rmSync(b, { recursive: true, force: true }); }
                if (fs.existsSync(a)) { fs.mkdirSync(path.dirname(b), { recursive: true }); fs.cpSync(a, b, { recursive: true, filter: (f) => path.basename(f) !== 'LOCK' }); }
            }
            done.push(g.id);
        }
        say(`📋 คัดลอกสคริปต์จาก ${src.id} → ${done.join(', ')} แล้ว${noTm.length ? ` · ข้าม ${noTm.map((g) => g.id).join(', ')} (ยังไม่มี Tampermonkey)` : ''} · ของเดิมอยู่ใน backup`);
        if (wasOn.length) (async () => { for (const g of wasOn) { try { await startGroup(g); } catch (e) { say('❌ ' + e.message); } await sleep(Math.max(1, +CFG.startGapSec || 5) * 1000); } })();
        return { done, skip: noTm.map((g) => g.id), reopened: wasOn.map((g) => g.id) };
    } finally { cloning = false; }
}
async function prepGroup(g, openGame) {
    if (S.prep[g.id] && S.prep[g.id].running) return;
    S.prep[g.id] = { running: true, go: false, done: false, failed: false, msg: '', steps: { chrome: 'doing', tm: 'wait', allow: 'wait', script: 'wait' } };
    const P = S.prep[g.id];
    try {
        stepSet(g, 'chrome', 'doing', 'รอ Chrome พร้อม…');
        if (!(await waitFor(() => jget(g.debugPort, '/json/version'), 40000, 1000))) throw Error('Chrome ไม่ตอบภายใน 40 วิ');
        stepSet(g, 'chrome', 'ok');
        // 1) Tampermonkey
        stepSet(g, 'tm', 'doing', 'ตรวจ Tampermonkey…');
        let st = await extStatus(g);
        if (!st.installed) {
            const pol = S.policy.user || S.policy.machine;
            stepSet(g, 'tm', 'doing', pol ? 'รอ Chrome ติดตั้ง Tampermonkey ตามนโยบาย…' : 'ยังไม่มี Tampermonkey — กด "เพิ่มใน Chrome" ในหน้าร้านค้าที่เปิดขึ้นมา');
            const storeTab = pol ? '' : await openTab(g, TM_STORE);
            // รอดูจากรายการแท็บ/ตัวทำงานของ Chrome (เห็น Tampermonkey ทันทีที่ติดตั้ง) — ไม่ต้องเปิดหน้า chrome://extensions ซ้ำ ๆ
            const got = await waitFor(() => (S.groups[g.id] || {}).tm === true, 600000, 2000);
            await sleep(1500); await closeTab(g, storeTab); await closeTmWelcome(g);      // ติดตั้งเสร็จ → ปิดหน้าร้านค้า + หน้าต้อนรับ
            st = got ? await waitFor(async () => { const s = await extStatus(g); return s.installed ? s : null; }, 30000, 3000) : null;
            if (!st) throw Error('รอติดตั้ง Tampermonkey นานเกิน 10 นาที');
        }
        stepSet(g, 'tm', 'ok', `มี Tampermonkey แล้ว${st.version ? ' (v' + st.version + ')' : ''}`);
        // 2) Allow User Scripts
        if (!st.allowed) {
            stepSet(g, 'allow', 'doing', 'ยังไม่ได้เปิด Allow User Scripts…');
            if (CFG.autoAllow) { try { await allowUserScripts(g); } catch (e) { say('⚠️ ' + e.message); } st = await extStatus(g); }
            if (!st.allowed) {
                stepSet(g, 'allow', 'doing', 'เปิดสวิตช์ "Allow User Scripts" ในหน้าตั้งค่า Tampermonkey ที่เปิดขึ้นมา');
                const extTab = await openTab(g, 'chrome://extensions/?id=' + TM_ID);
                st = await waitFor(async () => { const s = await extStatus(g); return s.allowed ? s : null; }, 600000, 8000);
                await closeTab(g, extTab);      // เปิดสวิตช์แล้ว → ปิดหน้าตั้งค่า
                if (!st) throw Error('รอเปิด Allow User Scripts นานเกิน 10 นาที');
            }
        }
        stepSet(g, 'allow', 'ok', 'Allow User Scripts เปิดแล้ว');
        // 3) สคริปต์: เข้าเกม → รอสคริปต์ตอบ
        const si = scriptInfo();
        let since = Date.now();
        stepSet(g, 'script', 'doing', 'เข้าหน้าเกม แล้วรอสคริปต์ตอบ…');
        if (openGame) P.go = true;      // หน้าเตรียมความพร้อมพาเข้าเกมเอง
        else if (!((S.groups[g.id] || {}).targets || []).some(isGame)) await openTab(g, gameUrlFor(g));
        else { await reloadGames(g); }
        let sc = await waitFor(() => scriptOk(g, since), 45000, 1000);
        if (sc && sc.ld && si && verNum(sc.v) < verNum(si.version)) {      // มีตัวโหลดแล้วแต่หน้าเกมยังรันชุดเก่า → รีโหลดก็ได้ชุดใหม่
            stepSet(g, 'script', 'doing', `มีสคริปต์ใหม่ v${si.version} — รีโหลดหน้าเกมเพื่ออัปเดต…`);
            since = Date.now(); await reloadGames(g);
            sc = (await waitFor(() => scriptOk(g, since), 45000, 1000)) || sc;
        }
        if (!sc || !sc.ld) {      // ยังไม่มีสคริปต์ หรือยังเป็นแบบเก่า (ไม่อัปเดตเอง) → ติดตั้งตัวโหลดครั้งเดียว
            if (!si) throw Error('ไม่พบไฟล์สคริปต์ (*.user.js) ในโฟลเดอร์โปรแกรม');
            stepSet(g, 'script', 'doing', sc ? 'เปลี่ยนเป็นแบบอัปเดตอัตโนมัติ — กด "Update" ในหน้าของ Tampermonkey ที่เปิดขึ้นมา (ครั้งเดียว หลังจากนี้อัปเดตเองตอนรีโหลดเกม)' : 'ยังไม่มีสคริปต์ — กด "Install" ในหน้าของ Tampermonkey ที่เปิดขึ้นมา (ครั้งเดียว หลังจากนี้อัปเดตเองตอนรีโหลดเกม)');
            const tid = await openTab(g, `http://127.0.0.1:${CFG.port}/aetherack.user.js?t=${Date.now()}`);
            await waitFor(async () => !(await jget(g.debugPort, '/json/list')).some((x) => x.id === tid), 600000, 3000);      // Tampermonkey ปิดแท็บเองเมื่อกดติดตั้ง
            await sleep(1500); await closeTmWelcome(g); since = Date.now(); await reloadGames(g);
            sc = await waitFor(() => scriptOk(g, since), 60000, 1000);
            if (!sc) throw Error('ติดตั้งสคริปต์แล้วแต่สคริปต์ยังไม่ตอบ — ลองรีโหลดหน้าเกม');
        }
        stepSet(g, 'script', 'ok', `สคริปต์ v${sc.v} ทำงานแล้ว${sc.ld ? ' (อัปเดตเองตอนรีโหลดเกม)' : ''}`);
        P.done = true; P.msg = '✅ พร้อมแล้ว'; say(`✅ ${g.id}: พร้อมใช้งาน`);
    } catch (e) {
        P.failed = true; P.msg = '❌ ' + e.message; say(`❌ ${g.id}: ${e.message}`);
        for (const k of Object.keys(P.steps)) if (P.steps[k] === 'doing') P.steps[k] = 'fail';
    } finally { P.running = false; P.go = true; }      // ล้มเหลวก็พาเข้าเกมอยู่ดี (เล่นเองได้)
}
setInterval(() => { policyScan().catch(() => {}); }, 60000);
setTimeout(() => { policyScan().catch(() => {}); }, 1500);
async function eachRunning(fn) {
    const res = [];
    for (const g of CFG.groups) { if (!(S.groups[g.id] || {}).debug) continue; try { res.push({ id: g.id, ok: true, r: await fn(g) }); } catch (e) { res.push({ id: g.id, ok: false, err: e.message }); say('❌ ' + e.message); } }
    if (!res.length) throw Error('ยังไม่มี Chrome ที่เปิดจากโปรแกรมนี้');
    return res;
}

// ---------------------------------------------------------------
// HTTP (127.0.0.1 เท่านั้น)
// ---------------------------------------------------------------
function body(req, max = 2e6) { if (req._b !== undefined) return Promise.resolve(req._b); return new Promise((res, rej) => { let d = ''; req.setEncoding('utf8'); req.on('data', (c) => { d += c; if (d.length > max) { rej(Error('too big')); req.destroy(); } }); req.on('end', () => { try { res(d ? JSON.parse(d) : {}); } catch (e) { rej(Error('bad json')); } }); }); }
function send(res, code, obj) { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); }
const publicGroups = () => CFG.groups.map((g) => { const i = S.groups[g.id] || {}; return { id: g.id, name: g.name, proxy: proxyPlain(g.proxy), proxyAuth: !!(g.proxy && proxyCreds(g)), proxyRaw: g.proxy, dir: g.dir, debugPort: g.debugPort, running: !!i.running, debug: !!i.debug, outside: !!i.outside, ram: i.ram || 0, procs: i.procs || 0, games: (i.targets || []).filter(isGame).length, max: maxOf(g), maxScreens: g.maxScreens || '', loginIds: (CFG.loginIds || {})[g.id] || [], tm: i.tm === undefined ? null : i.tm, ext: i.ext || null, script: i.script || null, prep: S.prep[g.id] || null }; });

// ---------------------------------------------------------------
// 📱 ใช้จากมือถือ / นอกบ้าน: Cloudflare Quick Tunnel (cloudflared.exe โหลดมาไว้ใน tools/ ให้เอง ไม่ต้องติดตั้ง/สมัครอะไร) → ลิงก์ https://xxx.trycloudflare.com
// ตัวเชื่อมต่อทำงานแยกจาก Manager → อัปเดต/รีสตาร์ท Manager ลิงก์เดิมยังใช้ได้ (เปลี่ยนเมื่อปิดเปิดคอมใหม่เท่านั้น)
// ทุกคำขอที่มาทางลิงก์ต้องล็อกอินด้วย PIN (scrypt) · คุกกี้ HttpOnly+Secure+SameSite=Strict · ผิด 5 ครั้ง/IP = ล็อก 15 นาที · ผิดรวม 20 ครั้ง/ชม. = ปิดล็อกอิน 1 ชม.
// จากนอกเครื่อง: ห้ามอัปเดต/อัปโหลด/ปิดโปรแกรม/แก้ตั้งค่า · ซ่อนรหัสพร็อกซี/Webhook · แจ้งเตือนเข้ามือถือ (Web Push เข้ารหัส) ตอน Captcha/ตาย/ติดคุก/หลุด
// ---------------------------------------------------------------
const RM_FILE = path.join(ROOT, 'remote.json'), CF_EXE = path.join(ROOT, 'tools', process.platform === 'win32' ? 'cloudflared.exe' : 'cloudflared'), CF_LOG = path.join(ROOT, 'tools', 'cloudflared.log');
const RM = { on: false, salt: '', hash: '', sess: [], url: '', host: '', pid: 0, nonce: '', st: 'ปิดอยู่', fails: {}, gFails: [], lockAll: 0, dl: 0, vapid: null, subs: [], push: { captcha: true, dead: true, jail: true, off: false, gm: true }, dcLink: true };
try { const j = JSON.parse(fs.readFileSync(RM_FILE, 'utf8')); Object.assign(RM, { on: !!j.on, salt: j.salt || '', hash: j.hash || '', sess: (j.sess || []).filter((x) => x.exp > Date.now()), url: j.url || '', pid: +j.pid || 0, nonce: j.nonce || '', vapid: j.vapid || null, subs: Array.isArray(j.subs) ? j.subs : [], push: Object.assign(RM.push, j.push || {}), dcLink: j.dcLink !== false, pinLen: +j.pinLen || 0, pinDig: !!j.pinDig }); } catch (e) { /* ยังไม่เคยตั้ง */ }
const rmSave = () => { try { fs.writeFileSync(RM_FILE + '.tmp', JSON.stringify({ on: RM.on, salt: RM.salt, hash: RM.hash, sess: RM.sess.filter((x) => x.exp > Date.now()), url: RM.url, pid: RM.pid, nonce: RM.nonce, vapid: RM.vapid, subs: RM.subs, push: RM.push, dcLink: RM.dcLink, pinLen: RM.pinLen || 0, pinDig: !!RM.pinDig })); fs.renameSync(RM_FILE + '.tmp', RM_FILE); } catch (e) { /* ignore */ } };
const sha = (t) => crypto.createHash('sha256').update(String(t)).digest('hex');
const pwHash = (pw, salt) => crypto.scryptSync(String(pw), salt, 32).toString('hex');
function rmCookie(req) { const m = /(?:^|;\s*)aeth_s=([A-Za-z0-9_-]{20,100})/.exec(String(req.headers.cookie || '')); return m ? m[1] : ''; }
function rmSession(req) { const t = rmCookie(req); if (!t) return null; const h = sha(t), x = RM.sess.find((q) => q.h === h && q.exp > Date.now()); if (x) x.seen = Date.now(); return x || null; }
function rmIp(req) { return String(req.headers['cf-connecting-ip'] || req.socket.remoteAddress || '?').slice(0, 60); }
function rmLogin(req, pw) {
    const now = Date.now(), ip = rmIp(req), f = RM.fails[ip] || (RM.fails[ip] = { n: 0, until: 0 });
    RM.gFails = RM.gFails.filter((t) => now - t < 3600000);
    if (now < RM.lockAll) return { err: 'ปิดการล็อกอินชั่วคราว (มีคนใส่ PIN ผิดหลายครั้ง) — ลองใหม่ภายหลัง' };
    if (now < f.until) return { err: `ใส่ PIN ผิดหลายครั้ง — รอ ${Math.ceil((f.until - now) / 60000)} นาที` };
    const ok = RM.hash && crypto.timingSafeEqual(Buffer.from(pwHash(pw, RM.salt), 'hex'), Buffer.from(RM.hash, 'hex'));
    if (!ok) {
        f.n++; RM.gFails.push(now); if (f.n >= 5) { f.until = now + 900000; f.n = 0; }
        if (RM.gFails.length >= 20) { RM.lockAll = now + 3600000; say('📱 มีการใส่ PIN ผิดจากลิงก์มือถือ 20 ครั้งใน 1 ชม. — ปิดล็อกอินจากนอกเครื่อง 1 ชม.'); }
        say(`📱 ใส่ PIN ผิดจากนอกเครื่อง (IP ${ip})`); return { err: 'PIN ไม่ถูกต้อง' };
    }
    f.n = 0; const tok = crypto.randomBytes(32).toString('base64url');
    RM.sess.push({ h: sha(tok), exp: now + 30 * 86400000, at: now, seen: now, ip, ua: String(req.headers['user-agent'] || '').slice(0, 120) }); if (RM.sess.length > 20) RM.sess.splice(0, RM.sess.length - 20); rmSave();
    say(`📱 ล็อกอินจากนอกเครื่องสำเร็จ (IP ${ip})`); return { tok };
}
// 🔒 ตัวเชื่อมต่อ Cloudflare: ล็อกรุ่น + ตรวจ SHA-256 ก่อนใช้ · ไฟล์เดิมที่ hash ไม่ตรง (เช่นโหลดจากรุ่นก่อน ๆ) ต้องมีลายเซ็นดิจิทัลของ Cloudflare, Inc. ที่ Windows ยืนยันว่าถูกต้อง ไม่งั้นลบแล้วโหลดรุ่นที่ล็อกไว้ใหม่
const CF_VER = '2026.10.3', CF_SHA256 = '76b2805253d0d6ffacb092a7acfbee99e7af6917835c0c5410e23f3ef5052da2';
const CF_URL = `https://github.com/cloudflare/cloudflared/releases/download/${CF_VER}/cloudflared-windows-amd64.exe`;
const sha256Of = (buf) => crypto.createHash('sha256').update(buf).digest('hex');
function cfSigned(file) {      // Windows ตรวจลายเซ็น Authenticode: ต้อง Valid และผู้เซ็นเป็น Cloudflare, Inc.
    if (process.platform !== 'win32') return Promise.resolve(false);
    const ps = `$s = Get-AuthenticodeSignature -LiteralPath '${file.replace(/'/g, "''")}'; if ($s.Status -eq 'Valid' -and $s.SignerCertificate.Subject -match 'O="?Cloudflare, Inc') { 'OK' } else { 'NO ' + $s.Status }`;
    return new Promise((ok) => execFile('powershell', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true, timeout: 30000 }, (e, out) => ok(!e && /^OK/.test(String(out).trim()))));
}
async function cfVerify(file) {
    try { if (sha256Of(fs.readFileSync(file)) === CF_SHA256) return true; } catch (e) { return false; }
    return cfSigned(file);
}
async function cfDownload() {
    if (process.platform !== 'win32') throw Error('รองรับเฉพาะ Windows');
    if (fs.existsSync(CF_EXE)) {
        if (await cfVerify(CF_EXE)) return;
        say('🔒 ตัวเชื่อมต่อ Cloudflare ในโฟลเดอร์ tools ตรวจสอบไม่ผ่าน (hash/ลายเซ็นไม่ตรง) — ลบแล้วโหลดรุ่นที่ตรวจแล้วใหม่');
        try { fs.unlinkSync(CF_EXE); } catch (e) { throw Error('ลบไฟล์ตัวเชื่อมต่อเดิมไม่ได้ (อาจกำลังทำงานอยู่) — ปิด/เปิดคอมใหม่แล้วลองอีกครั้ง'); }
    }
    RM.st = `กำลังโหลดตัวเชื่อมต่อ Cloudflare ${CF_VER} (~55 MB) ครั้งแรก…`; RM.dl = 1;
    try {
        const buf = await httpsGet(CF_URL, 150e6);
        if (!buf || buf[0] !== 0x4d || buf[1] !== 0x5a) throw Error('ไฟล์ที่โหลดมาไม่ใช่โปรแกรม Windows');
        const h = sha256Of(buf); if (h !== CF_SHA256) throw Error(`ไฟล์ที่โหลดมา SHA-256 ไม่ตรง (ได้ ${h.slice(0, 12)}…) — ไม่ใช้ไฟล์นี้`);
        fs.mkdirSync(path.dirname(CF_EXE), { recursive: true }); fs.writeFileSync(CF_EXE + '.tmp', buf); fs.renameSync(CF_EXE + '.tmp', CF_EXE);
        say(`🔒 โหลดตัวเชื่อมต่อ Cloudflare ${CF_VER} แล้ว (ตรวจ SHA-256 ผ่าน)`);
    } finally { RM.dl = 0; }
}
const pidAlive = (pid) => { if (!pid) return false; try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } };
// เลข PID ที่จำไว้เป็น cloudflared จริงไหม (เปิดคอมใหม่ เลขเดิมอาจเป็นโปรแกรมอื่น → ห้ามปิดผิดตัว)
function pidIsCf(pid) {
    if (!pidAlive(pid)) return Promise.resolve(false);
    if (process.platform !== 'win32') { try { return Promise.resolve(/cloudflared/.test(fs.readFileSync(`/proc/${pid}/cmdline`, 'utf8'))); } catch (e) { return Promise.resolve(false); } }
    return new Promise((ok) => execFile('tasklist', ['/FI', `PID eq ${pid}`, '/FO', 'CSV', '/NH'], { windowsHide: true, timeout: 8000 }, (e, out) => ok(!e && /cloudflared/i.test(String(out)))));
}
// ลิงก์ยังพาเข้ามาถึง Manager ตัวนี้จริงไหม (ถามผ่านอินเทอร์เน็ต → ต้องได้รหัสลับประจำลิงก์กลับมา)
async function cfAlive(u) { try { return String(await httpsGet(u + '/rm-alive?t=' + Date.now(), 2000)) === RM.nonce; } catch (e) { return false; } }
let cfBusy = false, cfBad = 0;
async function cfStart(fresh) {
    if (cfBusy || !RM.on) return; cfBusy = true;
    try {
        if (!fresh && RM.url && await pidIsCf(RM.pid)) {      // ตัวเชื่อมต่อจากรอบก่อนยังทำงาน (เพิ่งอัปเดต/รีสตาร์ท Manager) → ใช้ลิงก์เดิม
            RM.host = RM.url.replace(/^https:\/\//, '').toLowerCase(); RM.st = 'กำลังตรวจลิงก์เดิม…';
            if (await cfAlive(RM.url)) { RM.st = 'เปิดอยู่'; say(`📱 ลิงก์ใช้จากมือถือ (เดิม): ${RM.url}`); return; }
        }
        await cfKill();
        try { await cfDownload(); } catch (e) { RM.st = '❌ โหลดตัวเชื่อมต่อไม่สำเร็จ: ' + e.message; return; }
        if (!RM.on) return;
        RM.st = 'กำลังเปิดลิงก์…'; RM.url = ''; RM.host = ''; RM.nonce = crypto.randomBytes(16).toString('hex');
        fs.mkdirSync(path.dirname(CF_LOG), { recursive: true });
        const fd = fs.openSync(CF_LOG, 'w');
        const pr = spawn(CF_EXE, ['tunnel', '--no-autoupdate', '--url', `http://127.0.0.1:${CFG.port}`], { detached: true, windowsHide: true, stdio: ['ignore', fd, fd] });
        pr.on('error', (e) => { RM.st = '❌ เปิดตัวเชื่อมต่อไม่ได้: ' + e.message; }); pr.unref(); fs.closeSync(fd);
        RM.pid = pr.pid || 0; rmSave();
        for (let i = 0; i < 60 && RM.on && !RM.url; i++) {
            await sleep(1000);
            let t = ''; try { t = fs.readFileSync(CF_LOG, 'utf8'); } catch (e) { /* ignore */ }
            const m = /https:\/\/[a-z0-9-]+\.trycloudflare\.com/i.exec(t); if (m && !/api\.trycloudflare/i.test(m[0])) RM.url = m[0];
            if (!pidAlive(RM.pid)) break;
        }
        if (!RM.url) { RM.st = '❌ เปิดลิงก์ไม่สำเร็จ — จะลองใหม่อัตโนมัติ'; await cfKill(); return; }
        RM.host = RM.url.replace(/^https:\/\//, '').toLowerCase(); RM.st = 'เปิดอยู่'; cfBad = 0; rmSave();
        say(`📱 ลิงก์ใช้จากมือถือ (ใหม่): ${RM.url}`);
        rmNewLink();
    } finally { cfBusy = false; }
}
async function cfKill() { const pid = RM.pid; RM.pid = 0; if (pid && await pidIsCf(pid)) { try { process.kill(pid); } catch (e) { /* ignore */ } } }
function cfStop() { const k = cfKill(); RM.url = ''; RM.host = ''; RM.st = 'ปิดอยู่'; rmSave(); return k; }
setInterval(async () => {      // ตรวจทุก 2 นาที: ลิงก์ใช้ไม่ได้ 3 รอบติด → เปิดลิงก์ใหม่
    if (!RM.on || cfBusy) return;
    if (!RM.url || !pidAlive(RM.pid)) { cfStart(true); return; }
    if (await cfAlive(RM.url)) { cfBad = 0; if (RM.st !== 'เปิดอยู่') RM.st = 'เปิดอยู่'; return; }
    if (++cfBad >= 3) { RM.st = 'ลิงก์หลุด — กำลังเปิดใหม่…'; cfStart(true); }
}, 120000);
// ลิงก์เปลี่ยน → แจ้งเข้ามือถือ (Web Push) + Discord (ช่องแจ้งเตือน) ให้กดเปิดลิงก์ใหม่ได้เลย
function rmNewLink() {
    pushAll({ title: '🔗 ลิงก์ Manager ใหม่', body: 'กดเพื่อเปิด (ล็อกอินด้วย PIN อีกครั้ง)', tag: 'link', url: RM.url });
    const wh = (CFG.links || {}).discord;
    if (RM.dcLink && wh) httpsPost(wh, JSON.stringify({ content: `📱 ลิงก์ Aetherack Manager ใหม่ (ใช้จากมือถือ): ${RM.url}\n🔒 ต้องใส่ PIN ก่อนเข้า`, flags: 4 }), { 'Content-Type': 'application/json' }).catch(() => {});
}
function httpsPost(u, data, hdr) {
    return new Promise((resolve, reject) => {
        const r = require('node:https').request(u, { method: 'POST', headers: Object.assign({ 'Content-Length': Buffer.byteLength(data), 'User-Agent': 'AetherackManager/' + VERSION }, hdr || {}), timeout: 15000 }, (x) => { let d = ''; x.on('data', (c) => { if (d.length < 4000) d += c; }); x.on('end', () => resolve({ code: x.statusCode, body: d })); });
        r.on('error', reject).on('timeout', () => r.destroy(Error('หมดเวลา'))); r.end(data);
    });
}

// 🔔 Web Push (RFC 8291 aes128gcm + VAPID RFC 8292) — ไม่ต้องลงแพ็กเกจเพิ่ม · ข้อความเข้ารหัสถึงมือถือโดยตรง
function vapidKeys() {
    if (RM.vapid && RM.vapid.d) return RM.vapid;
    const k = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' }).privateKey.export({ format: 'jwk' });
    RM.vapid = { d: k.d, x: k.x, y: k.y }; rmSave(); return RM.vapid;
}
const vapidPub = () => { const v = vapidKeys(); return Buffer.concat([Buffer.from([4]), Buffer.from(v.x, 'base64url'), Buffer.from(v.y, 'base64url')]).toString('base64url'); };
function vapidAuth(endpoint) {
    const v = vapidKeys(), aud = new URL(endpoint).origin;
    const enc = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
    const data = enc({ typ: 'JWT', alg: 'ES256' }) + '.' + enc({ aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: 'https://github.com/AetherackDev/Aeherack' });
    const key = crypto.createPrivateKey({ key: { kty: 'EC', crv: 'P-256', d: v.d, x: v.x, y: v.y }, format: 'jwk' });
    const sig = crypto.sign('sha256', Buffer.from(data), { key, dsaEncoding: 'ieee-p1363' }).toString('base64url');
    return `vapid t=${data}.${sig}, k=${vapidPub()}`;
}
function pushEncrypt(sub, payload) {
    const ua = Buffer.from(sub.keys.p256dh, 'base64url'), auth = Buffer.from(sub.keys.auth, 'base64url');
    const ec = crypto.createECDH('prime256v1'); ec.generateKeys(); const as = ec.getPublicKey(), secret = ec.computeSecret(ua), salt = crypto.randomBytes(16);
    const hk = (ikm, s, info, n) => Buffer.from(crypto.hkdfSync('sha256', ikm, s, info, n));
    const ikm = hk(secret, auth, Buffer.concat([Buffer.from('WebPush: info\0'), ua, as]), 32);
    const cek = hk(ikm, salt, Buffer.from('Content-Encoding: aes128gcm\0'), 16), nonce = hk(ikm, salt, Buffer.from('Content-Encoding: nonce\0'), 12);
    const c = crypto.createCipheriv('aes-128-gcm', cek, nonce);
    const ct = Buffer.concat([c.update(Buffer.concat([Buffer.from(payload), Buffer.from([2])])), c.final(), c.getAuthTag()]);
    const rs = Buffer.alloc(4); rs.writeUInt32BE(4096);
    return Buffer.concat([salt, rs, Buffer.from([as.length]), as, ct]);
}
async function pushOne(sub, msg) {
    const body = pushEncrypt(sub, JSON.stringify(msg));
    const r = await httpsPost(sub.endpoint, body, { 'Content-Type': 'application/octet-stream', 'Content-Encoding': 'aes128gcm', TTL: '3600', Urgency: 'high', Authorization: vapidAuth(sub.endpoint) });
    if (r.code === 404 || r.code === 410) return 'gone';
    if (r.code >= 300) throw Error('HTTP ' + r.code + ' ' + r.body.slice(0, 120));
    return 'ok';
}
async function pushAll(msg) {
    if (!RM.subs.length) return 0;
    let n = 0, gone = false;
    await Promise.all(RM.subs.map(async (s) => { try { if (await pushOne(s, msg) === 'gone') { s.gone = 1; gone = true; } else { n++; s.ok = Date.now(); } } catch (e) { s.err = e.message.slice(0, 100); } }));
    if (gone) { RM.subs = RM.subs.filter((s) => !s.gone); rmSave(); }
    return n;
}
// 🧩 เช็คผู้เล่น: เวลาที่เหลือ (สคริปต์ส่ง hc.t ตอนส่งสถานะ → หักเวลาที่ผ่านไปตั้งแต่นั้น)
const hcLeft = (p, now) => (p.hc && p.hc.t >= 0 ? Math.max(0, p.hc.t - Math.round(((now || Date.now()) - p.ts) / 1000)) : -1);
const hcText = (p, now) => { const t = hcLeft(p, now); return (t >= 0 ? `เหลือ ${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}` : '') + (p.hc && p.hc.n >= 0 ? ` · ผิดได้อีก ${p.hc.n} ครั้ง` : ''); };
// 🧩 เช็คผู้เล่นเด้ง → ดึงหน้าต่างจอนั้นขึ้นมาหน้าสุดให้เอง (หลายจอพร้อมกัน: ทีละจอ ตอบเสร็จค่อยดึงจอถัดไป) · ไม่ตอบแทน
const HCF = { cur: '', at: 0, seen: {} };
setInterval(() => {
    if (CFG.hcFocus === false) return;
    const now = Date.now(), wait = Object.values(S.peers).filter((p) => now - p.ts < 30000 && p.kd && p.kd.k === 'captcha');
    for (const t of Object.keys(HCF.seen)) if (!wait.some((p) => p.tab === t)) delete HCF.seen[t];
    if (HCF.cur && wait.some((p) => p.tab === HCF.cur) && now - HCF.at < 90000) return;      // จอที่ดึงไว้ยังรอตอบ
    const p = wait.filter((x) => x.targetId && x.tab !== HCF.cur && !HCF.seen[x.tab]).sort((a, b) => hcLeft(a, now) - hcLeft(b, now))[0];
    if (!p) { if (HCF.cur && !wait.some((x) => x.tab === HCF.cur)) HCF.cur = ''; return; }
    const g = groupOf(p.group); if (!g) return;
    HCF.cur = p.tab; HCF.at = now; HCF.seen[p.tab] = now;
    focusTarget(g, p.targetId).then(() => say(`🧩 ${p.name} ถูกเช็คผู้เล่น — ดึงหน้าต่างขึ้นมาให้แล้ว${hcText(p, now) ? ' (' + hcText(p, now) + ')' : ''}`)).catch(() => {});
}, 2000);
// จับเหตุการณ์ฝั่ง Manager (หน้าเว็บมือถือปิดอยู่ก็ยังเตือน) — ตัวละครทุกเครื่อง (รวมเครื่องลูก)
const PUSHST = {};
setInterval(() => {
    if (!RM.subs.length) return;
    const now = Date.now(), G = new Map(allGroups().map((g) => [g.id, g]));
    for (const p of allPeers()) {
        const g = G.get(p.group), on = now - p.ts < 30000;
        const k = !on ? (g && g.debug && now - p.ts < 300000 ? 'off' : '') : (p.kd && p.kd.k) || '';
        const prev = PUSHST[p.tab] || { k, at: now };
        const hl = k === 'captcha' ? hcLeft(p, now) : -1;
        if (k === 'captcha' && prev.k === k && RM.push.captcha && !prev.late && hl >= 0 && hl <= 60) {      // ใกล้หมดเวลาแล้วยังไม่ตอบ → เตือนซ้ำ
            pushAll({ title: `⏰ เช็คผู้เล่นใกล้หมดเวลา! ${p.name}`, body: hcText(p, now) + ' · ตอบในหน้าเกมด่วน', tag: p.tab + 'captcha', kind: 'captcha', url: RM.url || '/' }).catch(() => {});
            prev.late = true; PUSHST[p.tab] = prev; continue;
        }
        if (['captcha', 'dead', 'jail', 'off'].includes(k) && RM.push[k] && (prev.k !== k || (k === 'captcha' && now - prev.at > 180000))) {
            const where = (p.mach ? p.mach + ' · ' : '') + (p.group ? String(p.group).replace(/^[a-z0-9]{6}__/, '') : '');
            pushAll({ title: { captcha: `🧩 Captcha! ${p.name}`, dead: `💀 ${p.name} ตาย`, jail: `⛓️ ${p.name} ติดคุก`, off: `⚫ ${p.name} ขาดการติดต่อ` }[k], body: (where ? where + ' · ' : '') + (k === 'captcha' && hcText(p, now) ? hcText(p, now) + ' · ' : '') + 'กดเพื่อเปิด Manager', tag: p.tab + k, kind: k, url: RM.url || '/' });
            PUSHST[p.tab] = { k, at: now }; continue;
        }
        if (prev.k !== k || !PUSHST[p.tab]) PUSHST[p.tab] = { k, at: now };
    }
}, 4000);

const RM_DENY = /^\/api\/(gamefiles\/open|app\/|script\/upload|quit|config|remote|link|setup|policy|links|group\/add|group\/del|tmclone|repair|rpc)/;
// หน้าล็อกอินมือถือ: แป้นตัวเลขบนหน้าเว็บ กดได้ทันที (ไม่ต้องแตะช่องให้คีย์บอร์ดขึ้น) · ครบจำนวนหลักของ PIN = เข้าสู่ระบบเอง · PIN มีตัวอักษร → ใช้คีย์บอร์ด
const LOGIN_HTML = (msg) => `<!doctype html><html lang="th" translate="no" class="notranslate"><head><meta charset="utf-8"><meta name="google" content="notranslate"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"><title>Aetherack Manager</title><meta name="theme-color" content="#16181c"><link rel="manifest" href="/manifest.webmanifest"><link rel="apple-touch-icon" href="/icon.png"><meta name="apple-mobile-web-app-capable" content="yes">
<style>*{-webkit-tap-highlight-color:transparent}body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#16181c;color:#e8e6e1;font-family:"Noto Sans Thai",system-ui,sans-serif;user-select:none;-webkit-user-select:none}form{width:min(340px,92vw);background:#1f2228;border:1px solid #33363d;border-radius:14px;padding:22px}h1{font-size:20px;margin:0 0 4px;color:#e8b04a;text-align:center}p{color:#9a9ca3;font-size:13px;margin:0 0 14px;text-align:center}
#dots{display:flex;justify-content:center;gap:12px;height:22px;margin:6px 0 16px}#dots i{width:14px;height:14px;border-radius:50%;border:2px solid #e8b04a;box-sizing:border-box}#dots i.f{background:#e8b04a}
.kp{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.kp button{height:62px;border:1px solid #33363d;border-radius:12px;background:#101114;color:#e8e6e1;font-size:26px;font-weight:600;touch-action:manipulation}.kp button:active{background:#e8b04a;color:#1a1405}.kp .ok{background:#e8b04a;color:#1a1405;font-size:18px}.kp .bk{font-size:20px}
#pw{width:100%;box-sizing:border-box;padding:12px;border-radius:8px;border:1px solid #33363d;background:#101114;color:#e8e6e1;font-size:20px;letter-spacing:4px;text-align:center;display:none;margin-bottom:10px}.kb #pw{display:block}.kb .kp,.kb #dots{display:none}.kb #go{display:block}
#go{display:none;width:100%;padding:12px;border:0;border-radius:8px;background:#e8b04a;color:#1a1405;font-weight:700;font-size:16px}.sw{display:block;text-align:center;margin-top:14px;color:#9a9ca3;font-size:13px;text-decoration:underline;background:none;border:0;width:100%}.e{color:#ff6b6b;font-size:14px;margin-top:12px;text-align:center}</style></head>
<body><form action="#" id="f" autocomplete="off" onsubmit="return false"><h1>Aetherack Manager</h1><p>ใส่ PIN ที่ตั้งไว้ในหน้า ตั้งค่า → ใช้จากมือถือ (บนคอม)</p>
<input type="text" id="pw" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" data-lpignore="true" data-1p-ignore style="-webkit-text-security:disc"><div id="dots"></div>
<div class="kp">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => `<button type="button" data-k="${n}">${n}</button>`).join('')}<button type="button" class="bk" data-k="b">⌫</button><button type="button" data-k="0">0</button><button type="button" class="ok" data-k="ok">เข้า</button></div>
<button type="button" id="go" onclick="">เข้าสู่ระบบ</button><button type="button" class="sw" id="sw">PIN มีตัวอักษร? ใช้คีย์บอร์ด</button>${msg ? `<div class="e">${String(msg).replace(/[<>&"]/g, '')}</div>` : ''}</form>
<script>(function(){var L=${RM.pinDig ? +RM.pinLen || 0 : 0},f=document.getElementById('f'),pw=document.getElementById('pw'),d=document.getElementById('dots'),sent=false;
function draw(){var n=Math.max(L||6,pw.value.length),h='';for(var i=0;i<n;i++)h+='<i class="'+(i<pw.value.length?'f':'')+'"></i>';d.innerHTML=h;}
var er=document.querySelector('.e');function msg(m){if(!er){er=document.createElement('div');er.className='e';f.appendChild(er);}er.textContent=m;}
function go(){if(sent||pw.value.length<6)return;sent=true;msg('');fetch('/login',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Login-Js':'1'},body:'pw='+encodeURIComponent(pw.value),credentials:'same-origin'}).then(function(r){return r.json().catch(function(){return{ok:false,err:'HTTP '+r.status};});}).then(function(j){if(j.ok){location.replace('/');return;}sent=false;pw.value='';draw();msg(j.err||'เข้าสู่ระบบไม่สำเร็จ');if(navigator.vibrate)navigator.vibrate([80,60,80]);}).catch(function(){sent=false;msg('ติดต่อ Manager ไม่ได้ — ลองใหม่');});}
document.querySelector('.kp').addEventListener('click',function(e){var b=e.target.closest('button');if(!b||sent)return;var k=b.getAttribute('data-k');if(navigator.vibrate)navigator.vibrate(15);
if(k==='b')pw.value=pw.value.slice(0,-1);else if(k==='ok'){go();return;}else if(pw.value.length<32)pw.value+=k;draw();if(L&&pw.value.length===L)setTimeout(go,120);});
document.addEventListener('keydown',function(e){if(f.className)return;if(/^[0-9]$/.test(e.key)){pw.value+=e.key;draw();if(L&&pw.value.length===L)go();}else if(e.key==='Backspace'){pw.value=pw.value.slice(0,-1);draw();}else if(e.key==='Enter'){e.preventDefault();go();}});
document.getElementById('go').onclick=function(){go();};document.getElementById('sw').onclick=function(){f.className=f.className?'':'kb';pw.value='';draw();if(f.className)pw.focus();};
f.addEventListener('submit',function(e){e.preventDefault();go();});draw();})();</script></body></html>`;
// คำขอจากนอกเครื่อง (ผ่านลิงก์) → ตรวจล็อกอิน · คืน true ถ้าจัดการตอบไปแล้ว (หยุดต่อ)
async function rmGate(req, res, url) {
    if (!RM.on || !RM.host || String(req.headers.host || '').toLowerCase() !== RM.host) { res.writeHead(403); res.end(); return true; }
    const sec = { 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };
    if (url.pathname === '/rm-alive') { res.writeHead(200, Object.assign({ 'Content-Type': 'text/plain' }, sec)); res.end(RM.nonce); return true; }
    if (url.pathname === '/login') {
        if (req.method === 'POST') {
            let d = ''; await new Promise((ok) => { req.on('data', (c) => { d += c; if (d.length > 2000) req.destroy(); }); req.on('end', ok); });
            const r = rmLogin(req, new URLSearchParams(d).get('pw') || '');
            const js = req.headers['x-login-js'] === '1', ck = r.tok ? `aeth_s=${r.tok}; Path=/; Max-Age=${30 * 86400}; HttpOnly; Secure; SameSite=Strict` : '';
            if (js) { if (!r.tok) await sleep(800); res.writeHead(r.tok ? 200 : 401, Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, r.tok ? { 'Set-Cookie': ck } : {}, sec)); res.end(JSON.stringify(r.tok ? { ok: true } : { ok: false, err: r.err })); return true; }
            if (r.tok) { res.writeHead(303, Object.assign({ Location: '/', 'Set-Cookie': `aeth_s=${r.tok}; Path=/; Max-Age=${30 * 86400}; HttpOnly; Secure; SameSite=Strict` }, sec)); res.end(); return true; }
            await sleep(800); res.writeHead(401, Object.assign({ 'Content-Type': 'text/html; charset=utf-8' }, sec)); res.end(LOGIN_HTML(r.err)); return true;
        }
        res.writeHead(200, Object.assign({ 'Content-Type': 'text/html; charset=utf-8' }, sec)); res.end(LOGIN_HTML('')); return true;
    }
    if (url.pathname === '/logout') { const t = rmCookie(req); if (t) { RM.sess = RM.sess.filter((q) => q.h !== sha(t)); rmSave(); } res.writeHead(303, Object.assign({ Location: '/login', 'Set-Cookie': 'aeth_s=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Strict' }, sec)); res.end(); return true; }
    if (/^\/(icon\.png|manifest\.webmanifest|sw\.js)$/.test(url.pathname)) return false;      // หน้าจอโฮมของมือถือดึงไอคอนโดยไม่มีคุกกี้
    if (!rmSession(req)) {
        if (url.pathname.startsWith('/api/')) send(res, 401, { ok: false, err: 'ต้องล็อกอินใหม่' });
        else { res.writeHead(303, Object.assign({ Location: '/login' }, sec)); res.end(); }
        return true;
    }
    if (/^\/aetherack\./.test(url.pathname) || RM_DENY.test(url.pathname)) { send(res, 403, { ok: false, err: 'ทำได้เฉพาะบนเครื่องคอม' }); return true; }
    req.remote = true; return false;
}
// มือถือขอรับแจ้งเตือน (Web Push) / ทดสอบ / ตั้งเรื่องที่เตือน — ทำจากมือถือได้
function rmPushApi(b, req) {
    if (b.op === 'key') return { key: vapidPub() };
    if (b.op === 'sub') {
        const s = b.sub || {}; if (!/^https:\/\//.test(String(s.endpoint || '')) || !s.keys || !s.keys.p256dh || !s.keys.auth) throw Error('ข้อมูลการแจ้งเตือนไม่ถูกต้อง');
        RM.subs = RM.subs.filter((x) => x.endpoint !== s.endpoint); RM.subs.push({ endpoint: String(s.endpoint).slice(0, 800), keys: { p256dh: String(s.keys.p256dh).slice(0, 200), auth: String(s.keys.auth).slice(0, 100) }, at: Date.now(), ua: String(req.headers['user-agent'] || '').slice(0, 120) });
        if (RM.subs.length > 10) RM.subs.splice(0, RM.subs.length - 10); rmSave(); say(`🔔 เพิ่มมือถือรับแจ้งเตือน (${RM.subs.length} เครื่อง)`); return {};
    }
    if (b.op === 'unsub') { RM.subs = RM.subs.filter((x) => x.endpoint !== b.endpoint); rmSave(); return {}; }
    if (b.op === 'test') return { n: 0, wait: pushAll({ title: '🔔 ทดสอบแจ้งเตือน', body: 'Aetherack Manager แจ้งเตือนเข้ามือถือได้แล้ว', tag: 'test', kind: 'test', url: RM.url || '/' }) };
    if (b.op === 'set') { for (const k of Object.keys(RM.push)) if (typeof (b.push || {})[k] === 'boolean') RM.push[k] = b.push[k]; rmSave(); return {}; }
    return null;
}
if (RM.on) setTimeout(() => cfStart(false), 2500);

// ---------------------------------------------------------------
// 🖥️ หลายเครื่อง (เน็ตวงเดียวกันในบ้าน): เครื่องหลัก 1 + เครื่องลูก — แต่ละเครื่องคุม Chrome ของตัวเอง (กติกา 3 จอ/เครื่องเหมือนเดิม)
// เครื่องลูกส่งสถานะมาให้เครื่องหลักทุก 3 วิ · กดคำสั่งกับตัวละคร/โปรไฟล์ของอีกเครื่อง → ส่งไปทำที่เครื่องนั้น · คำสั่ง "ทุกจอ" ทำทุกเครื่อง
// ทุกคำขอเซ็นด้วยรหัสคู่เครื่อง (HMAC + เวลา) · ไม่ส่งรหัสพร็อกซี/Webhook ข้ามเครื่อง · สั่งอัปเดต/ปิดโปรแกรม/แก้ตั้งค่าข้ามเครื่องไม่ได้
// ---------------------------------------------------------------
const LK_DENY = /^\/api\/(app\/|script\/upload|quit|config|remote|link|setup|policy|links|group\/add|group\/del|tmclone|repair|rpc|loginids|focusall|minall|arrange|ground)/;
const LK_BCAST = /^\/api\/(all\/cmd|startall|stopall|updateall)$/;
const LK_RE = /([a-z0-9]{6})__/;
const lkCfg = () => { const l = CFG.link || (CFG.link = {}); if (!l.sid) { l.sid = crypto.randomBytes(8).toString('hex').replace(/[^a-z0-9]/g, '').slice(0, 6).padEnd(6, '0'); l.role = l.role || 'off'; saveConfig(CFG); } return l; };
const LINK = { srv: null, subs: {}, q: {}, pend: new Map(), view: null, st: 'ปิดอยู่', err: '', at: 0, fails: {} };
const lkPort = () => +(lkCfg().lport) || CFG.port + 1;
function lanIps() { const r = []; for (const [n, l] of Object.entries(os.networkInterfaces())) for (const a of l || []) if (a.family === 'IPv4' && !a.internal && !/^169\.254\./.test(a.address)) r.push({ ip: a.address, n }); return r.sort((a, b) => (/^192\.168\./.test(b.ip) - /^192\.168\./.test(a.ip)) || (/virtual|vmware|vbox|hyper-v|wsl|vethernet/i.test(a.n) - /virtual|vmware|vbox|hyper-v|wsl|vethernet/i.test(b.n))); }
const lkSign = (key, ts, sid, p, raw) => crypto.createHmac('sha256', key).update(`${ts}.${sid}.${p}.${raw}`).digest('hex');
// ข้อมูลที่ส่งข้ามเครื่อง: ตัด proxy เต็ม (มีรหัส) ออก
const lkGroups = () => publicGroups().map((g) => { const o = Object.assign({}, g); delete o.proxyRaw; return o; });
const lkPeers = () => Object.values(S.peers);
const pre = (sid, id) => (id ? sid + '__' + id : id);
function lkMap(sid, name, off, peers, groups) {
    return {
        peers: (peers || []).map((p) => Object.assign({}, p, { tab: pre(sid, p.tab), group: pre(sid, p.group), ts: (+p.ts || 0) + off, mach: name, msid: sid })),
        groups: (groups || []).map((g) => Object.assign({}, g, { id: pre(sid, g.id), oid: g.id, mach: name, msid: sid })),
    };
}
// ทุกตัวละคร/โปรไฟล์จากเครื่องอื่น (ตัวเครื่องนี้ไม่รวม) — เครื่องหลัก: จากเครื่องลูกทุกตัว · เครื่องลูก: จากภาพรวมที่เครื่องหลักส่งมา
function lkOthers(exceptSid) {
    const l = lkCfg(), out = { peers: [], groups: [], machines: [] };
    if (l.role === 'main') {
        for (const [sid, s] of Object.entries(LINK.subs)) {
            if (sid === exceptSid) continue;
            const m = lkMap(sid, s.name, s.off, s.peers, s.groups); out.peers.push(...m.peers); out.groups.push(...m.groups);
            out.machines.push({ sid, name: s.name, ip: s.ip, at: s.at, v: s.v, n: (s.peers || []).filter((p) => Date.now() - (+p.ts || 0) - s.off < 30000).length, online: Date.now() - s.at < 15000, sys: s.sys });
        }
    } else if (l.role === 'sub' && LINK.view) {
        const v = LINK.view; out.peers = v.peers.map((p) => Object.assign({}, p, { ts: p.ts + v.off })); out.groups = v.groups; out.machines = v.machines;
    }
    return out;
}
const allPeers = () => Object.values(S.peers).concat(lkOthers().peers);
const allGroups = () => publicGroups().concat(lkOthers().groups);
// ภาพรวมที่เครื่องหลักส่งให้เครื่องลูก sid (ทุกเครื่อง ยกเว้นตัวมันเอง · เวลาเป็นของเครื่องหลัก)
function lkViewFor(sid) {
    const l = lkCfg(), me = lkMap(l.sid, l.name || os.hostname(), 0, lkPeers(), lkGroups()), o = lkOthers(sid);
    const ev = EV.slice(-200).map((e) => Object.assign({}, e, { mach: l.name || os.hostname(), group: pre(l.sid, e.group) }));
    for (const [s2, s] of Object.entries(LINK.subs)) if (s2 !== sid) for (const e of (s.ev || []).slice(-100)) ev.push(Object.assign({}, e, { at: e.at + s.off, mach: s.name, group: pre(s2, e.group) }));
    return { now: Date.now(), ev, peers: me.peers.concat(o.peers), groups: me.groups.concat(o.groups), machines: [{ sid: l.sid, name: l.name || os.hostname(), main: true, online: true, at: Date.now(), n: Object.values(S.peers).filter((p) => Date.now() - p.ts < 30000).length }].concat(o.machines) };
}
// เรียก API ของเครื่องตัวเอง (ทำงานเหมือนกดจากหน้า Manager บนเครื่องนี้)
function selfReq(method, p, b) {
    return new Promise((resolve) => {
        const data = method === 'GET' ? '' : JSON.stringify(b || {});
        const r = http.request({ host: '127.0.0.1', port: CFG.port, method, path: p, headers: { 'X-Aeth': '1', 'X-Link-From': '1', 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) }, timeout: 60000 }, (x) => { let d = ''; x.setEncoding('utf8'); x.on('data', (c) => { d += c; }); x.on('end', () => { let j; try { j = JSON.parse(d); } catch (e) { j = { ok: false, err: 'HTTP ' + x.statusCode }; } resolve({ code: x.statusCode, body: j }); }); });
        r.on('error', (e) => resolve({ code: 502, body: { ok: false, err: e.message } })).on('timeout', () => r.destroy(Error('หมดเวลา'))); r.end(data);
    });
}
// แทนที่ "sid__" ใน path/ข้อมูล → id จริงของเครื่องปลายทาง
function lkStrip(sid, p, b) { const re = new RegExp(sid + '__', 'g'); return { p: p.replace(re, ''), b: b === undefined ? undefined : JSON.parse(JSON.stringify(b).replace(re, '')) }; }
function lkFind(p, b) { const s = p + ' ' + (b === undefined ? '' : JSON.stringify(b)), re = new RegExp(LK_RE.source, 'g'); let m; const l = lkCfg(); while ((m = re.exec(s))) { const sid = m[1]; if (sid === l.sid || LINK.subs[sid] || (LINK.view && LINK.view.machines.some((x) => x.sid === sid))) return sid; } return ''; }
// เครื่องหลัก: ส่งคำสั่งไปเครื่องลูก sid แล้วรอผล
function lkToSub(sid, method, p, b) {
    const s = LINK.subs[sid]; if (!s || Date.now() - s.at > 20000) return Promise.resolve({ code: 503, body: { ok: false, err: `เครื่อง ${s ? s.name : sid} ไม่ได้เชื่อมต่ออยู่` } });
    const id = crypto.randomBytes(8).toString('hex');
    return new Promise((resolve) => {
        const to = setTimeout(() => { LINK.pend.delete(id); resolve({ code: 504, body: { ok: false, err: `เครื่อง ${s.name} ไม่ตอบ` } }); }, 45000);
        LINK.pend.set(id, (r) => { clearTimeout(to); resolve(r); });
        (LINK.q[sid] || (LINK.q[sid] = [])).push({ id, method, p, b }); lkFlush(sid);
    });
}
// เครื่องหลัก: จัดการคำขอที่มาจากเครื่องลูก (from) หรือจากหน้าเว็บ · bcast = ทำทุกเครื่อง
async function lkRoute(method, p, b, from, bcast) {
    const l = lkCfg();
    if (LK_DENY.test(p)) return { code: 403, body: { ok: false, err: 'คำสั่งนี้ทำข้ามเครื่องไม่ได้' } };
    if (bcast) {
        const subs = Object.keys(LINK.subs).filter((sid) => sid !== from && Date.now() - LINK.subs[sid].at < 20000);
        const rs = await Promise.all([from ? selfReq(method, p, b) : null].concat(subs.map((sid) => lkToSub(sid, method, p, b))));
        const n = rs.reduce((a, r) => a + ((r && r.body && +r.body.n) || 0), 0); return { code: 200, body: { ok: true, n } };
    }
    const sid = lkFind(p, b);
    if (!sid || sid === l.sid) { const x = sid ? lkStrip(sid, p, b) : { p, b }; return selfReq(method, x.p, x.b); }
    const x = lkStrip(sid, p, b); return lkToSub(sid, method, x.p, x.b);
}
function lkFlush(sid) { const s = LINK.subs[sid], q = LINK.q[sid]; if (!s || !s.wait || !q || !q.length) return; const w = s.wait; s.wait = null; clearTimeout(w.t); send(w.res, 200, { ok: true, cmds: q.splice(0, 20) }); }
// เครื่องหลัก: พอร์ตสำหรับเครื่องลูก (เปิดเฉพาะตอนเป็นเครื่องหลัก)
function lkAuth(req, raw, p) {
    const l = lkCfg(), ip = String(req.socket.remoteAddress || '').replace(/^::ffff:/, ''), f = LINK.fails[ip] || (LINK.fails[ip] = { n: 0, until: 0 });
    if (Date.now() < f.until) return { why: 'block' };
    const ts = +req.headers['x-lk-ts'] || 0, sid = String(req.headers['x-lk-sid'] || ''), sig = String(req.headers['x-lk-sig'] || '');
    if (!/^[a-z0-9]{6}$/.test(sid)) return { why: 'sig' };
    if (sid === l.sid) return { why: 'dupsid' };      // คัดลอกโฟลเดอร์ Manager มาทั้งชุด → เลขประจำเครื่องซ้ำ → ให้เครื่องลูกสุ่มใหม่
    if (Math.abs(Date.now() - ts) > 300000) return { why: 'time' };      // นาฬิกา 2 เครื่องไม่ตรงกัน → เครื่องลูกปรับเวลาที่ใช้เซ็นตามเครื่องหลัก
    const good = l.key && sig.length === 64 && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(lkSign(l.key, ts, sid, p, raw)));
    if (!good) { if (++f.n >= 20) { f.until = Date.now() + 600000; f.n = 0; say(`🖥️ มีเครื่อง ${ip} ใช้รหัสคู่เครื่องผิดหลายครั้ง — บล็อก 10 นาที`); } return { why: 'sig' }; }
    f.n = 0; return { sid };
}
function lkServe() {
    const l = lkCfg();
    if (l.role !== 'main' || !l.key) { if (LINK.srv) { try { LINK.srv.close(); } catch (e) { /* ignore */ } LINK.srv = null; } if (l.role !== 'sub') LINK.st = 'ปิดอยู่'; return; }
    if (LINK.srv) return;
    const srv = http.createServer((req, res) => {
        let raw = ''; req.setEncoding('utf8'); req.on('data', (c) => { raw += c; if (raw.length > 8e6) req.destroy(); });      // utf8 ทั้งก้อน: ตัวอักษรไทยที่ถูกตัดคร่อมก้อนข้อมูลไม่เพี้ยน (ไม่งั้นลายเซ็นไม่ตรง)
        req.on('end', async () => {
            try {
                const p = new URL(req.url, 'http://x').pathname, au = req.method === 'POST' ? lkAuth(req, raw, p) : { why: 'sig' }, sid = au.sid;
                if (!sid) { send(res, 403, { ok: false, why: au.why, now: au.why === 'time' ? Date.now() : undefined }); return; }
                const b = raw ? JSON.parse(raw) : {}, ip = String(req.socket.remoteAddress || '').replace(/^::ffff:/, '');
                if (p === '/link/sync') {
                    const known = !!LINK.subs[sid], s = LINK.subs[sid] || (LINK.subs[sid] = {});
                    Object.assign(s, { name: String(b.name || sid).slice(0, 30), ip, at: Date.now(), v: String(b.v || ''), off: Date.now() - (+b.now || Date.now()), peers: Array.isArray(b.peers) ? b.peers.slice(0, 200) : [], groups: Array.isArray(b.groups) ? b.groups.slice(0, 60) : [], ev: Array.isArray(b.ev) ? b.ev.slice(-200) : [], sys: b.sys || null });
                    if (!known) say(`🖥️ เครื่องลูก ${s.name} (${ip}) เชื่อมต่อแล้ว`);
                    send(res, 200, Object.assign({ ok: true }, lkViewFor(sid))); return;
                }
                if (p === '/link/wait') {      // รอคำสั่ง (ค้างไว้สูงสุด 25 วิ)
                    const s = LINK.subs[sid]; if (!s) { send(res, 200, { ok: true, cmds: [] }); return; }
                    if (s.wait) { clearTimeout(s.wait.t); send(s.wait.res, 200, { ok: true, cmds: [] }); }
                    s.wait = { res, t: setTimeout(() => { if (s.wait && s.wait.res === res) { s.wait = null; send(res, 200, { ok: true, cmds: [] }); } }, 25000) };
                    res.on('close', () => { if (s.wait && s.wait.res === res) { clearTimeout(s.wait.t); s.wait = null; } });
                    lkFlush(sid); return;
                }
                if (p === '/link/res') { const f = LINK.pend.get(String(b.id || '')); if (f) { LINK.pend.delete(b.id); f({ code: +b.code || 200, body: b.body || {} }); } send(res, 200, { ok: true }); return; }
                if (p === '/link/fwd') { const r = await lkRoute(b.method === 'GET' ? 'GET' : 'POST', String(b.p || ''), b.b, sid, !!b.bcast); send(res, 200, { ok: true, r }); return; }
                send(res, 404, { ok: false });
            } catch (e) { send(res, 500, { ok: false, err: e.message }); }
        });
    });
    srv.on('error', (e) => { LINK.st = `❌ เปิดพอร์ต ${lkPort()} ไม่ได้: ${e.code || e.message}`; LINK.srv = null; if (e.code === 'EADDRINUSE' && (LINK.retry = (LINK.retry || 0) + 1) <= 10) setTimeout(lkServe, 3000); });      // รีสตาร์ท: ตัวเก่ายังไม่ปล่อยพอร์ต
    srv.listen(lkPort(), '0.0.0.0', () => { LINK.st = 'เปิดรับเครื่องลูกอยู่'; say(`🖥️ เครื่องหลัก: รอเครื่องลูกที่พอร์ต ${lkPort()} (${lanIps().map((x) => x.ip).join(', ') || 'ไม่พบ IP ในบ้าน'})`); });
    LINK.srv = srv;
}
// เครื่องลูก: ส่งคำขอไปเครื่องหลัก (เซ็นทุกครั้ง)
function lkCall(p, b, timeout) {
    const l = lkCfg(), m = /^([\w.-]+):(\d+)$/.exec(l.main || '');
    if (!m) return Promise.reject(Error('ยังไม่ได้ใส่รหัสเชื่อมต่อของเครื่องหลัก'));
    const raw = JSON.stringify(b || {}), ts = Date.now() + (LINK.skew || 0);
    return new Promise((resolve, reject) => {
        const r = http.request({ host: m[1], port: +m[2], method: 'POST', path: p, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(raw), 'X-Lk-Sid': l.sid, 'X-Lk-Ts': ts, 'X-Lk-Sig': lkSign(l.key, ts, l.sid, p, raw) }, timeout: timeout || 10000 }, (x) => {
            let d = ''; x.setEncoding('utf8'); x.on('data', (c) => { d += c; }); x.on('end', () => {
                if (x.statusCode === 403) {
                    let j = {}; try { j = JSON.parse(d); } catch (e) { /* ignore */ }
                    if (j.why === 'time' && +j.now) { LINK.skew = +j.now - Date.now(); reject(Error('นาฬิกา 2 เครื่องไม่ตรงกัน — ปรับให้แล้ว กำลังลองใหม่')); return; }
                    if (j.why === 'dupsid') { l.sid = ''; lkCfg(); reject(Error('เลขประจำเครื่องซ้ำกับเครื่องหลัก — สุ่มใหม่แล้ว กำลังลองใหม่')); return; }
                    reject(Error(j.why === 'block' ? 'เครื่องหลักบล็อกชั่วคราว (ใส่รหัสผิดหลายครั้ง) — รอ 10 นาที หรือปิดเปิด Manager เครื่องหลัก' : 'รหัสเชื่อมต่อไม่ถูกต้อง — คัดลอกจากเครื่องหลักใหม่')); return;
                }
                try { resolve(JSON.parse(d)); } catch (e) { reject(Error('HTTP ' + x.statusCode)); }
            });
        });
        r.on('error', (e) => reject(Error(e.code === 'ECONNREFUSED' ? 'เครื่องหลักไม่ได้เปิดรับ (ปิด Manager อยู่ / ยังไม่ได้ตั้งเป็นเครื่องหลัก)' : e.code === 'ETIMEDOUT' || e.code === 'EHOSTUNREACH' ? 'ติดต่อเครื่องหลักไม่ได้ (คนละวงเน็ต / Firewall บล็อก)' : e.message))).on('timeout', () => r.destroy(Error('ติดต่อเครื่องหลักไม่ได้ (หมดเวลา)'))); r.end(raw);
    });
}
let lkGen = 0;
async function lkSubLoops() {
    const gen = ++lkGen, l = lkCfg(); if (l.role !== 'sub') { LINK.view = null; return; }
    LINK.st = 'กำลังเชื่อมต่อ…';
    (async () => {      // ส่งสถานะทุก 3 วิ → ได้ภาพรวมทุกเครื่องกลับมา
        let was = false;
        while (gen === lkGen) {
            try {
                const j = await lkCall('/link/sync', { name: l.name || os.hostname(), v: VERSION, now: Date.now(), peers: lkPeers(), groups: lkGroups(), ev: EV.slice(-200), sys: { cpu: S.cpu.pct, memTotal: os.totalmem(), memFree: os.freemem() } });
                if (gen !== lkGen) return;
                LINK.view = { off: Date.now() - (+j.now || Date.now()), peers: j.peers || [], groups: j.groups || [], machines: j.machines || [], ev: j.ev || [] };
                LINK.at = Date.now(); LINK.err = ''; LINK.st = 'เชื่อมต่อแล้ว'; if (!was) { was = true; say(`🖥️ เชื่อมต่อเครื่องหลัก ${(LINK.view.machines.find((x) => x.main) || {}).name || l.main} แล้ว`); }
            } catch (e) { LINK.err = e.message; LINK.st = '❌ ' + e.message; if (was) { was = false; say('🖥️ หลุดจากเครื่องหลัก: ' + e.message); } }
            await sleep(3000);
        }
    })();
    (async () => {      // รอคำสั่งจากเครื่องหลัก → ทำที่เครื่องนี้ → ส่งผลกลับ
        while (gen === lkGen) {
            let j = null; try { j = await lkCall('/link/wait', {}, 35000); } catch (e) { await sleep(3000); continue; }
            for (const c of (j && j.cmds) || []) {
                (async () => {
                    const r = LK_DENY.test(String(c.p)) || !/^\/api\//.test(String(c.p)) ? { code: 403, body: { ok: false, err: 'คำสั่งนี้ทำข้ามเครื่องไม่ได้' } } : await selfReq(c.method === 'GET' ? 'GET' : 'POST', String(c.p), c.b);
                    lkCall('/link/res', { id: c.id, code: r.code, body: r.body }).catch(() => {});
                })();
            }
        }
    })();
}
function lkApply() { lkServe(); lkSubLoops(); }
setTimeout(lkApply, 1500);
// ดักคำขอจากหน้าเว็บ: เป็นของเครื่องอื่น → ส่งต่อ · คำสั่งทุกจอ → ทำเครื่องนี้ + ส่งให้เครื่องอื่นด้วย · คืน true = ตอบไปแล้ว
async function lkIntercept(req, res, p) {
    const l = lkCfg(); if (l.role !== 'main' && l.role !== 'sub') return false;
    if (req.headers['x-link-from'] || !p.startsWith('/api/') || /^\/api\/(peer|hello|ver|state|ev|gamefiles|app\/upload|script\/upload)$/.test(p)) return false;
    let b; if (req.method === 'POST') { b = await body(req, 2e6); req._b = b; }
    if (req.method === 'POST' && LK_BCAST.test(p) && !(b && b.group && lkFind('', b.group))) {      // ทำที่เครื่องนี้ตามปกติ + ส่งต่อ
        if (l.role === 'main') lkRoute('POST', p, b, '', true).catch(() => {});
        else lkCall('/link/fwd', { method: 'POST', p, b, bcast: true }, 60000).catch(() => {});
        return false;
    }
    const sid = lkFind(p, b); if (!sid || sid === l.sid) return false;
    if (LK_DENY.test(p)) { send(res, 403, { ok: false, err: 'คำสั่งนี้ทำกับเครื่องอื่นไม่ได้ (ทำที่เครื่องนั้นแทน)' }); return true; }
    let r;
    if (l.role === 'main') { const x = lkStrip(sid, p, b); r = await lkToSub(sid, req.method, x.p, x.b); }
    else { try { r = (await lkCall('/link/fwd', { method: req.method, p, b }, 60000)).r; } catch (e) { r = { code: 503, body: { ok: false, err: 'ติดต่อเครื่องหลักไม่ได้: ' + e.message } }; } }
    send(res, r && r.code ? r.code : 502, (r && r.body) || { ok: false, err: 'ไม่สำเร็จ' }); return true;
}
// หน้า ตั้งค่า → หลายเครื่อง
function lkApi(b) {
    const l = lkCfg();
    if (b.op === 'role') {
        const role = ['off', 'main', 'sub'].includes(b.role) ? b.role : 'off';
        if (role === 'main' && !l.key) l.key = crypto.randomBytes(18).toString('base64url');
        if (role === 'sub') {
            const m = /^AETH1:([\w.-]+):(\d+):([\w-]{16,64})$/.exec(String(b.code || '').trim());
            if (!m) throw Error('รหัสเชื่อมต่อไม่ถูกต้อง — คัดลอกจากเครื่องหลัก (ขึ้นต้นด้วย AETH1:)');
            l.main = `${m[1]}:${m[2]}`; l.key = m[3];
        }
        if (role !== 'main') { for (const s of Object.values(LINK.subs)) if (s.wait) { clearTimeout(s.wait.t); send(s.wait.res, 200, { ok: true, cmds: [] }); } LINK.subs = {}; }
        l.role = role; saveConfig(CFG); say(`🖥️ หลายเครื่อง: ${{ off: 'ปิด', main: 'ตั้งเป็นเครื่องหลัก', sub: 'ตั้งเป็นเครื่องลูก → ' + l.main }[role]}`); lkApply(); return {};
    }
    if (b.op === 'name') { l.name = String(b.name || '').trim().slice(0, 20) || os.hostname(); saveConfig(CFG); return {}; }
    if (b.op === 'rekey') { l.key = crypto.randomBytes(18).toString('base64url'); LINK.subs = {}; saveConfig(CFG); say('🖥️ เปลี่ยนรหัสคู่เครื่องใหม่ — เครื่องลูกทุกเครื่องต้องใส่รหัสใหม่'); return {}; }
    if (b.op === 'forget') { const s = LINK.subs[b.sid]; if (s && s.wait) { clearTimeout(s.wait.t); send(s.wait.res, 200, { ok: true, cmds: [] }); } delete LINK.subs[b.sid]; return {}; }
    throw Error('ไม่รู้จักคำสั่ง');
}
function lkState() {
    const l = lkCfg(), ip = (lanIps()[0] || {}).ip || '';
    return { role: l.role || 'off', sid: l.sid, name: l.name || os.hostname(), st: LINK.st, err: LINK.err, main: l.main || '', ips: lanIps().map((x) => x.ip), port: lkPort(), code: l.role === 'main' && l.key && ip ? `AETH1:${ip}:${lkPort()}:${l.key}` : '', machines: lkOthers().machines };
}

// 🧪 ตรวจไฟล์เกมอัตโนมัติ: เกมอัปเดต → สคริปต์ในเกมส่งไฟล์เกม (index-*.js / index-*.css ที่เบราว์เซอร์โหลดไว้แล้ว ไม่ยิงเซิร์ฟเวอร์เพิ่ม) มาให้ Manager
// → เก็บไว้ในโฟลเดอร์ gamefiles (4 รุ่นล่าสุด — ส่งให้ Claude ตรวจละเอียดได้เลย) → ตรวจว่าส่วนหน้าจอที่สคริปต์ใช้ (class) ยังมีอยู่ไหม เทียบกับรุ่นก่อน → แจ้งครั้งเดียวต่อรุ่น
const GF_DIR = path.join(ROOT, 'gamefiles'), GF_IDX = path.join(GF_DIR, 'index.json');
const GF = { vers: [], pend: {}, timers: {} };
try { const j = JSON.parse(fs.readFileSync(GF_IDX, 'utf8')); GF.vers = Array.isArray(j.vers) ? j.vers : []; } catch (e) { /* ยังไม่เคยเก็บ */ }
const gfSave = () => { try { fs.mkdirSync(GF_DIR, { recursive: true }); fs.writeFileSync(GF_IDX + '.tmp', JSON.stringify({ vers: GF.vers }, null, 1)); fs.renameSync(GF_IDX + '.tmp', GF_IDX); } catch (e) { /* ignore */ } };
const GF_NAME = /^index-[\w-]{4,40}\.(js|css)$/;
// class ที่สคริปต์ใช้หาส่วนของหน้าเกม (จาก querySelector / closest / matches และรายการ SELECTORS) + ชื่อฟีเจอร์จาก HEALTH_CHECKS
function gfScriptClasses() {
    const si = scriptInfo(); if (!si) return null;
    const s = si.src, cls = new Set();
    for (const m of s.matchAll(/(?:querySelector(?:All)?|closest|matches)\(\s*(['`"])(.*?)\1/g)) for (const c of m[2].matchAll(/\.([a-zA-Z][\w-]+)/g)) cls.add(c[1]);
    const sb = /const SELECTORS = \{([\s\S]*?)\n {4}\};/.exec(s); if (sb) for (const c of sb[1].matchAll(/\.([a-zA-Z][\w-]+)/g)) cls.add(c[1]);
    const feat = {}, core = new Set();
    for (const m of s.matchAll(/\{ id: '(\w+)', g: '\w+', label: '([^']*)', feat: '([^']*)', sel: '([^']*)'(, soft: true)?/g)) {
        const c = (/\.([a-zA-Z][\w-]+)/.exec(m[4]) || [])[1]; if (!c) continue;
        feat[c] = `${m[2]} → ${m[3]}`; if (!m[5]) core.add(c);
    }
    for (const c of [...cls]) if (/^(at-|at_|aeth)/.test(c)) cls.delete(c);
    return { v: si.version, cls: [...cls].sort(), feat, core };
}
const gfHas = (text, c) => new RegExp('(?<![\\w-])' + c.replace(/[-]/g, '\\-') + '(?![\\w-])').test(text);
function gfAnalyze(js, css) {
    const sc = gfScriptClasses(); if (!sc) return null;
    let text = ''; try { text = fs.readFileSync(path.join(GF_DIR, js), 'utf8'); } catch (e) { return null; }
    if (css) try { text += '\n' + fs.readFileSync(path.join(GF_DIR, css), 'utf8'); } catch (e) { /* ไม่มี css */ }
    const present = sc.cls.filter((c) => gfHas(text, c));
    const prev = GF.vers.find((v) => v.js !== js && v.rep && Array.isArray(v.rep.present));
    const gone = prev ? prev.rep.present.filter((c) => sc.cls.includes(c) && !present.includes(c)) : [];
    const coreMiss = [...sc.core].filter((c) => sc.cls.includes(c) && !present.includes(c));
    return { at: Date.now(), script: sc.v, checked: sc.cls.length, present, gone, coreMiss, base: prev ? prev.js : '', size: text.length, gameVer: (GF.vers.find((x) => x.js === js) || {}).gameVer || '',
        feat: Object.fromEntries([...new Set(gone.concat(coreMiss))].map((c) => [c, sc.feat[c] || ''])) };
}
function gfRun(js, quiet) {
    const v = GF.vers.find((x) => x.js === js); if (!v) return;
    const rep = gfAnalyze(js, v.css); if (!rep) return; const first = !v.rep; v.rep = rep; gfSave();
    const bad = rep.gone.length + rep.coreMiss.length, list = [...new Set(rep.gone.concat(rep.coreMiss))];
    const head = `🧪 ไฟล์เกมรุ่นใหม่ ${js}${rep.gameVer ? ' (v' + rep.gameVer + ')' : ''}`;
    const msg = bad ? `⚠️ ส่วนหน้าจอที่สคริปต์ใช้หายไป ${list.length} รายการ: ${list.slice(0, 12).map((c) => '.' + c + (rep.feat[c] ? ` (${rep.feat[c]})` : '')).join(' · ')}` : rep.base ? `✅ ส่วนหน้าจอที่สคริปต์ใช้ยังอยู่ครบ (${rep.present.length}/${rep.checked} · เทียบกับ ${rep.base})` : `✅ ส่วนหลักที่สคริปต์ใช้มีครบ (${rep.present.length}/${rep.checked}) · เก็บไว้เป็นรุ่นอ้างอิงสำหรับเทียบครั้งต่อไป`;
    say(`${head} — ${msg}`);
    if (quiet || !first) return;
    evAdd({ tab: '', name: '', topic: bad ? 'health' : 'gamever', title: bad ? `⚠️ เกมอัปเดต: สคริปต์อาจใช้ไม่ได้บางส่วน` : '🧪 เกมอัปเดต: ตรวจไฟล์เกมแล้ว ใช้ได้', desc: `${js} · ${msg}` });
    if (lkCfg().role === 'sub') return;      // ใช้หลายเครื่อง: แจ้งจากเครื่องหลักที่เดียว
    if (bad && RM.subs.length) pushAll({ title: '⚠️ เกมอัปเดต — สคริปต์อาจใช้ไม่ได้บางส่วน', body: `หายไป ${list.length} รายการ · ส่งไฟล์ในโฟลเดอร์ gamefiles ให้ Claude ตรวจ`, tag: 'gf' + js, kind: 'gm', url: RM.url || '/' }).catch(() => {});
    const L = CFG.links || {}, wh = L.discord;
    if (wh && !(L.dc && L.dc.gamefile === false)) httpsPost(wh, JSON.stringify({ username: 'Aetheria Tracker', allowed_mentions: { parse: [] }, embeds: [{ title: bad ? '⚠️ เกมอัปเดต — สคริปต์อาจใช้ไม่ได้บางส่วน' : '🧪 เกมอัปเดต — ตรวจไฟล์เกมแล้ว', description: `${js}${rep.gameVer ? ' · v' + rep.gameVer : ''}\n${msg}${bad ? '\n\n📂 ไฟล์เกมอยู่ในโฟลเดอร์ `gamefiles` ของ Manager — ส่งให้ Claude ตรวจละเอียดได้เลย' : ''}`, color: bad ? 0xf59e0b : 0x22c55e, timestamp: new Date().toISOString(), footer: { text: 'Aetherack Manager v' + VERSION } }] }), { 'Content-Type': 'application/json' }).catch(() => {});
}
function gfApi(b) {
    const now = Date.now();
    for (const [k, t] of Object.entries(GF.pend)) if (now - t > 180000) delete GF.pend[k];
    if (b.op === 'need') {      // สคริปต์บอกชื่อไฟล์ที่หน้าเกมโหลดอยู่ → ตอบเฉพาะที่ยังไม่มี (กันหลายจอส่งซ้ำ)
        const names = (Array.isArray(b.names) ? b.names : []).map(String).filter((n) => GF_NAME.test(n)).slice(0, 6);
        const need = names.filter((n) => !fs.existsSync(path.join(GF_DIR, n)) && !GF.pend[n]);
        for (const n of need) GF.pend[n] = now;
        return { need };
    }
    if (b.op === 'put') {
        const name = String(b.name || ''), text = typeof b.text === 'string' ? b.text : '';
        if (!GF_NAME.test(name) || text.length < 1000) throw Error('ไฟล์ไม่ถูกต้อง');
        fs.mkdirSync(GF_DIR, { recursive: true }); fs.writeFileSync(path.join(GF_DIR, name + '.tmp'), text); fs.renameSync(path.join(GF_DIR, name + '.tmp'), path.join(GF_DIR, name)); delete GF.pend[name];
        const kind = name.endsWith('.js') ? 'js' : 'css', set = (Array.isArray(b.set) ? b.set : []).map(String);
        let v = GF.vers.find((x) => x.js === name || x.css === name || (kind === 'css' && set.includes(x.js)));
        if (!v && kind === 'js') { v = { js: name, css: set.find((n) => /\.css$/.test(n)) || '', at: now }; GF.vers.unshift(v); }
        if (v && kind === 'css') v.css = name;
        if (v && b.ver && !v.gameVer) { const raw = String(b.ver).slice(0, 300); let gv = ''; try { const o = JSON.parse(raw); gv = String(o.version || o.v || o.build || '').slice(0, 40); } catch (e) { gv = (/\d+(?:\.\d+)+[\w.-]*/.exec(raw) || [''])[0]; } v.gameVer = gv; }      // เวอร์ชันเกมจาก /version.json ที่สคริปต์อ่านไว้
        while (GF.vers.length > 4) { const o = GF.vers.pop(); for (const f of [o.js, o.css]) if (f && !GF.vers.some((x) => x.js === f || x.css === f)) try { fs.unlinkSync(path.join(GF_DIR, f)); } catch (e) { /* ignore */ } }
        gfSave(); say(`🧪 รับไฟล์เกม ${name} (${Math.round(text.length / 1024)} KB)`);
        if (v) { clearTimeout(GF.timers[v.js]); GF.timers[v.js] = setTimeout(() => { delete GF.timers[v.js]; gfRun(v.js); }, 8000); }      // รอ css ของรุ่นนี้มาครบก่อนตรวจ (แยกตามรุ่น)
        return {};
    }
    if (b.op === 'recheck') { const v = GF.vers[0]; if (!v) throw Error('ยังไม่มีไฟล์เกม — เปิดเกมสักจอ (สคริปต์ 5.98.5 ขึ้นไป)'); gfRun(v.js, true); return {}; }
    if (b.op === 'status') return { dir: GF_DIR, vers: GF.vers.map((v) => ({ js: v.js, css: v.css, at: v.at, rep: v.rep ? { at: v.rep.at, checked: v.rep.checked, present: v.rep.present.length, gone: v.rep.gone, coreMiss: v.rep.coreMiss, base: v.rep.base, feat: v.rep.feat, gameVer: v.rep.gameVer, script: v.rep.script } : null })) };
    throw Error('ไม่รู้จักคำสั่ง');
}

const server = http.createServer(async (req, res) => {
    try {
        // กันเว็บอื่นยิงเข้ามา: Host ต้องเป็น 127.0.0.1/localhost และ API ต้องมี header X-Aeth (เว็บทั่วไปส่ง header นี้ข้ามโดเมนไม่ได้)
        const host = String(req.headers.host || '');
        const url = new URL(req.url, 'http://127.0.0.1');
        const isLocal = new RegExp(`^(127\\.0\\.0\\.1|localhost):${CFG.port}$`).test(host) && !req.headers['cf-connecting-ip'] && !req.headers['cf-ray'];
        if (!isLocal && await rmGate(req, res, url)) return;
        if (/^\/aetherack\.(user|meta|core)\.js$/.test(url.pathname)) {      // user/meta = ตัวโหลด (ติดตั้งใน Tampermonkey) · core = สคริปต์ตัวจริง (ตัวโหลดดึงทุกครั้งที่เปิดหน้าเกม)
            const si = scriptInfo(); if (!si) { res.writeHead(404); res.end(); return; }
            const kind = url.pathname.split('.')[1];
            if (kind === 'core') {      // ~1 MB → บีบอัดส่ง (~200 KB) ให้ตัวโหลดโหลดทันภายในเวลาที่กำหนด แม้หลายจอโหลดพร้อมกัน
                S.coreHits = (S.coreHits || 0) + 1;
                if (/gzip/.test(String(req.headers['accept-encoding'] || ''))) {
                    if (!CORE_GZ || CORE_GZ.v !== si.version || CORE_GZ.len !== si.src.length) CORE_GZ = { v: si.version, len: si.src.length, buf: zlib.gzipSync(Buffer.from(si.src, 'utf8'), { level: 6 }) };
                    res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8', 'Content-Encoding': 'gzip', 'Content-Length': CORE_GZ.buf.length, 'Cache-Control': 'no-store' }); res.end(CORE_GZ.buf); return;
                }
            }
            res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-store' });
            res.end(kind === 'core' ? si.src : kind === 'meta' ? loaderHead(si) + '\n' : loaderSource(si)); return;
        }
        if (!url.pathname.startsWith('/api/')) {
            const f = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
            if (!/^[\w.-]+$/.test(f)) { res.writeHead(404); res.end(); return; }
            const file = path.join(PUBLIC, f);
            if (!fs.existsSync(file)) { res.writeHead(404); res.end(); return; }
            const ext = path.extname(f).toLowerCase();
            const type = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json' }[ext] || 'application/octet-stream';
            res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-store' }); fs.createReadStream(file).pipe(res); return;
        }
        if (req.headers['x-aeth'] !== '1') { send(res, 403, { ok: false, err: 'forbidden' }); return; }
        const p = url.pathname;
        let m0;
        if (await lkIntercept(req, res, p)) return;      // 🖥️ ของเครื่องอื่น → ส่งต่อ

        // จากสคริปต์ในเกม: ส่งสถานะ → รับคำสั่งที่ค้าง
        if (p === '/api/peer' && req.method === 'POST') {
            const b = await body(req); const snap = b && b.snap;
            if (!snap || !snap.tab || !snap.name) { send(res, 400, { ok: false }); return; }
            const old = S.peers[snap.tab] || {};
            for (const x of Object.values(S.peers)) {      // ตัวละครเดียวกันจากหน้าเกมก่อนรีโหลด → ลบของเก่า (ย้ายกระเป๋าล่าสุดมาด้วย)
                if (x.tab !== snap.tab && x.name === snap.name) { if (S.inv[x.tab] && !S.inv[snap.tab]) S.inv[snap.tab] = S.inv[x.tab]; delete S.inv[x.tab]; delete S.peers[x.tab]; delete S.cmds[x.tab]; }
            }
            const pf = snap.pf; delete snap.pf;      // สถิติเก็บแยก (ไม่ส่งไปกับสถานะทุก 2 วิ)
            S.peers[snap.tab] = Object.assign({ maps: old.maps || [], mapInfo: old.mapInfo || null }, snap, { ts: Date.now(), group: old.group || '', targetId: old.targetId || '', aurWhy: old.aurWhy || '' });      // รายชื่อแมพส่งมาเป็นระยะ ไม่ใช่ทุกรอบ
            if (pf && typeof pf === 'object' && pf.h) { S.stats[snap.name] = Object.assign({}, pf, { name: snap.name, cls: snap.cls || '', group: S.peers[snap.tab].group || (S.stats[snap.name] || {}).group || '', at: Date.now() }); statsDirty = true; }
            { const L = CFG.links, nv = verNum(snap.v || '0') >= verNum('5.97.2'); if (L && L.enforce !== false && snap.lk && (snap.lk !== linkHash(L, nv) || (nv && L.dc && snap.dh && snap.dh !== dcHashSrv(L.dc))) && Date.now() - (LK_AT[snap.tab] || 0) > 120000 && verNum(snap.v || '0') >= verNum('5.95.0')) { LK_AT[snap.tab] = Date.now(); queue(snap.tab, 'linkset', linkPayload(L, nv)); } }      // จอที่ค่ายังไม่ตรง → ส่งให้
            try { cfgTick(snap.tab); } catch (e) { /* ignore */ }
            const cmds = S.cmds[snap.tab] || []; delete S.cmds[snap.tab];
            send(res, 200, { ok: true, cmds: cmds.filter((c) => Date.now() - c.at < 180000) }); return;
        }
        if (p === '/api/inv' && req.method === 'POST') {      // สคริปต์ส่งของในกระเป๋ามา
            const b = await body(req); if (!b || !b.tab) { send(res, 400, { ok: false }); return; }
            if (b.pending) { S.inv[b.tab] = Object.assign({}, S.inv[b.tab] || {}, { pending: String(b.pending).slice(0, 120), pat: Date.now() }); send(res, 200, { ok: true }); return; }      // ยังไม่ว่าง (กำลังวาร์ป ฯลฯ) — ยังไม่มีข้อมูลใหม่
            const keep = S.inv[b.tab] || {};
            S.inv[b.tab] = { at: Date.now(), items: Array.isArray(b.items) ? b.items.slice(0, 400) : (b.err ? keep.items || [] : []), w: String(b.w || keep.w || ''), sl: String(b.sl || keep.sl || ''), z: String(b.z || keep.z || ''), err: String(b.err || ''), msg: String(b.msg || ''), tab: String(b.tabName || keep.tab || '') };
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/zone' && req.method === 'POST') {      // สคริปต์ส่งข้อมูลโซนของแมพมา (แผนที่ + โซน + ตัวเลือก)
            const b = await body(req, 4e6); if (!b || !b.tab) { send(res, 400, { ok: false }); return; }
            S.zone[b.tab] = { at: Date.now(), zone: b.zone || null, saved: !!b.saved, err: String(b.err || '') }; send(res, 200, { ok: true }); return;
        }
        if ((m0 = /^\/api\/zone\/([\w-]+)$/.exec(p)) && req.method === 'GET') { send(res, 200, { ok: true, z: S.zone[m0[1]] || null }); return; }
        if (p === '/api/skill' && req.method === 'POST') {      // สคริปต์ส่งรายการสกิลมา
            const b = await body(req); if (!b || !b.tab) { send(res, 400, { ok: false }); return; }
            if (b.pending) { S.skill[b.tab] = Object.assign({}, S.skill[b.tab] || {}, { pending: String(b.pending).slice(0, 120), pat: Date.now() }); send(res, 200, { ok: true }); return; }
            const keep = S.skill[b.tab] || {};
            S.skill[b.tab] = { at: Date.now(), list: Array.isArray(b.list) && (b.list.length || !keep.list) ? b.list.slice(0, 120) : keep.list || [], tabs: Array.isArray(b.tabs) && b.tabs.length ? b.tabs.slice(0, 8) : keep.tabs || [], pts: typeof b.pts === 'number' ? b.pts : -1, err: String(b.err || '').slice(0, 300), dump: String(b.dump || '').slice(0, 6000) }; skillDirty = true;
            send(res, 200, { ok: true }); return;
        }
        if ((m0 = /^\/api\/skill\/([\w-]+)$/.exec(p)) && req.method === 'GET') { send(res, 200, { ok: true, sk: S.skill[m0[1]] || null }); return; }
        if (p === '/api/askill' && req.method === 'POST') {      // สกิลที่ Auto ของเกมใช้
            const b = await body(req); if (!b || !b.tab) { send(res, 400, { ok: false }); return; }
            if (b.pending) { S.askill[b.tab] = Object.assign({}, S.askill[b.tab] || {}, { pending: String(b.pending).slice(0, 120), pat: Date.now() }); send(res, 200, { ok: true }); return; }
            S.askill[b.tab] = { at: Date.now(), list: Array.isArray(b.list) ? b.list.slice(0, 40) : [], max: +b.max || 9, err: String(b.err || '').slice(0, 300), dump: String(b.dump || '').slice(0, 6000) }; skillDirty = true;
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/autocfg' && req.method === 'POST') {      // ⚙️ ตั้งค่า Auto ทั้งหมดของเกม (ต่อสู้/มอน/เก็บของ/ยา·บัพ)
            const b = await body(req, 2e6); if (!b || !b.tab) { send(res, 400, { ok: false }); return; }
            if (b.pending) { S.acfg[b.tab] = Object.assign({}, S.acfg[b.tab] || {}, { pending: String(b.pending).slice(0, 120), pat: Date.now() }); send(res, 200, { ok: true }); return; }
            S.acfg[b.tab] = { at: Date.now(), cfg: b.cfg && typeof b.cfg === 'object' ? b.cfg : {}, opts: b.opts && typeof b.opts === 'object' ? b.opts : {}, err: String(b.err || '').slice(0, 300) };
            send(res, 200, { ok: true }); return;
        }
        if ((m0 = /^\/api\/autocfg\/([\w-]+)$/.exec(p)) && req.method === 'GET') { send(res, 200, { ok: true, ac: S.acfg[m0[1]] || null }); return; }
        if ((m0 = /^\/api\/askill\/([\w-]+)$/.exec(p)) && req.method === 'GET') { send(res, 200, { ok: true, as: S.askill[m0[1]] || null }); return; }
        if (p === '/api/cfg' && req.method === 'POST') {      // สคริปต์ส่ง Config ของตัวเองมา (หลัง cfgget / cfgset / cfgclear)
            const b = await body(req, 8e6); const pe = b && S.peers[b.tab]; if (!pe || !pe.group || !b.name || b.name !== pe.name) { send(res, 400, { ok: false }); return; }
            const k = cfgKey(pe.group, pe.name), pd = CFGS.pend[k];
            if (b.err) { CFGS.res[k] = { at: Date.now(), ok: false, msg: String(b.err).slice(0, 200) }; if (pd && b.req === pd.id) { delete CFGS.pend[k]; say(`❌ Config ${pe.name}: ${b.err}`); } }
            else {
                if (b.data && typeof b.data === 'object') CFGS.store[k] = { group: pe.group, name: pe.name, at: Date.now(), h: String(b.h || ''), data: b.data };
                if (pd && b.req === pd.id && b.did) { delete CFGS.pend[k]; CFGS.res[k] = { at: Date.now(), ok: true, msg: pd.mode === 'clear' ? `ย้าย Config ออกแล้ว${pd.from ? ' (' + pd.from + ')' : ''}` : `ใส่ Config แล้ว${pd.from ? ' (จาก ' + pd.from + ')' : ''}` }; say(`⚙️ ${pe.name} (${pe.group}): ${CFGS.res[k].msg}`); }
            }
            cfgsDirty = true; send(res, 200, { ok: true }); return;
        }
        // 🔑 ID ที่ใช้ Login (ข้อ 16) — เก็บเฉพาะชื่อผู้ใช้ ไม่เก็บรหัสผ่าน/token · แยกตามโปรไฟล์
        if (p === '/api/loginid' && req.method === 'POST') {
            const b = await body(req); const g = b && groupOf(String(b.grp || '')), id = String((b && b.id) || '').trim();
            if (!g || !/^[\w.@+-]{3,64}$/.test(id) || CFG.loginRemember === false) { send(res, 200, { ok: false }); return; }
            CFG.loginIds = CFG.loginIds || {}; const cur = (CFG.loginIds[g.id] || []).filter((x) => x !== id); CFG.loginIds[g.id] = [id].concat(cur).slice(0, 5); saveConfig(CFG);
            send(res, 200, { ok: true }); return;
        }
        if ((m0 = /^\/api\/loginid\/([\w-]+)$/.exec(p)) && req.method === 'GET') { send(res, 200, { ok: true, ids: CFG.loginRemember === false ? [] : ((CFG.loginIds || {})[m0[1]] || []), fill: CFG.loginFill !== false }); return; }
        if (p === '/api/token' && req.method === 'POST') {      // สคริปต์ส่งข้อมูลตลาด Token มา
            const b = await body(req, 2e6); const pe = b && S.peers[b.tab]; if (!pe) { send(res, 400, { ok: false }); return; }
            if (b.err) { TOK.last = Object.assign({}, TOK.last || {}, { err: String(b.err).slice(0, 200), errAt: Date.now(), errBy: pe.name }); send(res, 200, { ok: true }); return; }
            const num = (v) => (typeof v === 'number' && isFinite(v) ? v : null);
            const ranges = {}; for (const [k, r] of Object.entries(b.ranges || {}).slice(0, 8)) ranges[String(k).slice(0, 20)] = { avg: num(r.avg), vol: num(r.vol), empty: !!r.empty, pts: (Array.isArray(r.pts) ? r.pts : []).slice(0, 200).map((x) => ({ lb: String(x.lb || '').slice(0, 40), avg: num(x.avg), vol: num(x.vol) })).filter((x) => x.avg !== null) };
            const book = (a) => (Array.isArray(a) ? a : []).slice(0, 30).map((x) => ({ p: num(x.p), q: num(x.q), o: num(x.o) })).filter((x) => x.p !== null);
            TOK.last = { at: Date.now(), tab: b.tab, by: pe.name, ranges, asks: book(b.asks), bids: book(b.bids) };
            const ba = TOK.last.asks.length ? Math.min(...TOK.last.asks.map((x) => x.p)) : null, bb = TOK.last.bids.length ? Math.max(...TOK.last.bids.map((x) => x.p)) : null;
            TOK.hist.push({ t: Date.now(), ask: ba, bid: bb }); if (TOK.hist.length > 5000) TOK.hist.splice(0, TOK.hist.length - 5000);
            tokSave(); send(res, 200, { ok: true }); return;
        }
        if (p === '/api/gamefiles' && req.method === 'POST') { const b = await body(req, 25e6); send(res, 200, Object.assign({ ok: true }, gfApi(b || {}))); return; }      // 🧪 ไฟล์เกม (สคริปต์ส่งมา / หน้า ตั้งค่า ดูผล)
        if (p === '/api/gamefiles/open' && req.method === 'POST') { fs.mkdirSync(GF_DIR, { recursive: true }); if (process.platform === 'win32') spawn('explorer', [GF_DIR], { detached: true, stdio: 'ignore' }).unref(); send(res, 200, { ok: true, dir: GF_DIR }); return; }
        if (p === '/api/ptpos' && req.method === 'POST') {      // 👥 ลูกตี้ถามตำแหน่งหัวหน้า (ตามชื่อ) — หาในทุกเครื่องที่เชื่อมอยู่ · ข้อมูลต้องใหม่ไม่เกิน 15 วิ
            const b = await body(req, 5000), name = String((b && b.name) || '').trim(), now = Date.now();
            const pe = name && allPeers().filter((x) => x.name === name && x.pos && now - x.ts < 15000).sort((x, y) => y.ts - x.ts)[0];
            send(res, 200, pe ? { ok: true, pos: { x: +pe.pos.x, z: +pe.pos.z }, map: pe.map || '', ch: pe.ch || '', age: now - pe.ts } : { ok: true, pos: null }); return;
        }
        if (p === '/api/gmnotice' && req.method === 'POST') { const b = await body(req, 20000); send(res, 200, Object.assign({ ok: true }, await gmNotice(b || {}))); return; }      // 📢 สคริปต์เห็นประกาศจากทีมงาน
        if (p === '/api/ev' && req.method === 'POST') { const b = await body(req, 50000); send(res, 200, { ok: evAdd(b || {}) }); return; }      // สคริปต์ส่งเหตุการณ์มา (ทุกครั้งที่มีแจ้งเตือน)
        if (p === '/api/slog' && req.method === 'POST') {      // สคริปต์ส่ง Logs ล่าสุดมา (ตามคำสั่ง logs)
            const b = await body(req, 4e6); if (!b || !b.tab || !Array.isArray(b.entries)) { send(res, 400, { ok: false }); return; }
            S.slog[b.tab] = { at: Date.now(), name: (S.peers[b.tab] || {}).name || '', entries: b.entries.slice(-400).map((e) => ({ t: +e.t || 0, l: String(e.level || e.l || 'info').slice(0, 5), g: String(e.tag || e.g || '').slice(0, 12), m: maskSecrets(String(e.msg || e.m || '').slice(0, 600)) })) };
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/junk' && req.method === 'POST') {      // สคริปต์ส่งการตั้งค่าทิ้งขยะมา
            const b = await body(req); if (!b || !b.tab) { send(res, 400, { ok: false }); return; }
            S.junk[b.tab] = { at: Date.now(), opt: b.opt || {}, shared: !!b.shared, map: b.map || {}, icons: b.icons || {}, defs: Array.isArray(b.defs) ? b.defs.slice(0, 80) : [] }; send(res, 200, { ok: true }); return;
        }
        if ((m0 = /^\/api\/junk\/([\w-]+)$/.exec(p)) && req.method === 'GET') { send(res, 200, { ok: true, jk: S.junk[m0[1]] || null }); return; }
        if (p === '/api/market' && req.method === 'POST') {
            const b = await body(req, 4e6); if (!b || !b.tab) { send(res, 400, { ok: false }); return; }
            if (b.pending) { S.mk.last[b.tab] = Object.assign({}, S.mk.last[b.tab] || {}, { pending: String(b.pending).slice(0, 120), pat: Date.now() }); send(res, 200, { ok: true }); return; }
            if (b.buy && typeof b.buy === 'object') {      // 🛒 ผลการซื้อ
                const x = b.buy, pe = S.peers[b.tab] || {}; S.mk.buys = S.mk.buys || [];
                S.mk.buys.push({ at: Date.now(), tab: b.tab, who: pe.name || b.name || '', n: String(x.n || '').slice(0, 60), seller: String(x.seller || '').slice(0, 40), total: +x.total || 0, q: +x.q || 1, ok: !!x.ok, err: String(x.err || '').slice(0, 300), claimed: +x.claimed || 0 });
                if (S.mk.buys.length > 100) S.mk.buys.splice(0, S.mk.buys.length - 100); mkDirty = true;
                say(x.claimOnly ? `📦 ${pe.name || ''} รับของจากตลาด ${+x.claimed || 0} รายการ${x.err ? ' · ' + x.err : ''}` : x.ok ? `🛒 ${pe.name || ''} ซื้อ ${x.n}${+x.q > 1 ? ' ×' + x.q : ''} จาก ${x.seller} ${(+x.total || 0).toLocaleString()} z${x.claimed ? ' · รับของแล้ว' : ''}` : `🛒 ซื้อ ${x.n} ไม่สำเร็จ: ${x.err}`);
                send(res, 200, { ok: true }); return;
            }
            S.mk.last[b.tab] = { at: Date.now(), q: String(b.q || '').slice(0, 60), n: (b.rows || []).length, info: b.info || null, err: String(b.err || '').slice(0, 300), dump: String(b.dump || '').slice(0, 6000), passive: !!b.passive, rows: Array.isArray(b.rows) ? b.rows.slice(0, 120) : [] };
            if (Array.isArray(b.rows) && b.rows.length) mkIngest(b);
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/classdata' && req.method === 'POST') {
            const b = await body(req, 6e6); if (!b || !Array.isArray(b.classes) || !b.classes.length) { send(res, 400, { ok: false }); return; }
            const cd = { at: Date.now(), classes: b.classes.slice(0, 300), skills: Array.isArray(b.skills) ? b.skills.slice(0, 3000) : [] };
            const sig = (x) => JSON.stringify([x.classes, x.skills]);
            if (!S.cd || sig(S.cd) !== sig(cd)) { const first = !S.cd; S.cd = cd; try { fs.writeFileSync(CD_FILE, JSON.stringify(cd)); } catch (e) { /* ignore */ } say(`🎓 ${first ? 'ได้' : 'อัปเดต'}ข้อมูลอาชีพจากเกม: ${cd.classes.length} อาชีพ · ${cd.skills.length} สกิล`); }
            else S.cd.at = cd.at;
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/classdata' && req.method === 'GET') { send(res, 200, { ok: true, cd: S.cd }); return; }
        if (p === '/api/market' && req.method === 'GET') {
            const items = Object.values(S.mk.items).map((it) => { const h = it.hist, a = h[h.length - 1] || [], prev = h.slice(0, -1).reverse().find((x) => x[1]) || []; return { n: it.n, ic: it.ic, at: it.at, min: a[1] || 0, auc: a[2] || 0, cnt: a[3] || 0, qty: a[4] || 0, prev: prev[1] || 0, sp: h.slice(-40).map((x) => x[1]) }; }).sort((a, c) => c.at - a.at);
            send(res, 200, { ok: true, items, buys: (S.mk.buys || []).slice(-30), watch: S.mk.watch, alerts: S.mk.alerts.slice(-50), every: S.mk.every, nextAt: S.mk.nextAt, last: S.mk.last }); return;
        }
        if (p === '/api/market/item' && req.method === 'GET') { const it = S.mk.items[mkKey(url.searchParams.get('n'))]; send(res, 200, { ok: true, it: it || null }); return; }
        if (p === '/api/stats' && req.method === 'GET') { send(res, 200, { ok: true, stats: Object.values(S.stats), reset: CFG.sxReset || null, resetBy: CFG.sxResetBy || {}, fpsLog: CFG.fpsLog || [] }); return; }
        if (p === '/api/stats/reset') {      // 🔄 เริ่มนับสถิติใหม่ (ไม่ลบข้อมูล: จำเวลา + ค่าในชั่วโมงนั้นไว้หักออก) · clear = กลับไปดูแบบเดิม
            const b = await body(req);
            if (b && Array.isArray(b.names)) {      // รีเซ็ตเฉพาะตัวละคร (เลือกทั้งโปรไฟล์ = ส่งทุกชื่อในโปรไฟล์)
                const names = b.names.map(String).filter(Boolean).slice(0, 500), now = Date.now(), hk = Math.floor((now - new Date().getTimezoneOffset() * 60000) / 3600000);
                CFG.sxResetBy = CFG.sxResetBy || {};
                for (const n of names) {
                    if (b.clear) { delete CFG.sxResetBy[n]; continue; }
                    const a = S.stats[n] && S.stats[n].h && S.stats[n].h[hk];
                    CFG.sxResetBy[n] = { at: now, hk, base: [0, 1, 2, 3].map((i) => +(a && a[i]) || 0) };
                }
                saveConfig(CFG); say(`📊 ${b.clear ? 'ยกเลิกรีเซ็ต' : 'เริ่มนับใหม่'}: ${names.length} ตัว${names.length <= 3 ? ' (' + names.join(', ') + ')' : ''}`);
                send(res, 200, { ok: true, reset: CFG.sxReset || null, resetBy: CFG.sxResetBy }); return;
            }
            if (b && b.clear) delete CFG.sxReset;
            else {
                const now = Date.now(), hk = Math.floor((now - new Date().getTimezoneOffset() * 60000) / 3600000), base = {};
                for (const st of Object.values(S.stats)) { const a = st && st.h && st.h[hk]; if (st && st.name && a) base[st.name] = [0, 1, 2, 3].map((i) => +a[i] || 0); }
                CFG.sxReset = { at: now, hk, base };
            }
            saveConfig(CFG); say(b && b.clear ? '📊 ยกเลิกการรีเซ็ตสถิติ' : '📊 เริ่มนับสถิติใหม่');
            send(res, 200, { ok: true, reset: CFG.sxReset || null, resetBy: CFG.sxResetBy || {} }); return;
        }
        if (p === '/api/stats/del' && req.method === 'POST') { const b = await body(req); delete S.stats[String(b.name || '')]; statsDirty = true; send(res, 200, { ok: true }); return; }
        if (p === '/api/ramhist' && req.method === 'GET') { send(res, 200, { ok: true, hist: S.ramHist, limitGB: CFG.ramLimitGB }); return; }
        if ((m0 = /^\/api\/inv\/([\w-]+)$/.exec(p)) && req.method === 'GET') { send(res, 200, { ok: true, inv: S.inv[m0[1]] || null }); return; }
        if (p === '/api/ver' && req.method === 'GET') {      // สคริปต์ในเกมถามทุก 1 นาที: มีรุ่นใหม่ไหม + เปิดอัปเดตอัตโนมัติอยู่ไหม
            const si = scriptInfo(); send(res, 200, { ok: true, core: si ? si.version : '', auto: CFG.autoUpdate !== false }); return;
        }
        if (p === '/api/hello' && req.method === 'POST') {      // สคริปต์เปิดหน้าเกมแล้ว (ยังไม่ล็อกอินก็ได้)
            const b = await body(req); const g = groupOf(String(b.grp || ''));
            if (g) { const info = S.groups[g.id] || (S.groups[g.id] = {}); info.script = { v: String(b.v || '?').slice(0, 20), ld: String(b.ld || '').slice(0, 20), at: Date.now() }; }
            send(res, 200, { ok: true }); return;
        }
        if ((m0 = /^\/api\/prep\/([\w-]+)$/.exec(p)) && req.method === 'GET') {      // หน้าเตรียมความพร้อมถามสถานะ
            const g = groupOf(m0[1]); if (!g) { send(res, 404, { ok: false }); return; }
            send(res, 200, { ok: true, id: g.id, prep: S.prep[g.id] || null, game: gameUrlFor(g), enabled: CFG.prepOnStart !== false }); return;
        }
        if (p === '/api/state' && req.method === 'GET') {
            const si = scriptInfo();
            const lo = lkOthers(), rmt = !!req.remote, L0 = Object.assign({ sheet: '', discord: '', ping: '', enforce: true }, CFG.links || {}, { h: linkHash(CFG.links), h2: linkHash(CFG.links, true) });
            const lks = lkState(); if (rmt) lks.code = '';
            if (rmt) for (const k of ['sheet', 'discord', 'dstatus']) if (L0[k]) L0[k] = '•••';      // มือถือ: ไม่ส่ง Webhook / ลิงก์ Sheets
            send(res, 200, { ok: true, v: VERSION, script: si ? { file: si.file, version: si.version } : null, groups: publicGroups().map((g) => (rmt ? Object.assign(g, { proxyRaw: '' }) : g)).concat(lo.groups), peers: Object.values(S.peers).concat(lo.peers), remote: rmt, link: lks, rm: { on: RM.on, url: RM.url, st: RM.st, pw: !!RM.hash, n: RM.sess.filter((x) => x.exp > Date.now()).length, dl: RM.dl, subs: RM.subs.length, push: RM.push, dcLink: RM.dcLink }, log: S.log.slice(-60), sys: { cpu: S.cpu.pct, memTotal: os.totalmem(), memFree: os.freemem() }, links: L0, cfg: { appMode: !!CFG.appMode, browser: browserId(), browsers: browserList(), loginRemember: CFG.loginRemember !== false, loginFill: CFG.loginFill !== false, groundOff: !!CFG.groundOff, maxPerIp: CFG.maxPerIp, gameUrl: CFG.gameUrl, chromePath: CFG.chromePath, chromeFound: findChrome(), screen: CFG.screen, startGapSec: CFG.startGapSec, port: CFG.port, proxyUser: rmt ? '' : CFG.proxyUser || '', proxyPassSet: !!CFG.proxyPass, autoAllow: !!CFG.autoAllow, prepOnStart: CFG.prepOnStart !== false, autoUpdate: CFG.autoUpdate !== false, updateUrl: CFG.updateUrl || '', autoPurge: CFG.autoPurge !== false, purgeMin: CFG.purgeMin || 20, ramGuard: CFG.ramGuard !== false, ramLimitGB: CFG.ramLimitGB || 2.5, ramCooldownMin: CFG.ramCooldownMin || 60, reloadEveryH: CFG.reloadEveryH === undefined ? 12 : +CFG.reloadEveryH || 0, win: process.platform === 'win32', policy: S.policy } });
            return;
        }
        if (req.method !== 'POST') { send(res, 405, { ok: false }); return; }
        const b = await body(req, p === '/api/script/upload' ? 8e6 : p === '/api/app/upload' ? 40e6 : 2e6);
        let m;
        if ((m = /^\/api\/group\/([\w-]+)\/(start|stop|newwin|kill)$/.exec(p))) {
            const g = groupOf(m[1]); if (!g) throw Error('ไม่พบกลุ่ม');
            if (m[2] === 'kill') { const n = await killProfile(g); say(`🧹 ${g.id}: บังคับปิดโปรเซส Chrome ที่ค้าง ${n} ตัว`); scanProcs(); send(res, 200, { ok: true, n }); return; }
            if (m[2] === 'start') await startGroup(g); else if (m[2] === 'stop') await stopGroup(g); else await newGameWindow(g);
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/remote') {      // 📱 ตั้งค่าใช้จากมือถือ (ทำได้เฉพาะบนเครื่องคอม)
            if (typeof b.pw === 'string' && b.pw) { if (b.pw.length < 6) throw Error('PIN ต้องยาวอย่างน้อย 6 ตัว'); RM.salt = crypto.randomBytes(16).toString('hex'); RM.hash = pwHash(b.pw, RM.salt); RM.pinLen = b.pw.length; RM.pinDig = /^\d+$/.test(b.pw); RM.sess = []; say('📱 ตั้ง PIN ใช้จากมือถือใหม่ (ออกจากระบบทุกเครื่องแล้ว)'); }
            if (b.logoutAll) { RM.sess = []; say('📱 ออกจากระบบทุกเครื่องแล้ว'); }
            if (b.clearPush) { RM.subs = []; say('🔔 ลบมือถือที่รับแจ้งเตือนทั้งหมดแล้ว'); }
            if (typeof b.dcLink === 'boolean') RM.dcLink = b.dcLink;
            if (b.newLink && RM.on) { rmSave(); cfStart(true); send(res, 200, { ok: true }); return; }
            if (typeof b.on === 'boolean') { if (b.on && !RM.hash) throw Error('ตั้ง PIN ก่อน'); RM.on = b.on; if (RM.on) cfStart(false); else cfStop(); }
            rmSave(); send(res, 200, { ok: true }); return;
        }
        if (p === '/api/push') { const r = rmPushApi(b, req); if (!r) throw Error('ไม่รู้จักคำสั่ง'); if (r.wait) { r.n = await r.wait; delete r.wait; } send(res, 200, Object.assign({ ok: true }, r)); return; }
        if (p === '/api/link') { send(res, 200, Object.assign({ ok: true }, lkApi(b))); return; }
        if (p === '/api/startall') {
            const list = CFG.groups.filter((g) => !(S.groups[g.id] || {}).running && (!b.ids || b.ids.includes(g.id)));
            (async () => { for (const g of list) { try { await startGroup(g); } catch (e) { say('❌ ' + e.message); } await new Promise((r) => setTimeout(r, Math.max(1, +CFG.startGapSec || 5) * 1000)); } })();
            send(res, 200, { ok: true, n: list.length }); return;
        }
        if (p === '/api/rpc') {      // 🎮 ตั้งค่า Discord Rich Presence
            const R = Object.assign({ on: false, clientId: '', who: '', msg: '', scroll: true, show: { zeny: true, zph: true, time: true } }, CFG.rpc || {});
            if (typeof b.msg === 'string') { R.msg = b.msg.replace(/[\r\n]+/g, ' ').slice(0, 200); RPC.mq = 0; RPC.sig = ''; }
            if (typeof b.scroll === 'boolean') { R.scroll = b.scroll; RPC.mq = 0; RPC.sig = ''; }
            if (b.show && typeof b.show === 'object') { R.show = Object.assign({}, R.show); for (const k of ['zeny', 'zph', 'time']) if (typeof b.show[k] === 'boolean') R.show[k] = b.show[k]; RPC.sig = ''; }
            if (typeof b.on === 'boolean') R.on = b.on;
            if (typeof b.clientId === 'string') { const v = b.clientId.trim(); if (v && !/^\d{15,25}$/.test(v)) throw Error('Application ID ต้องเป็นตัวเลข (คัดลอกจาก Discord Developer Portal)'); if (v !== R.clientId) rpcClose(''); R.clientId = v; }
            if (typeof b.who === 'string') { R.who = b.who.slice(0, 40); RPC.sig = ''; }
            if (b.on !== undefined || b.clientId !== undefined || b.who !== undefined || b.show !== undefined || b.msg !== undefined || b.scroll !== undefined) { CFG.rpc = R; saveConfig(CFG); setTimeout(() => { try { rpcTick(); } catch (e) { /* ignore */ } }, 300); }
            send(res, 200, { ok: true, rpc: R, ready: RPC.ready, err: RPC.err, last: RPC.last, at: RPC.at }); return;
        }
        if (p === '/api/app/restart') { say('🔁 เปิด Manager ใหม่ (สั่งจากหน้า ตั้งค่า)'); send(res, 200, { ok: true }); setTimeout(restartSelf, 500); return; }
        if (p === '/api/repair') {
            if (b.op === 'fix') { const r = repairFix(Array.isArray(b.ids) ? b.ids.map(String) : []); send(res, 200, Object.assign({ ok: true }, r)); return; }
            send(res, 200, { ok: true, list: repairCheck() }); return;
        }
        if (p === '/api/tokens') {      // 🪙 ข้อมูลราคา Token ล่าสุด · op=scan อ่านตอนนี้ · on=true/false เปิด/ปิดอ่านอัตโนมัติ
            if (typeof b.on === 'boolean') { CFG.tokenOn = b.on; saveConfig(CFG); }
            let asked = null; if (b.op === 'scan') { const pe = tokAsk(true); if (!pe) throw Error('ไม่มีตัวละครที่ออนไลน์และว่าง (สคริปต์ 5.97.5 ขึ้นไป) ให้อ่านราคา'); asked = pe.name; TOK.next = Date.now() + 600000; }
            send(res, 200, { ok: true, on: CFG.tokenOn !== false, last: TOK.last, hist: TOK.hist.slice(-1000), asked, pending: TOK.asked && (!TOK.last || TOK.last.at < TOK.asked.at) && Date.now() - TOK.asked.at < 120000 ? TOK.asked : null }); return;
        }
        if (p === '/api/events') {      // 🔔 บันทึกเหตุการณ์: เครื่องนี้ + เครื่องอื่นที่เชื่อมอยู่ (ใหม่สุดก่อน)
            let list = EV.map((e) => Object.assign({}, e, { mach: '' }));
            const l = lkCfg();
            if (l.role === 'main') for (const [sid, s] of Object.entries(LINK.subs)) list = list.concat((s.ev || []).map((e) => Object.assign({}, e, { at: e.at + s.off, mach: s.name, group: pre(sid, e.group) })));
            else if (l.role === 'sub' && LINK.view) list = list.concat((LINK.view.ev || []).map((e) => Object.assign({}, e, { at: e.at + LINK.view.off })));
            list.sort((a, b2) => b2.at - a.at);
            if (b.clear) { EV = []; evDirty = true; list = []; say('🔔 ล้างบันทึกเหตุการณ์ของเครื่องนี้แล้ว'); }
            send(res, 200, { ok: true, list: list.slice(0, 600) }); return;
        }
        if (p === '/api/logs') {      // 📜 Logs: Manager (หน่วยความจำ + manager.log) หรือสคริปต์ของตัวละคร (สั่งให้ส่งมาใหม่ แล้วคืนชุดล่าสุดที่มี)
            if (b.src === 'peer') {
                const pe = S.peers[b.tab]; if (!pe) throw Error('ไม่พบตัวละคร');
                if (b.ask) queue(b.tab, 'logs', {});
                const sl = S.slog[b.tab]; send(res, 200, { ok: true, at: sl ? sl.at : 0, entries: sl ? sl.entries : [], online: Date.now() - pe.ts < 180000, v: pe.v || '' }); return;
            }
            let file = []; try { const fp = path.join(ROOT, 'manager.log'), st = fs.statSync(fp), fd = fs.openSync(fp, 'r'), n = Math.min(st.size, 200000), buf = Buffer.alloc(n); fs.readSync(fd, buf, 0, n, st.size - n); fs.closeSync(fd); file = buf.toString('utf8').split(/\r?\n/).slice(1).filter(Boolean).slice(-400); } catch (e) { /* ยังไม่มีไฟล์ */ }
            send(res, 200, { ok: true, lines: S.log.map(maskSecrets), file: file.map(maskSecrets) }); return;
        }
        if (p === '/api/cfgs') {      // รายการ Config ทุกตัวละคร (ไม่ส่งข้อมูลเต็ม)
            if (b.op === 'data') { const st = CFGS.store[b.key]; if (!st) throw Error('ยังไม่มีสำเนา Config ของตัวนี้'); send(res, 200, { ok: true, name: st.name, group: st.group, at: st.at, data: st.data }); return; }
            if (b.op === 'cancel') { delete CFGS.pend[b.key]; cfgsDirty = true; send(res, 200, { ok: true }); return; }
            if (b.op === 'apply') {      // { to, from | data, mode: copy|move } — ปลายทางออฟไลน์ = รอใส่ตอนออนไลน์
                const list = cfgList(), to = list.find((x) => x.key === b.to); if (!to) throw Error('ไม่พบตัวละครปลายทาง');
                let data, fromName = String(b.fromLabel || 'ไฟล์ที่นำเข้า').slice(0, 80), src = null;
                if (b.from) { src = list.find((x) => x.key === b.from); const st = CFGS.store[b.from]; if (!src || !st) throw Error('ยังไม่มีสำเนา Config ของต้นทาง'); if (b.from === b.to) throw Error('ต้นทางกับปลายทางเป็นตัวเดียวกัน'); data = st.data; fromName = `${src.name} (${src.group})`; }
                else data = b.data;
                data = cfgClean(data);
                const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
                cfgBackup(b.to, 'ก่อนเขียนทับด้วย ' + fromName); if (b.mode === 'move' && src) cfgBackup(b.from, 'ก่อนย้ายออก');
                CFGS.pend[b.to] = { id, mode: 'set', data, from: fromName, at: Date.now() };
                if (b.mode === 'move' && src) CFGS.pend[b.from] = { id: id + 'm', mode: 'clear', from: `ย้ายไป ${to.name} (${to.group})`, at: Date.now() };
                for (const k of [b.to, b.mode === 'move' && b.from]) if (k) { delete CFGS.res[k]; for (const p2 of Object.values(S.peers)) if (cfgKey(p2.group, p2.name) === k) CFG_Q[p2.tab] = 0; }
                cfgsDirty = true; say(`⚙️ ${b.mode === 'move' ? 'ย้าย' : 'คัดลอก'} Config ${fromName} → ${to.name} (${to.group})${to.online ? '' : ' · รอใส่ตอนตัวนั้นออนไลน์'}`);
                send(res, 200, { ok: true, online: to.online }); return;
            }
            send(res, 200, { ok: true, list: cfgList() }); return;
        }
        if (p === '/api/peer/forget') {      // ลบตัวละครที่เคยเล่น (ออฟไลน์) ออกจากรายการ — ตัวที่ยังออนไลน์ลบไม่ได้
            const tabs = Array.isArray(b.tabs) ? b.tabs : [b.tab]; let n = 0;
            for (const t of tabs) { const x = S.peers[t]; if (!x || Date.now() - x.ts < 180000) continue; delete S.peers[t]; delete S.cmds[t]; delete S.inv[t]; n++; }
            if (n) say(`🗑️ ลบตัวละครออฟไลน์ออกจากรายการ ${n} ตัว`);
            send(res, 200, { ok: true, n }); return;
        }
        if (p === '/api/stopall') { for (const g of CFG.groups) if ((S.groups[g.id] || {}).debug) await stopGroup(g).catch(() => {}); send(res, 200, { ok: true }); return; }
        if (p === '/api/app/upload') {      // อัปเดตโปรแกรมจาก zip ที่ลากมาวาง
            const buf = Buffer.from(String(b.b64 || ''), 'base64'); if (buf.length < 100) throw Error('ไม่ได้รับไฟล์');
            const v = applyAppZip(buf); send(res, 200, { ok: true, v }); setTimeout(restartSelf, 500); return;
        }
        if (p === '/api/app/check') { const r = await checkUpdate(); send(res, 200, Object.assign({ ok: true, cur: VERSION }, r)); return; }
        if (p === '/api/app/update') {      // โหลดจากลิงก์ → ตรวจ SHA-256 → ติดตั้ง → รีสตาร์ท
            const r = await checkUpdate(); if (!r.newer && !b.force) throw Error(`เป็นเวอร์ชันล่าสุดแล้ว (v${VERSION})`);
            let buf = null;
            const gh = /^https:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/([^?]+)/.exec(r.url);
            if (gh) { try { buf = await httpsGet(`https://api.github.com/repos/${gh[1]}/${gh[2]}/contents/${gh[4]}?ref=${gh[3]}`, 60e6, 0, { Accept: 'application/vnd.github.raw' }); } catch (e) { buf = null; } }      // GitHub API: ไฟล์ล่าสุดทันที
            if (!buf || (r.sha256 && crypto.createHash('sha256').update(buf).digest('hex').toLowerCase() !== r.sha256.toLowerCase())) buf = await httpsGet(r.url + (r.url.includes('?') ? '&' : '?') + 't=' + Date.now());      // สำรอง: raw (กันแคชด้วย ?t=)
            if (r.sha256) { const h = crypto.createHash('sha256').update(buf).digest('hex'); if (h.toLowerCase() !== r.sha256.toLowerCase()) throw Error('SHA-256 ไม่ตรง — ไฟล์อาจเสียหรือไม่ใช่ของจริง ยกเลิกการติดตั้ง'); }
            const v = applyAppZip(buf); send(res, 200, { ok: true, v }); setTimeout(restartSelf, 500); return;
        }
        if (p === '/api/script/upload') {      // อัปโหลดสคริปต์ใหม่จากหน้า ตั้งค่า (ลากไฟล์มาวาง / เลือกไฟล์)
            const text = String(b.text || '');
            const head = /\/\/ ==UserScript==[\s\S]*?\/\/ ==\/UserScript==/.exec(text);
            if (!head) throw Error('ไม่ใช่ไฟล์สคริปต์ Tampermonkey (ไม่พบหัว ==UserScript==)');
            if (!/@name\s+Aetheria Tracker/i.test(head[0])) throw Error('ไม่ใช่สคริปต์ Aetheria Tracker / Aetherack');
            const v = (/@version\s+(\S+)/.exec(head[0]) || [])[1]; if (!v) throw Error('ไฟล์ไม่มี @version');
            const old = scriptInfo();
            const bdir = path.join(ROOT, 'backup'); fs.mkdirSync(bdir, { recursive: true });
            for (const f of fs.readdirSync(ROOT)) if (/\.user\.js$/i.test(f)) fs.renameSync(path.join(ROOT, f), path.join(bdir, `${Date.now()}-${f}`));      // เก็บของเดิมไว้ใน backup/ (ย้อนกลับได้)
            fs.writeFileSync(path.join(ROOT, 'aetherack.user.js'), text);
            say(`⬆️ อัปโหลดสคริปต์ v${v}${old ? ` (เดิม v${old.version} เก็บไว้ใน backup)` : ''}`);
            send(res, 200, { ok: true, v, old: old ? old.version : '' }); return;
        }
        if (p === '/api/market/scan') {      // ค้นหาในตลาดตอนนี้ (ตัวละครที่เลือก หรือเลือกให้เอง)
            const pe = mkPickPeer(String(b.tab || '')); if (!pe) throw Error('ไม่มีตัวละครออนไลน์ที่ใช้สคริปต์ 5.72.0 ขึ้นไป');
            S.mk.lastUse = S.mk.lastUse || {}; S.mk.lastUse[pe.tab] = Date.now();
            queue(pe.tab, 'mkscan', { q: String(b.q || '').slice(0, 60), pages: Math.max(1, Math.min(5, +b.pages || 1)) }); send(res, 200, { ok: true, tab: pe.tab, name: pe.name }); return;
        }
        if (p === '/api/market/claim') {      // 📦 รับของทั้งหมดในแท็บ รับของ
            const pe = mkPickPeer(String(b.tab || '')); if (!pe || (b.tab && pe.tab !== String(b.tab))) throw Error('ตัวละครที่เลือกไม่ออนไลน์');
            if (verNum(pe.v || '0') < verNum('5.92.0')) throw Error(`${pe.name} ใช้สคริปต์ v${pe.v} — ต้อง 5.92.0 ขึ้นไป (รีโหลดเกม)`);
            queue(pe.tab, 'mkclaim', {}); send(res, 200, { ok: true, tab: pe.tab, name: pe.name }); return;
        }
        if (p === '/api/market/buy') {      // 🛒 ซื้อรายการที่เลือก (ตัวละครที่ระบุ) — ยืนยันใน Manager แล้ว
            const pe = mkPickPeer(String(b.tab || '')); if (!pe || (b.tab && pe.tab !== String(b.tab))) throw Error('ตัวละครที่เลือกไม่ออนไลน์ (หรือสคริปต์เก่ากว่า 5.91.0)');
            if (verNum(pe.v || '0') < verNum('5.92.0')) throw Error(`${pe.name} ใช้สคริปต์ v${pe.v} — ต้อง 5.92.0 ขึ้นไป (รีโหลดเกม)`);
            const buy = { n: String(b.n || '').slice(0, 60), seller: String(b.seller || '').slice(0, 40), total: Math.max(0, +b.total || 0), q: Math.max(1, +b.q || 1), claim: b.claim !== false };
            if (!buy.n || !buy.seller || !buy.total) throw Error('ข้อมูลรายการไม่ครบ');
            queue(pe.tab, 'mkbuy', { buy }); send(res, 200, { ok: true, tab: pe.tab, name: pe.name }); return;
        }
        if (p === '/api/market/watch') {
            if (Array.isArray(b.watch)) S.mk.watch = b.watch.slice(0, 60).map((w) => { const old = S.mk.watch.find((x) => mkKey(x.n) === mkKey(w.n)) || {}; return { n: String(w.n || '').slice(0, 50), max: Math.max(0, +w.max || 0), on: w.on !== false, lastAlert: old.lastAlert || 0, lastPrice: old.lastPrice || 0 }; }).filter((w) => w.n);
            if (b.every) S.mk.every = Math.max(5, Math.min(240, +b.every || 15));
            if (b.clearAlerts) S.mk.alerts = [];
            S.mk.nextAt = Math.min(S.mk.nextAt || 0, Date.now() + 5000); mkDirty = true; send(res, 200, { ok: true, watch: S.mk.watch, every: S.mk.every }); return;
        }
        if (p === '/api/tmclone') { const r = await tmClone(String(b.from || ''), Array.isArray(b.to) ? b.to.map(String) : null); send(res, 200, Object.assign({ ok: true }, r)); return; }
        if (p === '/api/tmdisk') { send(res, 200, { ok: true, g: CFG.groups.map((g) => ({ id: g.id, tm: tmInstalledOnDisk(g), data: tmHasData(g), ld: !!((S.groups[g.id] || {}).script || {}).ld })) }); return; }
        if (p === '/api/updateall') {      // อัปเดตสคริปต์ทุกจอ: มีตัวโหลด → ทยอยรีโหลด · ยังเป็นแบบเก่า → เปิดหน้าติดตั้งตัวโหลด (กด Update ครั้งเดียว)
            const si = scriptInfo(); if (!si) throw Error('ไม่พบไฟล์สคริปต์ในโฟลเดอร์โปรแกรม');
            const now = Date.now(), live = Object.values(S.peers).filter((x) => now - x.ts < 60000);
            const need = live.filter((x) => x.ld && verNum(x.v) < verNum(si.version));
            need.forEach((x, i) => setTimeout(() => queue(x.tab, 'reload'), i * 3000));
            const oldG = new Set(live.filter((x) => !x.ld && x.group).map((x) => x.group)); let opened = 0;
            for (const id of oldG) { const g = groupOf(id); if (g && (S.groups[id] || {}).debug) { await openTab(g, `http://127.0.0.1:${CFG.port}/aetherack.user.js?t=${now}`).catch(() => {}); opened++; } }
            say(`⬆️ อัปเดตทั้งหมดเป็น v${si.version}: รีโหลด ${need.length} จอ${opened ? ` · เปิดหน้าติดตั้งตัวโหลด ${opened} Chrome (กด Update)` : ''}`);
            send(res, 200, { ok: true, n: need.length, opened, v: si.version, latest: live.length - need.length - live.filter((x) => !x.ld).length }); return;
        }
        if (p === '/api/quit') {      // ปิดโปรแกรม (เปิดผ่าน .exe ไม่มีหน้าต่างดำให้ปิด) — Chrome ที่เปิดอยู่ยังเล่นต่อได้ แต่กลุ่มที่ใช้รหัสพร็อกซีจะออกเน็ตไม่ได้จนกว่าจะเปิดโปรแกรมใหม่
            say('⏻ ปิดโปรแกรม'); send(res, 200, { ok: true }); evFlush();
            try { fs.writeFileSync(QUIT_FLAG, String(Date.now())); } catch (e) { /* ignore */ }      // บอกตัวเฝ้าว่าปิดเอง ไม่ต้องเปิดใหม่
            const k = RM.pid && !b.keep ? cfStop().catch(() => {}) : null;      // ปิดโปรแกรมเอง = ปิดลิงก์มือถือด้วย (อัปเดต/รีสตาร์ท/เปิดตัวใหม่ทับ = ลิงก์เดิมอยู่ต่อ)
            Promise.race([k, sleep(k ? 9000 : 0)]).then(() => setTimeout(() => process.exit(0), 300)); return;
        }
        if (p === '/api/focusall' || p === '/api/minall') {      // ดึงทุกจอเกมขึ้นมา / ย่อทุกจอ (ไม่เปลี่ยนขนาด-ตำแหน่ง)
            let n = 0;
            for (const g of CFG.groups) {
                const info = S.groups[g.id]; if (!info || !info.debug) continue;
                const games = (await jget(g.debugPort, '/json/list').catch(() => [])).filter(isGame);
                for (const t of games) { try { if (p === '/api/focusall') await focusTarget(g, t.id); else await minimizeTarget(g, t.id); n++; } catch (e) { /* ignore */ } }
            }
            if (!n) throw Error('ไม่มีจอเกมที่เปิดจากโปรแกรม');
            say(p === '/api/focusall' ? `🖥️ ดึงจอเกมขึ้นมา ${n} จอ` : `➖ ย่อจอเกม ${n} จอ`); send(res, 200, { ok: true, n }); return;
        }
        if (p === '/api/arrange') { const r = await arrangeAll(b && b.w ? b : null); send(res, 200, Object.assign({ ok: true }, r)); return; }
        // เปิดหน้าให้ผู้ใช้กดเองในทุก Chrome (หรือเฉพาะกลุ่ม): ร้านค้า Tampermonkey / หน้ารายละเอียดส่วนขยาย (สวิตช์ Allow User Scripts) / หน้าติดตั้งสคริปต์
        if ((m = /^\/api\/setup\/(tm|ext|script)$/.exec(p))) {
            if (m[1] === 'script' && !scriptInfo()) throw Error('ไม่พบไฟล์สคริปต์ (*.user.js) ในโฟลเดอร์โปรแกรม');
            const url = m[1] === 'tm' ? TM_STORE : m[1] === 'ext' ? 'chrome://extensions/?id=' + TM_ID : `http://127.0.0.1:${CFG.port}/aetherack.user.js?t=${Date.now()}`;
            const pick = (g) => !b.group || b.group === g.id;
            const r = await eachRunning(async (g) => {
                if (!pick(g)) return 'skip'; if (m[1] === 'tm' && (S.groups[g.id] || {}).tm) return 'skip';
                if (m[1] === 'ext' && CFG.autoAllow) { await allowUserScripts(g); return 'auto'; }
                const tid = await openTab(g, url);
                if (m[1] === 'tm') closeWhen(g, tid, () => (S.groups[g.id] || {}).tm === true, 600000);
                else if (m[1] === 'ext') closeWhen(g, tid, async () => (await extStatus(g)).allowed, 600000, 8000);
                else setTimeout(() => closeTmWelcome(g).catch(() => {}), 30000);      // หน้าติดตั้งสคริปต์ Tampermonkey ปิดเองหลังกด Install
                return 'open';
            });
            const n = r.filter((x) => x.r === 'open' || x.r === 'auto').length;
            say({ tm: `🧩 เปิดหน้าติดตั้ง Tampermonkey ใน ${n} Chrome`, ext: `🧩 เปิดหน้าตั้งค่า Tampermonkey ใน ${n} Chrome — เปิดสวิตช์ Allow User Scripts`, script: `⬆️ เปิดหน้าติดตั้งสคริปต์ v${scriptInfo().version} ใน ${n} Chrome — กด ติดตั้ง/อัปเดต` }[m[1]]);
            send(res, 200, { ok: true, n }); return;
        }
        if ((m = /^\/api\/group\/([\w-]+)\/(prep|check)$/.exec(p))) {
            const g = groupOf(m[1]); if (!g) throw Error('ไม่พบกลุ่ม');
            if (!(S.groups[g.id] || {}).debug) throw Error(`${g.id} ยังไม่ได้เปิดจากโปรแกรม`);
            if (m[2] === 'check') {      // ตรวจ + ดึงจอเกมของโปรไฟล์นี้ขึ้นมา (แท็บที่ซ่อน/ย่ออยู่ Chrome จะหน่วงสคริปต์ ทำให้ไม่ส่งเวอร์ชันมา)
                await extStatus(g).catch(() => {});
                const tg = (await jget(g.debugPort, '/json/list').catch(() => [])).filter(isGame);
                for (const t of tg) await focusTarget(g, t.id).catch(() => {});
                const info = S.groups[g.id] || {}; if (info.script) info.script.at = 0;      // รอเวอร์ชันใหม่จากสคริปต์
                send(res, 200, { ok: true, n: tg.length }); return;
            }
            prepGroup(g, false).catch(() => {}); send(res, 200, { ok: true }); return;
        }
        if (p === '/api/loginids') {      // แก้/ลบ ID ที่จำไว้ของโปรไฟล์ · ตั้งค่าเปิด/ปิดการจำ
            if (typeof b.remember === 'boolean') CFG.loginRemember = b.remember;
            if (typeof b.fill === 'boolean') CFG.loginFill = b.fill;
            if (b.grp) { const g = groupOf(String(b.grp)); if (!g) throw Error('ไม่พบโปรไฟล์'); const ids = (Array.isArray(b.ids) ? b.ids : []).map((x) => String(x).trim()).filter((x) => /^[\w.@+-]{3,64}$/.test(x)); CFG.loginIds = CFG.loginIds || {}; if (ids.length) CFG.loginIds[g.id] = [...new Set(ids)].slice(0, 5); else delete CFG.loginIds[g.id]; }
            saveConfig(CFG); send(res, 200, { ok: true }); return;
        }
        if ((m0 = /^\/api\/group\/([\w-]+)\/tmpage$/.exec(p))) {      // 🧩 เปิดหน้า Tampermonkey (หน้าต่างปกติ) — ใช้ได้ทั้งโหมดแอป/ปกติ · ผู้ใช้ยืนยัน/ตั้งค่าเองในหน้านั้น
            const g = groupOf(m0[1]); if (!g || !(S.groups[g.id] || {}).debug) throw Error('ต้องเปิด Browser ของโปรไฟล์นี้ก่อน');
            const page = b.page === 'ext' ? 'chrome://extensions/?id=' + TM_ID : `chrome-extension://${TM_ID}/options.html#nav=dashboard`;
            await cdp(await browserWs(g), (send) => send('Target.createTarget', { url: page, newWindow: true }));
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/ground') {      // ⬛ พื้นดำทุกจอ เปิด/ปิด → ต่อ/ตัดตัวเปลี่ยนภาพ แล้วรีโหลดหน้าเกม (ไม่ใช้แคช) ทีละจอ
            CFG.groundOff = !!b.on; saveConfig(CFG); groundSync();
            const tg = []; for (const g of CFG.groups) for (const t of ((S.groups[g.id] || {}).targets || []).filter(isGame)) if (t.webSocketDebuggerUrl) tg.push(t);
            if (b.reload !== false) (async () => { await sleep(1500); for (const t of tg) { await cdp(t.webSocketDebuggerUrl, (send) => send('Page.reload', { ignoreCache: true })).catch(() => {}); await sleep(2500); } })();
            say(`⬛ ${CFG.groundOff ? 'เปิด' : 'ปิด'}โหมดพื้นดำ · รีโหลดหน้าเกม ${tg.length} จอ (ทีละจอ)`); send(res, 200, { ok: true, on: CFG.groundOff, n: tg.length }); return;
        }
        if (p === '/api/group/order') {      // สลับลำดับโปรไฟล์ (เปลี่ยนเฉพาะลำดับ ไม่แตะข้อมูลข้างใน)
            const ids = Array.isArray(b.ids) ? b.ids.map(String) : [];
            if (ids.length !== CFG.groups.length || new Set(ids).size !== ids.length || ids.some((id) => !groupOf(id))) throw Error('ลำดับโปรไฟล์ไม่ครบหรือไม่ถูกต้อง — รีเฟรชหน้าแล้วลองใหม่');
            CFG.groups = ids.map((id) => groupOf(id)); saveConfig(CFG);
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/group/add') {      // เพิ่มโปรไฟล์ (Chrome/IP) จากหน้าหลัก
            const id = String(b.id || '').trim(); if (!/^[\w-]{1,20}$/.test(id)) throw Error('ชื่อโปรไฟล์ใช้ตัวอังกฤษ/ตัวเลข ไม่เกิน 20 ตัว');
            if (groupOf(id)) throw Error(`มีโปรไฟล์ ${id} อยู่แล้ว`);
            const proxy = normProxy(b.proxy);
            const used = new Set(CFG.groups.map((g) => g.debugPort)); let port = 9301; while (used.has(port)) port++;
            CFG.groups.push({ id, name: String(b.name || id).trim() || id, proxy, dir: `C:\\Chrome${id}`, debugPort: port, maxScreens: Math.max(0, Math.min(20, parseInt(b.maxScreens, 10) || 0)) || undefined });
            saveConfig(CFG); relaysSync(); say(`➕ เพิ่มโปรไฟล์ ${id}${proxy ? ' (' + proxyPlain(proxy).replace(/^https?:\/\//, '') + ')' : ' (เน็ตบ้าน)'}`);
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/group/del') {      // 🗑️ ลบโปรไฟล์จากหน้าหลัก — ต้องปิด Chrome ก่อน · ไม่ลบโฟลเดอร์ข้อมูล Chrome (เพิ่มชื่อเดิมกลับมาได้ ข้อมูลอยู่ครบ)
            const g = groupOf(String(b.id || '')); if (!g) throw Error('ไม่พบโปรไฟล์');
            const i = S.groups[g.id] || {}; if (i.debug || i.running || i.outside) throw Error(`ปิด Chrome ของ ${g.id} ก่อนจึงลบได้`);
            CFG.groups = CFG.groups.filter((x) => x !== g); saveConfig(CFG); relaysSync();
            for (const pe of Object.values(S.peers)) if (pe.group === g.id) { delete S.peers[pe.tab]; delete S.cmds[pe.tab]; delete S.inv[pe.tab]; }
            delete S.groups[g.id]; delete S.prep[g.id];
            say(`🗑️ ลบโปรไฟล์ ${g.id} (โฟลเดอร์ ${g.dir} ยังอยู่ในเครื่อง)`); send(res, 200, { ok: true }); return;
        }
        if (p === '/api/checkall') { await eachRunning((g) => extStatus(g)); send(res, 200, { ok: true }); return; }
        if ((m = /^\/api\/setup\/(policy|unpolicy)$/.exec(p))) { await policySet(b.scope === 'machine' ? 'machine' : 'user', m[1] === 'policy'); send(res, 200, { ok: true }); return; }
        if ((m = /^\/api\/peer\/([\w-]+)\/cmd$/.exec(p))) {
            const pe = S.peers[m[1]]; if (!pe) throw Error('ไม่พบตัวละคร');
            const ex = {};
            if (b.map) ex.map = String(b.map).slice(0, 80);
            if (b.idx !== undefined) { ex.idx = +b.idx || 0; ex.ic = String(b.ic || '').slice(0, 300); ex.n = String(b.n || '').slice(0, 80); }
            if (Array.isArray(b.plan)) ex.plan = b.plan.slice(0, 6).map((r) => ({ s: String(r.s || '').slice(0, 4), t: +r.t || 0 }));
            if (typeof b.on === 'boolean') ex.on = b.on;
            const rects = (a) => a.slice(0, 60).map((z) => (Array.isArray(z) ? z.slice(0, 4).map((v) => Math.max(0, Math.floor(+v) || 0)) : [0, 0, 0, 0]));
            if (Array.isArray(b.zones)) ex.zones = rects(b.zones);
            if (Array.isArray(b.ban)) ex.ban = rects(b.ban);
            if (Array.isArray(b.spots)) ex.spots = b.spots.slice(0, 40).map((q) => (Array.isArray(q) ? [Math.floor(+q[0]) || 0, Math.floor(+q[1]) || 0] : [0, 0]));
            if (Array.isArray(b.skplan)) ex.plan = b.skplan.slice(0, 40).map((r) => ({ n: String(r.n || '').slice(0, 40), t: Math.max(0, Math.min(99, +r.t || 0)), c: String(r.c || '').slice(0, 24) }));
            if (Array.isArray(b.names)) ex.names = b.names.slice(0, 9).map((x) => String(x).slice(0, 40));
            if (b.wmax !== undefined) ex.wmax = Math.max(50, Math.min(100, +b.wmax || 90));
            const flat = (o, depth) => { const r = {}; for (const [k, v] of Object.entries(o || {}).slice(0, 400)) { if (!/^[^\x00-\x1f<>]{1,40}$/.test(k) || k === '__proto__' || k === 'constructor') continue; if (typeof v === 'boolean' || typeof v === 'number') r[k] = v; else if (typeof v === 'string') r[k] = v.slice(0, 60); else if (v === null) r[k] = null; else if (depth < 2 && v && typeof v === 'object') r[k] = flat(v, depth + 1); } return r; };
            if (b.jopt && typeof b.jopt === 'object') ex.opt = flat(b.jopt, 0);
            if (b.jmap && typeof b.jmap === 'object') ex.map = flat(b.jmap, 0);
            if (b.jmapReplace && typeof b.jmapReplace === 'object') ex.mapReplace = flat(b.jmapReplace, 0);
            if (typeof b.jshared === 'boolean') ex.shared = b.jshared;
            if (Array.isArray(b.items)) ex.items = b.items.slice(0, 60).map((x) => ({ idx: +x.idx || 0, ic: String(x.ic || '').slice(0, 300), n: String(x.n || '').slice(0, 80) }));
            if (b.acfg && typeof b.acfg === 'object') {      // ตั้งค่า Auto: รับเฉพาะคีย์ที่รู้จัก + ชนิดข้อมูลถูก
                const A = b.acfg, c = {}, bool = ['basicAttack', 'buffParty', 'acceptParty', 'autoQuiver', 'autoRevive', 'defendOthers', 'flyWing', 'pickupLoot'], num = ['autoReviveMax', 'flyWingIdleSeconds', 'flyWingMobs', 'hpPercent', 'spPercent', 'healPartyPercent'], lists = ['monsters', 'lootTypes', 'buffItems', 'hpItems', 'spItems'];
                for (const k of bool) if (typeof A[k] === 'boolean') c[k] = A[k];
                for (const k of num) if (A[k] !== undefined && isFinite(+A[k])) c[k] = +A[k];
                for (const k of lists) if (Array.isArray(A[k])) c[k] = A[k].slice(0, 20).map((x) => String(x).slice(0, 60));
                if (A.huntRadiusTiles === 'all' || isFinite(+A.huntRadiusTiles)) c.huntRadiusTiles = A.huntRadiusTiles === 'all' ? 'all' : +A.huntRadiusTiles;
                if (A.lootWhen === 'clear' || A.lootWhen === 'first') c.lootWhen = A.lootWhen;
                ex.cfg = c;
            }
            if (b.job !== undefined) ex.job = b.job && b.job.n ? { n: String(b.job.n).slice(0, 30), th: String(b.job.th || '').slice(0, 30), id: String(b.job.id || '').slice(0, 30) } : null;
            if (b.to !== undefined) ex.to = String(b.to).replace(/\D/g, '').slice(0, 3);
            if (Array.isArray(b.keep)) ex.keep = b.keep.slice(0, 100).map((x) => String(x || '').slice(0, 50)).filter(Boolean);
            if (Array.isArray(b.danger)) ex.danger = b.danger.slice(0, 60).map((x) => +x || 0);
            if (b.opt && typeof b.opt === 'object') { ex.opt = {}; for (const [k, v] of Object.entries(b.opt).slice(0, 30)) if (/^\w{1,20}$/.test(k) && (typeof v === 'boolean' || typeof v === 'number')) ex.opt[k] = v; }
            await peerCmd(pe, String(b.cmd || ''), Object.keys(ex).length ? ex : null); send(res, 200, { ok: true }); return;
        }
        if (p === '/api/all/cmd') {
            const cmd = String(b.cmd || ''); if (!SCRIPT_CMDS.has(cmd)) throw Error('คำสั่งนี้สั่งทั้งหมดไม่ได้');
            const list = Object.values(S.peers).filter((x) => Date.now() - x.ts < 30000 && (!b.group || x.group === b.group));
            const ex = cmd === 'r3cap' ? { v: Math.max(0, Math.min(60, Math.round(+b.v || 0))) } : cmd === 'convbuy' ? { o: { on: !!(b.o && b.o.on), at: +(b.o && b.o.at) || 50, qty: +(b.o && b.o.qty) || 100, keep: Math.max(0, +(b.o && b.o.keep) || 0), max: Math.max(0.5, Math.min(10, +(b.o && b.o.max) || 2.5)) } } : undefined;
            if (ex && ex.v !== undefined && !b.group) { CFG.fpsLog = (CFG.fpsLog || []).concat([{ at: Date.now(), v: ex.v }]).slice(-10); saveConfig(CFG); }      // จำเวลาเปลี่ยน FPS ไว้เทียบ Z/ชม. ก่อน-หลัง
            list.forEach((x, i) => { if (cmd === 'reload') setTimeout(() => queue(x.tab, cmd), i * 2500); else queue(x.tab, cmd, ex); });      // รีโหลดทยอยทีละจอ
            say(`📣 สั่ง "${cmd}"${ex ? ' = ' + (ex.v !== undefined ? ex.v : JSON.stringify(ex.o)) : ''} ${list.length} ตัว${b.group ? ' ใน ' + b.group : ''}`);
            send(res, 200, { ok: true, n: list.length }); return;
        }
        if (p === '/api/links') {      // 🔗 บันทึกลิงก์ + ส่งให้ทุกจอ
            const O = CFG.links || {}, has = (k) => b[k] !== undefined;      // ไม่ได้ส่งช่องไหนมา = คงค่าเดิมไว้
            const sheet = has('sheet') ? String(b.sheet || '').trim() : O.sheet || '', discord = has('discord') ? String(b.discord || '').trim() : O.discord || '', ping = has('ping') ? String(b.ping || '').replace(/\D/g, '').slice(0, 25) : O.ping || '';
            const dstatus = has('dstatus') ? String(b.dstatus || '').trim() : O.dstatus || '';
            if (dstatus && !/^https:\/\/(?:(?:ptb|canary)\.)?(?:discord|discordapp)\.com\/api\/webhooks\/\d+\/[\w-]+/.test(dstatus)) throw Error('Webhook ห้องสถานะต้องเป็น https://discord.com/api/webhooks/...');
            let dc = O.dc || null;
            if (b.dc && typeof b.dc === 'object') { const t = {}; for (const k of DC_KEYS) t[k] = !!(b.dc.topics || {})[k]; dc = { topics: t, supplyMin: Math.max(5, Math.min(100, parseInt(b.dc.supplyMin, 10) || 30)), stallMin: Math.max(2, Math.min(15, parseInt(b.dc.stallMin, 10) || 4)), gm: (b.dc.topics || {}).gm !== false, gamefile: (b.dc.topics || {}).gamefile !== false }; }
            if (sheet && !/^https:\/\/script\.google\.com\/macros\/s\/[\w-]+\/exec/.test(sheet)) throw Error('ลิงก์ Google Sheets ต้องเป็น https://script.google.com/macros/s/.../exec');
            if (discord && !/^https:\/\/(?:(?:ptb|canary)\.)?(?:discord|discordapp)\.com\/api\/webhooks\/\d+\/[\w-]+/.test(discord)) throw Error('Discord Webhook ต้องเป็น https://discord.com/api/webhooks/...');
            CFG.links = { sheet, discord, ping, dstatus, dc, enforce: has('enforce') ? b.enforce !== false : O.enforce !== false }; saveConfig(CFG);
            let n = 0; for (const pe of Object.values(S.peers)) if (Date.now() - pe.ts < 180000 && verNum(pe.v || '0') >= verNum('5.95.0')) { LK_AT[pe.tab] = Date.now(); queue(pe.tab, 'linkset', linkPayload(CFG.links, verNum(pe.v || '0') >= verNum('5.97.2'))); n++; }
            say(`🔗 บันทึกลิงก์ Google Sheets / Discord แล้ว · ส่งให้ ${n} จอ`); send(res, 200, { ok: true, n }); return;
        }
        if (p === '/api/config') {
            const next = Object.assign({}, CFG);
            for (const k of ['chromePath', 'gameUrl', 'bypass', 'perfFlags', 'proxyUser', 'updateUrl']) if (typeof b[k] === 'string') next[k] = b[k].trim();
            if (next.updateUrl && !/^https?:\/\//.test(next.updateUrl)) throw Error('ลิงก์ตรวจอัปเดตต้องขึ้นต้นด้วย https://');
            if (typeof b.proxyPass === 'string' && b.proxyPass !== '********') next.proxyPass = b.proxyPass;
            for (const k of ['autoAllow', 'prepOnStart', 'autoUpdate', 'autoPurge', 'ramGuard', 'appMode', 'hcFocus']) if (typeof b[k] === 'boolean') next[k] = b[k];
            if (typeof b.browser === 'string') { if (!BROWSERS[b.browser]) throw Error('ไม่รู้จัก Browser นี้'); next.browser = b.browser; }
            if (b.purgeMin !== undefined) next.purgeMin = Math.max(5, Math.min(240, +b.purgeMin || 20));
            if (b.ramLimitGB !== undefined) next.ramLimitGB = Math.max(0.5, Math.min(16, +b.ramLimitGB || 2.5));
            if (b.reloadEveryH !== undefined) next.reloadEveryH = Math.max(0, Math.min(72, Math.round(+b.reloadEveryH || 0)));
            if (b.ramCooldownMin !== undefined) next.ramCooldownMin = Math.max(10, Math.min(720, +b.ramCooldownMin || 60));      // ช่องรหัสแสดง ******** = ไม่เปลี่ยน
            for (const k of ['maxPerIp', 'startGapSec']) if (b[k] !== undefined) next[k] = Math.max(1, Math.min(50, +b[k] || 1));
            if (b.screen) next.screen = { width: +b.screen.width || 1920, height: +b.screen.height || 1040, cols: +b.screen.cols || 4 };
            if (Array.isArray(b.groups)) {
                const ids = new Set(), ports = new Set();
                next.groups = b.groups.map((g) => ({ id: String(g.id || '').trim(), name: String(g.name || g.id || '').trim(), proxy: (() => { try { return normProxy(g.proxy); } catch (e) { throw Error(`${String(g.id || '')}: ${e.message}`); } })(), dir: String(g.dir || '').trim(), debugPort: +g.debugPort, maxScreens: Math.max(0, Math.min(20, parseInt(g.maxScreens, 10) || 0)) || undefined }))
                    .filter((g) => g.id && g.dir && !/^[a-z0-9]{6}__/.test(g.id));      // โปรไฟล์ของเครื่องอื่น (หลายเครื่อง) ห้ามบันทึกเป็นของเครื่องนี้
                for (const g of next.groups) {
                    if (!/^[\w-]+$/.test(g.id)) throw Error(`ชื่อกลุ่ม "${g.id}" ใช้ได้แค่ตัวอังกฤษ/ตัวเลข`);
                    if (ids.has(g.id)) throw Error(`ชื่อกลุ่ม ${g.id} ซ้ำ`); ids.add(g.id);
                    if (!(g.debugPort >= 1024 && g.debugPort <= 65000) || ports.has(g.debugPort)) throw Error(`พอร์ตของ ${g.id} ไม่ถูกต้องหรือซ้ำ`); ports.add(g.debugPort);
                    if (g.proxy && !/^(https?|socks5?):\/\/([^\s/@]+@)?[^\s/@]+$/.test(g.proxy)) throw Error(`พร็อกซีของ ${g.id} ต้องเป็นแบบ http://IP:พอร์ต`);
                }
            }
            CFG = next; saveConfig(CFG); relaysSync(); say('💾 บันทึกการตั้งค่าแล้ว');
            send(res, 200, { ok: true }); return;
        }
        send(res, 404, { ok: false, err: 'not found' });
    } catch (e) {
        send(res, 400, { ok: false, err: e && e.message ? e.message : String(e) });
    }
});
// ---------------------------------------------------------------
// 🔄 อัปเดตตัวโปรแกรม: ไฟล์ zip (ลากวาง หรือโหลดจากลิงก์ manifest) → ตรวจ → สำรองของเดิม → แตกทับ → รีสตาร์ทตัวเอง
//    ไม่แตะ config.json / peers.json / backup · Chrome ที่เปิดอยู่เล่นต่อได้ (ต่อกลับเองหลังรีสตาร์ท)
// ---------------------------------------------------------------
function unzip(buf) {      // อ่าน zip แบบไม่ใช้แพ็กเกจเสริม (เก็บตรง / deflate)
    let e = buf.length - 22; while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
    if (e < 0) throw Error('ไม่ใช่ไฟล์ zip');
    const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const out = [];
    for (let k = 0; k < n; k++) {
        if (buf.readUInt32LE(p) !== 0x02014b50) throw Error('ไฟล์ zip เสีย');
        const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nlen = buf.readUInt16LE(p + 28), xlen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), loff = buf.readUInt32LE(p + 42);
        const name = buf.slice(p + 46, p + 46 + nlen).toString('utf8'); p += 46 + nlen + xlen + clen;
        if (name.endsWith('/')) continue;
        const start = loff + 30 + buf.readUInt16LE(loff + 26) + buf.readUInt16LE(loff + 28), raw = buf.slice(start, start + csize);
        if (method !== 0 && method !== 8) throw Error('zip ใช้วิธีบีบอัดที่ไม่รองรับ');
        out.push({ name: name.replace(/\\/g, '/'), data: method === 0 ? raw : zlib.inflateRawSync(raw) });
    }
    return out;
}
const KEEP = /^(gamefiles\/.*|crash\.log|guard\.beat|quit\.flag|events\.json|remote\.json|tools\/.*|config\.json|config\.default\.json|peers\.json|cfgs\.json|token\.json|stats\.json|skills\.json|market\.json|classdata\.json|manager\.log|backup\/.*)$/i;
function applyAppZip(buf) {
    const files = unzip(buf);
    const srv = files.find((f) => /(^|\/)server\.js$/.test(f.name)); if (!srv) throw Error('ใน zip ไม่มี server.js — ไม่ใช่ไฟล์ Aetherack Manager');
    const prefix = srv.name.slice(0, srv.name.length - 'server.js'.length);
    const v = (/const VERSION = '([^']+)'/.exec(srv.data.toString('utf8')) || [])[1]; if (!v) throw Error('อ่านเวอร์ชันจาก server.js ไม่ได้');
    const list = files.filter((f) => f.name.startsWith(prefix)).map((f) => ({ rel: f.name.slice(prefix.length), data: f.data }))
        .filter((f) => f.rel && !KEEP.test(f.rel) && !f.rel.split('/').some((x) => x === '..' || x === ''));
    const bdir = path.join(ROOT, 'backup', `app-${VERSION}-${Date.now()}`);
    for (const f of list) {      // สำรองไฟล์เดิมก่อนทับ
        const dst = path.join(ROOT, f.rel);
        if (fs.existsSync(dst)) { const b = path.join(bdir, f.rel); fs.mkdirSync(path.dirname(b), { recursive: true }); try { fs.copyFileSync(dst, b); } catch (e) { /* ignore */ } }
    }
    for (const f of list) { const dst = path.join(ROOT, f.rel); fs.mkdirSync(path.dirname(dst), { recursive: true }); fs.writeFileSync(dst, f.data); }
    say(`🔄 ติดตั้งโปรแกรม v${v} แล้ว (${list.length} ไฟล์ · ของเดิมเก็บไว้ใน backup) — รีสตาร์ท…`);
    return v;
}
// 🩺 ตรวจและซ่อม Manager (ข้อ 24): ตรวจก่อน (ไม่แก้อะไร) → ผู้ใช้เลือกข้อที่จะซ่อม → สำรองไฟล์ข้อมูลทั้งหมดก่อน → ซ่อมเฉพาะที่ปลอดภัย
const DATA_FILES = ['events.json', 'config.json', 'peers.json', 'cfgs.json', 'token.json', 'stats.json', 'skills.json', 'market.json', 'classdata.json'];
function repairCheck() {
    const out = [], add = (id, lv, msg, fix, extra) => out.push(Object.assign({ id, lv, msg, fix: fix || '' }, extra || {}));
    for (const f of DATA_FILES) { const fp = path.join(ROOT, f); if (!fs.existsSync(fp)) continue; try { JSON.parse(fs.readFileSync(fp, 'utf8')); } catch (e) { add('badjson:' + f, 'bad', `ไฟล์ ${f} เสีย อ่านไม่ได้ (${e.message.slice(0, 60)})`, `ย้ายไฟล์เสียไปเป็น ${f}.bad (เก็บไว้ ไม่ลบ) แล้วให้ Manager สร้างใหม่ — ${f === 'config.json' ? 'การตั้งค่าจะกลับเป็นค่าเริ่มต้น (มีสำเนาใน backup)' : 'ข้อมูลในไฟล์นั้นจะเริ่มใหม่'}`, { restart: true, risky: true }); } }
    const ids = new Set(), ports = new Set();
    for (const g of CFG.groups) { if (ids.has(g.id)) add('dupid:' + g.id, 'bad', `ชื่อโปรไฟล์ ${g.id} ซ้ำ`); ids.add(g.id); if (ports.has(g.debugPort)) add('dupport:' + g.id, 'bad', `พอร์ต ${g.debugPort} ของ ${g.id} ซ้ำกับโปรไฟล์อื่น — แก้ในหน้า ตั้งค่า`); ports.add(g.debugPort); }
    { const rp = new Map(); for (const g of CFG.groups) if (g.proxy) { const k = 18000 + (g.debugPort % 1000); if (rp.has(k)) add('relay:' + g.id, 'warn', `ตัวส่งรหัสพร็อกซีของ ${g.id} ชนกับ ${rp.get(k)} (พอร์ต ${k}) — เปลี่ยนพอร์ตของโปรไฟล์ใดโปรไฟล์หนึ่ง`); rp.set(k, g.id); } }
    if (!findChrome()) add('browser', 'bad', `ไม่พบ ${BROWSERS[browserId()].name} ในเครื่อง — เลือก Browser อื่นหรือใส่ที่อยู่ในหน้า ตั้งค่า`);
    let si = null; try { si = scriptInfo(); } catch (e) { /* ignore */ } if (!si || !si.version) add('script', 'bad', 'ไม่พบไฟล์สคริปต์ aetherack.user.js ในโฟลเดอร์โปรแกรม (หรืออ่านเวอร์ชันไม่ได้) — กด 🆕 อัปเดตโปรแกรมเพื่อโหลดใหม่');
    else { const old = Object.values(S.peers).filter((p) => Date.now() - p.ts < 180000 && p.v && verNum(p.v) < verNum(si.version)); if (old.length) add('oldscript', 'warn', `${old.length} จอยังใช้สคริปต์เก่า (${[...new Set(old.map((p) => p.v))].join(', ')}) — ล่าสุด ${si.version}`, 'สั่งรีโหลดหน้าเกมจอนั้นตอนว่าง (รีโหลดแบบปลอดภัย)', { tabs: old.map((p) => p.tab) }); }
    const tmp = fs.readdirSync(ROOT).filter((f) => /\.tmp$/.test(f)); if (tmp.length) add('tmp', 'warn', `ไฟล์ชั่วคราวค้าง ${tmp.length} ไฟล์ (${tmp.slice(0, 4).join(', ')})`, 'ลบไฟล์ .tmp ที่ค้าง');
    const oldPend = Object.entries(CFGS.pend).filter(([, v]) => Date.now() - (v.at || 0) > 7 * 86400000); if (oldPend.length) add('cfgpend', 'warn', `Config ที่รอใส่นานเกิน 7 วัน ${oldPend.length} รายการ (${oldPend.slice(0, 3).map(([k]) => k).join(', ')})`, 'ยกเลิกรายการที่รอค้าง (สำเนาปลายทางยังอยู่)');
    for (const g of CFG.groups) { const i = S.groups[g.id] || {}; if (i.outside) add('outside:' + g.id, 'warn', `${g.id} เปิดจากนอก Manager (ไม่มีช่องควบคุม) — ปิด Chrome ตัวนั้นแล้วเปิดจาก Manager`); }
    try { let n = 0; const walk = (d) => { for (const f of fs.readdirSync(d, { withFileTypes: true })) { const fp = path.join(d, f.name); if (f.isDirectory()) walk(fp); else n += fs.statSync(fp).size; } }; const bd = path.join(ROOT, 'backup'); if (fs.existsSync(bd)) walk(bd); if (n > 500e6) add('backup', 'warn', `โฟลเดอร์ backup ใหญ่ ${Math.round(n / 1e6)} MB — ลบของเก่าเองได้ (Manager ไม่ลบให้)`); } catch (e) { /* ignore */ }
    return out;
}
function repairFix(ids) {
    const all = repairCheck(), pick = all.filter((x) => x.fix && ids.includes(x.id)); if (!pick.length) return { done: [], restart: false };
    const ts = new Date().toISOString().replace(/[:.]/g, '-'), bdir = path.join(ROOT, 'backup', 'repair-' + ts); fs.mkdirSync(bdir, { recursive: true });
    for (const f of DATA_FILES) { const fp = path.join(ROOT, f); if (fs.existsSync(fp)) fs.copyFileSync(fp, path.join(bdir, f)); }      // สำรองก่อนซ่อมเสมอ
    const done = []; let restart = false;
    for (const x of pick) {
        try {
            if (x.id.startsWith('badjson:')) { const f = x.id.slice(8), fp = path.join(ROOT, f); fs.renameSync(fp, `${fp}.bad-${ts}`); restart = true; done.push(`ย้าย ${f} ที่เสียออกแล้ว`); }
            else if (x.id === 'oldscript') { for (const t of x.tabs || []) queue(t, 'reloadsafe', {}); done.push(`สั่งรีโหลดแบบปลอดภัย ${(x.tabs || []).length} จอ`); }
            else if (x.id === 'tmp') { for (const f of fs.readdirSync(ROOT).filter((f) => /\.tmp$/.test(f))) fs.unlinkSync(path.join(ROOT, f)); done.push('ลบไฟล์ .tmp แล้ว'); }
            else if (x.id === 'cfgpend') { for (const [k, v] of Object.entries(CFGS.pend)) if (Date.now() - (v.at || 0) > 7 * 86400000) delete CFGS.pend[k]; cfgsDirty = true; done.push('ยกเลิก Config ที่รอค้างแล้ว'); }
        } catch (e) { done.push(`❌ ${x.msg}: ${e.message}`); }
    }
    say(`🩺 ซ่อม Manager: ${done.join(' · ')} (สำรองไว้ที่ backup/repair-${ts})`);
    return { done, restart, backup: 'backup/repair-' + ts };
}
function restartSelf() {
    evFlush();
    for (const r of RELAYS.values()) { try { r.server.close(); } catch (e) { /* ignore */ } }
    server.close();
    let out = 'ignore'; try { out = fs.openSync(path.join(ROOT, 'manager.log'), 'a'); } catch (e) { /* ignore */ }
    spawn(process.execPath, [path.join(ROOT, 'server.js'), '--restarted'], { cwd: ROOT, detached: true, stdio: ['ignore', out, out], windowsHide: true }).unref();
    setTimeout(() => process.exit(0), 400);
}
function httpsGet(url, max = 60e6, hops = 0, hdr) {      // โหลดไฟล์ (ตามลิงก์ย้ายได้)
    return new Promise((resolve, reject) => {
        const mod = url.startsWith('https:') ? require('node:https') : http;
        mod.get(url, { headers: Object.assign({ 'User-Agent': 'AetherackManager/' + VERSION }, hdr || {}), timeout: 30000 }, (r) => {
            if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location && hops < 5) { r.resume(); resolve(httpsGet(new URL(r.headers.location, url).href, max, hops + 1, hdr)); return; }
            if (r.statusCode !== 200) { r.resume(); reject(Error('HTTP ' + r.statusCode)); return; }
            const ch = []; let n = 0;
            r.on('data', (c) => { n += c.length; if (n > max) { r.destroy(); reject(Error('ไฟล์ใหญ่เกิน')); } else ch.push(c); });
            r.on('end', () => resolve(Buffer.concat(ch))); r.on('error', reject);
        }).on('error', reject).on('timeout', function () { this.destroy(Error('หมดเวลา')); });
    });
}
async function checkUpdate() {
    const src = CFG.updateUrl || UPDATE_URL;
    let m = null;
    const gh = /^https:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/(.+)$/.exec(src);
    if (gh) {      // GitHub: ถาม API ก่อน (ได้ค่าล่าสุดทันที ไม่ติดแคช ~5 นาทีของ raw) · ไม่ได้ค่อยใช้ raw
        try { m = JSON.parse((await httpsGet(`https://api.github.com/repos/${gh[1]}/${gh[2]}/contents/${gh[4]}?ref=${gh[3]}`, 1e6, 0, { Accept: 'application/vnd.github.raw' })).toString('utf8')); } catch (e) { m = null; }
    }
    if (!m || !m.version) m = JSON.parse((await httpsGet(src + (src.includes('?') ? '&' : '?') + 't=' + Date.now(), 1e6)).toString('utf8'));
    if (!m || !m.version || !m.url) throw Error('ไฟล์ manifest ไม่ถูกต้อง (ต้องมี version และ url)');
    return { version: String(m.version), url: new URL(String(m.url), src).href,      // url ใน manifest เป็นชื่อไฟล์เฉย ๆ ได้ (อยู่โฟลเดอร์เดียวกับ manifest)
         sha256: String(m.sha256 || ''), notes: String(m.notes || ''), newer: verNum(m.version) > verNum(VERSION) };
}
function openAppWindow(u) {      // หน้ารวมเป็นหน้าต่างแอปแยก (มีไอคอนของโปรแกรม) · ไม่มี Chrome → เบราว์เซอร์ปกติ
    if (process.platform !== 'win32' || process.argv.includes('--no-open')) return;
    const exe = findChrome();
    if (exe) spawn(exe, [`--app=${u}`, `--user-data-dir=${path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'AetherackManager', 'app-window')}`, '--window-size=1400,900', '--no-first-run', '--no-default-browser-check', '--disable-features=Translate'], { detached: true, stdio: 'ignore' }).unref();
    else spawn('cmd', ['/c', 'start', '', u], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
}
// เปิดโปรแกรมซ้ำ: ตัวที่ค้างอยู่เป็นเวอร์ชันเก่ากว่า (เช่น แตก zip ทับตอนโปรแกรมยังเปิด) → สั่งตัวเก่าปิด แล้วรันตัวใหม่แทน · เวอร์ชันเดียวกัน → เปิดหน้ารวมให้
function takeOver() {
    const ask = (method, p, bd) => new Promise((resolve) => {
        const r = http.request({ host: '127.0.0.1', port: CFG.port, method, path: p, headers: { 'X-Aeth': '1', 'Content-Type': 'application/json' }, timeout: 4000 }, (x) => { let d = ''; x.on('data', (c) => d += c); x.on('end', () => { try { resolve(JSON.parse(d)); } catch (er) { resolve(null); } }); });
        r.on('error', () => resolve(null)).on('timeout', () => r.destroy()); r.end(method === 'POST' ? JSON.stringify(bd || {}) : undefined);
    });
    ask('GET', '/api/state').then(async (st) => {
        if (st && st.v && verNum(st.v) < verNum(VERSION)) {
            console.error(`ตัวเก่า v${st.v} เปิดค้างอยู่ — ปิดแล้วเปิด v${VERSION} แทน`);
            await ask('POST', '/api/quit', { keep: true });
            spawn(process.execPath, [path.join(ROOT, 'server.js'), '--takeover'], { cwd: ROOT, detached: true, stdio: 'inherit', windowsHide: true }).unref();
            setTimeout(() => process.exit(0), 300); return;
        }
        console.error(`โปรแกรมเปิดอยู่แล้ว — เปิดหน้ารวมให้แทน`); openAppWindow(`http://127.0.0.1:${CFG.port}/`); setTimeout(() => process.exit(0), 1500);
    });
}
// 🛡️ ข้อผิดพลาดที่ไม่ได้ดักไว้ → บันทึกลง crash.log + แจ้งในบันทึก แต่ไม่ปิดโปรแกรม (ตัวส่งต่อพร็อกซี/ลิงก์มือถือ/เครื่องลูกยังทำงานต่อ)
const CRASH_LOG = path.join(ROOT, 'crash.log'), CRASH_SAID = {};
function crashNote(kind, e) {
    const msg = String((e && e.message) || e).slice(0, 300), stack = String((e && e.stack) || msg);
    try { fs.appendFileSync(CRASH_LOG, `[${new Date().toLocaleString('th-TH', { hour12: false })}] v${VERSION} ${kind}\n${maskSecrets(stack)}\n\n`); } catch (er) { /* ignore */ }
    const now = Date.now(); if (now - (CRASH_SAID[msg] || 0) < 60000) return; CRASH_SAID[msg] = now;
    try { say(`⚠️ ข้อผิดพลาดภายใน (โปรแกรมทำงานต่อ · บันทึกใน crash.log): ${maskSecrets(msg)}`); } catch (er) { /* ignore */ }
}
process.on('uncaughtException', (e) => crashNote('uncaughtException', e));
process.on('unhandledRejection', (e) => crashNote('unhandledRejection', e));
// ✂️ ไฟล์บันทึกใหญ่เกิน 5 MB → เก็บไว้เฉพาะ 1 MB ท้ายสุด (ตรวจตอนเปิด + ทุกชั่วโมง)
function trimLog(f, max = 5e6, keep = 1e6) {
    try {
        const st = fs.statSync(f); if (st.size <= max) return;
        const fd = fs.openSync(f, 'r'), buf = Buffer.alloc(keep); fs.readSync(fd, buf, 0, keep, st.size - keep); fs.closeSync(fd);
        const s = buf.toString('utf8'), nl = s.indexOf('\n');
        fs.writeFileSync(f, `[ตัดไฟล์บันทึกเก่าออก — เหลือ ${Math.round(keep / 1e6)} MB ล่าสุด]\n` + s.slice(nl + 1));
    } catch (e) { /* ยังไม่มีไฟล์ */ }
}
const trimLogs = () => { trimLog(path.join(ROOT, 'manager.log')); trimLog(CRASH_LOG, 2e6, 5e5); };
trimLogs(); setInterval(trimLogs, 3600000);
// 🛡️ เปิดตัวเฝ้าไว้ 1 ตัว (มีตัวเฝ้าทำงานอยู่แล้ว = ไฟล์ guard.beat ยังใหม่ไม่เกิน 60 วิ)
function guardEnsure() {
    if (process.argv.includes('--no-guard')) return;
    try { if (Date.now() - (+fs.readFileSync(GUARD_BEAT, 'utf8') || 0) < 60000) return; } catch (e) { /* ยังไม่มีตัวเฝ้า */ }
    try { fs.writeFileSync(GUARD_BEAT, String(Date.now())); spawn(process.execPath, [path.join(ROOT, 'server.js'), '--guard'], { cwd: ROOT, detached: true, stdio: 'ignore', windowsHide: true }).unref(); } catch (e) { /* ignore */ }
}
let bindTry = 0;
server.on('error', (e) => {
    if (e.code === 'EADDRINUSE' && (process.argv.includes('--restarted') || process.argv.includes('--takeover')) && bindTry++ < 20) { setTimeout(() => server.listen(CFG.port, '127.0.0.1'), 500); return; }      // รีสตาร์ทหลังอัปเดต: รอตัวเก่าปิดพอร์ต
    if (e.code === 'EADDRINUSE') { takeOver(); return; }
    console.error(e.message); process.exit(1);
});
setTimeout(async () => {      // เปิดโปรแกรมแล้วตรวจ Chrome ที่เปิดค้างอยู่ 1 รอบ (Tampermonkey / Allow User Scripts) ให้ตารางสถานะมีข้อมูล
    for (const g of CFG.groups) { const i = S.groups[g.id] || {}; if (i.debug && !i.ext) await extStatus(g).catch(() => {}); }
}, 6000);
server.listen(CFG.port, '127.0.0.1', () => {
    relaysSync();      // Chrome ที่เปิดค้างไว้จากรอบก่อนยังชี้มาที่ตัวกลาง → เปิดตัวกลางรอไว้เลย (หลังได้พอร์ตหลักแล้ว = ไม่ได้เปิดซ้อน)
    const u = `http://127.0.0.1:${CFG.port}/`;
    say(`✅ Aetherack Manager v${VERSION} พร้อมใช้งาน: ${u}`);
    try { fs.unlinkSync(QUIT_FLAG); } catch (e) { /* ไม่มีไฟล์ */ }
    if (process.argv.includes('--by-guard')) say('🛡️ ตัวเฝ้าเปิด Manager ใหม่ให้ (รอบก่อนหยุดทำงานเอง — ดูรายละเอียดใน crash.log / manager.log)');
    guardEnsure(); setInterval(guardEnsure, 60000);
    if (!findChrome()) say('⚠️ ไม่พบ chrome.exe — ใส่ที่อยู่ในหน้า ตั้งค่า');
    if (!process.argv.includes('--restarted')) openAppWindow(u);      // รีสตาร์ทหลังอัปเดต: หน้ารวมเดิมต่อกลับเอง
});

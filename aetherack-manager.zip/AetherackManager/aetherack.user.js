// ==UserScript==
// @name         Aetheria Tracker Pro + Material Profit
// @namespace    https://github.com/yourname/aetheria-tracker
// @version      5.45.0
// @description  Aetheria Online Tracker - Sheets sync, Auto-Z, Revive (+Discord alert), Profit (materials / item drops by rarity / kills per monster), DPS, Ping, Logs
// @author       you
// @match        *://*.aetheria-online.in.th/*
// @match        *://aetheria-online.in.th/*
// @grant        GM_xmlhttpRequest
// @grant        unsafeWindow
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        GM_listValues
// @grant        GM_addValueChangeListener
// @connect      script.google.com
// @connect      script.googleusercontent.com
// @connect      aetheria-online.in.th
// @connect      discord.com
// @connect      discordapp.com
// @connect      127.0.0.1
// @connect      localhost
// @license      MIT
// ==/UserScript==

(function () {
    'use strict';


    const VERSION = '5.45.0';

    // ---------------------------------------------------------------
    // 🔗 ใช้ข้อมูลร่วมกันทุก Container ของ Firefox (Multi-Account Containers แยก localStorage ต่อ Container)
    //   คีย์ at_* ทุกตัว (การตั้งค่า/โปรไฟล์ตัวละคร/โซน/จุดยืนตี/มอนอันตราย/รายการซื้อ/ข้อความสถานะ Discord ฯลฯ) ถูกคัดลอกไปเก็บใน
    //   พื้นที่ของ Tampermonkey (GM_setValue ใช้ร่วมกันทุก Container) → Container อื่นดึงไปใช้ตอนเปิด + รับการเปลี่ยนแปลงสด ๆ
    //   ยกเว้นข้อมูลเฉพาะแท็บ/เครื่อง (สถานะแท็บ, Log, แคชไอเทม, รีโหลด, หน้าต่าง Dev) · ปิดได้ต่อ Container (at_share_off)
    // ---------------------------------------------------------------
    // ไม่แชร์: ข้อมูลเฉพาะแท็บ/เครื่อง + ข้อมูลก้อนใหญ่ที่บันทึกถี่และใช้แค่แท็บของตัวละครนั้น (Profit/สถิติ/แถบเวลา/Log/แคช)
    //   — เดิมแชร์ด้วย ทุกครั้งที่บันทึก Profit (ทุกไม่กี่วิ × ทุกจอ) ถูกส่งต่อไปทุกแท็บ → Tampermonkey กินแรม/ซีพียูหนัก เกมแลค
    const LS_SKIP = /^(at_peer:.*|at_reload_log|at_reload_pending|at_logs_v1|at_itemdb_v2|at_r3_boot|at_dps_last_.*|at_dev_on|at_dev_pos|at_share_off|at_profit_v1_.*|at_stats_v1.*|at_tl:.*|at_dev_maps|at_walk_blk|at_walk_cal.*|at_inv_seen.*|at_junk_stats.*|at_town.*|at_gfx_backup)$/;
    const LS_DEL = '\u0000del';
    const LSS = { ok: typeof GM_getValue === 'function' && typeof GM_setValue === 'function' && typeof GM_listValues === 'function', src: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), n: 0, pulled: 0, at: 0 };
    function lsShareOn() { try { return LSS.ok && localStorage.getItem('at_share_off') !== '1'; } catch (e) { return false; } }
    const lsShared = (k) => /^at_/.test(k) && !LS_SKIP.test(k) && lsShareOn();
    function lsPush(k, v) { try { GM_setValue('ls:' + k, v); GM_setValue('ls_bus', { k, s: LSS.src, n: ++LSS.n }); } catch (e) { /* ignore */ } }
    function lsSet(k, v) { localStorage.setItem(k, v); if (lsShared(k)) lsPush(k, String(v)); }
    function lsDel(k) { localStorage.removeItem(k); if (lsShared(k)) lsPush(k, LS_DEL); }
    function lsApply(k) {      // ค่าจาก Container อื่น → localStorage ของ Container นี้ (เขียนตรง ไม่ส่งกลับ)
        if (!lsShared(k)) return false;
        let v; try { v = GM_getValue('ls:' + k); } catch (e) { return false; }
        if (v === undefined || v === null) return false;
        try {
            if (v === LS_DEL) { if (localStorage.getItem(k) !== null) { localStorage.removeItem(k); return true; } return false; }
            if (localStorage.getItem(k) !== v) { localStorage.setItem(k, v); return true; }
        } catch (e) { /* ignore */ }
        return false;
    }
    function lsSyncAll(push) {
        if (!lsShareOn()) return 0;
        let n = 0; const have = new Set();
        try {
            for (const g of GM_listValues()) { if (g.indexOf('ls:') !== 0) continue; const k = g.slice(3); have.add(k); if (lsApply(k)) n++; }
            if (push) for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i) || ''; if (!have.has(k) && lsShared(k)) { const v = localStorage.getItem(k); if (v !== null) GM_setValue('ls:' + k, v); } }
        } catch (e) { /* ignore */ }
        LSS.at = Date.now(); return n;
    }
    try { if (LSS.ok) for (const g of GM_listValues()) if (g.indexOf('ls:') === 0 && LS_SKIP.test(g.slice(3)) && typeof GM_deleteValue === 'function') GM_deleteValue(g); } catch (e) { /* ignore */ }      // ล้างข้อมูลก้อนใหญ่ที่เคยแชร์ไว้
    // นำเข้าการตั้งค่าแบบ 2 จังหวะ: กดนำเข้า → พักข้อมูลไว้ → รีโหลด → เขียนทับตรงนี้ก่อนสคริปต์อ่านค่า (แท็บที่กำลังรันเขียนค่าเก่าทับไม่ได้)
    let IMPORTED = null;
    try {
        const raw = localStorage.getItem('aetherack_import');
        if (raw) {
            localStorage.removeItem('aetherack_import');
            const j = JSON.parse(raw);
            if (j && j.data && Date.now() - (j.at || 0) < 600000) {
                let n = 0;
                for (const k of Object.keys(j.data)) { const v = j.data[k]; if (/^at_\S+$/.test(k) && typeof v === 'string') { try { lsSet(k, v); n++; } catch (e) { /* ignore */ } } }
                IMPORTED = { n, src: j.src || '', to: j.to || [], chars: j.chars || [], zones: j.zones || 0 };
            }
        }
    } catch (e) { /* ignore */ }
    LSS.pulled = lsSyncAll(true);      // ต้องทำก่อนอ่านการตั้งค่า (Store/State ด้านล่าง)
    try { if (LSS.ok && typeof GM_addValueChangeListener === 'function') GM_addValueChangeListener('ls_bus', (name, oldV, v, remote) => { if (remote && v && v.k && v.s !== LSS.src) lsApply(v.k); }); } catch (e) { /* ignore */ }
    setInterval(() => { try { lsSyncAll(false); } catch (e) { /* ignore */ } }, 60000);      // เผื่อพลาดการแจ้งเตือน

    // ---------------------------------------------------------------
    // Config
    // ---------------------------------------------------------------
    const CONFIG = {
        TICK_MS: 1000,
        SEND_INTERVAL_MS: 30000,
        INV_STALE_MS: 60000,
        AUTO_COOLDOWN_MS: 3000,
        REVIVE_COOLDOWN_MS: 2500,
        ANNOUNCE_SCAN_MS: 2500,
        SAFE_MAPS: ['เมืองหลวงโซลเฮเวน', 'ตลาดคาราวาน'],
        NO_COUNT_MAPS: ['เมืองหลวงโซลเฮเวน', 'ตลาดคาราวาน', 'คุก', 'ห้องทดสอบดาเมจ', 'หอไข่นำโชค'], // ไม่นับ Profit/สถิติ
        SAFE_MAP_KEYWORDS: ['ปลอดภัย'], // เกมใส่คำนี้ท้ายชื่อแมพที่ไม่มีช่วงเลเวล (เมือง)
        API_TOKEN: '',

        // Profit
        MATERIAL_TYPES: ['Miscellaneous'], // ประเภทที่เกมจัดเป็นแท็บ "วัตถุดิบ" ในกระเป๋า
        PRICE_TTL_MS: 6 * 3600 * 1000, // อัปเดตข้อมูลไอเทม/ราคาจาก wiki ของเกมทุก 6 ชม.
        PRICE_RECHECK_MS: 10 * 60 * 1000, // เจอไอเทมที่ไม่รู้จัก -> รีเฟรชได้อีกครั้งหลังผ่านเวลานี้
        MIN_FARM_MS_FOR_RATE: 60000, // ต้องฟาร์มอย่างน้อย 1 นาทีถึงจะคิดต่อชั่วโมง
        MAX_TICK_GAP_MS: 120000, // กันเวลากระโดดตอนเครื่องหลับ/แท็บถูกหน่วง
        SAVE_INTERVAL_MS: 10000,
        CHAT_POLL_MS: 3000, // อ่านแชท "ระบบ" (ข้อความฆ่ามอน) ทุกกี่ ms

        // Ping / Logs / DPS
        PING_INTERVAL_MS: 5000,
        PING_TIMEOUT_MS: 4000,
        PING_URL: '/version.json',
        PING_WARN_MS: 150,
        PING_BAD_MS: 300,
        PING_HISTORY: 12,
        LOG_MAX: 400,
        DPS_POLL_MS: 500,

        // Discord: กันส่งรัว (ms) แยกตามหัวข้อ
        DISCORD_COOLDOWN_MS: { premium: 600000, gamever: 60000, death: 20000, town: 20000, lag: 300000, rare: 1500, captcha: 60000, stall: 300000, server: 120000, supply: 600000, wish: 1500, bag: 600000, jail: 60000, junk: 30000, chat: 4000, digest: 60000, boss: 2000, daily: 60000, health: 600000, stuck: 1800000, warpback: 20000 },
    };

    const REGEX = {
        whitespace: /\s+/g,
        commas: /,/g,
        channel: /(CH\s*\d+)/i,
        baseLv: /Base\s*Lv\.?\s*(\d+)/i,
        jobLv: /Job\s*Lv\.?\s*(\d+)/i,
        weight: /(\d+[\d,]*)\s*\/\s*(\d+[\d,]*)/,
        hours: /(\d+)\s*ชม/i,
        // เกมส่ง exp_gain เป็นข้อความระบบ: "<ชื่อมอน>: Base EXP +N · Job EXP +M"
        kill: /^(.+?)\s*:\s*Base EXP\s*\+/i,
        discordUrl: /^https:\/\/(?:(?:ptb|canary)\.)?(?:discord|discordapp)\.com\/api\/webhooks\/\d+\/[\w-]+/,
    };

    // ระดับไอเทมตามที่เกมใช้ (class rarity-* ใน CSS ของเกม)
    const RARITY = {
        common: { label: 'ธรรมดา', color: '#f3f0e8', rank: 0, int: 0xf3f0e8 },
        uncommon: { label: 'ดี', color: '#86efac', rank: 1, int: 0x86efac },
        rare: { label: 'หายาก', color: '#7cc4ff', rank: 2, int: 0x7cc4ff },
        epic: { label: 'มหากาพย์', color: '#c49bff', rank: 3, int: 0xc49bff },
        legendary: { label: 'ตำนาน', color: '#ffb347', rank: 4, int: 0xffb347 },
    };
    const rarityOf = (r) => RARITY[r] || RARITY.common;

    const SELECTORS = {
        charName: ['.hud-name'],
        charClass: ['.hud-class'],
        level: ['.hud-levels'],
        portrait: ['.hud-head .portrait'],
        weight: ['.inv-weight .bar-num'],
        zeny: ['.inv-zeny b'],
        slots: ['.inv-count'],
        mapName: ['.minimap-name'],
        channel: ['.minimap-ch'],
        autoToggle: ['.auto-toggle'],
        uiRoot: ['.ui-root'],
        gainFeed: ['.gain-feed'],
        announcement: ['.events-window', '.window-announcement', '[role="dialog"][aria-label*="กิจกรรม"]', '[role="dialog"][aria-label*="ประกาศ"]'],
        announcementClose: ['.win-close', '.close-btn', 'button[aria-label*="ปิด"]'],
        deathOverlay: ['.death-overlay', '.death-modal', '.modal-death'],
        returnTownBtn: ['.death-overlay .death-actions button.ghost', '.death-overlay button'],
        buffItems: ['.buff-icons.hud-buffs .buff-icon'],
    };

    const OWN_UI = '#aetheria-tracker, #aetheria-profit, #aetheria-dps, #aetheria-logs, #aetheria-config, #aetheria-zone, #aetheria-stats, #aetheria-dps-notice, #at-toast-container';

    // ---------------------------------------------------------------
    // Storage / State
    // ---------------------------------------------------------------
    // โปรไฟล์ต่อตัวละคร: คีย์การตั้งค่าเหล่านี้เก็บแยกเป็น "<key>@<ชื่อตัวละคร>" (ถ้ายังไม่เคยตั้ง จะใช้ค่าร่วมเดิมเป็นค่าเริ่มต้น)
    const PROFILE_KEYS = new Set(['at_url', 'at_sync', 'at_auto', 'at_revive', 'at_minimized', 'at_profit_open', 'at_dps_open', 'at_logs_open', 'at_stats_open',
        'at_opts', 'at_warp_dest', 'at_junk_v1', 'at_junk_sh', 'at_inv_seen', 'at_junk_stats', 'at_daily_last', 'at_theme', 'at_dps_notice_off', 'at_dc_url', 'at_webhook', 'at_ping_id', 'at_scale', 'at_wide', 'at_profit_docked', 'at_cfg_tab',
        'at_stat_map', 'at_stat_range', 'at_stat_metric', 'at_ping_death', 'at_ping_rars', 'at_filter_v2', 'at_dc_on', 'at_dc_open', 'at_dc_topics',
        'at_sec_open', 'at_pos_x', 'at_pos_y', 'at_profit_pos', 'at_dps_pos', 'at_logs_pos', 'at_config_pos', 'at_stats_pos']);
    const Store = {
        char: '',
        pk(key) { return Store.char && PROFILE_KEYS.has(key) ? `${key}@${Store.char}` : key; },
        get(key, def = null) {
            try {
                let v = null;
                if (Store.char && PROFILE_KEYS.has(key)) v = localStorage.getItem(`${key}@${Store.char}`);
                if (v === null) v = localStorage.getItem(key);
                return v === null ? def : v;
            } catch (e) { return def; }
        },
        set(key, val) {
            try { lsSet(Store.pk(key), String(val)); } catch (e) { /* ignore */ }
        },
        remove(key) {
            try { lsDel(Store.pk(key)); } catch (e) { /* ignore */ }
        },
        getJSON(key, def = null) {
            try { return JSON.parse(Store.get(key, 'null')) || def; } catch (e) { return def; }
        },
    };

    function loadFilter() {
        const def = { cats: { all: true, equip: false, usable: false, refine: false, card: false },
            rars: { all: false, common: false, uncommon: false, rare: false, epic: true, legendary: true } };
        const n = Store.getJSON('at_filter_v2');
        if (n && n.cats && n.rars) return { cats: Object.assign(def.cats, n.cats), rars: Object.assign(def.rars, n.rars) };
        // ย้ายค่าจาก v4.0.1
        const oc = Store.getJSON('at_filter_cats'), or = Store.getJSON('at_filter_rars');
        if (oc) Object.assign(def.cats, oc);
        if (or) Object.assign(def.rars, { all: !!or.all, common: !!or.normal, uncommon: !!or.good, rare: !!or.rare, epic: !!or.epic, legendary: !!or.legend });
        return def;
    }

    // สถานะปิด/เปิดภาพ 3D ล่าสุด (อ่านได้ก่อนรู้ชื่อตัวละคร) -> คืนค่าทันทีตอนโหลดหน้าเว็บ
    const R3_BOOT_KEY = 'at_r3_boot';
    function bootR3() { try { return localStorage.getItem(R3_BOOT_KEY) === '1'; } catch (e) { return false; } }

    function readPrefs() {
        return {
        webAppUrl: Store.get('at_url', ''),
        isSyncEnabled: Store.get('at_sync') !== 'false',
        isAutoEnabled: Store.get('at_auto') !== 'false',
        isReviveEnabled: Store.get('at_revive') !== 'false',
        isMinimized: Store.get('at_minimized') === 'true',
        // ตอนโหลดหน้า/สลับโปรไฟล์ เปิดแค่แผงหลัก — หน้าต่างอื่นเปิดเองเมื่อต้องการ
        isProfitOpen: false,
        isDpsOpen: false,
        isLogsOpen: false,
        isStatsOpen: false,
        opt: Object.assign({ autoCard: true, sound: true, captcha: true, stall: true, stallMin: 4, conn: true, supply: true, supplyMin: 30, chat: true, digest: false, lowSpec: false, renderOff: bootR3(), renderFps: 6, r3Gpu: true, hubOn: true, hubUrl: 'http://127.0.0.1:17321', lowGfx: false, relayOn: true, tabTitle: true, r3Idle: true, r3IdleMin: 7, chSpread: true, wish: {}, bagWarn: true, hotkeys: true, daily: false, dailyHour: 23, healthAlert: true, dropStat: true, keepOpts: {}, dropDiscard: false, dropDiscardRars: { common: true, uncommon: true, rare: true, epic: false, legendary: false }, junkSlotOn: true, junkSlotFree: 0, junkSlotGoal: 10, junkOn: false, junkDry: true, junkAll: false, junkLock: { common: false, uncommon: false, rare: true, epic: true, legendary: true }, junkAt: 90, junkTo: 80, junkMax: 30, statusLive: false, bossM60: true, bossM30: false, bossM10: true, bossM5: false, bossM1: true, bossSpawn: true, bossAuto: false, bossPing: false, bossBoard: true, warpBack: false, warpFly: false, warpHeal: false, warpZone: false, warpZoneMax: 80, flyRestock: false, zoneFit: true, zoneMinR: 6, zoneWalk: true, zoneWalkMax: 10, storySkip: true, pickBw: true, spotOn: true, spotMax: 25, dangerFlee: false, dangerPad: 3, manualPause: true, manualMin: 3, newDry: true, supplyRestock: false, chSwitch: false, chMin: 5, premWarn: true, premHrs: 6, statusCompact: false, autoReload: false, reloadMin: 3, verWatch: true, quietOn: false, quietFrom: 1, quietTo: 7, ovMini: true, ovPath: true, ovArrow: true, ovArrowMin: 3, ovWall: false, zoneGuard: true, zoneGuardSec: 30, walkMode: 'auto', buyOn: false, statOn: false, stat: [{ s: 'STR', t: 99 }, { s: 'VIT', t: 80 }, { s: 'DEX', t: 60 }], buyNpc: 'Shopkeeper', buy: [{ n: 'Fly Wing', min: 10, q: 50 }, { n: '', min: 0, q: 0 }, { n: '', min: 0, q: 0 }] }, Store.getJSON('at_opts', {})),
        theme: Object.assign({ preset: 'gold', acc: '#fcd34d', acc2: '#f59e0b', bg: '#141417', text: '#f4f4f5', op: 1 }, Store.getJSON('at_theme', {})),
        dpsNoticeOff: Store.get('at_dps_notice_off') === 'true',
        isSettingsOpen: false,
        panelX: Store.get('at_pos_x', '20px'),
        panelY: Store.get('at_pos_y', '80px'),

        discordUrl: Store.get('at_dc_url', '') || Store.get('at_webhook', ''),
        discordOn: Store.get('at_dc_on') === 'true',
        discordOpen: Store.get('at_dc_open') === 'true',
        dcPing: Store.get('at_ping_id', ''),
        uiScale: Math.min(1.3, Math.max(0.7, parseFloat(Store.get('at_scale', '1')) || 1)),
        wideLayout: Store.get('at_wide') === 'true',
        profitDocked: Store.get('at_profit_docked') !== 'false',
        cfgTab: Store.get('at_cfg_tab', 'sheets'),
        statMap: Store.get('at_stat_map', ''),
        statRange: Store.get('at_stat_range', '24h'),
        statMetric: Store.get('at_stat_metric', 'z'),
        pingDeath: Store.get('at_ping_death') !== 'false',
        pingRars: Object.assign({ common: false, uncommon: false, rare: false, epic: true, legendary: true }, Store.getJSON('at_ping_rars', {})),
        filter: loadFilter(),
        dcTopics: Object.assign({ death: true, town: false, jail: true, junk: true, lag: false, rare: false, captcha: true, stall: true, server: true, supply: true, wish: true, bag: true, chat: true, digest: false, boss: true, daily: true, health: true, stuck: true, premium: true, gamever: true, warpback: true }, Store.getJSON('at_dc_topics', {})),
        secOpen: Object.assign({ mats: true, drops: false, kills: false, stats: false }, Store.getJSON('at_sec_open', {})),

        };
    }

    const State = Object.assign(readPrefs(), {
        isGameReady: false,
        isSending: false,
        wasDead: false,
        lastSentSnapshot: '',
        lastAutoAttempt: 0,
        lastReviveAttempt: 0,
        autoAttempts: 0,
        lastInvSeenAt: 0,
        lastSendAt: 0,
        lastAnnounceAt: 0,
        lastPingAt: 0,
        lastChatAt: 0,

        statusText: 'กำลังเริ่มต้น...',
        statusType: 'warn',
        warpHold: false,
        cacheValues: {},
    });

    const savePrefs = () => {
        Store.set('at_sync', State.isSyncEnabled);
        Store.set('at_auto', State.isAutoEnabled);
        Store.set('at_revive', State.isReviveEnabled);
        Store.set('at_minimized', State.isMinimized);
        Store.set('at_profit_open', State.isProfitOpen);
        Store.set('at_dps_open', State.isDpsOpen);
        Store.set('at_logs_open', State.isLogsOpen);
        Store.set('at_stats_open', State.isStatsOpen);
        Store.set('at_opts', JSON.stringify(State.opt));
        if (typeof junkShareWrite === 'function') junkShareWrite();
        Store.set('at_theme', JSON.stringify(State.theme));
        Store.set('at_dps_notice_off', State.dpsNoticeOff);
        Store.set('at_url', State.webAppUrl);
        Store.set('at_dc_url', State.discordUrl);
        Store.set('at_ping_id', State.dcPing);
        Store.set('at_scale', State.uiScale);
        Store.set('at_wide', State.wideLayout);
        Store.set('at_profit_docked', State.profitDocked);
        Store.set('at_cfg_tab', State.cfgTab);
        Store.set('at_stat_map', State.statMap);
        Store.set('at_stat_range', State.statRange);
        Store.set('at_stat_metric', State.statMetric);
        Store.set('at_ping_death', State.pingDeath);
        Store.set('at_ping_rars', JSON.stringify(State.pingRars));
        Store.set('at_filter_v2', JSON.stringify(State.filter));
        Store.set('at_dc_on', State.discordOn);
        Store.set('at_dc_open', State.discordOpen);
        Store.set('at_dc_topics', JSON.stringify(State.dcTopics));
        Store.set('at_sec_open', JSON.stringify(State.secOpen));
    };

    const savePos = (x, y) => {
        State.panelX = x;
        State.panelY = y;
        Store.set('at_pos_x', x);
        Store.set('at_pos_y', y);
    };

    // ---------------------------------------------------------------
    // Logs (บันทึกการทำงานของสคริปต์นี้เอง ไม่ใช่ของเกม)
    // ---------------------------------------------------------------
    const LOG_KEY = 'at_logs_v1';
    const Log = {
        entries: [],
        seq: 0,
        add(level, tag, msg) {
            Log.entries.push({ id: ++Log.seq, t: Date.now(), level, tag, msg: String(msg) });
            if (Log.entries.length > CONFIG.LOG_MAX) Log.entries.splice(0, Log.entries.length - CONFIG.LOG_MAX);
            try {
                const fn = level === 'err' ? console.error : level === 'warn' ? console.warn : console.log;
                fn(`[Tracker][${tag}] ${msg}`);
            } catch (e) { /* ignore */ }
        },
        info(tag, msg) { Log.add('info', tag, msg); },
        ok(tag, msg) { Log.add('ok', tag, msg); },
        warn(tag, msg) { Log.add('warn', tag, msg); },
        err(tag, msg) { Log.add('err', tag, msg); },
        gain(tag, msg) { Log.add('gain', tag, msg); },
        save() {
            try { Store.set(LOG_KEY, JSON.stringify(Log.entries.slice(-150))); } catch (e) { /* ignore */ }
        },
        load() {
            const d = Store.getJSON(LOG_KEY);
            if (!Array.isArray(d)) return;
            for (const e of d) {
                if (e && e.msg) Log.entries.push({ id: ++Log.seq, t: e.t, level: e.level, tag: e.tag, msg: e.msg });
            }
        },
    };

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------
    const gameDomCache = new Map();
    const uiRefs = {};
    const pRefs = {}; // element ของแท็บ Profit
    const dRefs = {}; // element ของแท็บ DPS
    const lRefs = {}; // element ของแท็บ Logs
    const renderedState = {};
    const fieldMemo = {};

    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

    async function waitFor(cond, timeout = 1500, interval = 50) {
        const start = Date.now();
        while (Date.now() - start < timeout) {
            if (cond()) return true;
            await sleep(interval);
        }
        return false;
    }

    function queryGame(selectors) {
        for (const sel of selectors) {
            let el = gameDomCache.get(sel);
            if (el && el.isConnected) return el;
            el = document.querySelector(sel);
            if (el) {
                gameDomCache.set(sel, el);
                return el;
            }
        }
        return null;
    }

    function queryGameAll(selectors) {
        for (const sel of selectors) {
            const list = document.querySelectorAll(sel);
            if (list.length > 0) return list;
        }
        return [];
    }

    function isVisible(selectors) {
        const el = queryGame(selectors);
        return !!el && el.getClientRects().length > 0;
    }

    function isNodeVisible(el) {
        return !!el && el.isConnected && el.getClientRects().length > 0;
    }

    function isTyping() {
        const el = document.activeElement;
        if (!el) return false;
        if (el.closest && el.closest(OWN_UI)) return false; // ช่องกรอกของสคริปต์เองต้องไม่ขวาง auto/กลับเมือง
        const tag = el.tagName;
        return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || el.isContentEditable;
    }

    function pressKey(key, code, keyCode) {
        const opts = { key, code, keyCode, which: keyCode, bubbles: true, cancelable: true };
        document.dispatchEvent(new KeyboardEvent('keydown', opts));
        document.dispatchEvent(new KeyboardEvent('keyup', opts));
    }

    // view ของ MouseEvent/PointerEvent ต้องเป็น window ของหน้าเกม (ใน Tampermonkey `window` คือ sandbox → error)
    const VIEW = typeof unsafeWindow !== 'undefined' ? unsafeWindow : null;
    function triggerClick(el) {
        if (!el) return;
        const opts = { bubbles: true, cancelable: true, view: VIEW };
        el.dispatchEvent(new PointerEvent('pointerdown', opts));
        el.dispatchEvent(new MouseEvent('mousedown', opts));
        el.dispatchEvent(new PointerEvent('pointerup', opts));
        el.dispatchEvent(new MouseEvent('mouseup', opts));
        el.click();
    }

    function h(tag, cls, text) {
        const n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text !== undefined) n.textContent = text;
        return n;
    }

    const norm = (s) => String(s || '').replace(REGEX.whitespace, ' ').trim();
    const NF = new Intl.NumberFormat('th-TH');
    const fmt = (n) => NF.format(Math.round(n));
    const pad2 = (v) => String(v).padStart(2, '0');

    function fmtDuration(ms) {
        const s = Math.floor(ms / 1000);
        return `${pad2(Math.floor(s / 3600))}:${pad2(Math.floor((s % 3600) / 60))}:${pad2(s % 60)}`;
    }

    function fmtClock(ts) {
        const d = new Date(ts);
        return `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
    }

    function setNum(el, num, unit) {
        const sig = num + '\u0001' + (unit || '');
        if (el._sig === sig) return;
        el._sig = sig;
        el.textContent = num;
        if (unit) { const u = document.createElement('small'); u.textContent = unit; el.appendChild(u); }
    }

    function setT(el, text) {
        if (el && el.textContent !== text) el.textContent = text;
    }

    function setUI(key, text) {
        const val = text || '—';
        if (renderedState[key] === val) return;
        renderedState[key] = val;
        if (uiRefs[key]) uiRefs[key].textContent = val;
    }

    function setStatus(text, type = 'ok') {
        State.statusText = text;
        State.statusType = type;
        setUI('statusText', text);
        if (uiRefs.statusDot && renderedState.statusType !== type) {
            renderedState.statusType = type;
            uiRefs.statusDot.className = `at-dot at-dot-${type}`;
        }
    }

    function showToast(msg, type = 'info', icon) {
        if (!uiRefs.toastContainer) return;
        const toast = document.createElement('div');
        toast.className = `at-toast at-toast-${type}`;
        if (icon) {
            const im = document.createElement('img');
            im.src = icon; im.alt = ''; im.draggable = false;
            im.style.cssText = 'width:22px;height:22px;object-fit:contain;vertical-align:middle;margin-right:6px';
            toast.appendChild(im);
        }
        toast.appendChild(document.createTextNode(msg));
        uiRefs.toastContainer.appendChild(toast);
        requestAnimationFrame(() => toast.classList.add('show'));
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3200);
    }

    // สถานะที่อ่านจาก DOM ครั้งเดียวต่อ tick (ลดการสั่ง getClientRects ซ้ำ)
    const Frame = { now: 0, dead: false, invOpen: false, captcha: false };
    function refreshFrame(now) {
        Frame.now = now;
        Frame.dead = isVisible(SELECTORS.deathOverlay);
        Frame.invOpen = isVisible(SELECTORS.weight);
        Frame.captcha = isNodeVisible(document.querySelector('.human-check'));
    }

    // อ่านข้อความจาก element (จำผลไว้ ถ้าข้อความเดิมไม่ต้อง regex ใหม่)
    function readField(selectors, key) {
        const el = queryGame(selectors);
        if (el) {
            const raw = el.textContent;
            const memo = fieldMemo[key];
            if (memo && memo.raw === raw) return memo.val;
            let val = raw.trim().replace(REGEX.whitespace, ' ');
            if (key === 'channel') {
                const match = val.match(REGEX.channel);
                if (match) val = match[1];
            }
            fieldMemo[key] = { raw, val };
            State.cacheValues[key] = val;
            return val;
        }
        return State.cacheValues[key] || '';
    }

    // แมพฟาร์ม = รู้ชื่อแมพ และไม่ใช่เมือง (เมืองหลวง/ตลาด หรือมีคำว่า "ปลอดภัย")
    const farmMemo = { text: null, val: false };
    function isFarmMap() {
        const m = readField(SELECTORS.mapName, 'map');
        if (farmMemo.text === m) return farmMemo.val;
        let val = !!m;
        if (val && CONFIG.SAFE_MAPS.some((s) => m.includes(s))) val = false;
        if (val && CONFIG.SAFE_MAP_KEYWORDS.some((k) => m.includes(k))) val = false;
        if (val && CONFIG.NO_COUNT_MAPS.some((s) => m.startsWith(s))) val = false;
        farmMemo.text = m;
        farmMemo.val = val;
        return val;
    }

    // ชื่อแมพล้วน ๆ (เช่น "หนองพิษ") ตัด <small> ที่เป็น "Lv.60–70" / "ปลอดภัย" ออก
    const mapNameMemo = { raw: null, val: '' };
    function getMapName() {
        const el = queryGame(SELECTORS.mapName);
        if (!el) return State.cacheValues.mapClean || '';
        const raw = el.textContent;
        if (mapNameMemo.raw === raw) return mapNameMemo.val;
        const clone = el.cloneNode(true);
        clone.querySelectorAll('small').forEach((n) => n.remove());
        const name = norm(clone.textContent);
        mapNameMemo.raw = raw;
        mapNameMemo.val = name;
        State.cacheValues.mapClean = name;
        return name;
    }

    // ปุ่มกลับเมือง/ฟื้นคืนชีพ: หาเฉพาะใน .death-overlay (เดิมสแกนปุ่มทั้งหน้าทุกวินาที)
    function findReviveButton() {
        if (!Frame.dead) return null;
        const overlay = queryGame(SELECTORS.deathOverlay);
        if (!overlay) return null;

        // กำลังจะใช้ Rebirth Feather ฟื้นอัตโนมัติ -> ไม่กดกลับเมือง
        if (isNodeVisible(overlay.querySelector('.death-auto-revive'))) return null;

        let fallbackSpawnBtn = null;
        for (const btn of overlay.querySelectorAll('button, [role="button"]')) {
            if (!isNodeVisible(btn) || btn.disabled) continue;
            const txt = norm(btn.textContent);
            if (txt.includes('กลับเมืองหลวง')) return btn;
            if (txt.includes('ฟื้นที่จุดเกิด')) fallbackSpawnBtn = btn;
        }
        if (fallbackSpawnBtn) return fallbackSpawnBtn;

        const townBtn = queryGame(SELECTORS.returnTownBtn);
        if (isNodeVisible(townBtn) && !townBtn.disabled) return townBtn;
        return null;
    }

    // ---------------------------------------------------------------
    // Weight / buff / snapshot
    // ---------------------------------------------------------------
    function parseWeight() {
        const raw = readField(SELECTORS.weight, 'weight');
        if (!raw) return { text: '—', percent: 0 };
        const match = raw.match(REGEX.weight);
        if (match) {
            const cur = parseInt(match[1].replace(REGEX.commas, ''), 10);
            const max = parseInt(match[2].replace(REGEX.commas, ''), 10);
            if (max > 0) {
                const pct = Math.min(100, Math.round((cur / max) * 100));
                return { text: `${raw} (${pct}%)`, percent: pct };
            }
        }
        return { text: raw, percent: 0 };
    }

    const Icons = { tokenSrc: '', items: {}, monsters: null, monstersLoading: false };
    const itemIconSrc = (id) => (Icons.items && Icons.items[id] ? '/art/icons/' + Icons.items[id] : '');

    function isPremiumIcon(icon) {
        if (icon.tagName !== 'IMG') return false;
        const src = (icon.getAttribute('src') || '').split('?')[0];
        if (Icons.tokenSrc) return src === Icons.tokenSrc;
        return /token/i.test(src);
    }

    function parseBuff() {
        const list = queryGameAll(SELECTORS.buffItems);
        for (const item of list) {
            const icon = item.querySelector('.ui-icon');
            if (!icon || !isPremiumIcon(icon)) continue;
            const small = item.querySelector('small');
            let text = small ? small.textContent.trim() : 'ถาวร';
            const mh = text.match(REGEX.hours);
            if (mh) {
                const hrs = parseInt(mh[1], 10);
                if (hrs >= 24) text = `${(hrs / 24).toFixed(1)} วัน (${hrs} ชม.)`;
            }
            const src = icon.tagName === 'IMG' ? (icon.getAttribute('src') || '') : '';
            return { active: true, text, icon: src };
        }
        return { active: false, text: 'ยังไม่มีบัฟ', icon: '' };
    }

    function collectSnapshotData() {
        const rawLv = readField(SELECTORS.level, 'level');
        const baseLv = (rawLv.match(REGEX.baseLv) || [])[1] || '';
        const jobLv = (rawLv.match(REGEX.jobLv) || [])[1] || '';
        const weightInfo = parseWeight();
        const buffInfo = parseBuff();

        return {
            raw: {
                name: readField(SELECTORS.charName, 'name'),
                class: readField(SELECTORS.charClass, 'class'),
                baseLv,
                jobLv,
                weight: weightInfo.text,
                zeny: readField(SELECTORS.zeny, 'zeny'),
                slots: readField(SELECTORS.slots, 'slots'),
                premiumBuff: buffInfo.active ? buffInfo.text : 'ยังไม่มีบัฟ',
                map: readField(SELECTORS.mapName, 'map'),
                channel: readField(SELECTORS.channel, 'channel'),
            },
            meta: { weightPct: weightInfo.percent, buffActive: buffInfo.active, buffIcon: buffInfo.icon },
        };
    }

    // ---------------------------------------------------------------
    // Profit: วัตถุดิบ (มีราคา) + ไอเทมอื่น (สีตามระดับ) + มอนที่ฆ่า แยกตามตัวละคร
    // ---------------------------------------------------------------
    const PROFIT_KEY_PREFIX = 'at_profit_v1';
    const DB_KEY = 'at_itemdb_v2';

    const emptyLedger = () => ({
        items: {}, // วัตถุดิบ
        drops: {}, // ไอเทมอื่น (อุปกรณ์/เจม/การ์ด ฯลฯ)
        kills: { total: 0, by: {} }, // มอนที่ฆ่า
        chat: null, // ตัวชี้ตำแหน่งแชทที่อ่านแล้ว {at, n}
        farmMs: 0,
        startedAt: 0,
        lastGainAt: 0,
        lastMap: '',
        exp: { base: 0, job: 0, startMs: 0 }, // EXP จากการฆ่ามอน (แชทระบบ) · startMs = farmMs ตอนเริ่มนับ EXP (ไว้หารต่อชม.)
        deaths: 0, // ตายในแมพนี้กี่ครั้ง
        fly: 0, // ใช้ Fly Wing หาโซนในแมพนี้กี่อัน
    });

    const Profit = {
        charName: '',
        all: { v: 2, chat: null, lastMap: '', maps: {} }, // Profit แยกรายแมพ
        viewMap: '', // '' = ตามแมพที่ฟาร์มอยู่ (ล่าสุด)
        _empty: null,
        rev: 0,
        dirty: false,
        lastSaveAt: 0,
        lastTickAt: 0,
        wasInFarm: false,
        farming: false,
        pending: [],
        seenRows: new WeakSet(),
        confirmClearUntil: 0,
        db: { items: {}, mons: {}, size: 0, loadedAt: 0, checkedAt: 0, status: 'idle', error: '' },
    };

    function getProfitKey(charName = Profit.charName) {
        return charName ? `${PROFIT_KEY_PREFIX}_${charName}` : '';
    }

    const newAll = () => ({ v: 2, chat: null, lastMap: '', maps: {} });

    function parseLedger(d) {
        return {
            items: d.items && typeof d.items === 'object' ? d.items : {},
            drops: d.drops && typeof d.drops === 'object' ? d.drops : {},
            kills: d.kills && d.kills.by ? { total: Number(d.kills.total) || 0, by: d.kills.by } : { total: 0, by: {} },
            chat: null,
            farmMs: Number(d.farmMs) || 0,
            deaths: Number(d.deaths) || 0,
            fly: Number(d.fly) || 0,
            exp: d.exp && typeof d.exp === 'object' ? { base: Number(d.exp.base) || 0, job: Number(d.exp.job) || 0, startMs: Number(d.exp.startMs) || 0 } : { base: 0, job: 0, startMs: 0 },
            startedAt: Number(d.startedAt) || 0,
            lastGainAt: Number(d.lastGainAt) || 0,
            lastMap: String(d.lastMap || ''),
        };
    }

    const validChat = (c) => (c && typeof c.at === 'number' ? { at: c.at, n: Number(c.n) || 0 } : null);

    function ledgerFor(name) {
        const m = Profit.all.maps;
        return m[name] || (m[name] = emptyLedger());
    }
    // แมพที่กำลังโชว์ใน Profit: เลือกเอง > แมพที่ฟาร์มอยู่ > แมพฟาร์มล่าสุด
    function viewMapName() {
        return Profit.viewMap || (Profit.farming ? getMapName() : '') || Profit.all.lastMap || '';
    }
    // ledger ที่ "เขียนได้" = แมพที่ตัวละครอยู่ตอนนี้ (ไม่รวมกันระหว่างแมพ)
    function isCountMap(m) {
        if (!m) return false;
        if (CONFIG.SAFE_MAPS.some((x) => m.includes(x))) return false;
        if (CONFIG.SAFE_MAP_KEYWORDS.some((k) => m.includes(k))) return false;
        if (CONFIG.NO_COUNT_MAPS.some((x) => m.startsWith(x))) return false;
        return true;
    }
    function writeLedger() {
        const n = getMapName() || Profit.all.lastMap || 'ไม่ทราบแมพ';
        return ledgerFor(n);
    }
    function curLedger() {
        const n = (Profit.farming ? getMapName() : '') || Profit.all.lastMap;
        return (n && Profit.all.maps[n]) || null;
    }
    Object.defineProperty(Profit, 'data', {
        configurable: true,
        get() {
            const n = viewMapName();
            return (n && Profit.all.maps[n]) || (Profit._empty || (Profit._empty = emptyLedger()));
        },
    });
    function sumAll() {
        let z = 0, k = 0, ms = 0, bx = 0, jx = 0;
        for (const lg of Object.values(Profit.all.maps)) {
            for (const e of Object.values(lg.items)) z += e.qty * e.price;
            k += lg.kills.total; ms += lg.farmMs; bx += lg.exp.base; jx += lg.exp.job;
        }
        return { z, k, ms, bx, jx };
    }

    const PROFILE_POS_KEYS = ['at_pos_x', 'at_pos_y', 'at_profit_pos', 'at_logs_pos', 'at_config_pos', 'at_stats_pos'];
    function applyProfile(name, force) {
        const pnEl = document.getElementById('at-prof-name');
        if (pnEl && name) pnEl.textContent = name;
        if (!name || (Store.char === name && !force)) return;
        const sigOf = () => JSON.stringify([readPrefs(), PROFILE_POS_KEYS.map((k) => Store.get(k))]);
        const before = Store.char === name ? '' : sigOf();
        let prev = Store.char; try { prev = prev || localStorage.getItem('at_last_char') || ''; } catch (e) { /* ignore */ }
        // ไม่มีตัวล่าสุด หรือตัวล่าสุดไม่มีโปรไฟล์ (เช่น Chrome/โปรไฟล์ใหม่ที่เพิ่งนำเข้าการตั้งค่า) → ใช้ตัวละครที่มีการตั้งค่ามากที่สุดในเบราว์เซอร์นี้
        try {
            const hasProf = (n) => !!n && [...PROFILE_KEYS].some((k) => localStorage.getItem(`${k}@${n}`) !== null);
            if (!hasProf(prev) || prev === name) {
                const cnt = {};
                for (let i = 0; i < localStorage.length; i++) { const m = /^(at_[^@]+)@(.+)$/.exec(localStorage.key(i) || ''); if (m && PROFILE_KEYS.has(m[1]) && m[2] !== name) cnt[m[2]] = (cnt[m[2]] || 0) + 1; }
                const best = Object.entries(cnt).sort((a, b) => b[1] - a[1])[0];
                if (best) prev = best[0];
            }
        } catch (e) { /* ignore */ }
        Store.char = name;
        try {
            lsSet('at_last_char', name);
            // ตัวละครใหม่ที่ยังไม่มีโปรไฟล์เลย → คัดลอกการตั้งค่าของตัวที่ใช้ล่าสุดในเบราว์เซอร์นี้ (Sheets URL, Webhook, ออโต้, ธีม ฯลฯ)
            if (prev && prev !== name && localStorage.getItem('at_prof_inherit') !== '0' && ![...PROFILE_KEYS].some((k) => localStorage.getItem(`${k}@${name}`) !== null)) {
                let n = 0;
                for (const k of PROFILE_KEYS) { const v = localStorage.getItem(`${k}@${prev}`); if (v !== null) { lsSet(`${k}@${name}`, v); n++; } }
                if (n) { Log.ok('SYS', `ตัวละครใหม่ "${name}" — คัดลอกการตั้งค่าจาก "${prev}" (${n} รายการ)`); setTimeout(() => showToast(`🆕 ใช้การตั้งค่าของ ${prev} ให้ ${name} แล้ว`, 'ok'), 1500); }
            }
        } catch (e) { /* ignore */ }
        const after = sigOf();
        if (!force && before === after) return;
        const keepOpen = { isProfitOpen: State.isProfitOpen, isLogsOpen: State.isLogsOpen, isStatsOpen: State.isStatsOpen, isSettingsOpen: State.isSettingsOpen };
        Object.assign(State, readPrefs(), keepOpen); // หน้าต่างที่ผู้ใช้เปิดไว้แล้วไม่ถูกปิดตอนสลับโปรไฟล์
        for (const id of ['aetheria-tracker', 'aetheria-profit', 'aetheria-config', 'aetheria-stats', 'aetheria-logs', 'aetheria-dps', 'aetheria-idle', 'aetheria-info']) {
            const el = document.getElementById(id);
            if (el) el.remove();
        }
        Idle.el = null;
        Info.el = null;
        Junk.map = null;
        Junk.seen = null;
        if (typeof junkShareApply === 'function') junkShareApply();
        document.documentElement.classList.toggle('at-r3off', !!State.opt.renderOff);
        applyTheme();
        applyPerf();
        applyRender();
        Log.info('SYS', `โหลดโปรไฟล์การตั้งค่าของตัวละคร: ${name}`);
    }

    function profitLoad(charName = '') {
        const target = norm(charName || readField(SELECTORS.charName, 'name'));
        if (!target) return false;
        if (Profit.charName === target) return true;
        applyProfile(target);

        if (Profit.charName && Profit.dirty) profitSave(true);

        Profit.charName = target;
        const d = Store.getJSON(getProfitKey(target));
        const all = newAll();
        if (d && d.v === 2 && d.maps && typeof d.maps === 'object') {
            for (const [n, lg] of Object.entries(d.maps)) all.maps[n] = parseLedger(lg || {});
            all.chat = validChat(d.chat);
            all.lastMap = String(d.lastMap || '');
        } else if (d && d.items) {
            // ข้อมูลเก่า (รวมทุกแมพ) -> ยกไปไว้ในแมพที่ฟาร์มล่าสุด · EXP เริ่มนับใหม่
            const lg = parseLedger(d);
            lg.exp = { base: 0, job: 0, startMs: lg.farmMs };
            const nm = lg.lastMap || 'แมพเดิม';
            all.maps[nm] = lg;
            all.lastMap = nm;
            all.chat = validChat(d.chat);
            Log.warn('PROFIT', `ย้ายข้อมูลเก่าไปไว้ที่แมพ "${nm}" (v4.5 แยก Profit รายแมพ)`);
        }
        Profit.all = all;
        Profit.viewMap = '';
        Profit.dirty = false;
        Stats.load(target);
        Chat.lastRaw = null;
        Exp.rate = null; Exp.cal = null; Exp.jstart = null; Exp.tab = null;
        Profit.rev++;
        Log.info('PROFIT', `โหลดข้อมูลของตัวละคร: ${target} (${Object.keys(all.maps).length} แมพ)`);
        flushPending();
        return true;
    }

    function profitSave(force = false) {
        if (!Profit.charName) return;
        if (!Profit.dirty && !force) return;
        Store.set(getProfitKey(Profit.charName), JSON.stringify(Profit.all));
        Profit.dirty = false;
        Profit.lastSaveAt = Date.now();
        Stats.save(force);
    }

    function profitTotals(lg = Profit.data) {
        let total = 0, pieces = 0, types = 0;
        for (const e of Object.values(lg.items)) {
            total += e.qty * e.price;
            pieces += e.qty;
            types++;
        }
        let dropPieces = 0, dropTypes = 0;
        for (const e of Object.values(lg.drops)) {
            dropPieces += e.qty;
            dropTypes++;
        }
        const kills = lg.kills.total;
        const farmMs = lg.farmMs;
        const rated = farmMs >= CONFIG.MIN_FARM_MS_FOR_RATE;
        const hours = farmMs / 3600000;
        return {
            total, pieces, types, dropPieces, dropTypes, kills,
            perHour: rated ? total / hours : null,
            killsPerHour: rated ? kills / hours : null,
            perKill: kills > 0 ? total / kills : null,
        };
    }

    // EXP ต่อชั่วโมงของ ledger หนึ่ง (นับเฉพาะช่วงที่เริ่มเก็บ EXP แล้ว)
    function expPerHour(lg) {
        const ms = lg.farmMs - (lg.exp.startMs || 0);
        if (ms < CONFIG.MIN_FARM_MS_FOR_RATE) return null;
        const h = ms / 3600000;
        return { base: lg.exp.base / h, job: lg.exp.job / h };
    }

    // ---------------------------------------------------------------
    // Stats: สถิติ Zeny (วัตถุดิบ) + จำนวนมอนที่ฆ่า แยกตามแมพ / รีเซ็ตเองเมื่อขึ้นเดือนใหม่
    // ล้างประวัติ Profit ไม่กระทบสถิติ · เก็บแยก key ต่อตัวละคร
    // q = ช่วงละ 5 นาที (เก็บ 26 ชม.) · h = ช่วงละ 1 ชม. (เก็บทั้งเดือน) · ค่า = [zeny, kills]
    // ---------------------------------------------------------------
    const STATS_PREFIX = 'at_stats_v1';
    const Stats = {
        data: { month: '', maps: {} },
        charName: '',
        dirty: false,
        savedAt: 0,
        rev: 0,
        sumRev: -1,
        sum: { z: 0, k: 0, bx: 0, jx: 0 },
        monthKey() {
            const d = new Date();
            return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
        },
        hourKey(ts) { return Math.floor((ts - new Date(ts).getTimezoneOffset() * 60000) / 3600000); },
        load(name) {
            Stats.charName = name;
            const d = Store.getJSON(`${STATS_PREFIX}_${name}`);
            Stats.data = d && d.maps ? d : { month: '', maps: {} };
            Stats.dirty = false;
            Stats.checkMonth();
            Stats.rev++;
        },
        checkMonth() {
            const m = Stats.monthKey();
            if (Stats.data.month !== m) {
                if (Stats.data.month) Log.warn('STATS', `ขึ้นเดือนใหม่ (${m}) · รีเซ็ตสถิติของเดือน ${Stats.data.month}`);
                Stats.data = { month: m, maps: {} };
                Stats.dirty = true;
                Stats.rev++;
            }
        },
        rec(map, z, k, bx = 0, jx = 0) {
            if (!map || !Stats.charName) return;
            Stats.checkMonth();
            const ts = Date.now();
            const m = Stats.data.maps[map] || (Stats.data.maps[map] = { q: {}, h: {} });
            const add = (o, key) => { const a = o[key] || (o[key] = [0, 0, 0, 0]); a[0] += z; a[1] += k; a[2] = (a[2] || 0) + bx; a[3] = (a[3] || 0) + jx; };
            add(m.q, Math.floor(ts / 300000));
            add(m.h, Stats.hourKey(ts));
            Stats.dirty = true;
            Stats.rev++;
        },
        save(force) {
            if (!Stats.charName || !Stats.dirty) return;
            const now = Date.now();
            if (!force && now - Stats.savedAt < 30000) return;
            const cutoff = Math.floor(now / 300000) - 312;
            for (const m of Object.values(Stats.data.maps)) {
                for (const k of Object.keys(m.q)) if (+k < cutoff) delete m.q[k];
            }
            Store.set(`${STATS_PREFIX}_${Stats.charName}`, JSON.stringify(Stats.data));
            Stats.dirty = false;
            Stats.savedAt = now;
        },
        maps() {
            return Object.entries(Stats.data.maps)
                .map(([name, m]) => {
                    let z = 0, k = 0, bx = 0, jx = 0;
                    for (const a of Object.values(m.h)) { z += a[0]; k += a[1]; bx += a[2] || 0; jx += a[3] || 0; }
                    return { name, z, k, bx, jx };
                })
                .sort((a, b) => b.z - a.z || b.k - a.k);
        },
        total() {
            if (Stats.sumRev === Stats.rev) return Stats.sum;
            let z = 0, k = 0, bx = 0, jx = 0;
            for (const m of Stats.maps()) { z += m.z; k += m.k; bx += m.bx; jx += m.jx; }
            Stats.sum = { z, k, bx, jx };
            Stats.sumRev = Stats.rev;
            return Stats.sum;
        },
        // mi: 0 = zeny, 1 = kills · คืนค่า [{v, t}] เรียงจากเก่าไปใหม่
        series(sel, range, mi) {
            const now = Date.now();
            const maps = sel === '*' ? Object.values(Stats.data.maps) : [Stats.data.maps[sel]].filter(Boolean);
            const cfg = { '1h': { n: 12, per: 0 }, '24h': { n: 24, per: 1 }, '7d': { n: 28, per: 6 }, '4w': { n: 28, per: 24 } }[range] || { n: 24, per: 1 };
            const out = [];
            if (!cfg.per) {
                const cur = Math.floor(now / 300000);
                for (let i = cfg.n - 1; i >= 0; i--) {
                    const key = cur - i;
                    let v = 0;
                    for (const m of maps) { const a = m.q[key]; if (a) v += a[mi] || 0; }
                    out.push({ v, t: key * 300000 });
                }
            } else {
                const off = new Date(now).getTimezoneOffset() * 60000;
                const cur = Math.floor(Stats.hourKey(now) / cfg.per);
                for (let i = cfg.n - 1; i >= 0; i--) {
                    const key = cur - i;
                    let v = 0;
                    for (const m of maps) {
                        for (let j = 0; j < cfg.per; j++) { const a = m.h[key * cfg.per + j]; if (a) v += a[mi] || 0; }
                    }
                    out.push({ v, t: key * cfg.per * 3600000 + off });
                }
            }
            return out;
        },
    };

    const STAT_RANGES = [['1h', '1 ชม.'], ['24h', '24 ชม.'], ['7d', '7 วัน'], ['4w', '4 สัปดาห์']];
    function statLabel(t, range) {
        const d = new Date(t);
        if (range === '1h' || range === '24h') return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
        if (range === '7d') return `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)} ${pad2(d.getHours())}h`;
        return `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}`;
    }
    function fmtShort(v) {
        if (v >= 1e6) return (v / 1e6).toFixed(v >= 1e7 ? 0 : 1) + 'M';
        if (v >= 1e3) return (v / 1e3).toFixed(v >= 1e4 ? 0 : 1) + 'k';
        return String(Math.round(v));
    }

    // list = [{pts, col, dot, unit, name}] — วาดหลายเส้นบนสเกลเดียวกัน (EXP = 2 เส้น Base/Job)
    function statChartSVG(list, range, big) {
        const W = big ? 720 : 300, H = big ? 300 : 140, L = big ? 54 : 36, R = 14, T = list.length > 1 ? (big ? 26 : 22) : 14, B = big ? 26 : 20;
        const fs = big ? 11 : 9;
        const max = Math.max(1, ...list.flatMap((S) => S.pts.map((p) => p.v)));
        const n = list[0].pts.length;
        const x = (i) => L + (n === 1 ? 0 : (i * (W - L - R)) / (n - 1));
        const y = (v) => T + (H - T - B) * (1 - v / max);
        let s = `<svg viewBox="0 0 ${W} ${H}" width="100%" role="img" aria-label="กราฟสถิติ">`;
        s += '<defs>' + list.map((S, si) => `<linearGradient id="at-stg${si}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${S.col}" stop-opacity="${list.length > 1 ? '.16' : '.28'}"/><stop offset="1" stop-color="${S.col}" stop-opacity="0"/></linearGradient>`).join('') + '</defs>';
        for (const f of [0, 0.5, 1]) {
            const gy = y(max * f);
            s += `<line x1="${L}" x2="${W - R}" y1="${gy.toFixed(1)}" y2="${gy.toFixed(1)}" stroke="rgba(255,255,255,.08)" stroke-width="1"/>`;
            s += `<text x="${L - 5}" y="${(gy + 3).toFixed(1)}" text-anchor="end" font-size="${fs}" fill="#a1a1aa">${fmtShort(max * f)}</text>`;
        }
        list.forEach((S, si) => {
            const pts = S.pts;
            const line = pts.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(p.v).toFixed(1)}`).join(' ');
            s += `<path d="${line} L${x(n - 1).toFixed(1)} ${y(0).toFixed(1)} L${x(0).toFixed(1)} ${y(0).toFixed(1)} Z" fill="url(#at-stg${si})"/>`;
            s += `<path d="${line}" fill="none" stroke="${S.col}" stroke-width="${big ? 2.6 : 2}" stroke-linejoin="round" stroke-linecap="round"${si ? ' stroke-dasharray="0"' : ''}/>`;
            pts.forEach((p, i) => {
                s += `<circle cx="${x(i).toFixed(1)}" cy="${y(p.v).toFixed(1)}" r="${big ? (n > 20 ? 3.4 : 4.5) : (n > 20 ? 2.3 : 3)}" fill="${S.dot}" stroke="#18181b" stroke-width="1"><title>${S.name ? S.name + ' · ' : ''}${statLabel(p.t, range)} · ${fmt(p.v)}${S.unit}</title></circle>`;
            });
        });
        if (list.length > 1) {
            let lx = L;
            list.forEach((S) => {
                s += `<circle cx="${lx + 4}" cy="9" r="4" fill="${S.col}"/><text x="${lx + 12}" y="${9 + fs / 2 - 1}" font-size="${fs}" fill="#d4d4d8">${S.name}</text>`;
                lx += big ? 110 : 80;
            });
        }
        const p0 = list[0].pts;
        for (const i of [0, Math.floor((n - 1) / 2), n - 1]) {
            s += `<text x="${x(i).toFixed(1)}" y="${H - 5}" text-anchor="${i === 0 ? 'start' : i === n - 1 ? 'end' : 'middle'}" font-size="${fs}" fill="#a1a1aa">${statLabel(p0[i].t, range)}</text>`;
        }
        return s + '</svg>';
    }

    function resolveStatMap() {
        if (State.statMap === '*') return '*';
        if (State.statMap && Stats.data.maps[State.statMap]) return State.statMap;
        if (!State.statMap) {
            const cur = Profit.farming ? getMapName() : '';
            return cur && Stats.data.maps[cur] ? cur : '*';
        }
        return '*';
    }

    // ---------------------------------------------------------------
    // หน้าต่างสถิติ (แนวนอน ขนาดใหญ่) : แท็บแมพ · Zeny/ฆ่ามอน · ช่วงเวลา · กราฟ · อันดับแมพ
    // ---------------------------------------------------------------
    const sRefs = {};

    function positionStats(force) {
        const w = sRefs.panel;
        if (!w || (w.dataset.placed === '1' && !force)) return;
        const r = w.getBoundingClientRect();
        w.style.left = Math.max(4, (window.innerWidth - r.width) / 2) + 'px';
        w.style.top = Math.max(8, (window.innerHeight - r.height) / 2 - 10) + 'px';
        w.dataset.placed = '1';
    }

    function toggleStats(force) {
        State.isStatsOpen = typeof force === 'boolean' ? force : !State.isStatsOpen;
        savePrefs();
        if (!sRefs.panel) return;
        (State.isStatsOpen ? Anim.show : Anim.hide)(sRefs.panel, (v) => { sRefs.panel.style.display = v ? 'flex' : 'none'; });
        if (State.isStatsOpen) {
            sRefs.key = '';
            sRefs.tabsSig = '';
            renderStatsWin();
            positionStats();
        }
        relayoutAll(!State.isStatsOpen);
    }

    function buildStatsWindow() {
        if (document.getElementById('aetheria-stats')) return;
        injectStyles();
        const w = document.createElement('div');
        w.id = 'aetheria-stats';
        w.style.display = State.isStatsOpen ? 'flex' : 'none';
        w.innerHTML = `
            <div class="as-header" id="as-drag">
                <span class="as-title">📈 สถิติการฟาร์ม</span>
                <span class="as-sub" id="as-sub"></span>
                <button class="at-icon-btn" id="as-close" type="button" title="ปิด">✕</button>
            </div>
            <div class="as-maps" id="as-maps"></div>
            <div class="as-ctrl">
                <div class="ap-pills" id="as-metric"></div>
                <div class="ap-pills" id="as-range"></div>
            </div>
            <div class="as-main">
                <div class="as-left">
                    <div class="as-info" id="as-info"></div>
                    <div class="ap-chart as-chart" id="as-chart"></div>
                </div>
                <div class="as-side">
                    <div class="as-kpis" id="as-kpis"></div>
                    <div class="as-rank-t">🏆 อันดับแมพ (เดือนนี้)</div>
                    <div class="as-rank" id="as-rank"></div>
                </div>
            </div>
            <div class="as-rank-t" style="padding:0 16px">📋 ตารางเทียบแมพ <small style="opacity:.6;font-weight:500">(จากประวัติ Profit ของตัวละครนี้ · กดหัวตารางเพื่อเรียง)</small></div>
            <div class="as-cmp" id="as-cmp"></div>
            <div class="as-note" id="as-note"></div>
        `;
        document.body.appendChild(w);
        const $ = (id) => document.getElementById(id);
        sRefs.panel = w;
        sRefs.maps = $('as-maps');
        sRefs.info = $('as-info');
        sRefs.chart = $('as-chart');
        sRefs.kpis = $('as-kpis');
        sRefs.rank = $('as-rank');
        sRefs.note = $('as-note');
        sRefs.sub = $('as-sub');
        sRefs.key = '';
        sRefs.tabsSig = '';

        const mkPills = (host, defs, attr, apply) => defs.map(([v, t]) => {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'ap-pill';
            b.textContent = t;
            b.dataset[attr] = v;
            b.addEventListener('click', (e) => { e.stopPropagation(); apply(v); savePrefs(); sRefs.key = ''; renderStatsWin(); });
            host.appendChild(b);
            return b;
        });
        sRefs.mBtns = mkPills($('as-metric'), [['z', '💰 Zeny จากวัตถุดิบ'], ['k', '⚔️ ฆ่ามอน'], ['e', '✨ EXP (Base / Job)']], 'm', (v) => { State.statMetric = v; });
        sRefs.rBtns = mkPills($('as-range'), STAT_RANGES, 'r', (v) => { State.statRange = v; });
        $('as-close').addEventListener('click', (e) => { e.stopPropagation(); toggleStats(false); });
        makeWindowDraggable(w, $('as-drag'), 'at_stats_pos');
        if (Store.getJSON('at_stats_pos')) w.dataset.placed = '1';
        if (State.isStatsOpen) { renderStatsWin(); positionStats(); }
    }

    function renderMapCompare() {
        const box = document.getElementById('as-cmp'); if (!box) return;
        const cols = [['name', 'แมพ'], ['ms', 'เวลาฟาร์ม'], ['zh', 'Zeny/ชม.'], ['kh', 'ฆ่า/ชม.'], ['bh', 'Base EXP/ชม.'], ['d', 'ตาย'], ['f', 'Fly Wing'], ['fh', 'Fly/ชม.']];
        const rows = Object.entries(Profit.all.maps).map(([name, lg]) => {
            const t = profitTotals(lg), ex = expPerHour(lg), h = lg.farmMs / 3600000;
            return { name, ms: lg.farmMs, zh: t.perHour || 0, kh: t.killsPerHour || 0, bh: ex ? ex.base : 0, d: lg.deaths || 0, f: lg.fly || 0, fh: h >= 1 / 60 ? (lg.fly || 0) / h : 0 };
        }).filter((r) => r.ms > 0);
        const sk = sRefs.cmpSort || 'zh', dir = sRefs.cmpDir || -1;
        rows.sort((a, b) => (sk === 'name' ? String(a.name).localeCompare(String(b.name)) : a[sk] - b[sk]) * (sk === 'name' ? -dir : dir) * -1);
        const best = rows.reduce((m, r) => (r.zh > (m ? m.zh : -1) ? r : m), null);
        const f1 = (v) => (v ? fmt(v) : '—');
        let html = '<table><thead><tr>' + cols.map(([k, t]) => `<th data-k="${k}">${t}${k === sk ? (dir < 0 ? ' ▾' : ' ▴') : ''}</th>`).join('') + '</tr></thead><tbody>';
        for (const r of rows) html += `<tr class="${r === best && rows.length > 1 ? 'best' : ''}"><td>${escapeHtml(r.name)}</td><td>${fmtDuration(r.ms)}</td><td>${f1(r.zh)}</td><td>${f1(r.kh)}</td><td>${f1(r.bh)}</td><td>${r.d || '—'}</td><td>${r.f || '—'}</td><td>${r.fh ? r.fh.toFixed(1) : '—'}</td></tr>`;
        html += '</tbody></table>';
        if (!rows.length) html = '<div class="ap-empty">ยังไม่มีข้อมูล</div>';
        box.innerHTML = html;
        box.querySelectorAll('th').forEach((th) => th.addEventListener('click', (e) => { e.stopPropagation(); const k = th.dataset.k; if (sRefs.cmpSort === k) sRefs.cmpDir = -(sRefs.cmpDir || -1); else { sRefs.cmpSort = k; sRefs.cmpDir = -1; } renderMapCompare(); }));
    }

    function renderStatsWin() {
        if (!State.isStatsOpen || !sRefs.panel) return;
        const sel = resolveStatMap();
        const key = [Stats.rev, sel, State.statRange, State.statMetric, Math.floor(Date.now() / 60000), Exp.baseMax ? 1 : 0].join('|');
        if (sRefs.key === key) return;
        sRefs.key = key;

        const list = Stats.maps();
        const pick = (v) => { State.statMap = v; savePrefs(); sRefs.key = ''; renderStatsWin(); };
        const mk = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt !== undefined) e.textContent = txt; return e; };

        // แท็บแมพ (สร้างใหม่เมื่อรายการหรือแมพที่เลือกเปลี่ยน)
        const sig = sel + '|' + list.map((m) => m.name).join('|');
        if (sRefs.tabsSig !== sig) {
            sRefs.tabsSig = sig;
            sRefs.maps.textContent = '';
            const add = (v, t) => {
                const b = mk('button', 'as-tab' + (v === sel ? ' on' : ''), t);
                b.type = 'button';
                b.addEventListener('click', (e) => { e.stopPropagation(); pick(v); });
                sRefs.maps.appendChild(b);
            };
            add('*', '🌐 ทุกแมพ');
            for (const m of list) add(m.name, m.name);
            if (!list.length) sRefs.maps.appendChild(mk('span', 'as-empty', 'ยังไม่มีสถิติ — ออกไปฟาร์มที่แมพนอกเมืองแล้วระบบจะเริ่มเก็บให้'));
        }

        const metric = State.statMetric === 'k' || State.statMetric === 'e' ? State.statMetric : 'z';
        const isE = metric === 'e';
        const mi = metric === 'k' ? 1 : 0;
        sRefs.mBtns.forEach((b) => b.classList.toggle('on', b.dataset.m === metric));
        sRefs.rBtns.forEach((b) => b.classList.toggle('on', b.dataset.r === State.statRange));

        const sz = Stats.series(sel, State.statRange, 0);
        const sk = Stats.series(sel, State.statRange, 1);
        const sb = Stats.series(sel, State.statRange, 2);
        const sj = Stats.series(sel, State.statRange, 3);
        const cur = mi === 0 ? sz : sk;
        const sumOf = (a) => a.reduce((s, p) => s + p.v, 0);
        const zSum = sumOf(sz), kSum = sumOf(sk), bSum = sumOf(sb), jSum = sumOf(sj);
        const peak = Math.max(0, ...cur.map((p) => p.v));
        const active = cur.filter((p) => p.v > 0).length;
        const unit = mi === 0 ? 'z' : 'ตัว';
        const name = sel === '*' ? 'ทุกแมพ' : sel;
        const rangeName = (STAT_RANGES.find((r) => r[0] === State.statRange) || [0, ''])[1];

        setT(sRefs.sub, `${name} · ${rangeName}`);
        setT(sRefs.info, isE ? `✨ EXP ต่อช่วง (Base / Job) · ${name}` : `${mi === 0 ? '💰 Zeny' : '⚔️ ฆ่ามอน'} ต่อช่วง · ${name}`);
        if (isE) {
            sRefs.chart.innerHTML = (bSum || jSum)
                ? statChartSVG([
                    { pts: sb, col: State.theme.acc, dot: '#ffffff', unit: ' exp', name: 'Base EXP' },
                    { pts: sj, col: '#7cc4ff', dot: '#bfe3ff', unit: ' exp', name: 'Job EXP' },
                ], State.statRange, true)
                : '<div class="ap-empty" style="padding:70px 0">ยังไม่มีข้อมูล EXP ในช่วงนี้ (เริ่มเก็บตั้งแต่ v4.8.0)</div>';
        } else {
            const col = mi === 0 ? State.theme.acc2 : '#7cc4ff';
            const dot = mi === 0 ? State.theme.acc : '#bfe3ff';
            sRefs.chart.innerHTML = cur.some((p) => p.v > 0) ? statChartSVG([{ pts: cur, col, dot, unit: mi === 0 ? ' z' : ' ตัว', name: '' }], State.statRange, true) : '<div class="ap-empty" style="padding:70px 0">ยังไม่มีข้อมูลในช่วงนี้</div>';
        }

        const mon = sel === '*' ? Stats.total() : (list.find((m) => m.name === sel) || { z: 0, k: 0, bx: 0, jx: 0 });
        sRefs.kpis.textContent = '';
        const cap = levelCapInfo();
        const kp = isE ? [
            ['✨ Base EXP ช่วงนี้', `${fmt(bSum)} exp`, true],
            ['✨ Job EXP ช่วงนี้', `${fmt(jSum)} exp`, false],
            ['📊 Base สูงสุด/ช่วง', `${fmt(Math.max(0, ...sb.map((p) => p.v)))} exp`, false],
            ['📊 Job สูงสุด/ช่วง', `${fmt(Math.max(0, ...sj.map((p) => p.v)))} exp`, false],
            ['🗓️ เดือนนี้ (Base)', `${fmt(mon.bx)} exp`, false],
            ['🗓️ เดือนนี้ (Job)', `${fmt(mon.jx)} exp`, false],
            ['🎯 ถึง Lv 99', cap.text, true, cap.title],
        ] : [
            ['💰 Zeny ช่วงนี้', `${fmt(zSum)} z`, mi === 0],
            ['⚔️ ฆ่ามอนช่วงนี้', `${fmt(kSum)} ตัว`, mi === 1],
            [`📊 สูงสุด/ช่วง`, `${fmt(peak)} ${unit}`, false],
            [`📉 เฉลี่ย/ช่วงที่มีข้อมูล`, active ? `${fmt(sumOf(cur) / active)} ${unit}` : '—', false],
            ['🗓️ เดือนนี้ (Zeny)', `${fmt(mon.z)} z`, false],
            ['🗓️ เดือนนี้ (ฆ่ามอน)', `${fmt(mon.k)} ตัว`, false],
        ];
        for (const [t, v, hot, tip] of kp) {
            const c = mk('div', 'ap-card' + (hot ? ' hot' : ''));
            if (tip) c.title = tip;
            c.appendChild(mk('span', '', t));
            c.appendChild(mk('b', '', v));
            sRefs.kpis.appendChild(c);
        }

        sRefs.rank.textContent = '';
        list.forEach((m, i) => {
            const row = mk('button', 'as-rrow' + (m.name === sel ? ' on' : ''));
            row.type = 'button';
            row.appendChild(mk('span', 'as-rn', `${i + 1}. ${m.name}`));
            row.appendChild(mk('span', 'as-rv', `${fmtShort(m.z)} z · ${fmt(m.k)} ตัว`));
            row.addEventListener('click', (e) => { e.stopPropagation(); pick(m.name); });
            sRefs.rank.appendChild(row);
        });
        if (!list.length) sRefs.rank.appendChild(mk('div', 'ap-empty', 'ยังไม่มีข้อมูล'));

        renderMapCompare();
        setT(sRefs.note, `สถิติของ ${Profit.charName || 'ตัวละครนี้'} · รีเซ็ตเองต้นเดือน (ล้างประวัติ Profit ไม่กระทบ) · เมืองหลวง/ตลาด/คุก/ห้องทดสอบ/หอไข่ ไม่นับ แต่เลือกดูแมพอื่นได้ทุกที่`);
    }

    // ---------------------------------------------------------------
    // โหมดปิดภาพ 3D: ลดอัตราการวาดของเกม (requestAnimationFrame) + ซ่อน canvas แล้วโชว์หน้าสถานะแทน
    // เกมยังเชื่อมต่อ/ฟาร์มต่อ (Auto เป็นของฝั่งเซิร์ฟเวอร์) · UI ของเกมและของสคริปต์ยังอยู่
    // ---------------------------------------------------------------
    const PW = typeof unsafeWindow !== 'undefined' ? unsafeWindow : window;
    const Raf = { native: null, cancelNative: null, seq: 1e9, pend: new Map() };
    // ระหว่างเดิน/วาร์ป/ซื้อของ ต้องเปิดภาพชั่วคราว (ตอนปิดภาพ เกมเดินแค่ ~6 เฟรม/วิ → คลิกเดิน/คุย NPC พลาด) · ค่าที่ตั้งไว้ (renderOff) ไม่เปลี่ยน
    const R3T = { force: false, idleAt: 0 };
    // 🎮 กราฟิกประหยัด (เปิดหลายจอ): ปรับการตั้งค่ากราฟิกของเกมเอง (webgame.camera) ให้การ์ดจอทำงานน้อยลง
    //    จำกัด 30 FPS · ความละเอียด 1x · ปิดเอฟเฟกต์สกิล/ตัวเลขดาเมจ/ป้าย/แสงหมวก/สั่นจอ · แสดงผู้เล่นอื่นไม่เกิน 5 คน
    //    (โปรเซส GPU ของ Firefox ตัวเดียววาดให้ทุกจอ → เปิด 16 จอแล้วคอขวดที่การ์ดจอ) · เกมอ่านค่าตอนโหลด → เปลี่ยนแล้วต้องรีโหลด
    const LOWGFX = { fpsLimit: 30, render: 1, effects: 'off', damageNumbers: 'off', maxPlayers: 5, banners: false, hatSparkle: false, hatBob: false, shake: false, playerNames: 'hover' };
    function lowGfxSet(on) {
        let cur = {}; try { cur = JSON.parse(localStorage.getItem('webgame.camera') || '{}') || {}; } catch (e) { cur = {}; }
        if (on) {
            if (!Object.keys(LOWGFX).some((k) => cur[k] !== LOWGFX[k])) return false;
            try { if (!localStorage.getItem('at_gfx_backup')) localStorage.setItem('at_gfx_backup', JSON.stringify(cur)); } catch (e) { /* ignore */ }
            localStorage.setItem('webgame.camera', JSON.stringify(Object.assign({}, cur, LOWGFX)));
            return true;
        }
        let bk = null; try { bk = JSON.parse(localStorage.getItem('at_gfx_backup') || 'null'); } catch (e) { bk = null; }
        if (!bk) return false;
        const back = Object.assign({}, cur); for (const k of Object.keys(LOWGFX)) { if (k in bk) back[k] = bk[k]; else delete back[k]; }
        localStorage.setItem('webgame.camera', JSON.stringify(back)); localStorage.removeItem('at_gfx_backup');
        return true;
    }
    try {      // เปิดไว้แต่ค่าของเกมยังไม่ตรง (เช่น Container ใหม่ / เกมรีเซ็ตค่า) → ตั้งแล้วรีโหลด 1 ครั้ง
        if (State.opt.lowGfx && lowGfxSet(true)) { if (sessionStorage.getItem('at_gfx_rl') !== '1') { sessionStorage.setItem('at_gfx_rl', '1'); location.reload(); } }
        else sessionStorage.removeItem('at_gfx_rl');
    } catch (e) { /* ignore */ }
    const r3Off = () => !!State.opt.renderOff && !R3T.force;
    const Idle = { el: null, cv: null, refs: {} };

    function installRafThrottle() {
        try {
            if (Raf.native || !PW.requestAnimationFrame) return;
            Raf.native = PW.requestAnimationFrame.bind(PW);
            Raf.cancelNative = PW.cancelAnimationFrame.bind(PW);
            PW.requestAnimationFrame = function (cb) {
                if (!r3Off() || State.opt.r3Gpu !== false) return Raf.native(cb);      // โหมดใหม่: เกมเดินเต็มความเร็ว (ตัดแค่คำสั่งวาดของการ์ดจอ)
                const id = ++Raf.seq;
                const rec = { t: 0, r: 0 };
                rec.t = setTimeout(() => {
                    rec.r = Raf.native((ts) => { Raf.pend.delete(id); cb(ts); });
                }, 1000 / Math.max(2, State.opt.renderFps));
                Raf.pend.set(id, rec);
                return id;
            };
            PW.cancelAnimationFrame = function (id) {
                const rec = Raf.pend.get(id);
                if (rec) {
                    clearTimeout(rec.t);
                    if (rec.r) Raf.cancelNative(rec.r);
                    Raf.pend.delete(id);
                    return undefined;
                }
                return Raf.cancelNative(id);
            };
        } catch (e) {
            Log.warn('SYS', 'ติดตั้งตัวลดเฟรมเรตไม่สำเร็จ: ' + (e && e.message));
        }
    }

    // 🌙 ปิดภาพ 3D แบบใหม่ (5.36): เกมยังคำนวณเต็มความเร็ว (เดิน/วาร์ป/Auto ปกติ) แต่คำสั่งวาดของ WebGL ไม่ทำงาน → การ์ดจอแทบว่าง + พักเสียงเกม
    //    มินิแมพ/หน้าต่างของเกมเป็น 2D/HTML ไม่ได้ใช้ WebGL → ระบบเดินที่อ่านมินิแมพยังทำงาน · ไม่แก้ไฟล์เกม
    const GpuIdle = { on: () => r3Off() && State.opt.r3Gpu !== false, skipped: 0, audio: new Set(), muted: false };
    (function installGpuIdle() {
        try {
            const names = ['drawArrays', 'drawElements', 'drawArraysInstanced', 'drawElementsInstanced', 'drawRangeElements', 'clear'];
            for (const P of [PW.WebGLRenderingContext, PW.WebGL2RenderingContext]) {
                const proto = P && P.prototype; if (!proto) continue;
                for (const n of names) {
                    const orig = proto[n]; if (typeof orig !== 'function' || orig.__atGpu) continue;
                    const wrap = function (...a) { if (GpuIdle.on()) { GpuIdle.skipped++; return undefined; } return orig.apply(this, a); };
                    wrap.__atGpu = true; proto[n] = wrap;
                }
            }
            for (const k of ['AudioContext', 'webkitAudioContext']) {      // จำ AudioContext ของเกม (สร้างหลังสคริปต์เริ่ม) ไว้พักเสียง
                const C = PW[k]; if (typeof C !== 'function' || C.__atGpu) continue;
                const H = new Proxy(C, { construct(t, args, nt) { const ctx = Reflect.construct(t, args, nt); try { GpuIdle.audio.add(ctx); } catch (e) { /* ignore */ } return ctx; } });
                H.__atGpu = true; PW[k] = H;
            }
        } catch (e) { Log.warn('SYS', 'ติดตั้งโหมดปิดภาพแบบใหม่ไม่สำเร็จ: ' + (e && e.message)); }
    })();
    setInterval(() => {
        try {
            const want = GpuIdle.on();
            if (want === GpuIdle.muted) return;
            GpuIdle.muted = want;
            for (const ctx of GpuIdle.audio) { if (ctx === Snd.ctx) continue; try { if (want && ctx.state === 'running') { ctx.suspend(); ctx.__atMuted = true; } else if (!want && ctx.__atMuted) { ctx.__atMuted = false; ctx.resume(); } } catch (e) { /* ignore */ } }
            document.querySelectorAll('audio, video').forEach((m) => { try { if (want && !m.paused) { m.__atMuted = true; m.pause(); } else if (!want && m.__atMuted) { m.__atMuted = false; m.play().catch(() => {}); } } catch (e) { /* ignore */ } });
        } catch (e) { /* ignore */ }
    }, 1000);

    function mainCanvas() {
        let best = null, area = 0;
        document.querySelectorAll('canvas').forEach((c) => {
            const a = (c.width || 0) * (c.height || 0);
            if (a > area) { area = a; best = c; }
        });
        return best;
    }

    function ensureIdle() {
        const t = Date.now();
        if (!Idle.cv || !Idle.cv.isConnected || t - (Idle.cvAt || 0) > 5000) {
            Idle.cvAt = t;
            const c = mainCanvas();
            if (c !== Idle.cv && Idle.cv) Idle.cv.classList.remove('at-cv-off');
            Idle.cv = c;
        }
        if (Idle.cv && !Idle.cv.classList.contains('at-cv-off')) Idle.cv.classList.add('at-cv-off');
        if (Idle.el && Idle.el.isConnected) {
            // canvas ของเกมสร้างทีหลัง: ย้ายหน้าสถานะเข้าไปอยู่ในกรอบเกม
            const want = Idle.cv && Idle.cv.parentElement;
            if (want && Idle.el.parentElement !== want) {
                if (Idle.hostFix) { Idle.hostFix.style.position = ''; Idle.hostFix = null; }
                if (getComputedStyle(want).position === 'static') { want.style.position = 'relative'; Idle.hostFix = want; }
                Idle.el.style.position = '';
                want.appendChild(Idle.el);
            }
            return;
        }
        const host = Idle.cv && Idle.cv.parentElement ? Idle.cv.parentElement : document.body;
        const el = document.createElement('div');
        el.id = 'aetheria-idle';
        el.innerHTML = `
            <div class="ai-card">
                <div class="ai-head">🌙 ปิดภาพ 3D อยู่ <small>เกมยังทำงานเบื้องหลัง · ตัวละครยังฟาร์มต่อ</small></div>
                <div class="ai-who"><b id="ai-name">—</b><span id="ai-class">—</span><em id="ai-lv">—</em></div>
                <div class="ai-status" id="ai-status">—</div>
                <div class="ai-bars" id="ai-bars"></div>
                <div class="ai-grid">
                    <div class="ap-card"><span>⏱️ เวลาฟาร์ม</span><b id="ai-time">—</b></div>
                    <div class="ap-card"><span>💰 Zeny วัตถุดิบ</span><b id="ai-z">—</b></div>
                    <div class="ap-card hot"><span>📈 ต่อชั่วโมง</span><b id="ai-zh">—</b></div>
                    <div class="ap-card"><span>⚔️ ฆ่ามอน</span><b id="ai-k">—</b></div>
                    <div class="ap-card"><span>🎯 ตัว/ชม.</span><b id="ai-kh">—</b></div>
                    <div class="ap-card"><span>✨ Base EXP/ชม.</span><b id="ai-bx">—</b></div>
                    <div class="ap-card"><span>🎯 ถึง Lv 99</span><b id="ai-eta">—</b></div>
                    <div class="ap-card"><span>🗺️ แมพ</span><b id="ai-map">—</b></div>
                    <div class="ap-card"><span>📶 Ping</span><b id="ai-ping">—</b></div>
                    <div class="ap-card ai-wide"><span>⭐ บัฟ Premium</span><b id="ai-prem">—</b></div>
                </div>
                <div class="ai-btns">
                    <button class="at-btn-ghost" id="ai-stats" type="button">📈 ดูสถิติ</button>
                    <button class="at-btn-ghost" id="ai-profit" type="button">💰 Profit</button>
                    <button class="at-btn-ghost" id="ai-on" type="button">🖥️ เปิดภาพ 3D กลับมา</button>
                </div>
            </div>`;
        if (host !== document.body && getComputedStyle(host).position === 'static') { host.style.position = 'relative'; Idle.hostFix = host; }
        if (host === document.body) el.style.position = 'fixed';
        host.appendChild(el);
        Idle.el = el;
        Idle.refs = {};
        for (const id of ['name', 'class', 'lv', 'status', 'bars', 'time', 'z', 'zh', 'k', 'kh', 'bx', 'eta', 'map', 'ping', 'prem']) Idle.refs[id] = el.querySelector('#ai-' + id);
        el.querySelector('#ai-stats').addEventListener('click', (e) => { e.stopPropagation(); toggleStats(); });
        el.querySelector('#ai-profit').addEventListener('click', (e) => { e.stopPropagation(); toggleProfit(); });
        el.querySelector('#ai-on').addEventListener('click', (e) => { e.stopPropagation(); setRenderOff(false); });
    }

    function renderIdle() {
        if (!r3Off()) return;
        ensureIdle();
        const r = Idle.refs;
        const d = collectSnapshotData().raw;
        const lg = curLedger() || Profit.data;
        const t = profitTotals(lg);
        setT(r.name, d.name || '—');
        setT(r.class, d.class || '—');
        setT(r.lv, `Base ${d.baseLv || '—'} · Job ${d.jobLv || '—'}`);
        const map = getMapName() || '—';
        let st;
        if (Frame.captcha) st = '🧩 เกมขอตรวจสอบผู้เล่น — กลับมาตอบเอง!';
        else if (Frame.dead) st = '💀 ตัวละครตาย' + (State.isReviveEnabled ? ' (กำลังกลับเมืองอัตโนมัติ)' : '');
        else if (isJailMap(map)) st = `⛓️ ติดคุก · ${map}${Town.map ? ' มา ' + fmtTown(Date.now() - Town.since) : ''}`;
        else if (Profit.farming) st = `🟢 กำลังฟาร์ม · ${map}`;
        else if (Town.map) st = `🏙️ อยู่ที่ ${Town.map} มา ${fmtTown(Date.now() - Town.since)}`;
        else st = `⏸️ ${map}`;
        setT(r.status, st);
        const kd = charKind().k;
        const cls = 'ai-status' + (kd === 'captcha' || kd === 'dead' ? ' bad' : kd === 'farm' ? ' ok' : ' warn');
        if (r.status.className !== cls) r.status.className = cls;

        // HP / SP จาก HUD ของเกม
        const bars = [...document.querySelectorAll('.bar:not(.bar-exp)')].slice(0, 2).map((b) => {
            const lab = norm((b.querySelector('span') || {}).textContent || '');
            const num = norm((b.querySelector('.bar-num') || {}).textContent || '');
            const fill = b.querySelector('.bar-fill');
            const w = fill ? parseFloat(fill.style.width) : NaN;
            return `${lab} ${num}${isFinite(w) ? ` (${Math.round(w)}%)` : ''}`;
        }).filter(Boolean).join('   ·   ');
        setT(r.bars, bars);

        const ex = expPerHour(lg);
        setT(r.time, fmtDuration(lg.farmMs));
        setT(r.z, `${fmt(t.total)} z`);
        setT(r.zh, t.perHour === null ? 'รอข้อมูล…' : `${fmt(t.perHour)} z/ชม.`);
        setT(r.k, `${fmt(t.kills)} ตัว`);
        setT(r.kh, t.killsPerHour === null ? 'รอข้อมูล…' : `${fmt(t.killsPerHour)}/ชม.`);
        setT(r.bx, ex ? `${fmt(ex.base)} exp/ชม.` : 'รอข้อมูล…');
        setT(r.eta, levelCapInfo().text);
        setT(r.map, getMapName() || Profit.all.lastMap || '—');
        setT(r.ping, (Ping.summary && Ping.summary.text) || '—');
        const pm = collectSnapshotData();
        const prem = pm.meta.buffActive ? `✅ มี · เหลือ ${pm.raw.premiumBuff}` : '❌ ไม่มีบัฟ Premium';
        setT(r.prem, prem);
        const pc = r.prem.parentElement;
        pc.classList.toggle('ai-prem-on', !!pm.meta.buffActive);
    }

    function applyRender() {
        const on = r3Off();
        document.documentElement.classList.toggle('at-r3off', on);
        try { lsSet(R3_BOOT_KEY, State.opt.renderOff ? '1' : '0'); } catch (e) { /* ignore */ }
        const b = document.getElementById('at-r3-btn');
        if (b) {
            b.textContent = State.opt.renderOff ? (R3T.force ? '🖥️ เปิดภาพ 3D กลับมา (ตอนนี้เปิดชั่วคราว)' : '🖥️ เปิดภาพ 3D กลับมา') : '🌙 ปิดภาพ 3D (ประหยัดเครื่อง)';
            b.classList.toggle('on', !!State.opt.renderOff);
        }
        document.querySelectorAll('.at-switch[data-opt="renderOff"]').forEach((s) => s.classList.toggle('on', !!State.opt.renderOff));
        if (on) {
            ensureIdle();
            renderIdle();
        } else {
            if (Idle.cv) Idle.cv.classList.remove('at-cv-off');
            document.querySelectorAll('canvas.at-cv-off').forEach((c) => c.classList.remove('at-cv-off'));
            if (Idle.el) { Idle.el.remove(); Idle.el = null; }
            if (Idle.hostFix) { Idle.hostFix.style.position = ''; Idle.hostFix = null; }
        }
    }

    // 💤 ไม่ได้แตะจอ (คลิก/กดปุ่ม/เลื่อน) ในแท็บนี้นานเกินที่ตั้ง → ปิดภาพ 3D เอง · แตะจออีกครั้ง → เปิดภาพกลับ (เฉพาะที่ปิดให้อัตโนมัติ)
    const Idle3D = { lastUser: Date.now(), auto: false };
    for (const ty of ['keydown', 'mousedown', 'wheel', 'touchstart']) {
        window.addEventListener(ty, (e) => {
            if (!e.isTrusted) return;
            Idle3D.lastUser = Date.now();
            if (Idle3D.auto && State.opt.renderOff) { Idle3D.auto = false; setRenderOff(false); Log.info('SYS', '👆 แตะจอแล้ว — เปิดภาพ 3D กลับ'); }
        }, true);
    }
    setInterval(() => {
        try {
            if (!State.opt.r3Idle || State.opt.renderOff || !State.isGameReady) { if (!State.opt.renderOff) Idle3D.auto = false; return; }
            const min = Math.max(1, +State.opt.r3IdleMin || 7);
            if (Date.now() - Idle3D.lastUser > min * 60000) { Idle3D.auto = true; setRenderOff(true); Log.info('SYS', `💤 ไม่ได้แตะจอ ${min} นาที — ปิดภาพ 3D อัตโนมัติ (แตะจอเพื่อเปิดกลับ)`); }
        } catch (e) { /* ignore */ }
    }, 15000);
    function setRenderOff(v) {
        State.opt.renderOff = !!v;
        savePrefs();
        applyRender();
        Log.info('SYS', v ? 'ปิดภาพ 3D (ประหยัดเครื่อง) · บันทึกสถานะไว้' : 'เปิดภาพ 3D กลับมา · บันทึกสถานะไว้');
    }

    // ---------------------------------------------------------------
    // Town timer: อยู่แมพที่ไม่ใช่แมพฟาร์ม (เมือง/คุก ฯลฯ) มากี่นาที · นับตลอดแม้ย่อ/ปิด UI · รีเซ็ตเมื่อเปลี่ยนแมพ
    // ---------------------------------------------------------------
    const Town = { map: '', since: 0, savedAt: 0, loaded: false, saved: null };

    function fmtTown(ms) {
        const s = Math.max(0, Math.floor(ms / 1000));
        const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
        if (h) return `${h} ชม. ${m} นาที`;
        if (m) return `${m} นาที ${pad2(sec)} วิ`;
        return `${sec} วิ`;
    }

    function townTick(now) {
        if (!State.isGameReady) return;
        const map = getMapName();
        if (!map) return;
        if (!Town.loaded) { Town.saved = Store.getJSON('at_town_v1'); Town.loaded = true; }
        if (!isFarmMap()) {
            if (Town.map !== map) {
                const s = Town.saved;
                if (s && s.map === map && now - s.seen < 120000 && s.since <= now) Town.since = s.since; // รีเฟรชหน้าเว็บ ไม่รีเซ็ต
                else { Town.since = now; Log.info('TOWN', `เข้า ${map}`); }
                Town.saved = null;
                Town.map = map;
            }
            if (now - Town.savedAt > 10000) {
                Town.savedAt = now;
                Store.set('at_town_v1', JSON.stringify({ map, since: Town.since, seen: now }));
            }
        } else {
            if (Town.map) {
                Log.info('TOWN', `ออกจาก ${Town.map} · อยู่มา ${fmtTown(now - Town.since)}`);
                Town.map = '';
                Store.set('at_town_v1', '');
            }
            Town.saved = null;
        }
    }

    function renderTown() {
        const row = document.getElementById('at-town-row');
        const chip = document.getElementById('at-town-chip');
        if (!row || !chip) return;
        const on = !!Town.map;
        const txt = on ? fmtTown(Date.now() - Town.since) : '';
        const rd = on ? '' : 'none';
        if (row.style.display !== rd) row.style.display = rd;
        const cd = on && State.isMinimized ? '' : 'none';
        if (chip.style.display !== cd) chip.style.display = cd;
        if (on) {
            setT(document.getElementById('at-town-time'), txt);
            setT(chip, '🏙️ ' + txt);
            row.title = `อยู่ที่ ${Town.map} มาแล้ว (รีเซ็ตเมื่อเปลี่ยนแมพ/ออกจากเมือง) — ใช้เช็ค AFK`;
        }
    }

    // ---------------------------------------------------------------
    // v4.4: เสียง/แจ้งเตือน · Captcha · บอทค้าง · หลุดการเชื่อมต่อ · ของใช้ใกล้หมด · แชท · EXP · สรุปรายชั่วโมง · ป๊อปอัปการ์ด
    // ---------------------------------------------------------------
    const Watch = {
        cap: false, capBeepAt: 0,
        farmSince: 0, stallMap: '', stallFired: false,
        srv: false, crash: false, goneSince: 0, lost: false,
        supply: {}, supplyAt: 0, jail: false, jailAt: 0,
        chatRaw: null, chatSeen: null, chatName: '', chatAt: 0,
        cardSeen: 0, cardClick: 0,
        digestAt: 0,
    };
    const Snd = { ctx: null };
    const Exp = { at: 0, rate: null, cal: null, cur: null, jstart: null, jcur: null, tab: null, tabName: '', lv: 0, jlv: 0, baseMax: false, jobMax: false };
    const Digest = { base: null, at: 0, rares: [], wasFarming: false };

    function beep(kind) {
        if (!State.opt.sound) return;
        try {
            const C = window.AudioContext || window.webkitAudioContext;
            if (!C) return;
            const ctx = Snd.ctx || (Snd.ctx = new C());
            if (ctx.state === 'suspended') ctx.resume();
            const seq = kind === 'alarm' ? [880, 660, 880, 660, 880] : [660, 880];
            let t = ctx.currentTime;
            for (const f of seq) {
                const o = ctx.createOscillator(), g = ctx.createGain();
                o.type = 'sine';
                o.frequency.value = f;
                g.gain.setValueAtTime(0.0001, t);
                g.gain.exponentialRampToValueAtTime(0.25, t + 0.02);
                g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
                o.connect(g);
                g.connect(ctx.destination);
                o.start(t);
                o.stop(t + 0.2);
                t += 0.22;
            }
        } catch (e) { /* ignore */ }
    }

    // แจ้งเตือนบนจอ + เสียง + Discord (ถ้าเปิดหัวข้อไว้)
    function raiseAlert(topic, o) {
        Log.warn('ALERT', `${o.title} · ${o.desc}`);
        showToast(o.toast || o.title, 'warn', o.thumb);
        beep(o.sound || 'alarm');
        sendDiscord(topic, { title: o.title, description: o.desc, color: o.color || 0xf87171, fields: o.fields || [] }, { ping: o.ping !== false, thumb: o.thumb, once: o.once, onceMs: o.onceMs });
    }

    const charLabel = () => Profit.charName || readField(SELECTORS.charName, 'name') || '—';

    function watchCaptcha(now) {
        if (Frame.captcha) {
            if (!Watch.cap) {
                Watch.cap = true;
                Watch.capBeepAt = now;
                if (State.opt.captcha) {
                    const prompt = norm((document.querySelector('.human-check-prompt') || {}).textContent || '');
                    raiseAlert('captcha', {
                        title: '🧩 เกมขอตรวจสอบผู้เล่น!',
                        desc: `**${charLabel()}** ถูกเช็คผู้เล่น ต้องตอบภายในเวลา ไม่เช่นนั้นจะถูกส่งเข้าคุก — กลับมาที่หน้าจอทันที${prompt ? `\n> ${prompt}` : ''}`,
                        fields: [{ name: 'แมพ', value: getMapName() || '—', inline: true }],
                        color: 0xf59e0b,
                        toast: '🧩 เกมขอตรวจสอบผู้เล่น! กลับมาตอบด่วน',
                    });
                }
            } else if (State.opt.captcha && now - Watch.capBeepAt > 10000) {
                Watch.capBeepAt = now;
                beep('alarm');
            }
        } else if (Watch.cap) {
            Watch.cap = false;
            Log.info('ALERT', 'หน้าต่างตรวจสอบผู้เล่นปิดแล้ว');
        }
    }

    function watchStall(now) {
        const auto = queryGame(SELECTORS.autoToggle);
        const autoOn = !!auto && (auto.classList.contains('on') || auto.getAttribute('aria-pressed') === 'true');
        const map = getMapName();
        if (!State.opt.stall || !Profit.farming || Frame.dead || Frame.captcha || !autoOn) {
            Watch.farmSince = 0;
            Watch.stallFired = false;
            return;
        }
        if (!Watch.farmSince || Watch.stallMap !== map) {
            Watch.farmSince = now;
            Watch.stallMap = map;
            Watch.stallFired = false;
        }
        const act = Math.max(Watch.farmSince, (curLedger() || {}).lastGainAt || 0, Profit.lastKillAt || 0);
        const idleMs = now - act;
        if (idleMs >= State.opt.stallMin * 60000) {
            if (!Watch.stallFired) {
                Watch.stallFired = true;
                raiseAlert('stall', {
                    title: '🧟 บอทอาจค้างในแมพฟาร์ม',
                    desc: `**${charLabel()}** เปิด Auto อยู่ที่ **${map || '—'}** แต่ไม่มีของดรอป/ไม่ได้ฆ่ามอนมา ${fmtTown(idleMs)} (อาจค้าง ยา/ลูกธนูหมด หรือมอนหมดแมพ)`,
                    color: 0xfb923c,
                    toast: `🧟 ไม่มีความเคลื่อนไหว ${Math.round(idleMs / 60000)} นาที อาจค้าง`,
                });
            }
        } else {
            Watch.stallFired = false;
        }
    }

    function watchConn(now) {
        if (!State.opt.conn) return;
        const srv = document.querySelector('.server-banner-row.restart');
        const srvOn = isNodeVisible(srv);
        if (srvOn && !Watch.srv) {
            raiseAlert('server', {
                title: '🔧 เซิร์ฟเวอร์กำลังจะรีสตาร์ท',
                desc: norm(srv.textContent).slice(0, 300),
                color: 0xf59e0b, ping: false, sound: 'beep', once: 'srv-restart', onceMs: 900000,
            });
        }
        Watch.srv = srvOn;

        const crashOn = isNodeVisible(document.querySelector('.crash-box'));
        if (crashOn && !Watch.crash) {
            raiseAlert('server', {
                title: '💥 เกมแสดงข้อผิดพลาด (crash)',
                desc: `**${charLabel()}** — หน้าจอเกมหยุดทำงาน ต้องรีเฟรชหน้าเว็บ\n(ถ้าเปิดหลายจอ จะแจ้งครั้งเดียวต่อ 3 นาที — จอที่ crash พร้อมกันไม่แจ้งซ้ำ)`,
                color: 0xef4444, once: 'srv-crash', onceMs: 180000,
            });
        }
        Watch.crash = crashOn;
        reloadCheck(now, crashOn);

        if (State.isGameReady) {
            const hudGone = !queryGame(SELECTORS.charName) || isNodeVisible(document.querySelector('.reconnecting'));
            if (hudGone) {
                if (!Watch.goneSince) Watch.goneSince = now;
                if (!Watch.lost && now - Watch.goneSince > 25000) {
                    Watch.lost = true;
                    raiseAlert('server', {
                        title: '📡 หลุดการเชื่อมต่อจากเกม',
                        desc: `**${charLabel()}** ไม่พบหน้าจอตัวละครมาแล้ว ${Math.round((now - Watch.goneSince) / 1000)} วินาที (หลุด/รอคิวเข้าเกม)\n(ถ้าเปิดหลายจอ จะแจ้งครั้งเดียวต่อ 3 นาที — ดูว่าตัวไหนหลุดได้ที่กล่องสถานะ)`,
                        color: 0xef4444, once: 'srv-lost', onceMs: 180000,
                    });
                }
            } else {
                if (Watch.lost) Log.ok('ALERT', 'กลับเข้าเกมแล้ว');
                Watch.goneSince = 0;
                Watch.lost = false;
            }
        }
    }

    const ITEM_TYPE_TH = { Consumable: 'ของใช้ / ยา', Equipment: 'อุปกรณ์', Card: 'การ์ด', Enchantment: 'เอนชานต์', AwakeningStone: 'หินปลุกพลัง', Miscellaneous: 'วัตถุดิบ / เบ็ดเตล็ด' };
    const IconRev = { src: null, map: {} };
    // รูปไอคอนในช่องด่วน -> id ไอเทม (ย้อนจาก manifest ของเกม)
    // ไอคอนหนึ่งไฟล์อาจใช้ร่วมกันหลายไอเทม (เช่น เจมทุกตัวใช้รูปม่วงเหมือนกัน) → คืนรายชื่อ id ที่เป็นไปได้ทั้งหมด
    function iconCands(src) {
        if (!src || !Icons.items) return [];
        if (IconRev.src !== Icons.items) {
            IconRev.src = Icons.items;
            IconRev.map = {};
            for (const [id, f] of Object.entries(Icons.items)) (IconRev.map[f] || (IconRev.map[f] = [])).push(+id);
        }
        return IconRev.map[String(src).split('?')[0].replace(/^.*\/art\/icons\//, '')] || [];
    }
    // คืน id เฉพาะเมื่อรูปนี้เป็นของไอเทมเดียวเท่านั้น (ถ้าคลุมเครือ = 0 ห้ามเดา)
    function itemIdFromIcon(src) {
        const c = iconCands(src);
        return c.length === 1 ? c[0] : 0;
    }

    // ⭐ Wishlist: ไอเทมที่ตามหา — ดรอปเมื่อไหร่แจ้งเตือนทันที (เก็บต่อโปรไฟล์)
    const wishHas = (name) => !!(State.opt.wish && State.opt.wish[norm(name).toLowerCase()]);
    function wishToggle(name) {
        const k = norm(name).toLowerCase();
        State.opt.wish = Object.assign({}, State.opt.wish || {});
        if (State.opt.wish[k]) delete State.opt.wish[k]; else State.opt.wish[k] = name;
        savePrefs();
        Profit.rev++;
        if (typeof Wiki !== 'undefined' && Wiki.el) renderWikiList();
        if (typeof Info !== 'undefined' && Info.el) { const sb = Info.el.querySelector('.ai2-body'); const st = sb ? sb.scrollTop : 0; showInfo(); const nb = Info.el && Info.el.querySelector('.ai2-body'); if (nb) nb.scrollTop = st; }
    }

    // 🎒 ช่องเก็บของใกล้เต็ม: แจ้งที่ 85% และ 100% (ต่ำกว่า 80% แล้วค่อยเตือนใหม่)
    function watchBag(now) {
        if (!State.opt.bagWarn || now - (Watch.bagAt || 0) < 5000) return;
        Watch.bagAt = now;
        const m = /(\d+)\s*\/\s*(\d+)/.exec(readField(SELECTORS.slots, 'slots') || '');
        if (!m || +m[2] <= 0) return;
        const used = +m[1], max = +m[2], r = used / max;
        const lvl = r >= 1 ? 2 : r >= 0.85 ? 1 : 0;
        if (r < 0.8) { Watch.bagLvl = 0; return; }
        if (lvl > (Watch.bagLvl || 0)) {
            Watch.bagLvl = lvl;
            raiseAlert('bag', {
                title: lvl === 2 ? '🔴 ช่องเก็บของเต็มแล้ว!' : '🟠 ช่องเก็บของใกล้เต็ม',
                desc: `**${charLabel()}** — ช่องเก็บของ **${used}/${max}** (${Math.round(r * 100)}%)${lvl === 2 ? ' · ของที่ดรอปจะเก็บไม่ได้' : ''}`,
                fields: [{ name: 'แมพ', value: getMapName() || '—', inline: true }],
                color: lvl === 2 ? 0xef4444 : 0xfb923c, ping: lvl === 2, sound: 'beep',
                toast: `🎒 ช่องเก็บของ ${used}/${max}`,
            });
        }
    }

    // ⌨️ ปุ่มลัด: Alt+P Profit · Alt+W Wiki · Alt+C Config · Alt+L Logs · Alt+M ย่อ/ขยาย
    document.addEventListener('keydown', (e) => {
        if (!State.opt.hotkeys || !e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
        const t = e.target;
        if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
        const id = { KeyX: 'at-btn-pause', KeyP: 'at-btn-profit', KeyW: 'at-btn-wiki', KeyC: 'at-btn-settings', KeyL: 'at-btn-logs', KeyD: 'at-btn-dev', KeyM: 'at-btn-min' }[e.code];
        const btn = id && document.getElementById(id);
        if (btn) { e.preventDefault(); e.stopPropagation(); btn.click(); }
    }, true);

    function supplyAlert(slotLabel, n, min, ref) {
        const fire = (it) => {
            const name = (it && it.name) || ref.name || slotLabel;
            const typ = ref.ammo ? 'ลูกธนู / กระสุน' : it ? (ITEM_TYPE_TH[it.type] || it.type || '') : '';
            raiseAlert('supply', {
                title: '🎒 ของใช้ใกล้หมด',
                desc: `**${charLabel()}** — **${name}**${typ ? ` (${typ})` : ''} เหลือ **${n}** (ต่ำกว่า ${min})`,
                fields: [{ name: 'ไอเทม', value: name, inline: true }, { name: 'ประเภท', value: typ || '—', inline: true }, { name: 'เหลือ', value: `${fmt(n)} ชิ้น`, inline: true }, { name: 'ตำแหน่ง', value: slotLabel, inline: true }],
                color: 0xfb923c, ping: false, sound: 'beep', thumb: ref.icon || '',
                toast: `🎒 ${name} เหลือ ${n}`,
            });
        };
        infoLoad().then(() => fire(ref.id ? Info.itemById.get(ref.id) : Info.byItemName.get(norm(ref.name))), () => fire(null));
    }

    function watchSupply(now) {
        if (!State.opt.supply || now - Watch.supplyAt < 5000) return;
        Watch.supplyAt = now;
        const min = State.opt.supplyMin;
        const check = (key, label, n, ref) => {
            if (n < min) {
                if (!Watch.supply[key]) {
                    Watch.supply[key] = true;
                    supplyAlert(label, n, min, ref);
                }
            } else if (n >= min * 1.2) {
                Watch.supply[key] = false;
            }
        };
        document.querySelectorAll('.hot-slot.item').forEach((s, i) => {
            const sub = s.querySelector('.hot-sub');
            const m = sub && /x\s*([\d,]+)/i.exec(sub.textContent);
            if (!m) return;
            const im = s.querySelector('img');
            const icon = im ? im.getAttribute('src') || '' : '';
            const hk = norm((s.querySelector('.hot-key') || {}).textContent || '') || String(i + 1);
            check('hb' + hk, `ช่องด่วนที่ ${hk}`, parseInt(m[1].replace(/,/g, ''), 10), { id: itemIdFromIcon(icon), icon, name: '' });
        });
        const am = document.querySelector('.equip-slot.equip-ammo.filled');
        if (am && isNodeVisible(am)) {
            const lab = norm((am.querySelector('.equip-label') || am).textContent);
            const m = /x\s*([\d,]+)/i.exec(lab) || /([\d,]+)\s*$/.exec(lab);
            if (m) {
                const im = am.querySelector('img');
                const icon = im ? im.getAttribute('src') || '' : '';
                check('ammo', 'ช่องลูกธนู/กระสุน', parseInt(m[1].replace(/,/g, ''), 10), { id: itemIdFromIcon(icon), icon, name: lab.replace(/\s*x\s*[\d,]+\s*$/i, ''), ammo: true });
            }
        }
    }

    // ติดคุก: ตรวจจากชื่อแมพ "คุก" · แจ้งตอนเข้า และตอนพ้นโทษ
    function watchJail(now) {
        const map = getMapName();
        const jail = !!map && isJailMap(map);
        if (jail && !Watch.jail) {
            Watch.jail = true;
            Watch.jailAt = now;
            raiseAlert('jail', {
                title: '⛓️ ตัวละครติดคุก!',
                desc: `**${charLabel()}** อยู่ที่ **${map}** — อาจเป็นเพราะตอบเช็คผู้เล่นไม่ทัน หรือถูกส่งเข้าคุก กลับมาดูที่หน้าจอ`,
                fields: [{ name: 'แมพ', value: map, inline: true }, { name: 'เลเวล', value: (() => { const d = collectSnapshotData().raw; return `Base ${d.baseLv || '—'} / Job ${d.jobLv || '—'}`; })(), inline: true }],
                color: 0xef4444, toast: '⛓️ ตัวละครติดคุก!',
            });
        } else if (!jail && Watch.jail) {
            Watch.jail = false;
            const dur = fmtTown(now - Watch.jailAt);
            Log.ok('ALERT', `พ้นโทษออกจากคุกแล้ว (อยู่ในคุก ${dur})`);
            showToast('🔓 ออกจากคุกแล้ว', 'info');
            delete Discord.last.jail;
            sendDiscord('jail', { title: '🔓 ออกจากคุกแล้ว', description: `**${charLabel()}** ออกจากคุกมาอยู่ที่ **${map || '—'}** (อยู่ในคุก ${dur})`, color: 0x3ddc84, fields: [] }, { ping: false });
        }
    }

    function watchChat(now) {
        if (!State.opt.chat || !Profit.charName || now - Watch.chatAt < 2500) return;
        Watch.chatAt = now;
        const me = Profit.charName;
        let raw;
        try { raw = localStorage.getItem('webgame.chat.' + me); } catch (e) { return; }
        if (!raw || raw === Watch.chatRaw) return;
        Watch.chatRaw = raw;
        let arr;
        try { arr = JSON.parse(raw); } catch (e) { return; }
        if (!Array.isArray(arr)) return;
        const first = !Watch.chatSeen || Watch.chatName !== me;
        if (first) { Watch.chatSeen = new Set(); Watch.chatName = me; }
        if (Watch.chatSeen.size > 800) Watch.chatSeen.clear();
        for (const e of arr) {
            if (!e || typeof e.text !== 'string' || e.channel === 'system') continue;
            const isW = e.channel === 'whisper' && e.from && e.from !== me;
            const isGM = e.staff === 'gm' && e.from !== me;
            if (!isW && !isGM) continue;
            const k = `${e.at}|${e.from}|${e.text}`;
            if (Watch.chatSeen.has(k)) continue;
            Watch.chatSeen.add(k);
            if (first) continue;
            raiseAlert('chat', {
                title: isGM ? `🛡️ GM ทักมา: ${e.from || ''}` : `💬 กระซิบจาก ${e.from}`,
                desc: `**${charLabel()}** ได้รับข้อความ\n> ${String(e.text).slice(0, 400)}`,
                color: isGM ? 0xef4444 : 0xf0abfc,
                sound: isGM ? 'alarm' : 'beep',
            });
        }
    }

    // ป๊อปอัป "ได้รับการ์ด!" -> กด ตกลง (หน่วงเล็กน้อยให้เห็นการ์ดก่อน)
    // หาปุ่ม "ตกลง" ของป๊อปอัปการ์ด: ไม่พึ่งชื่อคลาสอย่างเดียว (เกมอาจเปลี่ยนชื่อ) — หาปุ่มที่เขียนว่า "ตกลง" ซึ่งอยู่ในกล่องที่มีข้อความ "ได้รับการ์ด"
    function findCardOk() {
        const bd = document.querySelector('.card-viewer-backdrop.gained');
        if (bd && isNodeVisible(bd)) {
            const btns = [...bd.querySelectorAll('.card-buttons button, button')].filter((b) => isNodeVisible(b) && !b.disabled);
            const b = btns.find((x) => /ตกลง/.test(x.textContent)) || btns[0];
            if (b) return { btn: b, root: bd };
        }
        for (const b of document.querySelectorAll('button')) {
            if (b.disabled || !/^\s*ตกลง\s*$/.test(b.textContent) || !isNodeVisible(b) || b.closest(OWN_UI)) continue;
            let n = b.parentElement;
            for (let i = 0; n && i < 9; i++, n = n.parentElement) {
                if (/ได้รับการ์ด/.test(n.textContent || '') && (n.textContent || '').length < 1500) return { btn: b, root: n };
            }
        }
        return null;
    }

    // 🃏 รูปการ์ดจริงจากป๊อปอัป "ได้รับการ์ด!" → ใช้เป็นรูปใน Discord แทนไอคอนการ์ด (ไอคอนในกระเป๋า/แชทเป็นรูปเดียวกันทุกใบ)
    //    จำไว้ต่อชื่อการ์ด (at_card_art) — ดรอปใบเดิมครั้งหน้าได้รูปทันที
    const CardArt = { map: null, last: null, warned: false };
    function cardArtMap() { if (!CardArt.map) { try { CardArt.map = JSON.parse(localStorage.getItem('at_card_art') || '{}') || {}; } catch (e) { CardArt.map = {}; } } return CardArt.map; }
    function cardArtGrab(root) {
        const nm = norm((root.querySelector('.card-info-name') || root.querySelector('.card-art-name') || {}).textContent || '');
        let best = '', bs = 0;
        for (const el of root.querySelectorAll('*')) {
            let src = '';
            if (el.tagName === 'IMG') src = el.currentSrc || el.src || '';
            else { let bg = ''; try { bg = getComputedStyle(el).backgroundImage || ''; } catch (e) { /* ignore */ } const m = /url\(["']?([^"')]+)["']?\)/.exec(bg); if (m) src = m[1]; }
            if (!src || /^(data|blob):/.test(src) || /\/art\/icons\//.test(src)) continue;      // ไอคอนเล็ก / รูปที่ Discord ดึงไม่ได้
            const r = el.getBoundingClientRect(); let sc = r.width * r.height; if (sc < 900) continue;
            if (/card/i.test(src)) sc *= 1.5;
            if (/frame|border|back|bg|glow|shine|light|rarity|mask/i.test(src)) sc *= 0.2;      // กรอบ/พื้นหลังการ์ด ไม่ใช่ภาพการ์ด
            if (sc > bs) { bs = sc; best = src; }
        }
        if (!best) { if (!CardArt.warned) { CardArt.warned = true; Log.warn('CARD', `อ่านรูปการ์ด${nm ? ` ${nm}` : ''}ในป๊อปอัปไม่ได้ — Discord จะใช้ไอคอนการ์ดแทน`); } return ''; }
        let abs = best; try { abs = new URL(best, location.href).href; } catch (e) { /* ignore */ }
        CardArt.last = { name: nm, url: abs, at: Date.now() };
        if (nm) { const m = cardArtMap(); if (m[nm] !== abs) { m[nm] = abs; try { lsSet('at_card_art', JSON.stringify(m)); } catch (e) { /* ignore */ } Log.info('CARD', `🃏 จำรูปการ์ด ${nm}`); } }
        return abs;
    }
    // ส่งการ์ดเข้า Discord: รอรูปจากป๊อปอัปสูงสุด ~5 วิ (ข้อความแชทกับป๊อปอัปมาไม่พร้อมกัน)
    function cardSend(g, emb, so) {
        const t0 = Date.now();
        const go = () => {
            const L = CardArt.last;
            const art = cardArtMap()[g.name] || (L && Date.now() - L.at < 15000 ? L.url : '');
            if (!art && Date.now() - t0 < 5000) { setTimeout(go, 700); return; }
            const e = Object.assign({}, emb, { title: '🃏 ได้การ์ด!' });
            if (art) e.image = { url: art };
            sendDiscord('rare', e, art ? Object.assign({}, so, { thumb: '' }) : so);
        };
        go();
    }
    function cardTick(now) {
        const f = Frame.captcha ? null : findCardOk();
        if (!f) { Watch.artDone = false; Watch.artAt = 0; } else if (!Watch.artDone && now - (Watch.artAt || 0) > 400) { Watch.artAt = now; if (cardArtGrab(f.root)) Watch.artDone = true; }      // อ่านรูปก่อนกดปิด (ทำแม้ปิดกดตกลงอัตโนมัติ)
        if (!State.opt.autoCard || Frame.captcha) { Watch.cardSeen = 0; return; }
        if (!f) { Watch.cardSeen = 0; Watch.cardTries = 0; return; }
        if (!Watch.cardSeen) { Watch.cardSeen = now; return; }
        if (now - Watch.cardSeen < 900 || now - (Watch.cardClick || 0) < 1500) return;
        Watch.cardClick = now;
        Watch.cardTries = (Watch.cardTries || 0) + 1;
        const nm = norm((f.root.querySelector('.card-info-name') || f.root.querySelector('.card-art-name') || {}).textContent || '');
        const r = f.btn.getBoundingClientRect();
        const opts = { bubbles: true, cancelable: true, view: VIEW, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0 };
        try {
            f.btn.dispatchEvent(new PointerEvent('pointerover', opts));
            f.btn.dispatchEvent(new MouseEvent('mouseover', opts));
            f.btn.dispatchEvent(new PointerEvent('pointerdown', opts));
            f.btn.dispatchEvent(new MouseEvent('mousedown', opts));
            f.btn.dispatchEvent(new PointerEvent('pointerup', opts));
            f.btn.dispatchEvent(new MouseEvent('mouseup', opts));
            f.btn.dispatchEvent(new MouseEvent('click', opts));
        } catch (e) { f.btn.click(); }
        if (Watch.cardTries >= 2) { try { f.btn.focus(); pressKey('Enter', 'Enter', 13); } catch (e) { /* ignore */ } }
        Log.ok('AUTO', `กด "ตกลง" ป๊อปอัปการ์ด${nm ? `: ${nm}` : ''}${Watch.cardTries > 1 ? ` (ครั้งที่ ${Watch.cardTries})` : ''}`);
    }

    // ---- EXP / เวลาเลเวลอัป / Lv 99 ----
    const BASE_MAX_LV = 99;
    const EXPTAB_PREFIX = 'at_exptab_v1';

    function readExpPct() {
        const bars = [...document.querySelectorAll('.bar.bar-exp')];
        const read = (b) => {
            const n = b && b.querySelector('.bar-num');
            const t = n ? norm(n.textContent) : '';
            const v = parseFloat(t.replace('%', ''));
            return { v: isFinite(v) ? v : null, max: /MAX/i.test(t) };
        };
        const a = read(bars[0]), j = read(bars[1]);
        return { base: a.v, baseMax: a.max, job: j.v, jobMax: j.max };
    }

    function expTab() {
        if (Exp.tab && Exp.tabName === Profit.charName) return Exp.tab;
        Exp.tabName = Profit.charName;
        Exp.tab = Store.getJSON(`${EXPTAB_PREFIX}_${Profit.charName}`, {}) || {};
        return Exp.tab;
    }

    // เก็บตัวอย่างทุก 5 วินาที: เรียนรู้ว่าแต่ละเลเวลต้องใช้ EXP เท่าไหร่ (เกมไม่เปิดตารางให้ฝั่ง client)
    function expSample(now) {
        if (now - Exp.at < 5000 || !Profit.charName) return;
        Exp.at = now;
        const p = readExpPct();
        const lvTxt = readField(SELECTORS.level, 'level');
        const lv = parseInt((REGEX.baseLv.exec(lvTxt) || [])[1], 10);
        const jlv = parseInt((REGEX.jobLv.exec(lvTxt) || [])[1], 10);
        Exp.lv = lv; Exp.jlv = jlv;
        Exp.baseMax = p.baseMax || lv >= BASE_MAX_LV;
        Exp.jobMax = p.jobMax;
        const tot = sumAll();
        if (!Exp.rate || Exp.rate.name !== Profit.charName || tot.bx < Exp.rate.bx || tot.ms < Exp.rate.ms) {
            Exp.rate = { name: Profit.charName, bx: tot.bx, jx: tot.jx, ms: tot.ms };
        }
        if (p.job !== null && isFinite(jlv)) {
            if (!Exp.jstart || Exp.jstart.name !== Profit.charName || tot.ms < Exp.jstart.ms) Exp.jstart = { name: Profit.charName, jlv, pct: p.job, ms: tot.ms };
            Exp.jcur = { jlv, pct: p.job, ms: tot.ms };
        } else Exp.jcur = null;
        if (Exp.baseMax || p.base === null || !isFinite(lv)) { Exp.cal = null; Exp.cur = null; return; }
        const tab = expTab();
        const c = Exp.cal;
        if (!c || c.name !== Profit.charName || lv < c.lv || tot.bx < c.bx0) {
            Exp.cal = { name: Profit.charName, lv, pct0: p.base, bx0: tot.bx };
        } else if (lv > c.lv) {
            if (lv === c.lv + 1 && 100 - c.pct0 >= 30 && tot.bx > c.bx0) {
                tab[c.lv] = Math.round((tot.bx - c.bx0) / ((100 - c.pct0) / 100));
                Store.set(`${EXPTAB_PREFIX}_${Profit.charName}`, JSON.stringify(tab));
                Log.ok('EXP', `เรียนรู้: Base Lv ${c.lv} ใช้ EXP ≈ ${fmt(tab[c.lv])}`);
            }
            Exp.cal = { name: Profit.charName, lv, pct0: p.base, bx0: tot.bx };
        }
        Exp.cur = { base: p.base, job: p.job, lv, jlv };
    }

    function expRate() {
        const r = Exp.rate;
        if (!r) return null;
        const tot = sumAll();
        const h = (tot.ms - r.ms) / 3600000;
        if (h * 60 < 3) return null;
        const v = (tot.bx - r.bx) / h;
        return v > 0 ? v : null;
    }

    function baseEta() {
        const lvNow = parseInt((REGEX.baseLv.exec(readField(SELECTORS.level, 'level')) || [])[1], 10);
        if (Exp.baseMax || lvNow >= BASE_MAX_LV) return { capped: true };
        const c = Exp.cal, cur = Exp.cur;
        if (!c || !cur) return null;
        const rate = expRate();
        if (!rate) return null;
        const dPct = cur.base - c.pct0;
        if (dPct < 1) return null; // ต้องคืบหน้า ≥1% ในเลเวลนี้ก่อน ถึงจะรู้ว่าเลเวลนี้ใช้ EXP เท่าไหร่
        const rCur = (sumAll().bx - c.bx0) / (dPct / 100);
        const tab = expTab();
        const keys = Object.keys(tab).map(Number).sort((a, b) => a - b);
        const ratios = [];
        for (let i = 1; i < keys.length; i++) if (keys[i] === keys[i - 1] + 1 && tab[keys[i - 1]] > 0) ratios.push(tab[keys[i]] / tab[keys[i - 1]]);
        const g = ratios.length ? Math.min(1.25, Math.max(1.02, ratios.reduce((a, b) => a + b, 0) / ratios.length)) : 1.08;
        let need = (rCur * (100 - cur.base)) / 100;
        let r = rCur;
        for (let L = cur.lv + 1; L < BASE_MAX_LV; L++) { r = tab[L] || r * g; need += r; }
        return { hours: need / rate, exact: cur.lv >= BASE_MAX_LV - 1, learned: keys.length, g, need, rate, levels: BASE_MAX_LV - cur.lv };
    }

    function jobEta() {
        const s = Exp.jstart, c = Exp.jcur;
        if (Exp.jobMax) return { capped: true };
        if (!s || !c) return null;
        const h = (c.ms - s.ms) / 3600000;
        if (h * 60 < 3) return null;
        const rate = ((c.jlv - s.jlv) * 100 + (c.pct - s.pct)) / h;
        return rate > 0 ? { hours: (100 - c.pct) / rate } : null;
    }

    function fmtEta(h) {
        if (h === null || h === undefined || !isFinite(h)) return 'รอข้อมูล…';
        if (h < 1) return `${Math.max(1, Math.round(h * 60))} นาที`;
        // แสดงเป็น "ชั่วโมง" เสมอ (มีจุลภาคคั่นหลักพัน) · <10 ชม. โชว์ทศนิยม 1 ตำแหน่ง
        return `${h < 10 ? h.toFixed(1) : NF.format(Math.round(h))} ชม.`;
    }

    // ข้อความการ์ด "ถึง Lv 99" + คำอธิบาย
    function levelCapInfo() {
        const b = baseEta();
        const j = jobEta();
        let text, title = '';
        if (b && b.capped) {
            text = 'เวลตันแล้ว ✅';
            title = `Base Lv ${BASE_MAX_LV} (เลเวลสูงสุด)`;
        } else if (b) {
            text = `${b.exact ? '' : '≈ '}${fmtEta(b.hours)}`;
            title = `${text}\nเวลาโดยประมาณที่จะถึง Base Lv ${BASE_MAX_LV} = EXP ที่เหลือ ÷ อัตรา EXP ที่ฟาร์มได้\n• EXP ที่เหลือ ≈ ${fmt(b.need)} (อีก ${b.levels} เลเวล)\n• อัตรา ≈ ${fmt(b.rate)} exp/ชม.\n• ≈ ${fmtEta(b.hours)}${b.hours > 24 ? ` (${(b.hours / 24).toFixed(1)} วัน)` : ''}${b.hours > 8760 ? '\n⚠️ เกิน 1 ปี — ค่านี้เดาจากสูตรเพิ่ม EXP ต่อเลเวลที่เรียนรู้ได้ยังน้อย อาจคลาดมาก' : ''}\n` + (b.exact ? '' : ` · เกมไม่เปิดตาราง EXP ให้ จึงประมาณจากเลเวลปัจจุบัน + เรียนรู้ทีละเลเวล (เรียนรู้แล้ว ${b.learned} เลเวล · ตัวคูณ ${b.g.toFixed(2)}/เลเวล)`);
        } else {
            text = 'รอข้อมูล…';
            title = 'ต้องฟาร์มต่อเนื่องอย่างน้อย ~3 นาที และ EXP ในเลเวลนี้คืบหน้า ≥1%';
        }
        if (j) title += '\n' + (j.capped ? 'Job: เลเวลตันแล้ว' : `Job Lv ถัดไปอีก ≈ ${fmtEta(j.hours)}`);
        return { text, title };
    }

    // ---- สรุปผลฟาร์มรายชั่วโมง / ตอนกลับเมือง ----
    function digestTick(now) {
        if (now - Watch.digestAt < 10000) return;
        Watch.digestAt = now;
        if (!State.opt.digest || !Profit.charName) { Digest.base = null; return; }
        const snap = sumAll();
        if (!Digest.base || snap.ms < Digest.base.ms || snap.z < Digest.base.z) {
            Digest.base = snap; Digest.at = now; Digest.rares = []; Digest.wasFarming = Profit.farming;
            return;
        }
        const farmed = snap.ms - Digest.base.ms;
        const hourly = Profit.farming && now - Digest.at >= 3600000 && farmed >= 60000;
        const left = Digest.wasFarming && !Profit.farming && farmed >= 300000;
        Digest.wasFarming = Profit.farming;
        if (!hourly && !left) return;
        const hrs = farmed / 3600000;
        const dz = snap.z - Digest.base.z, dk = snap.k - Digest.base.k;
        const fields = [
            { name: '⏱️ เวลาฟาร์ม', value: fmtDuration(farmed), inline: true },
            { name: '💰 Zeny วัตถุดิบ', value: `+${fmt(dz)} z`, inline: true },
            { name: '📈 อัตรา', value: `${fmt(dz / hrs)} z/ชม.`, inline: true },
            { name: '⚔️ ฆ่ามอน', value: `${fmt(dk)} ตัว (${fmt(dk / hrs)}/ชม.)`, inline: true },
            { name: '✨ Base EXP', value: `+${fmt(snap.bx - Digest.base.bx)} (${fmtShort((snap.bx - Digest.base.bx) / hrs)}/ชม.)`, inline: true },
            { name: '✨ Job EXP', value: `+${fmt(snap.jx - Digest.base.jx)}`, inline: true },
        ];
        if (Digest.rares.length) fields.push({ name: '🎁 ดรอปน่าสนใจ', value: Digest.rares.slice(0, 12).join('\n').slice(0, 1000), inline: false });
        sendDiscord('digest', {
            title: left ? '🏙️ สรุปผลฟาร์ม (กลับเข้าเมือง)' : '🕒 สรุปผลฟาร์มรายชั่วโมง',
            description: `**${charLabel()}** · ${getMapName() || Profit.all.lastMap || '—'}`,
            color: 0x7cc4ff,
            fields,
        }, {});
        Log.ok('DIGEST', `ส่งสรุป ${left ? 'ตอนกลับเมือง' : 'รายชั่วโมง'}: +${fmt(dz)} z · ${dk} ตัว`);
        Digest.base = snap; Digest.at = now; Digest.rares = [];
    }

    function watchTick(now) {
        watchCaptcha(now);
        watchConn(now);
        if (!State.isGameReady) return;
        watchStall(now);
        watchSupply(now);
        watchBag(now);
        junkInvWatch(now);
        watchJail(now);
        watchChat(now);
        cardTick(now);
        expSample(now);
        digestTick(now);
        dailyTick(now);
        healthTick(now);
        dropStatTick(now);
        premTick(now);
        verTick(now);
    }

    // ⭐ บัฟ Premium ใกล้หมด / หมดแล้ว
    const Prem = { at: 0, had: false, gone: 0 };
    function premTick(now) {
        if (!State.opt.premWarn || now - Prem.at < 30000 || !Store.char) return;
        Prem.at = now;
        const b = parseBuff();
        const key = 'at_prem_warn@' + Store.char;
        if (!b.active) {
            if (Prem.had && ++Prem.gone >= 2) {      // หายไป 2 รอบติด (กันไอคอนกระพริบ)
                Prem.had = false; Prem.gone = 0;
                try { lsDel(key); } catch (e) { /* ignore */ }
                raiseAlert('premium', { title: '⭐ บัฟ Premium หมดแล้ว', desc: `**${charLabel()}** — บัฟ Premium หมดแล้ว`, color: 0xf59e0b, ping: true, sound: 'beep', toast: '⭐ บัฟ Premium หมดแล้ว' });
            }
            return;
        }
        Prem.had = true; Prem.gone = 0;
        const mh = /(\d+)\s*ชม/.exec(b.text); if (!mh) return;
        const h = +mh[1];
        if (h > State.opt.premHrs) { try { lsDel(key); } catch (e) { /* ignore */ } return; }
        try { if (localStorage.getItem(key)) return; lsSet(key, String(now)); } catch (e) { return; }
        raiseAlert('premium', { title: '⭐ บัฟ Premium ใกล้หมด', desc: `**${charLabel()}** — บัฟ Premium เหลือ **${b.text}** (ตั้งเตือนไว้ ≤ ${State.opt.premHrs} ชม.)`, color: 0xfacc15, ping: true, sound: 'beep', thumb: b.icon || '', toast: `⭐ บัฟ Premium เหลือ ${b.text}` });
    }

    // 🆕 เกมอัปเดตเวอร์ชัน (/version.json) → แจ้งเตือน + ตรวจสุขภาพสคริปต์
    const Ver = { at: 0, busy: false };
    function verTick(now) {
        if (!State.opt.verWatch || Ver.busy || now - Ver.at < 300000) return;
        Ver.at = now; Ver.busy = true;
        fetch(`${CONFIG.PING_URL}?v=${now}`, { cache: 'no-store', credentials: 'omit' }).then((r) => (r.ok ? r.text() : '')).then((t) => {
            const sig = String(t || '').trim().slice(0, 300); if (!sig) return;
            let old = ''; try { old = localStorage.getItem('at_game_ver') || ''; lsSet('at_game_ver', sig); } catch (e) { /* ignore */ }
            if (!old || old === sig) return;
            Log.warn('VER', `เกมอัปเดตเวอร์ชัน: ${old.slice(0, 80)} → ${sig.slice(0, 80)}`);
            raiseAlert('gamever', { title: '🆕 เกมอัปเดตเวอร์ชันใหม่', desc: `**${charLabel()}** — เวอร์ชันเกมเปลี่ยน\n> ${old.slice(0, 120)}\n> → ${sig.slice(0, 120)}\nสคริปต์จะตรวจสุขภาพให้ ถ้ามีปัญหาจะแจ้ง (หัวข้อ 🩺)`, color: 0x60a5fa, ping: false, sound: 'beep', toast: '🆕 เกมอัปเดตเวอร์ชันใหม่ — กำลังตรวจสุขภาพสคริปต์', once: 'gamever:' + sig.slice(0, 60), onceMs: 3600000 });
            setTimeout(() => {
                try {
                    healthRun(['hud', 'api']);
                    const bad = HEALTH_CHECKS.filter((c) => (c.g === 'hud' || c.g === 'api') && !c.soft && Health.res[c.id] && !Health.res[c.id].ok);
                    Log[bad.length ? 'warn' : 'ok']('VER', bad.length ? 'หลังเกมอัปเดต ตรวจไม่ผ่าน: ' + bad.map((c) => c.label).join(', ') : 'หลังเกมอัปเดต ตรวจสุขภาพผ่าน (ส่วนหน้าจอหลัก/ข้อมูลเกม) · ตรวจละเอียดได้ที่ Config ▸ 🩺');
                    if (bad.length) sendDiscord('health', { title: '🩺 หลังเกมอัปเดต สคริปต์หาบางส่วนไม่เจอ', description: `**${charLabel()}**`, color: 0xfbbf24, fields: bad.map((c) => ({ name: `❌ ${c.label}`, value: c.feat, inline: false })).slice(0, 10) }, {});
                    renderHealth();
                } catch (e) { /* ignore */ }
            }, 20000);
        }).catch(() => {}).finally(() => { Ver.busy = false; });
    }

    // 🔄 รีเฟรชหน้าเว็บเองเมื่อเกมค้าง/หลุดนาน
    const RELOAD_LOG = 'at_reload_log', RELOAD_PEND = 'at_reload_pending';
    function reloadCheck(now, crashOn) {
        if (!State.opt.autoReload) { Watch.crashSince = 0; return; }
        if (crashOn) { if (!Watch.crashSince) Watch.crashSince = now; } else Watch.crashSince = 0;
        const since = crashOn ? Watch.crashSince : (Watch.lost ? Watch.goneSince : 0);
        if (!Watch.reloadJit) Watch.reloadJit = Math.floor(Math.random() * 45000);      // หลายจอ: ไม่รีโหลดพร้อมกันทุกจอ
        if (!since || now - since < Math.max(1, +State.opt.reloadMin || 3) * 60000 + Watch.reloadJit) return;
        const why = crashOn ? 'เกมแสดงหน้าจอ crash' : 'หลุดการเชื่อมต่อ';
        if (State.opt.newDry) { if (now - (Watch.reloadDryAt || 0) > 300000) { Watch.reloadDryAt = now; Log.info('RELOAD', `[ทดลอง] ${why} นาน ${fmtTown(now - since)} — จะรีโหลดหน้าเว็บ (ปิดโหมดทดลองเพื่อให้ทำจริง)`); } return; }
        let logA = []; try { logA = (JSON.parse(localStorage.getItem(RELOAD_LOG) || '[]') || []).filter((t) => now - t < 1800000); } catch (e) { /* ignore */ }
        if (logA.length >= 3) { if (now - (Watch.reloadCapAt || 0) > 600000) { Watch.reloadCapAt = now; Log.warn('RELOAD', 'รีโหลดครบ 3 ครั้งใน 30 นาทีแล้ว — หยุดรีโหลดอัตโนมัติ'); sendDiscord('server', { title: '🔄 รีโหลดอัตโนมัติครบโควตาแล้ว', description: `**${charLabel()}** — รีโหลด 3 ครั้งใน 30 นาทีแล้วยังไม่หาย ต้องเข้าไปดูเอง`, color: 0xef4444 }, { ping: true }); } return; }
        logA.push(now);
        try { lsSet(RELOAD_LOG, JSON.stringify(logA)); lsSet(RELOAD_PEND, JSON.stringify({ at: now, why, name: charLabel() })); } catch (e) { /* ignore */ }
        Log.warn('RELOAD', `${why} นาน ${fmtTown(now - since)} → รีโหลดหน้าเว็บ (ครั้งที่ ${logA.length}/3 ใน 30 นาที)`);
        sendDiscord('server', { title: '🔄 รีโหลดหน้าเว็บอัตโนมัติ', description: `**${charLabel()}** — ${why} นาน ${fmtTown(now - since)}`, color: 0xf59e0b }, { ping: false, once: 'reload', onceMs: 180000 });
        try { profitSave(true); Log.save(); } catch (e) { /* ignore */ }
        Watch.crashSince = 0; Watch.goneSince = 0;
        setTimeout(() => location.reload(), 2500);
    }

    function sheetExtras() {
        const cl = curLedger() || emptyLedger();
        const t = profitTotals(cl);
        const ping = Ping.summary && Ping.summary.ms;
        return {
            zPerHour: t.perHour === null ? '' : Math.round(t.perHour),
            killsPerHour: t.killsPerHour === null ? '' : Math.round(t.killsPerHour),
            farmMinutes: Math.round(cl.farmMs / 60000),
            pingMs: typeof ping === 'number' ? ping : '',
        };
    }

    // ---- สำรอง/กู้คืนการตั้งค่าและสถิติ ----
    // ข้อมูลชั่วคราว/เฉพาะเครื่อง ไม่เอาไปสำรอง (แคช, Logs, id ข้อความกล่องสถานะ Discord, ข้อมูลที่แท็บอื่นแชร์กัน)
    const BACKUP_SKIP = /^(at_itemdb_v2|at_logs_v1|at_status_msg|at_boss_msg|at_r3_boot|at_peer:.*|at_dps_last_.*)$/;
    // ส่งออกเฉพาะการตั้งค่า (ย้ายไป Chrome/โปรไฟล์อื่น): ไม่เอา Profit / สถิติ / แถบเวลา / ข้อมูลเดินติด ฯลฯ ที่เป็นของเครื่องเดิม
    const SETTINGS_SKIP = /^(at_profit_v1_.*|at_stats_v1.*|at_tl:.*|at_town.*|at_walk_blk|at_walk_cal.*|at_inv_seen.*|at_junk_stats.*|at_dev_maps|at_gfx_backup|at_reload_.*|at_share_off|at_prem_warn.*|at_daily_last.*)$/;
    function exportBackup(settingsOnly) {
        const out = {};
        try {
            for (let i = 0; i < localStorage.length; i++) {
                const k = localStorage.key(i);
                if (/^at_/.test(k) && !BACKUP_SKIP.test(k) && !(settingsOnly && SETTINGS_SKIP.test(k))) out[k] = localStorage.getItem(k);
            }
        } catch (e) { /* ignore */ }
        const blob = new Blob([JSON.stringify({ app: 'aetherack', version: VERSION, at: Date.now(), data: out }, null, 1)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `aetherack-${settingsOnly ? 'settings' : 'backup'}-${new Date().toISOString().slice(0, 10)}.json`;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
        showToast(`💾 ${settingsOnly ? 'ส่งออกการตั้งค่า' : 'สำรองข้อมูล'}แล้ว (${Object.keys(out).length} รายการ) · ไฟล์มี Webhook/URL ของคุณ เก็บให้ปลอดภัย`, 'ok');
        Log.ok('BACKUP', `ส่งออก${settingsOnly ? 'การตั้งค่า' : ''} ${Object.keys(out).length} รายการ`);
    }

    function importBackup(file) {
        if (!file) return;
        const rd = new FileReader();
        rd.onload = () => {
            try {
                const j = JSON.parse(String(rd.result));
                const d = j && j.data;
                if (!d || typeof d !== 'object') throw new Error('รูปแบบไฟล์ไม่ถูกต้อง');
                const keys = Object.keys(d).filter((k) => /^at_\S+$/.test(k) && !BACKUP_SKIP.test(k) && typeof d[k] === 'string');      // คีย์โปรไฟล์มี @ชื่อตัวละคร (ไทยได้) จึงต้องไม่จำกัดแค่ \w
                if (!keys.length) throw new Error('ไม่พบข้อมูลที่กู้คืนได้');
                const cnt = {};
                for (const k of keys) { const m = /^(at_[^@]+)@(.+)$/.exec(k); if (m && PROFILE_KEYS.has(m[1])) cnt[m[2]] = (cnt[m[2]] || 0) + 1; }
                const chars = Object.keys(cnt).sort((a, b) => cnt[b] - cnt[a]);
                let zones = 0; try { zones = Object.keys(JSON.parse(d.at_fly_zones || '{}') || {}).length; } catch (e) { /* ignore */ }
                let spots = 0; try { spots = Object.keys(JSON.parse(d.at_fly_spots || '{}') || {}).length; } catch (e) { /* ignore */ }
                const hasUrl = keys.some((k) => /^at_url(@|$)/.test(k) && d[k]), hasHook = keys.some((k) => /^at_(webhook|dc_url)(@|$)/.test(k) && d[k]);
                const sum = `ไฟล์: ${file.name}\n• ${keys.length} รายการ\n• ตัวละคร ${chars.length}: ${chars.join(', ') || '(ไม่มี)'}\n• โซนฟาร์ม ${zones} แมพ · จุดยืนตี ${spots} แมพ\n• Web App URL: ${hasUrl ? 'มี' : 'ไม่มี'} · Webhook: ${hasHook ? 'มี' : 'ไม่มี'}`;
                if (!window.confirm(`${sum}\n\nกู้คืน? ข้อมูลที่ซ้ำกันจะถูกแทนที่ แล้วหน้าเว็บจะรีโหลด`)) return;
                const put = {};
                for (const k of keys) put[k] = d[k];
                // ตัวละครในเบราว์เซอร์นี้ที่ไม่มีในไฟล์ (เช่น Chrome ใหม่ใช้ตัวคนละชื่อ) → เลือกว่าจะใช้การตั้งค่าของตัวไหนในไฟล์
                const here = new Set(Store.char ? [Store.char] : []);
                try { for (let i = 0; i < localStorage.length; i++) { const m = /^(at_[^@]+)@(.+)$/.exec(localStorage.key(i) || ''); if (m && PROFILE_KEYS.has(m[1])) here.add(m[2]); } } catch (e) { /* ignore */ }
                for (const n of chars) here.delete(n);
                let src = '';
                if (chars.length && here.size) {
                    const list = chars.map((n, i) => `${i + 1}) ${n} (${cnt[n]} ค่า)`).join('\n');
                    const ans = window.prompt(`ตัวละครในเบราว์เซอร์นี้ที่ไม่มีในไฟล์:\n${[...here].join(', ')}\n\nจะใช้การตั้งค่าของตัวไหนในไฟล์ให้ตัวเหล่านี้? พิมพ์เลข (ยกเลิก = ไม่คัดลอก)\n${list}`, '1');
                    src = chars[Number(ans) - 1] || '';
                    if (src) for (const to of here) for (const pk of PROFILE_KEYS) { if (/pos/.test(pk)) continue; const v = d[`${pk}@${src}`]; if (typeof v === 'string') put[`${pk}@${to}`] = v; }
                }
                for (const k of Object.keys(put)) { try { lsSet(k, put[k]); } catch (er) { /* ignore */ } }      // เขียนตรง ไม่ผ่าน Store.set (ไม่ให้คีย์ถูกต่อชื่อโปรไฟล์ซ้ำ)
                try { localStorage.setItem('aetherack_import', JSON.stringify({ at: Date.now(), data: put, src, to: src ? [...here] : [], chars, zones })); } catch (er) { /* ignore */ }      // เขียนซ้ำอีกรอบตอนเปิดใหม่
                Log.ok('BACKUP', `กำลังนำเข้า ${Object.keys(put).length} รายการ — รีโหลด`); Log.save();
                const all = window.confirm('นำเข้าแล้ว ✅\n\nรีโหลด "ทุกจอ" ในเบราว์เซอร์นี้ด้วยไหม? (จออื่นจะได้ใช้การตั้งค่าใหม่)\nOK = ทุกจอ · Cancel = เฉพาะจอนี้');
                if (all) { try { GM_setValue('reload_all', { at: Date.now(), src: TAB_ID, v: VERSION }); } catch (er) { /* ignore */ } }
                showToast('✅ กู้คืนข้อมูลแล้ว กำลังรีโหลด…', 'ok');
                setTimeout(() => location.reload(), 800);
            } catch (e) {
                showToast('❌ นำเข้าไม่สำเร็จ: ' + (e && e.message), 'err');
                Log.err('BACKUP', 'นำเข้าไม่สำเร็จ: ' + (e && e.message));
            }
        };
        rd.onerror = () => { showToast('❌ อ่านไฟล์ไม่ได้', 'err'); Log.err('BACKUP', 'อ่านไฟล์ไม่ได้'); };
        rd.readAsText(file);
    }

    // ---------------------------------------------------------------
    // v5.4.0 — สถิติการทิ้งขยะ · สรุปประจำวัน · ตรวจสุขภาพสคริปต์
    // ---------------------------------------------------------------
    const JunkStat = {
        KEY: 'at_junk_stats',
        dayKey(t) { const d = new Date(t || Date.now()); return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`; },
        empty() { return { runs: 0, items: 0, qty: 0, pct: 0, by: {} }; },
        load() {
            const d = Store.getJSON(JunkStat.KEY);
            return d && d.days && d.total ? d : { days: {}, total: JunkStat.empty() };
        },
        add(t, done, pct) {
            t.runs += 1; t.items += done.length; t.pct += pct;
            for (const x of done) { t.qty += x.qty; t.by[x.name] = (t.by[x.name] || 0) + x.qty; }
        },
        // pctA/pctB = น้ำหนักก่อน/หลังทิ้ง (%) — อ่านไม่ได้ = null
        rec(done, pctA, pctB) {
            if (!done || !done.length) return;
            const s = JunkStat.load();
            const pct = pctA !== null && pctB !== null && pctA > pctB ? pctA - pctB : 0;
            const k = JunkStat.dayKey();
            JunkStat.add(s.days[k] || (s.days[k] = JunkStat.empty()), done, pct);
            JunkStat.add(s.total, done, pct);
            const keys = Object.keys(s.days).sort();
            while (keys.length > 35) delete s.days[keys.shift()];
            const top = (o) => Object.fromEntries(Object.entries(o).sort((a, b) => b[1] - a[1]).slice(0, 60));
            s.total.by = top(s.total.by);
            for (const d of Object.values(s.days)) d.by = top(d.by);
            Store.set(JunkStat.KEY, JSON.stringify(s));
        },
        // คืนค่ารวมของช่วง: 'today' | 'week' | 'all'
        sum(range) {
            const s = JunkStat.load();
            if (range === 'all') return s.total;
            const out = JunkStat.empty();
            const now = Date.now();
            const keys = range === 'today' ? [JunkStat.dayKey(now)] : Array.from({ length: 7 }, (_, i) => JunkStat.dayKey(now - i * 86400000));
            for (const k of keys) {
                const d = s.days[k];
                if (!d) continue;
                out.runs += d.runs; out.items += d.items; out.qty += d.qty; out.pct += d.pct;
                for (const [n, q] of Object.entries(d.by)) out.by[n] = (out.by[n] || 0) + q;
            }
            return out;
        },
        top(by, n) { return Object.entries(by).sort((a, b) => b[1] - a[1]).slice(0, n); },
    };

    function renderJunkStat() {
        const box = document.getElementById('at-junk-stat');
        if (!box) return;
        box.textContent = '';
        const rows = [['วันนี้', 'today'], ['7 วันล่าสุด', 'week'], ['รวมทั้งหมด', 'all']];
        for (const [label, rg] of rows) {
            const s = JunkStat.sum(rg);
            const line = h('div', 'ac-l');
            line.textContent = s.runs
                ? `${label}: ${fmt(s.runs)} รอบ · ${fmt(s.items)} รายการ · ${fmt(s.qty)} ชิ้น · น้ำหนักลด ≈ ${s.pct.toFixed(1)}%`
                : `${label}: ยังไม่เคยทิ้ง`;
            box.appendChild(line);
        }
        const all = JunkStat.sum('all');
        const top = JunkStat.top(all.by, 5);
        if (top.length) box.appendChild(h('div', 'ac-l', 'ทิ้งบ่อยสุด: ' + top.map(([n, q]) => `${n} ×${fmt(q)}`).join(' · ')));
        box.appendChild(h('div', 'ac-l', 'นับเฉพาะการทิ้งจริง (โหมดทดลองไม่นับ) · เก็บแยกต่อตัวละคร'));
    }

    // ---- สรุปประจำวันส่ง Discord ----
    const Daily = { chkAt: 0, sentAt: 0 };
    function dayStats(dayIdx) {
        let z = 0, k = 0, bx = 0, jx = 0;
        const maps = [];
        for (const [name, m] of Object.entries(Stats.data.maps || {})) {
            let mz = 0, mk = 0;
            for (const [key, a] of Object.entries(m.h || {})) {
                if (Math.floor(+key / 24) !== dayIdx) continue;
                mz += a[0] || 0; mk += a[1] || 0; bx += a[2] || 0; jx += a[3] || 0;
            }
            if (mz || mk) maps.push({ name, z: mz, k: mk });
            z += mz; k += mk;
        }
        maps.sort((a, b) => b.z - a.z || b.k - a.k);
        return { z, k, bx, jx, maps };
    }
    function dailyEmbed() {
        const day = dayStats(Math.floor(Stats.hourKey(Date.now()) / 24));
        const raw = (typeof collectSnapshotData === 'function' && collectSnapshotData().raw) || {};
        const js = JunkStat.sum('today');
        const fields = [
            { name: '💰 Zeny วัตถุดิบ', value: `+${fmt(day.z)} z`, inline: true },
            { name: '⚔️ ฆ่ามอน', value: `${fmt(day.k)} ตัว`, inline: true },
            { name: '✨ EXP', value: `Base +${fmt(day.bx)} · Job +${fmt(day.jx)}`, inline: true },
        ];
        if (day.maps.length) fields.push({ name: '🗺️ แมพที่ฟาร์มวันนี้', value: day.maps.slice(0, 5).map((m) => `${m.name} — ${fmt(m.z)} z · ${fmt(m.k)} ตัว`).join('\n'), inline: false });
        fields.push({
            name: '🗑️ ทิ้งขยะวันนี้',
            value: js.runs ? `${fmt(js.runs)} รอบ · ${fmt(js.items)} รายการ · ${fmt(js.qty)} ชิ้น (น้ำหนักลด ≈ ${js.pct.toFixed(1)}%)` + (JunkStat.top(js.by, 3).length ? '\n' + JunkStat.top(js.by, 3).map(([n, q]) => `${n} ×${fmt(q)}`).join(' · ') : '') : 'ไม่ได้ทิ้ง',
            inline: false,
        });
        return {
            title: '📅 สรุปประจำวัน',
            description: `**${charLabel()}** · Base ${raw.baseLv || '—'} / Job ${raw.jobLv || '—'} · ${JunkStat.dayKey()}`,
            color: 0x7cc4ff,
            fields,
        };
    }
    function dailySend(manual) {
        if (!Stats.charName) { if (manual) showToast('ยังไม่รู้ชื่อตัวละคร', 'warn'); return; }
        if (manual && !REGEX.discordUrl.test(State.discordUrl)) { showToast('ยังไม่ได้ตั้ง Webhook Discord', 'warn'); return; }
        const today = JunkStat.dayKey();
        Daily.sentAt = Date.now();
        sendDiscord('daily', dailyEmbed(), {
            force: !!manual,
            onDone: (ok) => {
                if (ok && !manual) Store.set('at_daily_last', today);
                if (manual) showToast(ok ? '📅 ส่งสรุปวันนี้แล้ว' : '❌ ส่งสรุปไม่สำเร็จ ดูใน Logs', ok ? 'ok' : 'err');
            },
        });
        Log.info('DAILY', manual ? 'ส่งสรุปประจำวัน (กดเอง)' : 'ส่งสรุปประจำวันอัตโนมัติ');
    }
    function dailyTick(now) {
        if (!State.opt.daily || !State.isGameReady || !Stats.charName || now - Daily.chkAt < 30000) return;
        Daily.chkAt = now;
        if (!dcReady('daily') || now - Daily.sentAt < 120000) return;
        if (new Date(now).getHours() < State.opt.dailyHour) return;
        if (Store.get('at_daily_last', '') === JunkStat.dayKey(now)) return;
        const day = dayStats(Math.floor(Stats.hourKey(now) / 24));
        if (!day.z && !day.k && !day.bx) return;      // วันนี้ยังไม่มีข้อมูลฟาร์ม
        dailySend(false);
    }

    // ---- ตรวจสุขภาพสคริปต์: เช็คว่าส่วนของเกมที่สคริปต์พึ่งพายังอยู่ครบ (ใช้ดูหลังเกมอัปเดต) ----
    const Health = { res: {}, at: 0, bad: {}, alertSig: '', alertAt: 0, running: false, passAt: 0 };
    const hq = (sel) => { try { return document.querySelector(sel); } catch (e) { return null; } };
    const hasDropBtn = () => [...document.querySelectorAll('.inventory .inv-actions button, .inventory .inv-detail button')].some((b) => /ทิ้ง/.test(b.textContent));
    // g: hud = มองเห็นตลอด · inv = เฉพาะตอนเปิดกระเป๋า · sel = ต้องเลือกไอเทมก่อน · api = ข้อมูลจากเซิร์ฟเวอร์เกม
    // soft = ไม่มีก็ไม่ผิดปกติเสมอไป (ไม่เตือนอัตโนมัติ)
    const HEALTH_CHECKS = [
        { id: 'name', g: 'hud', label: 'ชื่อตัวละคร', feat: 'โปรไฟล์ / ทุกฟีเจอร์', sel: '.hud-name' },
        { id: 'level', g: 'hud', label: 'เลเวล', feat: 'Sheets / Profit / EXP', sel: '.hud-levels' },
        { id: 'map', g: 'hud', label: 'ชื่อแมพ', feat: 'Profit / สถิติแยกแมพ / กล่องสถานะ', sel: '.minimap-name' },
        { id: 'channel', g: 'hud', label: 'ช่อง (CH)', feat: 'กล่องสถานะ Discord', sel: '.minimap-ch' },
        { id: 'auto', g: 'hud', label: 'ปุ่มออโต้ (Z)', feat: 'Auto-Z', sel: '.auto-toggle', soft: true },
        { id: 'feed', g: 'hud', label: 'ฟีดไอเทมที่ได้', feat: 'Profit / ดรอป', sel: '.gain-feed', soft: true },
        { id: 'weight', g: 'inv', label: 'น้ำหนักกระเป๋า', feat: 'ทิ้งขยะ / เตือนกระเป๋าเต็ม', sel: '.inv-weight .bar-num' },
        { id: 'zeny', g: 'inv', label: 'Zeny', feat: 'Sheets', sel: '.inv-zeny b' },
        { id: 'slots', g: 'inv', label: 'ช่องเก็บของ', feat: 'เตือนช่องเต็ม / สีช่อง', sel: '.inv-count' },
        { id: 'grid', g: 'inv', label: 'ตารางไอเทม', feat: 'ทิ้งขยะ / สแกนกระเป๋า', sel: '.inventory .inv-grid' },
        { id: 'slot', g: 'inv', label: 'ช่องไอเทม', feat: 'ทิ้งขยะ / สแกนกระเป๋า', sel: '.inventory .inv-grid .inv-slot' },
        { id: 'tabs', g: 'inv', label: 'แท็บหมวดในกระเป๋า', feat: 'ทิ้งขยะ', sel: '.inventory .inv-tabs button' },
        { id: 'sort', g: 'inv', label: 'ปุ่มจัดเรียง', feat: 'ทิ้งขยะ', sel: '.inventory .inv-sort' },
        { id: 'close', g: 'inv', label: 'ปุ่มปิดกระเป๋า', feat: 'ทิ้งขยะ / สแกน', sel: '.inventory .inv-close' },
        { id: 'detail', g: 'sel', label: 'ชื่อไอเทมที่เลือก', feat: 'ทิ้งขยะ (ตรวจชื่อก่อนทิ้ง)', sel: '.inventory .inv-detail-name' },
        { id: 'drop', g: 'sel', label: 'ปุ่ม "ทิ้ง"', feat: 'ทิ้งขยะ', sel: '.inventory .inv-actions button (ข้อความ "ทิ้ง")', fn: hasDropBtn },
        { id: 'wiki', g: 'api', label: 'ข้อมูล Wiki (/wiki-data)', feat: 'Wiki / ทิ้งขยะ / ราคา', fn: () => !!(Info.data && (Info.data.items || []).length) },
        { id: 'icons', g: 'api', label: 'รายการไอคอนไอเทม', feat: 'ไอคอนในทิ้งขยะ / Wiki', fn: () => Object.keys(Icons.items || {}).length > 0 },
        // ----- v5.19.1: ส่วนที่ระบบเดิน/วาร์ป/ซื้อของ/อัพสเตตัส ใช้ -----
        { id: 'hudStatus', g: 'hud', label: 'กรอบสถานะตัวละคร (HUD)', feat: 'อัพสเตตัส (ปุ่มแต้มสถานะ) / HP·SP', sel: '.hud-status' },
        { id: 'coord', g: 'hud', label: 'พิกัดตัวละครบนมินิแมพ (x, z)', feat: 'เดิน / วาร์ป / โซนฟาร์ม / Fly Wing หาโซน', sel: '.minimap (ตัวเลข "x, z")', fn: () => !!Dev.minimapCell() },
        { id: 'chBtn', g: 'hud', label: 'ปุ่มเปลี่ยน CH', feat: 'ย้าย CH (คนเต็ม / ไม่มีความเคลื่อนไหว)', sel: 'button.minimap-ch', soft: true },
        { id: 'hotbar', g: 'hud', label: 'แถบด่วน (ไอเทม)', feat: 'Fly Wing / Butterfly Wing / ของใช้ใกล้หมด', sel: '.hot-slot', soft: true },
        { id: 'mmCanvas', g: 'hud', label: 'มินิแมพของเกม (canvas)', feat: '🗺️ โซน / เส้นทางบนมินิแมพ', sel: '.minimap-stage canvas', soft: true },
        { id: 'zoomCtl', g: 'hud', label: 'ปุ่มซูมข้างมินิแมพ', feat: 'ระบบเดิน (ปรับซูม)', sel: '.minimap-zoom', soft: true },
        { id: 'camCfg', g: 'api', label: 'การตั้งค่ากล้องเกม (webgame.camera)', feat: 'ระบบเดินด้วยการคลิก (ขนาดช่อง / มุมเอียง)', soft: true, fn: () => { try { return !!JSON.parse(localStorage.getItem('webgame.camera') || 'null'); } catch (e) { return false; } } },
        { id: 'chatStore', g: 'api', label: 'ข้อความแชทระบบ (นับฆ่ามอน / EXP)', feat: 'Profit ฆ่ามอน / EXP / บอทค้าง / ย้าย CH', soft: true, fn: () => { try { return !!localStorage.getItem('webgame.chat.' + (Profit.charName || readField(SELECTORS.charName, 'name'))); } catch (e) { return false; } } },
        { id: 'mapFile', g: 'api', label: 'ไฟล์แมพ + ช่องชน (กำแพง)', feat: 'หาทางเดิน / โซนฟาร์ม / หา NPC', soft: true, fn: () => { const t = Dev.D.tm; if (!t) return { ok: false, note: Dev.D.tmState === 'loading' ? 'กำลังโหลด…' : 'ไม่พบไฟล์แมพของแมพนี้' }; return t.col ? { ok: true, note: `${t.id} · ${t.w}×${t.h}` } : { ok: false, note: `${t.id}: ไม่พบข้อมูลช่องชน` }; } },
        { id: 'gameVer', g: 'api', label: 'ไฟล์เวอร์ชันเกม (/version.json)', feat: 'เตือนเกมอัปเดต / วัด Ping', soft: true, fn: () => { try { return !!localStorage.getItem('at_game_ver'); } catch (e) { return false; } } },
        // ----- การตั้งค่าของระบบที่เปิดไว้ (ตรวจเฉพาะระบบที่เปิด) -----
        { id: 'cfgSheets', g: 'cfg', label: 'Google Sheets: ตั้ง Web App URL', feat: 'ซิงค์กระเป๋า / ซิงค์โซน', when: () => State.isSyncEnabled, fn: () => /^https:\/\/script\.google\.com\//.test(State.webAppUrl || '') },
        { id: 'cfgDiscord', g: 'cfg', label: 'Discord: Webhook ถูกต้อง', feat: 'แจ้งเตือนทั้งหมด', when: () => State.discordOn, fn: () => REGEX.discordUrl.test(State.discordUrl || '') },
        { id: 'cfgFlyHot', g: 'cfg', label: 'Fly Wing อยู่ในแถบด่วน', feat: '🎯 Fly Wing หาโซน / 🪽 ใช้หลังถึงแมพ', when: () => State.opt.warpZone || State.opt.warpFly, fn: () => { const sl = Dev.flySlot(); if (!sl) return { ok: false, note: 'ลาก Fly Wing จากกระเป๋าไปใส่แถบด่วน' }; const q = /x\s*([\d,]+)/i.exec((sl.querySelector('.hot-sub') || {}).textContent || ''); return { ok: true, note: q ? `เหลือ ${q[1]}` : '' }; } },
        { id: 'cfgZones', g: 'cfg', label: 'มีโซนฟาร์มของแมพล่าสุด', feat: '🎯 Fly Wing หาโซน', when: () => State.opt.warpZone, fn: () => { let f = ''; try { f = localStorage.getItem('at_warp_last@' + (Store.char || '-')) || ''; } catch (e) { /* ignore */ } if (!f) return { ok: false, note: 'ยังไม่มีแมพฟาร์มที่จำไว้' }; const n = Dev.zonesFor(f).length; return n ? { ok: true, note: `${f}: ${n} โซน` } : { ok: false, note: `${f}: ยังไม่ได้วาดโซน (🗺️ กำหนดโซนฟาร์ม)` }; } },
        { id: 'cfgWarpBack', g: 'cfg', label: 'จำแมพฟาร์มล่าสุดไว้แล้ว', feat: '↩️ กลับแมพเดิม / ▶️ กลับไปฟาร์มต่อ', when: () => State.opt.warpBack, fn: () => { let f = ''; try { f = localStorage.getItem('at_warp_last@' + (Store.char || '-')) || ''; } catch (e) { /* ignore */ } return f ? { ok: true, note: f } : { ok: false, note: 'ไปฟาร์มสักแมพก่อน' }; } },
        { id: 'cfgBw', g: 'cfg', label: 'Butterfly Wing อยู่ในแถบด่วน', feat: '🦋 / 🧴 กลับเมืองไปซื้อ', when: () => State.opt.flyRestock || State.opt.supplyRestock, fn: () => !!Dev.hotSlotOf('Butterfly Wing', 'Fly Wing') },
        { id: 'cfgFlyBuy', g: 'cfg', label: 'มี Fly Wing ในรายการซื้อของ', feat: '🦋 Fly Wing ใกล้หมด → กลับไปซื้อ', when: () => State.opt.flyRestock, fn: () => (State.opt.buy || []).some((b) => b && /^fly wing$/i.test(String(b.n || '').trim()) && +b.q > 0) },
        { id: 'cfgSupplyHot', g: 'cfg', label: 'ของใช้ในรายการซื้อของอยู่ในแถบด่วน', feat: '🧴 ของใช้ใกล้หมด → กลับไปซื้อ', when: () => State.opt.supplyRestock, fn: () => {
            const items = (State.opt.buy || []).filter((b) => b && String(b.n || '').trim() && +b.q > 0 && !/^(butterfly|fly) wing$/i.test(String(b.n).trim())).map((b) => String(b.n).trim());
            if (!items.length) return { ok: false, note: 'ยังไม่มีของใช้ในรายการ (นอกจาก Fly/Butterfly Wing)' };
            const miss = items.filter((n) => !Dev.hotSlotOf(n));
            return miss.length ? { ok: false, note: 'ไม่อยู่ในแถบด่วน: ' + miss.join(', ') } : { ok: true, note: items.join(', ') };
        } },
        { id: 'cfgShopNpc', g: 'cfg', label: 'พบ NPC ร้านค้าที่ตั้งไว้', feat: '🛒 ซื้อของอัตโนมัติ', when: () => State.opt.buyOn || State.opt.flyRestock || State.opt.supplyRestock, fn: () => {
            const nm = String(State.opt.buyNpc || 'Shopkeeper').trim();
            if (!/เมืองหลวง/.test(getMapName())) return { na: true, note: 'ตรวจได้เมื่ออยู่ในเมืองหลวง' };
            const list = Dev.npcNames(); if (!list.length) return { na: true, note: 'ยังโหลดแผนที่ไม่เสร็จ' };
            const hit = list.filter((n) => n.toLowerCase().includes(nm.toLowerCase()));
            return hit.length ? { ok: true, note: hit.join(', ') } : { ok: false, note: `ไม่พบ "${nm}" (มี: ${list.slice(0, 8).join(', ')})` };
        } },
        { id: 'cfgAutoGear', g: 'cfg', label: 'ปุ่มตั้งค่าต่อสู้อัตโนมัติ (ตั้งระยะล่า)', feat: '⭕ ปรับระยะล่าให้อยู่ในโซน', when: () => State.opt.warpZone && State.opt.zoneFit, fn: () => !!document.querySelector('.auto-gear') },
        { id: 'cfgStat', g: 'cfg', label: 'ตั้งลำดับอัพสเตตัสแล้ว', feat: '📈 อัพสเตตัสอัตโนมัติ', when: () => State.opt.statOn, fn: () => (State.opt.stat || []).some((x) => x && +x.t > 0) },
        { id: 'cfgDry', g: 'cfg', label: 'ระบบใหม่ทำงานจริง (ไม่ใช่โหมดทดลอง)', feat: '🧴 ซื้อของใช้ / 📡 ย้าย CH / 🔄 รีโหลด', soft: true, when: () => State.opt.supplyRestock || State.opt.chSwitch || State.opt.autoReload, fn: () => (State.opt.newDry ? { ok: false, note: 'ยังเปิด 🧪 โหมดทดลองอยู่ — ระบบเหล่านี้แค่บันทึก Logs ไม่ทำจริง' } : true) },
    ];
    function healthRun(groups) {
        const now = Date.now();
        for (const c of HEALTH_CHECKS) {
            if (!groups.includes(c.g)) continue;
            if (c.when) { let on = false; try { on = !!c.when(); } catch (e) { on = false; } if (!on) { Health.res[c.id] = { ok: true, na: true, note: 'ไม่ได้เปิดใช้', at: now }; continue; } }
            let ok = false, note = '', na = false;
            try {
                const r = c.fn ? c.fn() : !!hq(c.sel);
                if (r && typeof r === 'object') { na = !!r.na; ok = na || !!r.ok; note = r.note || ''; } else ok = !!r;
            } catch (e) { ok = false; note = 'ตรวจไม่ได้: ' + (e && e.message); }
            Health.res[c.id] = { ok, na, note, at: now };
        }
        Health.at = now;
    }
    function healthTick(now) {
        if (now - Health.passAt < 30000) return;
        Health.passAt = now;
        if (!State.isGameReady || Frame.dead || Frame.captcha || Health.running) return;
        const gs = Frame.invOpen ? ['hud', 'inv'] : ['hud'];
        healthRun(gs);
        for (const c of HEALTH_CHECKS) {
            if (!gs.includes(c.g) || c.soft) continue;
            Health.bad[c.id] = Health.res[c.id].ok ? 0 : (Health.bad[c.id] || 0) + 1;
        }
        const fails = HEALTH_CHECKS.filter((c) => !c.soft && (Health.bad[c.id] || 0) >= (c.g === 'hud' ? 4 : 2));
        if (!fails.length) { Health.alertSig = ''; return; }
        if (!State.opt.healthAlert) return;
        const sig = fails.map((c) => c.id).sort().join(',');
        if (sig === Health.alertSig && now - Health.alertAt < 6 * 3600000) return;
        Health.alertSig = sig; Health.alertAt = now;
        Log.err('HEALTH', 'ไม่พบส่วนของเกมที่สคริปต์ใช้: ' + fails.map((c) => c.label).join(', ') + ' — เกมอาจอัปเดต');
        showToast('🩺 ตรวจพบส่วนของเกมที่สคริปต์หาไม่เจอ (เกมอาจอัปเดต) ดูที่ Config ▸ ตรวจสุขภาพ', 'warn');
        sendDiscord('health', {
            title: '🩺 สคริปต์หาส่วนของเกมไม่เจอ',
            description: `**${charLabel()}** · เกมอาจอัปเดต ฟีเจอร์ต่อไปนี้อาจทำงานไม่ถูก`,
            color: 0xfbbf24,
            fields: fails.map((c) => ({ name: `❌ ${c.label}`, value: `${c.feat}\n${c.sel || ''}`.slice(0, 300), inline: false })).slice(0, 10),
        }, {});
        if (document.getElementById('at-health-list')) renderHealth();
    }
    async function healthDeep() {
        if (Health.running) return;
        if (Junk.running || InvLock.owner) { showToast('กำลังใช้กระเป๋าอยู่ ลองใหม่อีกครั้ง', 'warn'); return; }
        Health.running = true; InvLock.owner = 'health';
        renderHealth();
        let opened = false;
        try {
            await infoLoad().catch(() => {});
            try { Dev.update(); } catch (e) { /* ignore */ }      // โหลดไฟล์แมพของแมพนี้ (ใช้ตรวจช่องชน / NPC)
            await waitFor(() => Dev.D.tmState !== 'loading', 4000);
            healthRun(['cfg']);
            if (!isVisible(SELECTORS.weight)) {
                pressKey('i', 'KeyI', 73);
                opened = true;
                if (!(await waitFor(() => isVisible(SELECTORS.weight), 2500))) {
                    healthRun(['hud', 'api']);
                    for (const c of HEALTH_CHECKS) if (c.g === 'inv' || c.g === 'sel') delete Health.res[c.id];
                    showToast('เปิดกระเป๋าไม่สำเร็จ — ตรวจได้เฉพาะส่วนที่มองเห็นอยู่', 'warn');
                    return;
                }
            }
            await sleep(600);
            healthRun(['hud', 'inv', 'api']);
            const first = invSlots().findIndex((e) => e.classList.contains('filled'));
            if (first >= 0) {
                invSlots()[first].click();
                await waitFor(() => { const e = invSlots()[first]; return !!e && e.classList.contains('selected') && hq('.inventory .inv-detail-name'); }, 1500);
                healthRun(['sel']);
                const empty = invSlots().find((e) => !e.classList.contains('filled'));
                if (empty) { empty.click(); await sleep(250); }
            } else {
                for (const c of HEALTH_CHECKS) if (c.g === 'sel') delete Health.res[c.id];
            }
        } finally {
            try {
                await dismissConfirm();
                if (opened && isVisible(SELECTORS.weight)) {
                    pressKey('i', 'KeyI', 73);
                    await sleep(450);
                    if (isVisible(SELECTORS.weight)) { const c = hq('.inventory .inv-close'); if (c) c.click(); }
                }
            } catch (e) { /* ignore */ }
            Health.running = false;
            if (InvLock.owner === 'health') InvLock.owner = '';
            const bad = HEALTH_CHECKS.filter((c) => Health.res[c.id] && !Health.res[c.id].ok && !c.soft);
            Log[bad.length ? 'warn' : 'ok']('HEALTH', bad.length ? 'ตรวจแล้ว ไม่ผ่าน: ' + bad.map((c) => c.label).join(', ') : 'ตรวจสุขภาพสคริปต์แล้ว ผ่านทั้งหมด');
            showToast(bad.length ? `🩺 พบปัญหา ${bad.length} จุด` : '🩺 ตรวจแล้ว ผ่านทั้งหมด', bad.length ? 'warn' : 'ok');
            renderHealth();
        }
    }
    function renderHealth() {
        const box = document.getElementById('at-health-list');
        if (!box) return;
        box.textContent = '';
        const checked = HEALTH_CHECKS.filter((c) => Health.res[c.id]);
        const bad = checked.filter((c) => !Health.res[c.id].ok && !Health.res[c.id].na && !c.soft);
        const sum = h('div', 'ac-l');
        sum.textContent = Health.running ? '⏳ กำลังตรวจ…' : !checked.length ? 'ยังไม่ได้ตรวจ — กดปุ่มด้านบน' : `ตรวจล่าสุด ${new Date(Health.at).toLocaleTimeString('th-TH')} · ผ่าน ${checked.length - bad.length}/${checked.length}${bad.length ? ` · ❌ ${bad.length}` : ' ✅'}`;
        box.appendChild(sum);
        const groups = [['hud', 'หน้าจอหลักของเกม'], ['inv', 'กระเป๋า'], ['sel', 'เลือกไอเทมในกระเป๋า'], ['api', 'ข้อมูลจากเซิร์ฟเวอร์เกม'], ['cfg', 'การตั้งค่าของระบบที่เปิดไว้']];
        for (const [g, title] of groups) {
            box.appendChild(h('div', 'ac-l', title));
            for (const c of HEALTH_CHECKS.filter((x) => x.g === g)) {
                const r = Health.res[c.id];
                const mark = !r ? '⚪' : r.na ? '➖' : r.ok ? '✅' : c.soft ? '🟡' : '❌';
                const row = h('div', 'ah-row');
                row.appendChild(h('span', 'ah-mark', mark));
                const txt = h('span', 'ah-txt', c.label);
                txt.appendChild(h('small', '', ' · ' + c.feat));
                row.appendChild(txt);
                if (r && r.note) row.appendChild(h('small', 'ah-note', ' — ' + r.note));
                if (r && !r.ok && c.sel) row.appendChild(h('code', 'ah-sel', c.sel));
                row.title = !r ? 'ยังไม่ได้ตรวจ (บางข้อตรวจเฉพาะตอนเปิดกระเป๋า / กด "ตรวจตอนนี้")' : r.na ? 'ข้ามข้อนี้ (ไม่ได้เปิดใช้ระบบนี้ / ยังตรวจไม่ได้ในตอนนี้)' : r.ok ? 'พบ' : c.soft ? 'ไม่พบ — อาจเป็นเรื่องปกติ (ขึ้นกับว่าอยู่ในแมพ/สถานะไหน)' : 'ไม่พบ — เกมอาจเปลี่ยนโครงสร้างหน้า';
                box.appendChild(row);
            }
        }
    }

    // ---------------------------------------------------------------
    // v5.5.0 — อ่านการ์ดข้อมูลไอเทม (stat / option) · แนบ stat ใน Discord · ไม่ทิ้งไอเทมที่มีออฟที่ต้องการ
    // ---------------------------------------------------------------
    // รายการ option ที่มีในเกม (ช่วงค่าจากภาพหน้าจอ: ถ้าค่ามีหลายช่วงใช้ช่วงกว้างสุด) · pct = ค่าเป็น %
    const OPT_DEFS = [
        { k: 'Max HP', lo: 30, hi: 75 }, { k: 'DEF', lo: 5, hi: 12 }, { k: 'MDEF', lo: 5, hi: 12 },
        { k: 'ความเร็วเดิน', pct: 1, lo: 2, hi: 5 }, { k: 'พลังฮีล', pct: 1, lo: 3, hi: 8 }, { k: 'ลดดาเมจที่ได้รับ', pct: 1, lo: 3, hi: 8 }, { k: 'โอกาสบล็อก', pct: 1, lo: 2, hi: 5 },
        { k: 'STR', lo: 2, hi: 10 }, { k: 'INT', lo: 2, hi: 10 }, { k: 'DEX', lo: 2, hi: 10 }, { k: 'AGI', lo: 2, hi: 10 }, { k: 'VIT', lo: 2, hi: 8 }, { k: 'LUK', lo: 2, hi: 8 },
        { k: 'ATK', lo: 6, hi: 16 }, { k: 'ATK', pct: 1, lo: 4, hi: 10 }, { k: 'MATK', lo: 6, hi: 16 }, { k: 'MATK', pct: 1, lo: 4, hi: 10 },
        { k: 'HIT', lo: 2, hi: 10 }, { k: 'FLEE', lo: 2, hi: 10 }, { k: 'ASPD', lo: 2, hi: 6 }, { k: 'CRIT', lo: 2, hi: 6 },
        { k: 'ดาเมจเวท', pct: 1, lo: 6, hi: 16 }, { k: 'ดาเมจระยะประชิด', pct: 1, lo: 6, hi: 16 }, { k: 'ดาเมจระยะไกล', pct: 1, lo: 6, hi: 16 }, { k: 'ดาเมจคริ', pct: 1, lo: 10, hi: 30 },
    ].map((d) => Object.assign(d, { id: d.k + (d.pct ? '%' : ''), n: d.k.replace(/\s+/g, '').toUpperCase(), label: `${d.k} +${d.lo}–${d.hi}${d.pct ? '%' : ''}` }));
    const OPT_BY_LEN = OPT_DEFS.slice().sort((a, b) => b.n.length - a.n.length);
    const baseItemName = (s) => norm(s).replace(/\s*\[\d+\]\s*$/, '').replace(/^\+\d+\s+/, '');
    const fmtStat = (v) => (Number.isInteger(v) ? String(v) : v.toFixed(1));

    // แยก "ชื่อ +ตัวเลข(%)" ทุกรายการในข้อความ · def = เป็น option ที่รู้จัก (และค่าอยู่ในช่วงที่เป็นไปได้) · ค่านอกช่วง เช่น ATK +130 ถือเป็นค่าพื้นฐานของไอเทม
    function parseStatEntries(text) {
        const flat = String(text).replace(/[\r\n]+/g, ' | ');
        const out = [];
        const re = /([A-Za-z฀-๿][A-Za-z฀-๿ ]*?)\s*\+\s*(\d+(?:\.\d+)?)\s*(%?)/g;
        let m;
        while ((m = re.exec(flat))) {
            const lab = m[1].replace(/\s+/g, ' ').trim(), val = parseFloat(m[2]), pct = m[3] === '%';
            const ln = lab.replace(/\s+/g, '').toUpperCase();
            let def = null;
            for (const d of OPT_BY_LEN) {
                if (!!d.pct !== pct || !ln.endsWith(d.n)) continue;
                const pre = ln.slice(0, ln.length - d.n.length).slice(-1);
                if (/[A-Z]/.test(d.n[0]) && /[A-Z]/.test(pre)) continue;      // MDEF ไม่ใช่ DEF
                def = d; break;
            }
            out.push({ lab: def ? def.k : lab.slice(-24), val, pct, def: def && val >= def.lo && val <= def.hi ? def : null });
        }
        return out;
    }
    // บรรทัดที่เป็นแค่ข้อความปุ่ม (เช่น "ใช้" "ทิ้ง" หรือ "ใช้ทิ้ง" ที่ติดกัน) ไม่ใช่ข้อมูลไอเทม
    function isBtnLine(line, btns) {
        let r = line;
        for (const b of (btns || []).filter(Boolean).sort((a, c) => c.length - a.length)) r = r.split(b).join('');
        return !r.replace(/[\s·|]+/g, '');
    }
    // ค่าพื้นฐานของอุปกรณ์ (อาวุธ ATK/MATK · เกราะ DEF/MDEF) อยู่บรรทัดแรกๆ ก่อน option → ไม่นับเป็น option (กันเข้าใจผิดว่า DEF +6 ของเกราะเป็นออฟ)
    function markBase(entries, cat) {
        const exp = cat === 'weapon' ? ['ATK', 'MATK'] : cat === 'armor' ? ['DEF', 'MDEF'] : null;
        if (!exp) return;
        const seen = new Set();
        for (const e of entries) {
            const lb = String(e.lab).replace(/\s+/g, '').toUpperCase();
            if (!exp.includes(lb) || e.pct || seen.has(lb)) break;
            e.base = true; e.def = null; seen.add(lb);
        }
    }
    // ออฟพิเศษ (ไอเทมมหากาพย์ขึ้นไป): บรรทัดสกิล/เอฟเฟกต์ เช่น "Shadow Fang: แรงขึ้น +20%" หรือ "เมื่อโจมตีปกติ มีโอกาส 10% ใช้ …"
    // และโบนัสที่ต้องตีบวก เช่น "(ตีบวก +7 ขึ้นไป)" — แยกออกจาก Stat/Option ปกติ
    const RE_REFINE_SEG = /([A-Za-z฀-๿% ]*?\+\s*\d+(?:\.\d+)?\s*%?)\s*\(\s*ตีบวก\s*\+?\s*(\d+)\s*ขึ้นไป\s*\)/g;
    const RE_REFINE_ANY = /\(\s*ตีบวก\s*\+?\s*(\d+)\s*ขึ้นไป\s*\)/;
    const isSpecialLine = (l) => /^[A-Za-z][A-Za-z' ]{2,30}:\s+\S/.test(l) || /มีโอกาส\s*\d/.test(l) || /^เมื่อ\S/.test(l);
    function parseItemCard(text, src, btnTexts, cat) {
        const lines = String(text).split(/\n+/).map((s) => s.replace(/\s+/g, ' ').trim().replace(/ต้อง(?:มี)?\s*(?:Base\s*)?Lv\.?\s*(\d+)/g, 'ต้องมี Base Lv.$1'))      // เกมเข
            .filter((s) => s && !/ดับเบิล|ถับเบิล|ดับเบิ้ล|ลากไป/.test(s) && !isBtnLine(s, btnTexts));
        const special = [], refine = [], statLines = [], restLines = [];
        for (let line of lines) {
            const m0 = RE_REFINE_ANY.exec(line);
            if (isSpecialLine(line)) {
                if (m0) refine.push({ n: +m0[1], text: line.replace(RE_REFINE_ANY, '').trim() }); else special.push(line);
                continue;
            }
            // ส่วนของบรรทัดที่เป็นโบนัสตีบวก (เช่น "ATK % +25 (ตีบวก +10 ขึ้นไป)") แยกออก เหลือส่วนที่เป็น Stat ปกติ
            line = line.replace(RE_REFINE_SEG, (all, seg, n) => { refine.push({ n: +n, text: norm(seg).replace(/^[|·,\s]+/, '') }); return ' '; });
            if (RE_REFINE_ANY.test(line)) { const m = RE_REFINE_ANY.exec(line); refine.push({ n: +m[1], text: line.replace(RE_REFINE_ANY, '').trim() }); continue; }
            line = norm(line);
            if (!line) continue;
            statLines.push(line);
        }
        refine.sort((a, b) => a.n - b.n);
        const entries = parseStatEntries(statLines.join('\n'));
        markBase(entries, cat);
        for (const l of statLines) if (!parseStatEntries(l).length) restLines.push(l);
        return { src, lines, entries, opts: entries.filter((e) => e.def), special, refine, restLines, ok: /น้ำหนัก/.test(text) };
    }
    function findTipText(base) {
        let best = null;
        for (const e of document.querySelectorAll('body div, body section, body aside, body article')) {
            if (e.closest(OWN_UI)) continue;
            const t = e.textContent || '';
            if (t.length > 1500 || !/น้ำหนัก/.test(t) || !/ขาย/.test(t) || !t.toLowerCase().includes(base)) continue;
            if (!best || t.length < best.textContent.length) best = e;
        }
        return best ? String(best.innerText || best.textContent) : '';
    }
    async function hoverCard(el, name) {
        const r = el.getBoundingClientRect();
        const o = { bubbles: true, cancelable: true, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, view: VIEW };
        const fire = (types) => { for (const t of types) { try { el.dispatchEvent(t.startsWith('pointer') ? new PointerEvent(t, o) : new MouseEvent(t, o)); } catch (e) { /* ignore */ } } };
        fire(['pointerover', 'pointerenter', 'mouseover', 'mouseenter', 'mousemove']);
        const base = baseItemName(name).toLowerCase();
        let txt = '';
        await waitFor(() => { txt = findTipText(base); return !!txt; }, 900, 100);
        fire(['mousemove', 'mouseout', 'mouseleave', 'pointerout', 'pointerleave']);
        return txt;
    }
    // อ่านข้อมูลไอเทมที่เลือกอยู่: กรอบรายละเอียดในกระเป๋าก่อน ถ้าไม่มีบรรทัด "น้ำหนัก" ค่อยลองชี้เมาส์เอา tooltip
    async function readItemCard(slotEl, name, idx, cat) {
        const detail = document.querySelector('.inventory .inv-detail');
        const btns = detail ? [...detail.querySelectorAll('button')].map((b) => norm(b.textContent)) : [];
        let text = detail ? String(detail.innerText || detail.textContent || '') : '';
        let src = 'detail';
        if (typeof idx === 'number' && !(slotEl && slotEl.isConnected)) slotEl = invSlots()[idx];      // เกมวาดช่องใหม่หลังกดเลือก → อ้างช่องเดิมตามลำดับ
        if (!/น้ำหนัก/.test(text) && slotEl) {
            const tip = await hoverCard(slotEl, name);
            if (tip) { text = tip; src = 'tooltip'; }
        }
        return parseItemCard(text, src, btns, cat);
    }
    function keepOptHit(card) {
        const K = State.opt.keepOpts || {};
        for (const e of card.opts) { const min = K[e.def.id]; if (min !== undefined && e.val >= (+min || 0)) return e; }
        return null;
    }
    function slotInfoDom() {
        const el = document.querySelector('.inv-count');
        const m = el && /(\d+)\s*\/\s*(\d+)/.exec(el.textContent || '');
        return m && +m[2] > 0 ? { used: +m[1], max: +m[2], free: +m[2] - +m[1] } : null;
    }
    function slotInfoHud() {
        const m = /(\d+)\s*\/\s*(\d+)/.exec(readField(SELECTORS.slots, 'slots') || '');
        return m && +m[2] > 0 ? { used: +m[1], max: +m[2], free: +m[2] - +m[1] } : null;
    }

    // ---- แนบ stat/option ของอุปกรณ์ที่ดรอปไปใน Discord ----
    const DropStat = { q: [], lastRun: 0, running: false, known: {} };
    // ทิ้งอุปกรณ์ที่เพิ่งดรอปถ้าออฟไม่ตรงที่เลือก (เลือกระดับที่ทิ้งได้ในหน้าตั้งค่า · Wishlist ไม่แตะ)
    // ให้ออฟตัดสินแทนการล็อกระดับ: อุปกรณ์ที่ตั้งเป็น 🗑️ ขยะ + ระดับที่ติ๊กไว้ในช่อง "ทิ้งถ้าออฟไม่ตรง" (ออฟตรง = เก็บ · ไม่ตรง = ทิ้ง) · Wishlist ไม่แตะ
    function optRuleOk(wi) {
        return !!(State.opt.dropDiscard && wi && Object.keys(State.opt.keepOpts || {}).length && ['weapon', 'armor', 'accessory'].includes(itemCat(wi))
            && (State.opt.dropDiscardRars || {})[wi.rarity || 'common'] && !wishHas(wi.name));
    }
    function discardWanted(info) {
        return !!(State.opt.dropDiscard && info && Object.keys(State.opt.keepOpts || {}).length && (State.opt.dropDiscardRars || {})[info.rarity || 'common']);
    }
    // ปิดกล่องยืนยันที่ค้าง (กดยกเลิก) — กันกระเป๋าปิดแล้วกล่อง "ทิ้ง X?" ค้างหน้าจอ
    async function dismissConfirm() {
        for (let k = 0; k < 3; k++) {
            const dlg = document.querySelector('.confirm-dialog');
            if (!dlg) return false;
            const cancel = [...dlg.querySelectorAll('button')].find((b) => !b.classList.contains('danger')) || dlg.querySelector('button');
            if (cancel) cancel.click();
            await sleep(300);
        }
        return !document.querySelector('.confirm-dialog');
    }
    // 🎬 ฉากเนื้อเรื่อง (หน้าภาพเต็มจอ + ปุ่ม "ข้าม" มุมขวาบน · .story-skip ในโค้ดเกม) → กดข้ามให้
    (function storySkipWatch() {
        let at = 0;
        setInterval(() => {
            try {
                if (!State.opt.storySkip) return;
                const b = document.querySelector('.story-skip');
                if (!b || !isNodeVisible(b) || b.disabled || Date.now() - at < 1500) return;
                at = Date.now();
                b.click();
                Log.info('AUTO', 'กด "ข้าม" ฉากเนื้อเรื่องให้แล้ว');
            } catch (e) { /* ignore */ }
        }, 800);
    })();
    // เฝ้าระวัง: กล่องยืนยันค้างทั้งที่กระเป๋าปิดและไม่มีระบบไหนกำลังทำงาน → ยกเลิกให้
    (function confirmWatchdog() {
        let seen = 0;
        setInterval(() => {
            try {
                const dlg = document.querySelector('.confirm-dialog');
                if (!dlg || isVisible(SELECTORS.weight) || InvLock.owner || !/ทิ้ง/.test(dlg.textContent || '')) { seen = 0; return; }
                if (++seen < 2) return;
                seen = 0;
                const t = norm(dlg.textContent).slice(0, 40);
                dismissConfirm().then((ok) => Log.warn('SYS', `กล่องยืนยันทิ้งค้างหลังปิดกระเป๋า (${t}) — ${ok ? 'ยกเลิกให้แล้ว' : 'ยกเลิกไม่สำเร็จ'}`));
            } catch (e) { /* ignore */ }
        }, 2500);
    })();
    async function destroyCurrent(name) {
        const findBtn = () => {
            const all = [...document.querySelectorAll('.inventory .inv-actions button, .inventory .inv-detail button')];
            return all.find((b) => b.classList.contains('danger') && /ทิ้ง/.test(b.textContent)) || all.find((b) => /ทิ้ง/.test(b.textContent));
        };
        await waitFor(() => { const b = findBtn(); return b && !b.disabled; }, 1500);
        const btn = findBtn();
        if (!btn || btn.disabled) return false;
        btn.click();
        if (!(await waitFor(() => document.querySelector('.confirm-dialog'), 4000))) { await sleep(600); await dismissConfirm(); return false; }
        const dlg = document.querySelector('.confirm-dialog');
        if (!norm(dlg.textContent).toLowerCase().includes(baseItemName(name).toLowerCase())) {
            await dismissConfirm();
            return false;
        }
        await sleep(350);
        const yes = dlg.querySelector('button.danger');
        if (!yes) { await dismissConfirm(); return false; }
        yes.click();
        if (!(await waitFor(() => !document.querySelector('.confirm-dialog'), 2500))) {
            const y2 = document.querySelector('.confirm-dialog button.danger');
            if (y2) y2.click();
            if (!(await waitFor(() => !document.querySelector('.confirm-dialog'), 2500))) { await dismissConfirm(); return false; }
        }
        return true;
    }
    function dropSend(job, card, slotNo, action) {
        if (!job.notify) return;
        const emb = Object.assign({}, job.emb, { fields: (job.emb.fields || []).slice() });
        let ping = job.so.ping;
        if (card && card.ok) {
            const stat = card.entries.map((e) => `${e.lab} +${fmtStat(e.val)}${e.pct ? '%' : ''}`);
            // รายการยาว (> 6 บรรทัด) แบ่งเป็น 2 คอลัมน์ข้างกัน (inline) ใช้พื้นที่ฝั่งขวาที่ว่างอยู่
            const cols = (name, lines) => {
                if (lines.length <= 6) return [{ name, value: lines.join('\n'), inline: false }];
                const h = Math.ceil(lines.length / 2);
                return [{ name, value: lines.slice(0, h).join('\n'), inline: true }, { name: '\u200b', value: lines.slice(h).join('\n'), inline: true }];
            };
            if (stat.length) emb.fields.push(...cols('📊 Stat', stat));
            if (card.opts.length) emb.fields.push(...cols('🎲 Option', card.opts.map((e) => `${e.def.k} +${fmtStat(e.val)}${e.pct ? '%' : ''}`)));
            if (card.special && card.special.length) emb.fields.push({ name: '✨ ออฟพิเศษ', value: card.special.join('\n').slice(0, 900), inline: false });
            if (card.refine && card.refine.length) emb.fields.push({ name: '🔨 โบนัสตีบวก', value: card.refine.map((r) => `ตีบวก +${r.n} ขึ้นไป → ${r.text}`).join('\n').slice(0, 900), inline: false });
            const rest = (card.restLines || card.lines).filter((l) => baseItemName(l).toLowerCase() !== baseItemName(job.g.name).toLowerCase()).flatMap((l) => l.split(/\s+·\s+/)).filter(Boolean).slice(0, 14);
            if (rest.length) emb.fields.push({ name: '📋 รายละเอียด', value: rest.join('\n').slice(0, 900), inline: false });
            const hit = keepOptHit(card);
            const wantOpts = Object.keys(State.opt.keepOpts || {}).length > 0 && job.info && job.info.type === 'Equipment';
            if (hit) { emb.title = '✨ ไอเทมดรอป · มีออฟที่ตั้งไว้'; ping = true; }
            else if (wantOpts) {      // ออฟไม่ตรงที่เลือก: แจ้งเฉย ๆ ไม่แท็ก/ปิงแม้เป็นไอเทมระดับสูง
                emb.title = action === 'discarded' ? '🗑️ ไอเทมดรอป · ออฟไม่ตรง (ทิ้งแล้ว)' : '✨ ไอเทมดรอป · ออฟไม่ตรง';
                emb.fields.push({ name: '⚠️ ออฟไม่ตรงที่เลือกไว้', value: action === 'discarded' ? 'ทิ้งอัตโนมัติแล้ว' : action === 'discard-failed' ? 'พยายามทิ้งแต่ไม่สำเร็จ' : 'ไม่ตรงกับ option ที่เลือก', inline: false });
                ping = false;
            }
            if (slotNo) emb.fields.push({ name: 'อ่านจากช่อง', value: `#${slotNo}`, inline: true });
        }
        sendDiscord('rare', emb, Object.assign({}, job.so, { ping }));
    }
    function dropEnqueue(job) {
        job.at = Date.now();
        DropStat.q.push(job);
        while (DropStat.q.length > 8) { const j = DropStat.q.shift(); dropSend(j, null); }
    }
    async function dropStatRun() {
        DropStat.running = true; InvLock.owner = 'dropstat';
        let opened = false;
        const batch = DropStat.q.slice(0, 4);
        const result = new Map();
        try {
            await infoLoad().catch(() => {});
            if (!isVisible(SELECTORS.weight)) {
                pressKey('i', 'KeyI', 73);
                opened = true;
                if (!(await waitFor(() => isVisible(SELECTORS.weight), 2500))) { Log.warn('DROPSTAT', 'เปิดกระเป๋าไม่สำเร็จ — ส่งแจ้งเตือนแบบไม่มี stat'); return; }
            }
            await sleep(600);
            const used = new Set();
            for (const job of batch) {
                const want = baseItemName(job.g.name).toLowerCase();
                const id = job.info && job.info.id;
                const wiJ = Info.itemById && id ? Info.itemById.get(id) : null;
                const wiCat = wiJ ? itemCat(wiJ) : '';
                const cands = [];
                invSlots().forEach((el, idx) => {
                    if (!el.classList.contains('filled') || used.has(idx)) return;
                    const cs = iconCands(slotIcon(el));
                    if (cs.length && (!id || cs.includes(id))) cands.push(idx);
                });
                const reads = [];
                for (const idx of cands.slice(-10).reverse()) {
                    const el = invSlots()[idx];
                    if (!el) continue;
                    el.click();
                    await waitFor(() => { const e = invSlots()[idx]; return !!e && e.classList.contains('selected') && document.querySelector('.inventory .inv-detail-name'); }, 1500);
                    const nm = baseItemName((document.querySelector('.inventory .inv-detail-name') || {}).textContent).toLowerCase();
                    if (nm !== want) continue;
                    const card = await readItemCard(invSlots()[idx], job.g.name, idx, wiCat);
                    if (!card.ok) continue;
                    const fp = card.entries.map((e) => e.lab + e.val + (e.pct ? '%' : '')).join(',');
                    reads.push({ idx, card, fp });
                    if (cands.length === 1) break;
                }
                if (!reads.length) continue;
                const known = DropStat.known[want] || (DropStat.known[want] = new Set());
                const fresh = reads.filter((r) => !known.has(r.fp));
                const pick = (fresh.length ? fresh : reads).slice().sort((a, b) => b.idx - a.idx)[0];      // ไอเทมใหม่มักอยู่ช่องท้ายสุด
                known.add(pick.fp);      // จำเฉพาะชิ้นที่เลือก — ดรอปครั้งถัดไปของชื่อเดียวกันจะเลือกชิ้นที่ยังไม่เคยอ่าน
                used.add(pick.idx);
                let action = '';
                // ทิ้ง: ต้องออฟไม่ตรง "ทุกชิ้นชื่อเดียวกัน" ที่อ่านได้ (กันทิ้งผิดชิ้น) · ไม่แตะ Wishlist / ของล็อก / ตีบวก
                if (discardWanted(job.info) && !keepOptHit(pick.card) && reads.every((r) => !keepOptHit(r.card)) && !wishHas(job.g.name)) {
                    const el = invSlots()[pick.idx];
                    if (el && !el.querySelector('.inv-lock') && !el.querySelector('.inv-refine')) {
                        el.click();
                        await waitFor(() => { const e = invSlots()[pick.idx]; return !!e && e.classList.contains('selected') && document.querySelector('.inventory .inv-detail-name'); }, 1500);
                        const dn = baseItemName((document.querySelector('.inventory .inv-detail-name') || {}).textContent).toLowerCase();
                        if (dn === want && await destroyCurrent(job.g.name)) { action = 'discarded'; }
                        else { action = 'discard-failed'; Log.warn('DROPSTAT', `${job.g.name}: ออฟไม่ตรงแต่ทิ้งไม่สำเร็จ`); }
                    }
                }
                result.set(job, { card: pick.card, slotNo: cands.length > 1 ? pick.idx + 1 : 0, action });
            }
            const empty = invSlots().find((e) => !e.classList.contains('filled'));
            if (empty) { empty.click(); await sleep(250); }
        } catch (e) {
            Log.err('DROPSTAT', 'ผิดพลาด: ' + (e && e.message));
        } finally {
            try {
                await dismissConfirm();
                if (opened && isVisible(SELECTORS.weight)) {
                    pressKey('i', 'KeyI', 73);
                    await sleep(450);
                    if (isVisible(SELECTORS.weight)) { const c = document.querySelector('.inventory .inv-close'); if (c) c.click(); }
                }
            } catch (e) { /* ignore */ }
            for (const job of batch) {
                const i = DropStat.q.indexOf(job);
                if (i >= 0) DropStat.q.splice(i, 1);
                const r = result.get(job);
                if (!r && job.notify) Log.warn('DROPSTAT', `${job.g.name}: อ่าน stat ไม่ได้ (หาในกระเป๋าไม่เจอ/อ่านรายละเอียดไม่ได้) — ส่งแบบไม่มี stat`);
                else if (r) Log.ok('DROPSTAT', `${job.g.name}: อ่าน stat ได้ ${r.card.entries.length} รายการ (option ${r.card.opts.length})`);
                if (r && r.action === 'discarded') Log.ok('DROPSTAT', `${job.g.name}: ออฟไม่ตรงที่เลือก → ทิ้งแล้ว${r.slotNo ? ` (ช่อง #${r.slotNo})` : ''}`);
                dropSend(job, r ? r.card : null, r ? r.slotNo : 0, r ? r.action : '');
            }
            DropStat.running = false; DropStat.lastRun = Date.now();
            if (InvLock.owner === 'dropstat') InvLock.owner = '';
        }
    }
    function dropStatTick(now) {
        if (!DropStat.q.length) return;
        for (const j of DropStat.q.slice()) {      // รอนานเกินไป (กระเป๋าไม่ว่าง/เกมไม่พร้อม) → ส่งไปก่อนแบบไม่มี stat
            if (now - j.at > 120000) { DropStat.q.splice(DropStat.q.indexOf(j), 1); dropSend(j, null); }      // (ไม่ได้ตั้งให้แจ้ง = ไม่ส่งอะไร)
        }
        if (!DropStat.q.length || DropStat.running || autoPaused() || autoBusy('dropstat')) return;
        if (!State.isGameReady || Frame.dead || Frame.captcha || isTyping()) return;
        if (now - DropStat.q[0].at < 6000 || now - DropStat.lastRun < 20000) return;      // รอให้ไอเทมเข้ากระเป๋า · ไม่เปิดกระเป๋าถี่เกินไป
        dropStatRun();
    }

    // ---- ทดสอบอ่านสเตตัสไอเทม (ใช้ตรวจว่าสคริปต์อ่านกรอบรายละเอียดของเกมได้ถูกไหม) ----
    async function cardTest() {
        const out = document.getElementById('at-card-test');
        const say = (t) => { if (out) out.textContent = t; };
        if (Junk.running || InvLock.owner || DropStat.running) { showToast('กำลังใช้กระเป๋าอยู่ ลองใหม่อีกครั้ง', 'warn'); return; }
        InvLock.owner = 'cardtest';
        let opened = false;
        try {
            await infoLoad().catch(() => {});
            say('⏳ กำลังเปิดกระเป๋า…');
            if (!isVisible(SELECTORS.weight)) {
                pressKey('i', 'KeyI', 73);
                opened = true;
                if (!(await waitFor(() => isVisible(SELECTORS.weight), 2500))) { say('เปิดกระเป๋าไม่สำเร็จ'); return; }
            }
            await sleep(600);
            let card = null, nm = '', firstCard = null, firstNm = '';
            const slots = invSlots();
            for (let i = 0; i < slots.length && i < 40; i++) {
                const el = invSlots()[i];
                if (!el || !el.classList.contains('filled')) continue;
                el.click();
                await waitFor(() => { const e = invSlots()[i]; return !!e && e.classList.contains('selected') && document.querySelector('.inventory .inv-detail-name'); }, 1500);
                const n = norm((document.querySelector('.inventory .inv-detail-name') || {}).textContent);
                const wi = n ? wikiByNameLC(n) : null;
                const c = await readItemCard(invSlots()[i], n, i, wi ? itemCat(wi) : '');
                if (!firstCard) { firstCard = c; firstNm = n; }
                if (wi && ['weapon', 'armor', 'accessory'].includes(itemCat(wi))) { card = c; nm = n; break; }
            }
            card = card || firstCard; nm = nm || firstNm;
            if (!card) { say('ไม่พบไอเทมในกระเป๋า'); return; }
            const empty = invSlots().find((e) => !e.classList.contains('filled'));
            if (empty) { empty.click(); await sleep(250); }
            const txt = [`ไอเทมที่อ่าน: ${nm}`, `แหล่งข้อมูล: ${card.src === 'tooltip' ? 'tooltip (ชี้เมาส์)' : 'กรอบรายละเอียดในกระเป๋า'}${card.ok ? '' : ' — ไม่พบบรรทัด "น้ำหนัก" (อ่านไม่ครบ)'}`, '', '── บรรทัดที่อ่านได้ ──', ...card.lines, '', '── stat ที่แยกได้ ──', ...(card.entries.length ? card.entries.map((e) => `${e.def ? '🎲' : '•'} ${e.lab} +${fmtStat(e.val)}${e.pct ? '%' : ''}${e.def ? '  (option ที่รู้จัก)' : e.base ? '  (ค่าพื้นฐานของไอเทม)' : ''}`) : ['(ไม่พบ)'])].join('\n');
            say(txt);
            Log.info('CARD', `ทดสอบอ่านไอเทม "${nm}": ${card.lines.length} บรรทัด · stat ${card.entries.length} · option ${card.opts.length} · แหล่ง ${card.src}`);
        } finally {
            try {
                await dismissConfirm();
                if (opened && isVisible(SELECTORS.weight)) {
                    pressKey('i', 'KeyI', 73);
                    await sleep(450);
                    if (isVisible(SELECTORS.weight)) { const c = document.querySelector('.inventory .inv-close'); if (c) c.click(); }
                }
            } catch (e) { /* ignore */ }
            if (InvLock.owner === 'cardtest') InvLock.owner = '';
        }
    }

    // ---- หน้าตั้งค่า: ออฟชั่นที่ไม่ทิ้ง ----
    function renderKeepOpts() {
        const box = document.getElementById('at-keepopts');
        if (!box) return;
        box.textContent = '';
        const K = State.opt.keepOpts || (State.opt.keepOpts = {});
        const save = () => { savePrefs(); };
        for (const d of OPT_DEFS) {
            const row = h('label', 'ak-row');
            const cb = h('input'); cb.type = 'checkbox'; cb.checked = K[d.id] !== undefined;
            const lab = h('span', 'ak-lab', d.label);
            const min = h('input', 'ak-min'); min.type = 'number'; min.min = '0'; min.step = '1'; min.placeholder = 'ตั้งแต่'; min.title = 'ว่าง = ค่าเท่าไรก็ไม่ทิ้ง · ใส่เลข = ไม่ทิ้งเมื่อค่าตั้งแต่เลขนี้ขึ้นไป';
            min.value = K[d.id] ? String(K[d.id]) : '';
            const on = () => { if (!cb.checked) cb.checked = true; K[d.id] = +min.value || 0; save(); };      // กดหรือพิมพ์ในช่อง "ตั้งแต่" = ติ๊ก option นี้ให้อัตโนมัติ
            cb.addEventListener('change', () => { if (cb.checked) K[d.id] = +min.value || 0; else delete K[d.id]; save(); });
            min.addEventListener('focus', on);
            min.addEventListener('input', on);
            for (const el of [cb, min]) { el.addEventListener('click', (e) => e.stopPropagation()); el.addEventListener('keydown', (e) => e.stopPropagation()); el.addEventListener('keyup', (e) => e.stopPropagation()); }
            row.append(cb, lab, min);
            box.appendChild(row);
        }
    }

    // ---- ธีมสี ----
    const THEME_PRESETS = {
        gold: { label: 'ทอง', acc: '#fcd34d', acc2: '#f59e0b', bg: '#141417', text: '#f4f4f5' },
        blue: { label: 'ฟ้า', acc: '#7cc4ff', acc2: '#3b82f6', bg: '#10151d', text: '#eef5ff' },
        purple: { label: 'ม่วง', acc: '#c49bff', acc2: '#8b5cf6', bg: '#17121f', text: '#f5f0ff' },
        green: { label: 'เขียว', acc: '#86efac', acc2: '#22c55e', bg: '#101712', text: '#effff3' },
        pink: { label: 'ชมพู', acc: '#f9a8d4', acc2: '#ec4899', bg: '#1a1217', text: '#fff0f7' },
        red: { label: 'แดง', acc: '#fca5a5', acc2: '#ef4444', bg: '#1a1111', text: '#fff1f1' },
        mono: { label: 'ขาวดำ', acc: '#e4e4e7', acc2: '#a1a1aa', bg: '#0a0a0a', text: '#fafafa' },
    };

    function hexToRgb(h) {
        const m = /^#?([\da-f]{2})([\da-f]{2})([\da-f]{2})$/i.exec(String(h || ''));
        return m ? [parseInt(m[1], 16), parseInt(m[2], 16), parseInt(m[3], 16)] : [0, 0, 0];
    }

    function applyTheme() {
        const T = State.theme;
        const acc = hexToRgb(T.acc), acc2 = hexToRgb(T.acc2), bg = hexToRgb(T.bg);
        const lift = (d) => bg.map((v) => Math.max(0, Math.min(255, Math.round(v + d)))).join(',');
        const lum = (0.299 * acc[0] + 0.587 * acc[1] + 0.114 * acc[2]) / 255;
        let st = document.getElementById('at-theme-style');
        if (!st) { st = document.createElement('style'); st.id = 'at-theme-style'; document.head.appendChild(st); }
        st.textContent = `:root{--at-acc:${T.acc};--at-acc-rgb:${acc.join(',')};--at-acc2:${T.acc2};--at-acc2-rgb:${acc2.join(',')};` +
            `--at-bg0-rgb:${lift(-7)};--at-bg-rgb:${lift(0)};--at-bg1-rgb:${lift(7)};--at-bg2-rgb:${lift(15)};` +
            `--at-text:${T.text};--at-op:${T.op};--at-on:${lum > 0.55 ? '#18181b' : '#ffffff'}}`;
    }

    function applyPerf() {
        document.documentElement.classList.toggle('at-lowspec', !!State.opt.lowSpec);
    }

    function bindConfigExtras(cfg) {
        bindJunkUI(cfg);
        const dn = cfg.querySelector('#at-daily-now');
        if (dn) dn.addEventListener('click', (e) => { e.stopPropagation(); dailySend(true); });
        const cr = cfg.querySelector('#at-card-run');
        if (cr) cr.addEventListener('click', (e) => { e.stopPropagation(); cardTest(); });
        renderKeepOpts();
        cfg.querySelectorAll('input[data-ddrar]').forEach((cb) => {
            const k = cb.dataset.ddrar;
            cb.checked = !!(State.opt.dropDiscardRars || {})[k];
            cb.addEventListener('change', () => { State.opt.dropDiscardRars = Object.assign({}, State.opt.dropDiscardRars, { [k]: cb.checked }); savePrefs(); });
            cb.addEventListener('click', (e) => e.stopPropagation());
        });
        const hr = cfg.querySelector('#at-health-run');
        if (hr) hr.addEventListener('click', (e) => { e.stopPropagation(); healthDeep(); });
        const jsr = cfg.querySelector('#at-junk-stat-reset');
        if (jsr) jsr.addEventListener('click', (e) => {
            e.stopPropagation();
            if (!jsr.dataset.arm) { jsr.dataset.arm = '1'; jsr.textContent = '⚠️ กดอีกครั้งเพื่อยืนยัน'; setTimeout(() => { jsr.dataset.arm = ''; jsr.textContent = '↺ ล้างสถิติการทิ้งของตัวละครนี้'; }, 3500); return; }
            jsr.dataset.arm = ''; jsr.textContent = '↺ ล้างสถิติการทิ้งของตัวละครนี้';
            Store.remove(JunkStat.KEY);
            renderJunkStat();
        });
        renderJunkStat();
        renderHealth();
        // สวิตช์/สไลเดอร์ทั่วไป (data-opt)
        cfg.querySelectorAll('.at-switch[data-opt]').forEach((el) => {
            const k = el.dataset.opt;
            el.classList.toggle('on', !!State.opt[k]);
            el.addEventListener('click', (e) => {
                e.stopPropagation();
                State.opt[k] = !State.opt[k];
                el.classList.toggle('on', State.opt[k]);
                savePrefs();
                if (k === 'flyRestock' && State.opt.flyRestock) { const p = Dev.flyRestockCheck(); if (p) { showToast('🦋 ' + p, 'warn'); const st = document.getElementById('at-warp-st'); if (st) st.textContent = '⚠️ ' + p; } }
                if (k === 'warpFly' && State.opt.warpFly && !Dev.flySlot()) { State.opt.warpFly = false; el.classList.remove('on'); savePrefs(); const msg = 'ยังไม่มี Fly Wing ในแถบด่วน — ลาก Fly Wing จากกระเป๋าไปใส่แถบด่วน (ช่องไหนก็ได้) ก่อน แล้วค่อยเปิดตัวเลือกนี้'; showToast('🪽 ' + msg, 'warn'); const st = document.getElementById('at-warp-st'); if (st) st.textContent = '⚠️ ' + msg; }
                if (/^junk/.test(k)) { Junk.nextAt = 0; if (k === 'junkOn' && State.opt.junkOn) Log.info('JUNK', `เปิดระบบทิ้งขยะอัตโนมัติ${State.opt.junkDry ? ' [โหมดทดลอง]' : ''} — จะตรวจน้ำหนักทันที`); }
                if (k === 'warpBack') { try { State.opt.warpBack ? Dev.warpBackOn() : Dev.warpBackOff(); } catch (er) { /* ignore */ } }
                if (k === 'lowSpec') applyPerf();
                if (k === 'lowGfx') { const ch = lowGfxSet(State.opt.lowGfx); Log.info('SYS', State.opt.lowGfx ? '🎮 เปิดกราฟิกประหยัด (30 FPS · ปิดเอฟเฟกต์)' : '🎮 คืนค่ากราฟิกเดิมของเกม'); if (ch) showToast('🎮 ตั้งค่ากราฟิกแล้ว — กด 🔄 รีโหลดทุกจอ (แผงหลัก) เพื่อใช้กับทุกจอ', 'ok'); }
                if (k === 'renderOff') { applyRender(); Log.info('SYS', State.opt.renderOff ? 'ปิดภาพ 3D (ประหยัดเครื่อง)' : 'เปิดภาพ 3D กลับมา'); }
                if (k === 'sound' && State.opt.sound) beep('beep');
            });
        });
        cfg.querySelectorAll('input[type=range][data-opt]').forEach((el) => {
            const k = el.dataset.opt;
            const lab = cfg.querySelector(`[data-optv="${k}"]`);
            el.value = State.opt[k];
            const show = () => { if (lab) lab.textContent = `${State.opt[k]} ${el.dataset.unit || ''}`; };
            show();
            el.addEventListener('input', () => { State.opt[k] = Number(el.value); show(); savePrefs(); if (/^junk/.test(k)) Junk.nextAt = 0; });
        });
        {
            const sel = cfg.querySelector('#at-prof-copy-sel'), btn = cfg.querySelector('#at-prof-copy');
            const fill = () => {
                const names = new Set();
                try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i) || ''; let m = /^at_[^@]+@(.+)$/.exec(k); if (m) names.add(m[1]); m = /^at_profit_v1_(.+)$/.exec(k); if (m) names.add(m[1]); m = /^at_peer:(.+)$/.exec(k); if (m) names.add(m[1]); } } catch (e) { /* ignore */ }
                names.delete(Store.char); sel.innerHTML = '';
                const o0 = document.createElement('option'); o0.value = ''; o0.textContent = names.size ? '— เลือกตัวละครปลายทาง —' : '(ยังไม่เห็นตัวละครอื่น)'; sel.appendChild(o0);
                for (const n of [...names].sort()) { const o = document.createElement('option'); o.value = n; o.textContent = n; sel.appendChild(o); }
            };
            if (sel && btn) {
                fill(); sel.addEventListener('focus', fill); sel.addEventListener('click', (e) => e.stopPropagation());
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const to = sel.value; if (!to || !Store.char) { showToast('เลือกตัวละครปลายทางก่อน', 'warn'); return; }
                    if (!window.confirm(`คัดลอกการตั้งค่าของ ${Store.char} ไปทับของ ${to}?`)) return;
                    savePrefs(); let n = 0;
                    for (const k of PROFILE_KEYS) { if (/pos/.test(k)) continue; const v = Store.get(k); if (v === null) continue; try { lsSet(`${k}@${to}`, v); n++; } catch (er) { /* ignore */ } }
                    showToast(`📋 คัดลอก ${n} รายการไปให้ ${to} แล้ว (มีผลตอนเปิดตัวนั้น/รีโหลด)`, 'ok');
                    Log.ok('SYS', `คัดลอกการตั้งค่า ${Store.char} → ${to} (${n} รายการ)`);
                });
                const pull = cfg.querySelector('#at-prof-pull');
                if (pull) pull.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const from = sel.value; if (!from || !Store.char) { showToast('เลือกตัวละครต้นทางก่อน', 'warn'); return; }
                    if (!window.confirm(`ดึงการตั้งค่าของ ${from} มาทับของ ${Store.char}?`)) return;
                    let n = 0;
                    for (const k of PROFILE_KEYS) { if (/pos/.test(k)) continue; const v = localStorage.getItem(`${k}@${from}`); if (v === null) continue; try { lsSet(`${k}@${Store.char}`, v); n++; } catch (er) { /* ignore */ } }
                    Log.ok('SYS', `ดึงการตั้งค่า ${from} → ${Store.char} (${n} รายการ)`);
                    showToast(`📥 ใช้การตั้งค่าของ ${from} แล้ว (${n} รายการ)`, 'ok');
                    applyProfile(Store.char, true);
                });
            }
            const zp = cfg.querySelector('#at-zone-push'), zl = cfg.querySelector('#at-zone-pull');
            if (zp) zp.addEventListener('click', (e) => { e.stopPropagation(); zoneSync('push'); });
            if (zl) zl.addEventListener('click', (e) => { e.stopPropagation(); zoneSync('pull'); });
        }
        { const sw = cfg.querySelector('#at-share-sw'), inf = cfg.querySelector('#at-share-info');
          const show = () => { if (sw) sw.classList.toggle('on', lsShareOn()); if (inf) { let n = 0, g = 0; try { for (const k of GM_listValues()) { if (k.indexOf('ls:') === 0) n++; else if (k.indexOf('gp:') === 0) g++; } } catch (e) { /* ignore */ } inf.textContent = !LSS.ok ? 'Tampermonkey ไม่อนุญาตพื้นที่เก็บร่วม (ติดตั้งสคริปต์ใหม่แล้วกดอนุญาต)' : lsShareOn() ? `เปิดอยู่ · ข้อมูลร่วม ${n} รายการ · แท็บที่เห็น ${g} แท็บ${LSS.pulled ? ` · ตอนเปิดดึงมา ${LSS.pulled} รายการ` : ''}` : 'ปิดอยู่ (Container นี้ใช้ข้อมูลของตัวเอง)'; } };
          if (sw) sw.addEventListener('click', (e) => { e.stopPropagation(); if (!LSS.ok) { showToast('Tampermonkey ยังไม่อนุญาตพื้นที่เก็บร่วม', 'warn'); return; } const on = !lsShareOn(); try { if (on) localStorage.removeItem('at_share_off'); else localStorage.setItem('at_share_off', '1'); } catch (er) { /* ignore */ } if (on) { const n = lsSyncAll(true); showToast(`🔗 เปิดใช้ข้อมูลร่วม — ดึงมา ${n} รายการ (รีโหลดหน้าเพื่อใช้การตั้งค่าที่ดึงมา)`, 'ok'); Log.info('SYS', `เปิดใช้ข้อมูลร่วมทุก Container · ดึงมา ${n} รายการ`); } else Log.info('SYS', 'ปิดใช้ข้อมูลร่วมใน Container นี้'); show(); });
          show(); setInterval(() => { if (inf && inf.offsetParent) show(); }, 5000); }
        { const pi = cfg.querySelector('#at-prof-inherit'); if (pi) { const get = () => { try { return localStorage.getItem('at_prof_inherit') !== '0'; } catch (e) { return true; } }; pi.classList.toggle('on', get()); pi.addEventListener('click', (e) => { e.stopPropagation(); const v = !get(); try { lsSet('at_prof_inherit', v ? '1' : '0'); } catch (er) { /* ignore */ } pi.classList.toggle('on', v); }); } }
        const pn = cfg.querySelector('#at-prof-name');
        if (pn) pn.textContent = Store.char || '(รอชื่อตัวละคร)';
        const profBtn = cfg.querySelector('#at-prof-reset');
        if (profBtn) profBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (!Store.char) return;
            if (!profBtn.dataset.arm) { profBtn.dataset.arm = '1'; profBtn.textContent = '⚠️ กดอีกครั้งเพื่อยืนยัน'; setTimeout(() => { profBtn.dataset.arm = ''; profBtn.textContent = '↺ รีเซ็ตโปรไฟล์ตัวละครนี้ (กลับเป็นค่าเริ่มต้น)'; }, 3500); return; }
            for (const k of PROFILE_KEYS) { try { lsDel(`${k}@${Store.char}`); } catch (er) { /* ignore */ } }
            applyProfile(Store.char, true);
        });
        const pbtn = cfg.querySelector('#at-live-peers-btn');
        if (pbtn) pbtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const el = document.getElementById('at-live-peers');
            if (!el) return;
            el.style.display = el.style.display === 'none' ? '' : 'none';
            Live.diagAt = 0;
        });
        const stU = cfg.querySelector('#at-dc-status-url');
        if (stU) {
            stU.value = Store.get('at_dc_status_url') || '';
            cfg.querySelector('#at-dc-status-save').addEventListener('click', (e) => {
                e.stopPropagation();
                const v = stU.value.trim();
                if (v && !REGEX.discordUrl.test(v)) { showToast('⚠️ Webhook ไม่ถูกต้อง', 'warn'); return; }
                Store.set('at_dc_status_url', v);
                Store.set('at_status_msg', ''); Store.set('at_boss_msg', '');
                Live.sentAt = 0; Live.bossAt = 0;
                showToast(v ? '✅ บันทึก Webhook ห้องสถานะ' : '✅ ใช้ Webhook หลักสำหรับสถานะ', 'ok');
            });
            cfg.querySelector('#at-dc-status-now').addEventListener('click', (e) => {
                e.stopPropagation();
                Live.busy = {}; Live.last = {};
                Live.force = Object.assign(Live.force || {}, { status: true });      // แก้ไขกล่องเดิม (ไม่สร้างใหม่) ด้วยข้อมูลทุกตัวละครที่เห็นตอนนี้
                showToast('🔄 กำลังอัปเดตกล่องสถานะเดิม…', 'ok');
            });
            cfg.querySelector('#at-dc-status-reset').addEventListener('click', (e) => {
                e.stopPropagation();
                Store.set('at_status_msg', ''); Live.last = {}; Live.busy = {};
                Live.force = Object.assign(Live.force || {}, { status: true });      // ส่งจากแท็บนี้ทันที ไม่รอคัดเลือกผู้อัปเดต
                showToast('♻️ กำลังสร้างกล่องสถานะใหม่…', 'ok');
            });
            cfg.querySelector('#at-dc-boss-reset').addEventListener('click', (e) => {
                e.stopPropagation();
                Store.set('at_boss_msg', ''); Live.last = {}; Live.busy = {};
                Live.force = Object.assign(Live.force || {}, { boss: true });
                showToast('♻️ กำลังสร้างกล่องบอสใหม่…', 'ok');
            });
        }
        const r3 = document.getElementById('at-r3-btn');
        if (r3) r3.addEventListener('click', (e) => { e.stopPropagation(); setRenderOff(!State.opt.renderOff); });
        const snd = cfg.querySelector('#at-snd-test');
        if (snd) snd.addEventListener('click', (e) => { e.stopPropagation(); const was = State.opt.sound; State.opt.sound = true; beep('alarm'); State.opt.sound = was; });

        // ธีม
        const pr = cfg.querySelector('#at-theme-presets');
        const inputs = { acc: '#at-th-acc', acc2: '#at-th-acc2', bg: '#at-th-bg', text: '#at-th-text' };
        const sync = () => {
            for (const [k, sel] of Object.entries(inputs)) cfg.querySelector(sel).value = State.theme[k];
            cfg.querySelector('#at-th-op').value = Math.round(State.theme.op * 100);
            setT(cfg.querySelector('#at-th-opv'), Math.round(State.theme.op * 100) + '%');
            pr.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.p === State.theme.preset));
        };
        for (const [id, p] of Object.entries(THEME_PRESETS)) {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'at-swatch';
            b.dataset.p = id;
            b.title = p.label;
            b.style.background = `linear-gradient(135deg, ${p.acc} 50%, ${p.bg} 50%)`;
            b.addEventListener('click', (e) => {
                e.stopPropagation();
                Object.assign(State.theme, { preset: id, acc: p.acc, acc2: p.acc2, bg: p.bg, text: p.text });
                savePrefs(); applyTheme(); sync();
            });
            pr.appendChild(b);
        }
        for (const [k, sel] of Object.entries(inputs)) {
            cfg.querySelector(sel).addEventListener('input', (e) => {
                State.theme[k] = e.target.value;
                State.theme.preset = 'custom';
                savePrefs(); applyTheme(); sync();
            });
        }
        cfg.querySelector('#at-th-op').addEventListener('input', (e) => {
            State.theme.op = Math.max(0.3, Math.min(1.3, Number(e.target.value) / 100));
            savePrefs(); applyTheme(); sync();
        });
        cfg.querySelector('#at-th-reset').addEventListener('click', (e) => {
            e.stopPropagation();
            Object.assign(State.theme, THEME_PRESETS.gold, { preset: 'gold', op: 1 });
            savePrefs(); applyTheme(); sync();
        });
        sync();

        // สำรอง/กู้คืน
        cfg.querySelector('#at-bk-export').addEventListener('click', (e) => { e.stopPropagation(); exportBackup(false); });
        cfg.querySelector('#at-bk-export-set').addEventListener('click', (e) => { e.stopPropagation(); exportBackup(true); });
        const file = cfg.querySelector('#at-bk-file');
        cfg.querySelector('#at-bk-import').addEventListener('click', (e) => { e.stopPropagation(); file.click(); });
        file.addEventListener('change', () => { importBackup(file.files[0]); file.value = ''; });
        cfgHelp(cfg);
        const hb = cfg.querySelector('#ac-help');
        if (hb) hb.addEventListener('click', (e) => { e.stopPropagation(); let f = false; try { f = localStorage.getItem('at_help_full') !== '1'; localStorage.setItem('at_help_full', f ? '1' : '0'); } catch (er) { /* ignore */ } cfgHelp(cfg); showToast(f ? '📖 แสดงคำอธิบายแบบเต็ม' : '❔ ย่อคำอธิบาย — ชี้หรือกดที่ ? เพื่อดู', 'info'); });
    }

    // ❔ คำอธิบายยาว ๆ ในหน้าต่าง Config → ย่อเป็นปุ่ม ? ข้างชื่อฟังก์ชัน (ชี้ = ดู · กด = ค้างไว้) · ปุ่ม 📖 บนหัวหน้าต่าง = แสดงแบบเต็ม
    const Tip = { el: null, pin: null };
    function tipShow(btn) {
        if (!Tip.el) { Tip.el = document.createElement('div'); Tip.el.id = 'at-tip'; document.body.appendChild(Tip.el); }
        Tip.el.innerHTML = (btn._src || []).map((x) => x.innerHTML).join('<div style="height:6px"></div>');
        Tip.el.style.display = 'block';
        const r = btn.getBoundingClientRect(), w = Tip.el.offsetWidth, h = Tip.el.offsetHeight, vw = window.innerWidth, vh = window.innerHeight;
        let x = Math.min(Math.max(6, r.left + r.width / 2 - w / 2), vw - w - 6), y = r.bottom + 6;
        if (y + h > vh - 6) y = Math.max(6, r.top - h - 6);
        Tip.el.style.left = x + 'px'; Tip.el.style.top = y + 'px';
    }
    function tipHide(force) { if (Tip.pin && !force) return; if (Tip.pin) Tip.pin.classList.remove('on'); Tip.pin = null; if (Tip.el) Tip.el.style.display = 'none'; }
    document.addEventListener('click', (e) => { if (Tip.pin && !(e.target && e.target.closest && e.target.closest('.at-hp'))) tipHide(true); }, true);
    function cfgHelp(root) {
        let full = false; try { full = localStorage.getItem('at_help_full') === '1'; } catch (e) { /* ignore */ }
        root.classList.toggle('at-help-full', full);
        tipHide(true);
        root.querySelectorAll('.ac-l').forEach((sp) => {
            if (sp.dataset.hp || sp.id || sp.querySelector('input,button,select,textarea')) return;
            if ((sp.textContent || '').trim().length <= 45) return;      // ป้ายสั้น ๆ (เช่น "Webhook URL") คงไว้
            sp.dataset.hp = '1'; sp.classList.add('at-hp-src');
            const prev = sp.previousElementSibling;
            if (prev && prev._hp) { prev._hp._src.push(sp); sp._hp = prev._hp; return; }      // คำอธิบายหลายบรรทัดติดกัน → รวมเป็นปุ่มเดียว
            const b = document.createElement('span'); b.className = 'at-hp'; b.textContent = '?'; b._src = [sp]; sp._hp = b;
            const host = prev && prev.classList.contains('at-toggle-row') ? prev.querySelector(':scope > span') : prev && prev.classList.contains('ac-title') ? prev : null;
            if (host) host.appendChild(b); else { b.classList.add('at-hp-solo'); b.textContent = '? คำอธิบาย'; sp.before(b); }
            b.addEventListener('mouseenter', () => { if (!Tip.pin) tipShow(b); });
            b.addEventListener('mouseleave', () => tipHide());
            b.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); if (Tip.pin === b) { tipHide(true); return; } tipHide(true); Tip.pin = b; b.classList.add('on'); tipShow(b); });
        });
    }

    // 🗺️ ซิงค์โซนฟาร์มข้ามเครื่องผ่าน Google Apps Script (ต้องเพิ่มโค้ด aetherack-zones-sync.gs ฝั่ง Apps Script)
    function zoneSync(dir) {
        const url = State.webAppUrl;
        if (!url) { showToast('ยังไม่ได้ตั้ง Web App URL ในแท็บ Sheets', 'warn'); return; }
        const fail = (why) => { showToast('❌ ซิงค์โซนไม่สำเร็จ: ' + why, 'err'); Log.err('ZONE', 'ซิงค์โซนไม่สำเร็จ: ' + why); };
        if (dir === 'push') {
            let zones = {}; try { zones = JSON.parse(localStorage.getItem('at_fly_zones') || '{}') || {}; } catch (e) { /* ignore */ }
            GM_xmlhttpRequest({
                method: 'POST', url, headers: { 'Content-Type': 'application/json' }, data: JSON.stringify({ action: 'zones_put', zones, at: Date.now() }), timeout: 15000,
                onload: (r) => { let j = null; try { j = JSON.parse(r.responseText); } catch (e) { /* ignore */ } if (r.status < 300 && j && j.ok) { showToast(`⬆️ ส่งโซนขึ้น Sheets แล้ว (${Object.keys(zones).length} แมพ)`, 'ok'); Log.ok('ZONE', `ส่งโซน ${Object.keys(zones).length} แมพขึ้น Sheets`); } else fail(`HTTP ${r.status} — ยังไม่ได้เพิ่มโค้ดซิงค์โซนใน Apps Script หรือยังไม่ได้ Deploy ใหม่?`); },
                onerror: () => fail('เครือข่าย'), ontimeout: () => fail('หมดเวลา'),
            });
        } else {
            GM_xmlhttpRequest({
                method: 'GET', url: url + (url.includes('?') ? '&' : '?') + 'action=zones_get&t=' + Date.now(), timeout: 15000,
                onload: (r) => {
                    let j = null; try { j = JSON.parse(r.responseText); } catch (e) { /* ignore */ }
                    const z = j && (j.zones || null);
                    if (r.status >= 300 || !z || typeof z !== 'object') { fail(`HTTP ${r.status} — ยังไม่ได้เพิ่มโค้ดซิงค์โซนใน Apps Script หรือยังไม่เคยส่งโซนขึ้น?`); return; }
                    let cur = {}; try { cur = JSON.parse(localStorage.getItem('at_fly_zones') || '{}') || {}; } catch (e) { /* ignore */ }
                    const merged = Object.assign(cur, z);
                    try { lsSet('at_fly_zones', JSON.stringify(merged)); } catch (e) { /* ignore */ }
                    showToast(`⬇️ ดึงโซนจาก Sheets แล้ว (${Object.keys(z).length} แมพ)`, 'ok'); Log.ok('ZONE', `ดึงโซน ${Object.keys(z).length} แมพจาก Sheets`);
                },
                onerror: () => fail('เครือข่าย'), ontimeout: () => fail('หมดเวลา'),
            });
        }
    }

    async function httpGetJSON(url) {
        try {
            const res = await fetch(url, { credentials: 'same-origin' });
            if (!res.ok) throw new Error('HTTP ' + res.status);
            return await res.json();
        } catch (firstErr) {
            return new Promise((resolve, reject) => {
                GM_xmlhttpRequest({
                    method: 'GET',
                    url: new URL(url, location.origin).href,
                    timeout: 20000,
                    onload: (r) => {
                        try {
                            if (r.status >= 200 && r.status < 300) resolve(JSON.parse(r.responseText));
                            else reject(new Error('HTTP ' + r.status));
                        } catch (e) { reject(e); }
                    },
                    onerror: () => reject(firstErr),
                    ontimeout: () => reject(new Error('timeout')),
                });
            });
        }
    }

    async function loadIconManifest() {
        try {
            const m = await httpGetJSON('/art/icons/manifest.json');
            const f = m && m.ui && m.ui.token;
            if (f) Icons.tokenSrc = '/art/icons/' + f;
            if (m && m.items) Icons.items = m.items;
        } catch (e) {
            Log.err('SYS', 'โหลด icon manifest ไม่สำเร็จ: ' + (e && e.message));
        }
    }

    // ไอคอนมอน: /art/monsters/<file> ตาม manifest ของเกม (โหลดเมื่อจำเป็นเท่านั้น)
    function ensureMonsterManifest() {
        if (Icons.monsters || Icons.monstersLoading) return;
        Icons.monstersLoading = true;
        httpGetJSON('/art/monsters/manifest.json')
            .then((m) => { Icons.monsters = m || {}; Profit.rev++; })
            .catch((e) => Log.err('SYS', 'โหลด monster manifest ไม่สำเร็จ: ' + (e && e.message)))
            .finally(() => { Icons.monstersLoading = false; });
    }

    function monsterIcon(name) {
        const id = Profit.db.mons[name];
        const m = Icons.monsters && id !== undefined ? Icons.monsters[id] : null;
        return m && m.file ? `/art/monsters/${m.file}` : '';
    }

    let dbLoading = null;

    function loadPriceDB(force = false) {
        if (dbLoading) return dbLoading;
        const db = Profit.db;
        const cached = Store.getJSON(DB_KEY);

        if (!force && !db.loadedAt && cached && cached.items && cached.mons && Date.now() - cached.at < CONFIG.PRICE_TTL_MS) {
            db.items = cached.items;
            db.mons = cached.mons;
            db.size = Object.keys(db.items).length;
            db.loadedAt = cached.at;
            db.checkedAt = Date.now();
            db.status = 'ok';
            Profit.rev++;
            flushPending();
            return Promise.resolve();
        }

        db.status = 'loading';
        db.checkedAt = Date.now();
        dbLoading = httpGetJSON('/wiki-data')
            .then((data) => {
                const items = {};
                for (const it of data.items || []) {
                    const nm = norm(it.name);
                    if (nm) items[nm] = [it.id, it.type, it.rarity || 'common', Number(it.sellPrice) || 0];
                }
                const mons = {};
                for (const m of data.monsters || []) {
                    const nm = norm(m.name);
                    if (nm) mons[nm] = m.id;
                }
                db.items = items;
                db.mons = mons;
                db.size = Object.keys(items).length;
                db.loadedAt = Date.now();
                db.status = 'ok';
                db.error = '';
                Store.set(DB_KEY, JSON.stringify({ at: db.loadedAt, items, mons }));
                Log.ok('DB', `โหลดข้อมูลเกมแล้ว: ไอเทม ${db.size} · มอนสเตอร์ ${Object.keys(mons).length}`);
                refreshLedgerFromDB();
            })
            .catch((e) => {
                Log.err('DB', 'โหลดข้อมูลไอเทม/ราคาไม่สำเร็จ: ' + (e && e.message));
                db.error = e && e.message ? e.message : 'error';
                if (cached && cached.items && !db.size) {
                    db.items = cached.items;
                    db.mons = cached.mons || {};
                    db.size = Object.keys(db.items).length;
                    db.loadedAt = cached.at;
                    db.status = 'stale';
                } else if (db.size) {
                    db.status = 'stale';
                } else {
                    db.status = 'error';
                }
            })
            .finally(() => {
                dbLoading = null;
                Profit.rev++;
                flushPending();
            });
        return dbLoading;
    }

    function refreshLedgerFromDB() {
        const apply = (e) => {
            const a = Profit.db.items[e.name];
            if (a) {
                e.id = a[0];
                e.rarity = a[2];
                e.price = a[3];
            }
        };
        for (const lg of Object.values(Profit.all.maps)) {
            Object.values(lg.items).forEach(apply);
            Object.values(lg.drops).forEach(apply);
            // วัตถุดิบที่เคยหลงไปอยู่ใน Item Drops -> ย้ายกลับไปรวมกับวัตถุดิบ
            for (const [k, e] of Object.entries(lg.drops)) {
                const a = Profit.db.items[e.name];
                if (a && CONFIG.MATERIAL_TYPES.includes(a[1])) {
                    const m = lg.items[k] || (lg.items[k] = Object.assign({}, e, { qty: 0 }));
                    m.qty += e.qty;
                    delete lg.drops[k];
                }
            }
        }
        Profit.dirty = true;
        Profit.rev++;
    }

    function touchLedger(lg) {
        if (!lg.startedAt) lg.startedAt = Date.now();
        lg.lastGainAt = Date.now();
        Profit.dirty = true;
        Profit.rev++;
    }

    const CAT_OF_TYPE = { Card: 'card', Equipment: 'equip', Consumable: 'usable', Enchantment: 'refine', AwakeningStone: 'refine' };
    function shouldNotifyItem(info) {
        if (!info || CONFIG.MATERIAL_TYPES.includes(info.type)) return false; // วัตถุดิบไม่ส่ง Discord
        const cat = CAT_OF_TYPE[info.type] || 'equip';
        const F = State.filter;
        if (!(F.cats.all || F.cats[cat])) return false;
        return !!(F.rars.all || F.rars[info.rarity || 'common']);
    }

    function addToLedger(g, info) {
        const lg = writeLedger();
        const items = lg.items;
        let e = items[g.name];
        if (!e) e = items[g.name] = { name: g.name, qty: 0, price: info.price, id: info.id, rarity: info.rarity, icon: g.icon || '' };
        e.qty += g.qty;
        e.price = info.price;
        e.rarity = info.rarity;
        if (g.icon && !e.icon) e.icon = g.icon;
        Stats.rec(getMapName(), g.qty * info.price, 0);
        touchLedger(lg);
        Log.gain('PROFIT', `+${g.name} x${g.qty} (${fmt(g.qty * info.price)} z) @${getMapName() || '-'}`);
    }

    function addDrop(g, info) {
        const lg = writeLedger();
        const drops = lg.drops;
        let e = drops[g.name];
        if (!e) e = drops[g.name] = { name: g.name, qty: 0, price: info.price, id: info.id, rarity: info.rarity, icon: g.icon || '' };
        e.qty += g.qty;
        e.price = info.price;
        e.rarity = info.rarity;
        if (g.icon && !e.icon) e.icon = g.icon;
        touchLedger(lg);
        const r = rarityOf(info.rarity);
        Log.gain('DROP', `+${g.name} x${g.qty} [${r.label}] @${getMapName() || '-'}`);
        if (r.rank >= 2) { Digest.rares.push(`${g.name} x${g.qty} (${r.label})`); if (Digest.rares.length > 40) Digest.rares.shift(); }
        if (wishHas(g.name)) {
            raiseAlert('wish', {
                title: '⭐ ได้ไอเทมที่ตามหา!',
                desc: `**${charLabel()}** ได้ **${g.name}** x${g.qty} (${r.label})`,
                fields: [{ name: 'แมพ', value: getMapName() || '—', inline: true }],
                color: 0xfacc15, ping: true, sound: 'beep', thumb: g.icon || '', toast: `⭐ ได้ ${g.name} x${g.qty}`,
            });
        }
        const notify = shouldNotifyItem(info);
        const emb = {
            title: '✨ ไอเทมดรอป',
            description: `**${g.name}** x${g.qty}  ·  ระดับ ${r.label}`,
            color: r.int,
            fields: [{ name: 'แมพ', value: getMapName() || '—', inline: true }],
        };
        const so = { ping: !!State.pingRars[info.rarity || 'common'], thumb: g.icon };
        // อุปกรณ์: รอเปิดกระเป๋าอ่าน stat/option (แนบใน Discord และ/หรือทิ้งถ้าออฟไม่ตรง) · อ่านไม่ได้ภายใน 2 นาทีจะส่งแบบไม่มี stat
        const dcOk = notify && dcReady('rare');
        if (info.type === 'Equipment' && ((State.opt.dropStat && dcOk) || discardWanted(info))) dropEnqueue({ g, info, emb, so, notify: dcOk });
        else if (notify) { if (info.type === 'Card') cardSend(g, emb, so); else sendDiscord('rare', emb, so); }
    }

    function addKill(name, bx, jx, mapOv) {
        const lg = mapOv ? ledgerFor(mapOv) : writeLedger();
        const k = lg.kills;
        Profit.lastKillAt = Date.now();
        lg.exp.base += bx || 0;
        lg.exp.job += jx || 0;
        k.total++;
        const e = k.by[name] || (k.by[name] = { count: 0 });
        e.count++;
        Stats.rec(mapOv || getMapName(), 0, 1, bx || 0, jx || 0);
        Profit.dirty = true;
        Profit.rev++;
    }

    function recordGain(g, final = false) {
        if (!g.farm) return;

        if (!Profit.charName) profitLoad();
        if (!Profit.charName) {
            if (Profit.pending.length < 300) Profit.pending.push(g);
            return;
        }

        const db = Profit.db;
        const noData = !db.size;

        if (db.status === 'idle' || db.status === 'loading' || (db.status === 'error' && noData)) {
            if (Profit.pending.length < 300) Profit.pending.push(g);
            return;
        }

        const a = db.items[g.name];
        if (!a) {
            // เป็นไอเทมใหม่ที่ cache ยังไม่รู้จัก -> รีเฟรชข้อมูลไม่เกิน 1 ครั้งต่อ 10 นาที
            if (!final && Date.now() - db.checkedAt > CONFIG.PRICE_RECHECK_MS) {
                if (Profit.pending.length < 300) Profit.pending.push(g);
                loadPriceDB(true);
            }
            return;
        }
        const info = { id: a[0], type: a[1], rarity: a[2], price: a[3] };
        if (CONFIG.MATERIAL_TYPES.includes(info.type)) addToLedger(g, info);
        else addDrop(g, info);
    }

    function flushPending() {
        if (!Profit.charName) return;
        const list = Profit.pending;
        Profit.pending = [];
        for (const g of list) recordGain(g, true);
    }

    // แถวฟีดของเกม: <div class="gain-row"><img class="gain-icon"> ได้รับ <b>ชื่อ</b><em> x3</em></div>
    // แถว Zeny ไม่มี <em> จึงถูกข้ามอัตโนมัติ
    function handleGainRow(row) {
        if (Profit.seenRows.has(row)) return;
        Profit.seenRows.add(row);

        const b = row.querySelector('b');
        const em = row.querySelector('em');
        if (!b || !em) return;

        const name = norm(b.textContent);
        const qty = parseInt(em.textContent.replace(/[^\d]/g, ''), 10);
        if (!name || !qty) return;

        const img = row.querySelector('img.gain-icon');
        recordGain({ name, qty, icon: img ? (img.getAttribute('src') || '') : '', farm: isFarmMap() });
    }

    // ---- ฆ่ามอน: อ่านข้อความระบบจากแชทที่เกมเก็บไว้ใน localStorage (webgame.chat.<ชื่อตัวละคร>) ----
    // ไม่ขึ้นกับแท็บแชทที่เปิดอยู่ และไม่นับซ้ำเวลาสลับแท็บ (ใช้ตัวชี้ตามเวลา at)
    const Chat = { lastRaw: null };

    function pollChat() {
        if (!Profit.charName) return;
        let raw;
        try { raw = localStorage.getItem('webgame.chat.' + readField(SELECTORS.charName, 'name')); } catch (e) { return; }
        if (!raw || raw === Chat.lastRaw) return;
        Chat.lastRaw = raw;

        let arr;
        try { arr = JSON.parse(raw); } catch (e) { return; }
        if (!Array.isArray(arr)) return;
        const sys = arr.filter((e) => e && e.channel === 'system' && typeof e.text === 'string' && typeof e.at === 'number');

        const data = Profit.all;
        if (!data.chat) {
            // ครั้งแรก: ข้ามประวัติเก่า เริ่มนับจากข้อความถัดไป
            const last = sys[sys.length - 1];
            if (last) {
                let n = 0;
                for (const e of sys) if (e.at === last.at) n++;
                data.chat = { at: last.at, n };
            } else {
                data.chat = { at: Date.now(), n: 0 };
            }
            Profit.dirty = true;
            return;
        }

        const cur = data.chat;
        let skip = cur.n;
        let newAt = cur.at;
        let newN = cur.n;
        for (const e of sys) {
            if (e.at < cur.at) continue;
            if (e.at === cur.at && skip > 0) { skip--; continue; }
            if (e.at === newAt) newN++; else { newAt = e.at; newN = 1; }
            const m = REGEX.kill.exec(e.text);
            if (m && Profit.farming) {
                // ข้อความที่เกิดก่อนเปลี่ยนแมพ ต้องนับให้แมพเดิม (แชทถูกอ่านช้ากว่าเวลาจริงเล็กน้อย)
                let mapOv = null;
                if (Profit.mapSince && e.at < Profit.mapSince - 1500) {
                    if (!isCountMap(Profit.prevMap)) continue;
                    mapOv = Profit.prevMap;
                }
                const bm = /Base EXP\s*\+\s*([\d,]+)/i.exec(e.text), jm = /Job EXP\s*\+\s*([\d,]+)/i.exec(e.text);
                addKill(norm(m[1]), bm ? parseInt(bm[1].replace(/,/g, ''), 10) : 0, jm ? parseInt(jm[1].replace(/,/g, ''), 10) : 0, mapOv);
            }
        }
        if (newAt !== cur.at || newN !== cur.n) {
            cur.at = newAt;
            cur.n = newN;
            Profit.dirty = true;
        }
    }

    function profitTick(now) {
        const curName = readField(SELECTORS.charName, 'name');
        if (curName && curName !== Profit.charName) profitLoad(curName);

        const inFarm = State.isGameReady && !!Profit.charName && isFarmMap();
        if (inFarm && Profit.wasInFarm && Profit.lastTickAt) {
            writeLedger().farmMs += Math.min(now - Profit.lastTickAt, CONFIG.MAX_TICK_GAP_MS);
            Profit.dirty = true;
        }
        {
            const m = getMapName();
            if (m && m !== Profit.curMap) { Profit.prevMap = Profit.curMap || ''; Profit.curMap = m; Profit.mapSince = Date.now(); }
        }
        Profit.lastTickAt = now;
        Profit.wasInFarm = inFarm;
        Profit.farming = inFarm;
        if (inFarm) {
            const mn = getMapName();
            if (mn && Profit.all.lastMap !== mn) {
                Profit.all.lastMap = mn;
                Profit.dirty = true;
            }
        }
        if (Profit.dirty && now - Profit.lastSaveAt >= CONFIG.SAVE_INTERVAL_MS) profitSave();
        Stats.save(false);
    }

    function clearProfit() {
        const n = viewMapName();
        if (n) delete Profit.all.maps[n]; // ล้างเฉพาะแมพที่กำลังดู · ตัวชี้แชทอยู่ที่ Profit.all.chat จึงไม่ถูกนับซ้ำ
        Profit.pending = [];
        Exp.rate = null; Exp.cal = null; Exp.jstart = null;
        Profit.confirmClearUntil = 0;
        Profit.rev++;
        Profit.dirty = true;
        profitSave(true);
        if (pRefs.clear) pRefs.clear.textContent = '🗑️ ล้างแมพนี้';
        Log.warn('PROFIT', `ล้างประวัติแมพ "${n || '-'}" ของ ${Profit.charName || 'ตัวละครนี้'}`);
        showToast(`🗑️ ล้างประวัติ Profit แมพ ${n || ''} แล้ว`, 'ok');
    }

    // ---------------------------------------------------------------
    // Discord (webhook) : แจ้งเตือนตอนตาย ฯลฯ ตามหัวข้อที่เลือก
    // ---------------------------------------------------------------
    const Discord = { last: {} };

    function dcReady(topic) {
        return State.discordOn && REGEX.discordUrl.test(State.discordUrl) && !!State.dcTopics[topic];
    }

    // จัดหน้าตา embed ให้เหมือนตัวอย่าง: หัวข้อตัวหนา + ค่าเป็น "ป้าย" (code pill) บรรทัดละอัน
    function prettyEmbed(embed) {
        const pill = (line) => (/[`]|<t:|<@|^\s*$|^▬+$|^#{1,3}\s|^\*\*/.test(line) ? line : '`' + line.replace(/`/g, "'") + '`');
        const out = Object.assign({}, embed);
        if (out.fields) {
            out.fields = out.fields.map((f) => Object.assign({}, f, { value: String(f.value).split('\n').map(pill).join('\n').slice(0, 1020) }));
        }
        return out;
    }

    // 🌙 ช่วงเวลาไม่รบกวน: ส่งข้อความตามปกติแต่ไม่แท็ก (ยกเว้นเรื่องด่วน: แคปช่า / ติดคุก / หลุดการเชื่อมต่อ)
    const QUIET_URGENT = ['captcha', 'jail', 'server'];
    function quietMute(topic) {
        if (!State.opt.quietOn || QUIET_URGENT.includes(topic)) return false;
        const h = new Date().getHours(), a = +State.opt.quietFrom || 0, b = +State.opt.quietTo || 0;
        return a === b ? false : a < b ? h >= a && h < b : h >= a || h < b;
    }
    // 🚦 คิวส่ง Discord ร่วมทุกแท็บ/ทุก Container: เว้นระยะ ≥1.2 วิ ต่อข้อความ (Webhook รับได้ ~5 ครั้ง/2 วิ) · โดน 429 → รอตามที่ Discord บอกแล้วส่งใหม่
    function dcSlot() {
        if (!LSS.ok) return 0;
        try { const now = Date.now(), nx = +GM_getValue('dc_next', 0) || 0, at = Math.max(now, Math.min(nx, now + 60000)); GM_setValue('dc_next', at + 1200); return at - now; } catch (e) { return 0; }
    }
    function dcRequest(o, tries = 0) {
        setTimeout(() => {
            GM_xmlhttpRequest(Object.assign({}, o, {
                onload: (res) => {
                    if (res.status === 429 && tries < 3) {
                        let wait = 2500; try { const j = JSON.parse(res.responseText || '{}'); const ra = +j.retry_after; if (ra > 0) wait = Math.ceil(ra > 60 ? ra : ra * 1000) + 400; } catch (e) { /* ignore */ }
                        try { if (LSS.ok) GM_setValue('dc_next', Math.max(+GM_getValue('dc_next', 0) || 0, Date.now() + wait)); } catch (e) { /* ignore */ }
                        Log.warn('DISCORD', `Discord ให้รอ (HTTP 429) — ส่งใหม่ใน ${Math.max(1, Math.round(wait / 1000))} วิ (ครั้งที่ ${tries + 1}/3)`);
                        setTimeout(() => dcRequest(o, tries + 1), wait); return;
                    }
                    if (o.onload) o.onload(res);
                },
            }));
        }, dcSlot());
    }
    function sendDiscord(topic, embed, opts = {}) {
        if (!opts.force && !dcReady(topic)) return;
        const now = Date.now();
        const cd = CONFIG.DISCORD_COOLDOWN_MS[topic] || 5000;
        if (!opts.force && Discord.last[topic] && now - Discord.last[topic] < cd) return;
        Discord.last[topic] = now;
        if (opts.once && LSS.ok) {      // เรื่องเดียวกันจากหลายจอ (เซิร์ฟล่ม/เกมอัปเดต) → ส่งจอเดียว
            try { const k = 'dc_once:' + opts.once, t = +GM_getValue(k, 0) || 0; if (now - t < (opts.onceMs || 600000)) { Log.info('DISCORD', `ข้าม "${topic}" — จออื่นแจ้งเรื่องนี้ไปแล้ว`); return; } GM_setValue(k, now); } catch (e) { /* ignore */ }
        }

        const pingId = String(State.dcPing || '').replace(/\D/g, '');
        const doPing = !!opts.ping && pingId.length >= 15 && !quietMute(topic);
        const iconUrl = opts.thumb ? (/^https?:/.test(opts.thumb) ? opts.thumb : location.origin + (opts.thumb.startsWith('/') ? '' : '/') + opts.thumb) : '';
        const body = {
            username: 'Aetheria Tracker',
            content: doPing ? `<@${pingId}>` : undefined,
            allowed_mentions: doPing ? { parse: [], users: [pingId] } : { parse: [] },
            embeds: [Object.assign({}, prettyEmbed(embed), iconUrl ? { thumbnail: { url: iconUrl } } : {}, {
                timestamp: new Date().toISOString(),
                footer: { text: `${Profit.charName || readField(SELECTORS.charName, 'name') || '—'} · v${VERSION}` },
            })],
        };
        dcRequest({
            method: 'POST',
            url: State.discordUrl,
            headers: { 'Content-Type': 'application/json' },
            data: JSON.stringify(body),
            timeout: 10000,
            onload: (res) => {
                const ok = res.status >= 200 && res.status < 300;
                if (ok) Log.ok('DISCORD', `ส่งแจ้งเตือน "${topic}" แล้ว`);
                else Log.err('DISCORD', `ส่ง "${topic}" ไม่สำเร็จ (HTTP ${res.status})`);
                if (opts.onDone) opts.onDone(ok, res.status);
            },
            onerror: () => { Log.err('DISCORD', `ส่ง "${topic}" ไม่สำเร็จ (เครือข่าย)`); if (opts.onDone) opts.onDone(false, 0); },
            ontimeout: () => { Log.err('DISCORD', `ส่ง "${topic}" ไม่สำเร็จ (หมดเวลา)`); if (opts.onDone) opts.onDone(false, 0); },
        });
    }

    function dcDeathEmbed() {
        const d = collectSnapshotData().raw;
        const overlay = queryGame(SELECTORS.deathOverlay);
        const hasFeather = !!overlay && [...overlay.querySelectorAll('button')].some((b) => /ฟื้นที่เดิม/.test(b.textContent));
        const map = getMapName() || '—';
        return {
            title: '💀 ตัวละครตาย',
            description: `**${d.name || '—'}** เสียชีวิตที่ **${map}** ${d.channel || ''}`,
            color: 0xf87171,
            fields: [
                { name: 'ตัวละคร', value: `${d.name || '—'} (${d.class || '—'})`, inline: true },
                { name: 'เลเวล', value: `Base ${d.baseLv || '—'} / Job ${d.jobLv || '—'}`, inline: true },
                { name: 'Rebirth Feather', value: hasFeather ? 'มี' : 'ไม่มี', inline: true },
                { name: 'กลับเมืองอัตโนมัติ', value: State.isReviveEnabled ? 'เปิด' : 'ปิด', inline: true },
                { name: 'Ping', value: (Ping.summary && Ping.summary.text) || '—', inline: true },
            ],
        };
    }

    function deathWatch() {
        if (Frame.dead && !State.wasDead) {
            State.wasDead = true;
            Log.warn('DEATH', `ตัวละครตาย @${getMapName() || '-'}`);
            State.lastDeathAt = Date.now();
            { const dm = getMapName(); if (isCountMap(dm)) { const lg = ledgerFor(dm); lg.deaths = (lg.deaths || 0) + 1; Profit.dirty = true; Profit.rev++; } }
            sendDiscord('death', dcDeathEmbed(), { ping: State.pingDeath });
        } else if (!Frame.dead && State.wasDead) {
            State.wasDead = false;
            Log.info('DEATH', 'ฟื้นแล้ว');
        }
    }

    // ---------------------------------------------------------------
    // Ping : วัด RTT ไปยังเซิร์ฟเวอร์เกมด้วย HTTP เบา ๆ (เดียวกับที่เกมใช้เช็กเวอร์ชัน)
    // ---------------------------------------------------------------
    const Ping = { samples: [], inFlight: false, level: 'idle', summary: null };

    function summarizePing() {
        const s = Ping.samples;
        if (!s.length) return { level: 'idle', ms: null, text: 'กำลังวัด…', tip: 'ยังไม่มีข้อมูล' };
        const oks = s.filter((x) => x.ms !== null).map((x) => x.ms);
        const last = s[s.length - 1];
        const lost = s.length - oks.length;
        if (!oks.length || last.ms === null) {
            return { level: 'err', ms: null, text: 'ไม่ตอบสนอง', tip: `ล่าสุดไม่ตอบสนอง (${last.err || 'error'}) · หลุด ${lost}/${s.length}` };
        }
        const recent = oks.slice(-8);
        const avg = Math.round(recent.reduce((a, b) => a + b, 0) / recent.length);
        const max = Math.max(...recent);
        const min = Math.min(...recent);
        const jitter = max - min;
        let level = 'ok';
        let label = 'ลื่น';
        if (last.ms >= CONFIG.PING_BAD_MS || lost >= 2) { level = 'err'; label = 'กระตุกหนัก'; }
        else if (last.ms >= CONFIG.PING_WARN_MS || jitter >= CONFIG.PING_WARN_MS || lost === 1) { level = 'warn'; label = 'ไม่ค่อยนิ่ง'; }
        return {
            level, ms: last.ms,
            text: `${last.ms} ms · ${label}`,
            tip: `ล่าสุด ${last.ms} ms · เฉลี่ย ${avg} · ต่ำสุด ${min} · สูงสุด ${max} · แกว่ง ${jitter} · หลุด ${lost}/${s.length}`,
        };
    }

    function pushPing(ms, err) {
        Ping.samples.push({ ms, err, t: Date.now() });
        if (Ping.samples.length > CONFIG.PING_HISTORY) Ping.samples.shift();
        const sum = summarizePing();
        Ping.summary = sum;
        if (sum.level !== Ping.level) {
            const prev = Ping.level;
            Ping.level = sum.level;
            if (sum.level === 'err') {
                Log.err('PING', `กระตุกหนัก: ${sum.tip}`);
                sendDiscord('lag', { title: '📶 เซิร์ฟเวอร์กระตุก', description: sum.tip, color: 0xfb923c });
            } else if (sum.level === 'warn') {
                Log.warn('PING', `ไม่ค่อยนิ่ง: ${sum.tip}`);
            } else if (sum.level === 'ok' && prev !== 'idle') {
                Log.ok('PING', `กลับมาปกติ: ${sum.text}`);
            }
        }
    }

    async function pingOnce() {
        if (Ping.inFlight || document.hidden) return;
        Ping.inFlight = true;
        let ctrl; try { ctrl = new PW.AbortController(); } catch (e) { ctrl = new AbortController(); }
        const to = setTimeout(() => ctrl.abort(), CONFIG.PING_TIMEOUT_MS);
        const t0 = performance.now();
        const url = `${CONFIG.PING_URL}?t=${Date.now()}`;
        try {
            const res = await PW.fetch(url, { cache: 'no-store', credentials: 'omit', signal: ctrl.signal });
            let ms = Math.round(performance.now() - t0);
            // เวลาจริงบนเครือข่าย (ส่งคำขอ → ได้ไบต์แรก) จาก Resource Timing — ไม่รวมเวลาที่แท็บมัวทำงานอื่น (เปิดหลายจอ/ปิดภาพ 3D/เครื่องยุ่ง)
            // เดิมจับเวลารวมทั้งหมด → ตอนแท็บยุ่ง ค่าพุ่งเป็นพันมิลลิวินาทีทั้งที่เน็ตปกติ (ping ปลอม)
            try {
                const pf = PW.performance, abs = new URL(url, location.href).href, es = pf.getEntriesByName(abs), en = es[es.length - 1];
                if (en && en.requestStart > 0 && en.responseStart >= en.requestStart) { const net = Math.round(en.responseStart - en.requestStart); if (net < ms) ms = Math.max(1, net); }
                if (pf.getEntriesByType('resource').length > 220) pf.clearResourceTimings();
            } catch (e) { /* ignore */ }
            try { if (res.body && res.body.cancel) res.body.cancel().catch(() => {}); } catch (e) { /* ignore */ }
            if (res.status >= 500) throw new Error('HTTP ' + res.status);
            pushPing(ms);
        } catch (e) {
            pushPing(null, e && e.name === 'AbortError' ? 'timeout' : (e && e.message) || 'error');
        } finally {
            clearTimeout(to);
            Ping.inFlight = false;
        }
    }

    // ---------------------------------------------------------------
    // DPS : อ่านจากมิเตอร์ DPS ของเกม (.dps-meter) ซึ่งเป็นค่าของตัวเราเองเท่านั้น
    // ทำงานเฉพาะตอนเปิดแท็บ DPS
    // ---------------------------------------------------------------
    const Dps = { live: null, last: null, timer: 0, sig: '' };

    function readDamageSetting() {
        try {
            const c = JSON.parse(localStorage.getItem('webgame.camera') || 'null');
            const v = c && c.damageNumbers;
            return v === 'mine' || v === 'off' ? v : 'all';
        } catch (e) { return 'all'; }
    }

    function readDpsMeter() {
        const root = document.querySelector('.dps-meter');
        if (!root || root.closest(OWN_UI)) return null;
        const txt = (sel) => norm((root.querySelector(sel) || {}).textContent);
        const grid = [];
        root.querySelectorAll('.dps-grid dt').forEach((dt) => {
            const dd = dt.nextElementSibling;
            grid.push({ label: norm(dt.textContent), value: norm(dd && dd.textContent), tip: (dd && dd.getAttribute('title')) || '' });
        });
        const sources = [];
        root.querySelectorAll('.dps-sources li').forEach((li) => {
            const small = norm((li.querySelector('small') || {}).textContent);
            const m = small.match(/([\d,]+)\s*·\s*(\d+)%/);
            sources.push({
                name: norm((li.querySelector('span') || {}).textContent),
                damage: m ? parseInt(m[1].replace(REGEX.commas, ''), 10) : 0,
                pct: m ? parseInt(m[2], 10) : 0,
                text: small,
            });
        });
        return {
            done: root.classList.contains('done'),
            title: txt('.dps-head span'),
            seconds: txt('.dps-head small'),
            dps: txt('.dps-big b'),
            grid, sources,
            stats: txt('.dps-stats'),
        };
    }

    function dpsPoll() {
        const snap = readDpsMeter();
        if (snap) {
            Dps.live = snap;
            if (snap.done) {
                const sig = `${snap.dps}|${snap.seconds}|${snap.grid.map((g) => g.value).join(',')}`;
                if (sig !== Dps.sig) {
                    Dps.sig = sig;
                    Dps.last = Object.assign({}, snap, { at: Date.now() });
                    Store.set('at_dps_last_' + Profit.charName, JSON.stringify(Dps.last));
                    Log.ok('DPS', `ผลทดสอบ: ${snap.dps} DPS · ${snap.grid.map((g) => `${g.label} ${g.value}`).join(' · ')}`);
                }
            }
        } else if (Dps.live) {
            Dps.live = null;
        }
        renderDps();
    }

    function startDpsPolling() {
        if (!Dps.last) {
            const d = Store.getJSON('at_dps_last_' + Profit.charName);
            if (d && d.dps) Dps.last = d;
        }
        if (!Dps.timer) Dps.timer = setInterval(dpsPoll, CONFIG.DPS_POLL_MS);
        dpsPoll();
    }

    function stopDpsPolling() {
        if (Dps.timer) clearInterval(Dps.timer);
        Dps.timer = 0;
        Dps.live = null;
    }

    // ---------------------------------------------------------------
    // Observers : ฟังเฉพาะจุดที่จำเป็น แทนการฟังทั้งหน้า (subtree ของ body)
    //   .ui-root (เฉพาะลูกตรง) -> เจอ .gain-feed / หน้าต่างประกาศ
    //   .gain-feed (ลูกตรง)    -> แถว "ได้รับ ..." ใหม่
    // ---------------------------------------------------------------
    function closeAnnouncements() {
        const wins = queryGameAll(SELECTORS.announcement);
        for (const win of wins) {
            if (win.closest(OWN_UI) || win.getClientRects().length === 0) continue;
            const closeBtn = win.querySelector(SELECTORS.announcementClose.join(','));
            if (closeBtn) {
                closeBtn.click();
                Log.info('SYS', 'ปิดหน้าต่างประกาศ/กิจกรรม');
            } else {
                const backdrop = win.closest('.events-backdrop');
                (backdrop || win).style.display = 'none';
            }
        }
    }

    let announceDebounce = null;
    const Obs = { root: null, rootEl: null, feed: null, feedEl: null };

    function attachFeedObserver(feed, countExisting) {
        if (Obs.feed) Obs.feed.disconnect();
        Obs.feedEl = feed;
        // แถวที่มีอยู่ก่อนเริ่มทำงาน = ของเก่า (ทำเครื่องหมายว่าเห็นแล้ว) / ฟีดที่เพิ่งเกิด = ของใหม่
        feed.querySelectorAll('.gain-row').forEach((r) => {
            if (countExisting) handleGainRow(r);
            else Profit.seenRows.add(r);
        });
        Obs.feed = new MutationObserver((mutations) => {
            for (const m of mutations) {
                for (const n of m.addedNodes) {
                    if (n.nodeType === 1 && n.classList.contains('gain-row')) handleGainRow(n);
                }
            }
        });
        Obs.feed.observe(feed, { childList: true });
    }

    function onRootChange() {
        const feed = queryGame(SELECTORS.gainFeed);
        if (feed && feed !== Obs.feedEl) attachFeedObserver(feed, true);
        clearTimeout(announceDebounce);
        announceDebounce = setTimeout(closeAnnouncements, 150);
    }

    function ensureObservers(initial) {
        const root = queryGame(SELECTORS.uiRoot);
        if (!root) return;
        if (Obs.rootEl !== root || !Obs.rootEl.isConnected) {
            if (Obs.root) Obs.root.disconnect();
            Obs.rootEl = root;
            Obs.root = new MutationObserver(onRootChange);
            Obs.root.observe(root, { childList: true });
        }
        const feed = queryGame(SELECTORS.gainFeed);
        if (feed && (feed !== Obs.feedEl || !Obs.feedEl.isConnected)) attachFeedObserver(feed, !initial);
    }

    // ---------------------------------------------------------------
    // Automations
    // ---------------------------------------------------------------
    function runAutomations(now) {
        if (!State.isGameReady || Frame.captcha) return;

        // ตาย: กดกลับเมืองหลวง (ถ้าเกมกำลังจะใช้ Rebirth Feather ฟื้นให้เอง ก็ปล่อยให้เกมทำ)
        if (State.isReviveEnabled && !Pause.manual && Frame.dead && now - State.lastReviveAttempt >= CONFIG.REVIVE_COOLDOWN_MS) {
            const reviveBtn = findReviveButton();
            if (reviveBtn) {
                State.lastReviveAttempt = now;
                State.reviveTries = (State.reviveTries || 0) + 1;
                const label = norm(reviveBtn.textContent);
                if (State.reviveTries % 2 === 1) reviveBtn.click(); else triggerClick(reviveBtn);
                Log.warn('AUTO', `ตัวละครตาย → กดปุ่ม "${label}" (ครั้งที่ ${State.reviveTries})`);
                setStatus('ตัวละครตาย (กลับเมือง)', 'err');
                showToast('💀 ตัวละครตาย ระบบกดกลับเมืองหลวงอัตโนมัติ', 'warn');
                if (label.includes('กลับเมืองหลวง')) {
                    sendDiscord('town', {
                        title: '🏙️ กดกลับเมืองหลวงแล้ว',
                        description: `**${Profit.charName || '—'}** ถูกส่งกลับเมืองหลวงอัตโนมัติ`,
                        color: 0xfcd34d,
                    });
                }
                return;
            }
        }

        if (!Frame.dead) State.reviveTries = 0;
        else if (State.isReviveEnabled && now - State.lastReviveAttempt >= CONFIG.REVIVE_COOLDOWN_MS * 2 && !(State.deadLogAt > now - 15000)) {
            State.deadLogAt = now;
            Log.warn('AUTO', 'ตายแล้วแต่ยังไม่พบปุ่มกลับเมือง (อาจกำลังรอ Rebirth Feather ฟื้นเอง)');
        }

        if (isTyping()) return;
        if (!State.isAutoEnabled || autoPaused()) return;
        const currentMap = readField(SELECTORS.mapName, 'map');
        const isInSafeMap = CONFIG.SAFE_MAPS.some((m) => currentMap.includes(m)) || CONFIG.SAFE_MAP_KEYWORDS.some((k) => currentMap.includes(k));
        if (isInSafeMap) return;

        if (State.warpHold) return;      // ระบบวาร์ปกำลังทำงาน: ห้ามเปิด Z จนกว่าจะถึงแมพปลายทาง
        const autoBtn = queryGame(SELECTORS.autoToggle);
        if (!autoBtn) return;

        const isAutoOn = autoBtn.classList.contains('on') || autoBtn.getAttribute('aria-pressed') === 'true';
        if (isAutoOn) {
            State.autoAttempts = 0;
            return;
        }

        if (now - State.lastAutoAttempt < CONFIG.AUTO_COOLDOWN_MS) return;
        State.lastAutoAttempt = now;
        State.autoAttempts++;

        if (State.autoAttempts % 2 === 1) {
            pressKey('z', 'KeyZ', 90);
            Log.info('AUTO', `เปิด Auto ด้วยปุ่ม Z (ครั้งที่ ${State.autoAttempts})`);
        } else {
            triggerClick(autoBtn);
            Log.info('AUTO', `เปิด Auto ด้วยการคลิกปุ่ม (ครั้งที่ ${State.autoAttempts})`);
        }
    }

    // ⏸️ หยุดระบบอัตโนมัติ: กดปุ่มเอง (manual) หรือเล่นเอง (ตรวจจากการกดคีย์/คลิกจริงของผู้เล่น — อีเวนต์ที่สคริปต์ยิงเองไม่นับ)
    const Pause = { manual: false, userUntil: 0, inputAt: 0 };
    const autoPaused = () => Pause.manual || Date.now() < Pause.userUntil;
    function stopRunningJobs() { try { Dev.warpStop(); Dev.D.abort = true; } catch (e) { /* ignore */ } }
    function setPauseAll(v) {
        Pause.manual = !!v;
        if (v) { Pause.userUntil = 0; stopRunningJobs(); }
        Log.info('PAUSE', v ? '⏸️ หยุดระบบอัตโนมัติทั้งหมด (Auto Z / วาร์ป / ซื้อของ / ทิ้งขยะ / อัพสเตตัส ฯลฯ)' : '▶️ เริ่มระบบอัตโนมัติต่อ');
        showToast(v ? '⏸️ หยุดระบบอัตโนมัติทั้งหมด' : '▶️ ระบบอัตโนมัติทำงานต่อ', 'info');
        renderPause();
    }
    (function watchUser() {
        const ours = '#aetheria-tracker, #aetheria-profit, #aetheria-dps, #aetheria-logs, #aetheria-config, #aetheria-stats, #aetheria-dev, #aetheria-zone, #aetheria-wiki, #aetheria-info, #aetheria-idle, #at-toast-container, #aetheria-dps-notice';
        // ไม่นับว่า "เล่นเอง": 20 วิแรกหลังเข้าเกม (คลิกล็อกอิน/เลือกตัว) และคลิกแรกที่แค่สลับมาที่หน้าต่างนี้ (Chrome Remote Desktop / หลายจอ)
        let readySince = 0, unfocused = !document.hasFocus(), focusT = 0;
        setInterval(() => { if (State.isGameReady) { if (!readySince) readySince = Date.now(); } else readySince = 0; }, 1000);
        window.addEventListener('blur', () => { clearTimeout(focusT); unfocused = true; });
        window.addEventListener('focus', () => { clearTimeout(focusT); focusT = setTimeout(() => { unfocused = false; }, 400); });
        const onUser = (e) => {
            try {
                if (e.isTrusted) Pause.inputAt = Date.now();
                if (!e.isTrusted || !State.opt.manualPause || !State.isGameReady || Pause.manual) return;
                if (!readySince || Date.now() - readySince < 20000) return;
                if (unfocused || !document.hasFocus()) { if (e.type === 'mousedown') { clearTimeout(focusT); focusT = setTimeout(() => { unfocused = false; }, 400); } return; }
                const t = e.target; if (t && t.closest && t.closest(ours)) return;
                if (e.type === 'keydown' && (e.altKey || e.ctrlKey || e.metaKey)) return;      // ปุ่มลัดของสคริปต์/เบราว์เซอร์
                const was = Date.now() < Pause.userUntil;
                Pause.userUntil = Date.now() + Math.max(1, +State.opt.manualMin || 3) * 60000;
                if (!was) { Log.info('PAUSE', `🖐️ ตรวจพบว่าเล่นเอง (${e.type === 'keydown' ? 'กดคีย์' : e.type === 'wheel' ? 'หมุนลูกกลิ้ง' : 'คลิก'}) — หยุดระบบอัตโนมัติชั่วคราว · กด "▶️ กลับไปฟาร์มต่อ" ที่แผงหลักเพื่อเริ่มทันที (ทำต่อเมื่อไม่ได้แตะเกม ${State.opt.manualMin} นาที)`); stopRunningJobs(); renderPause(); }
            } catch (er) { /* ignore */ }
        };
        for (const ty of ['keydown', 'mousedown', 'wheel']) window.addEventListener(ty, onUser, true);
    })();
    // 💬 ช่องแชทของเกมค้างโฟกัส (เช่น ปุ่ม Enter ตอนซื้อของเด้งไปเปิดแชท) → ระบบเดิน/วาร์ป/กลับฟาร์มเห็นว่า "กำลังพิมพ์" แล้วไม่ทำงาน
    //    ผู้เล่นไม่ได้กดคีย์/คลิกเกิน 8 วิ (ช่องว่าง) หรือ 60 วิ (มีข้อความค้าง) → ปลดโฟกัสให้เอง
    function unfocusChat(why) {
        try {
            if (!isTyping()) return false;
            const el = document.activeElement; el.blur();
            if (document.activeElement === el) { try { document.body.focus(); } catch (e) { /* ignore */ } }
            if (why) Log.info('AUTO', `💬 ปิดช่องพิมพ์แชทที่ค้างอยู่ (${why})`);
            return true;
        } catch (e) { return false; }
    }
    setInterval(() => {
        try {
            if (!State.isGameReady || !isTyping()) return;
            const el = document.activeElement, idle = Date.now() - Pause.inputAt, hasText = !!(el && 'value' in el && String(el.value || '').trim());
            if (idle > (hasText ? 60000 : 8000)) unfocusChat(hasText ? 'มีข้อความค้าง ไม่ได้พิมพ์ต่อ 1 นาที' : 'ไม่ได้พิมพ์');
        } catch (e) { /* ignore */ }
    }, 2000);
    function renderPause() {
        const row = document.getElementById('at-pause-row'), tx = document.getElementById('at-pause-txt'), b = document.getElementById('at-btn-pause');
        const p = autoPaused();
        if (row) { const d = p ? '' : 'none'; if (row.style.display !== d) row.style.display = d; }
        if (p && tx) setT(tx, Pause.manual ? 'หยุดอยู่ · กด ▶️ / Alt+X เพื่อทำต่อ' : `เล่นเอง · ทำต่อใน ${fmtTown(Pause.userUntil - Date.now())}`);
        if (b) { b.classList.toggle('active', Pause.manual); setT(b, Pause.manual ? '▶️' : '⏸️'); }
    }

    // กุญแจเปิดกระเป๋า: ซิงค์ Sheet กับทิ้งขยะใช้ปุ่ม I (สลับเปิด/ปิด) เหมือนกัน ต้องไม่ทำพร้อมกัน ไม่งั้นกดชนจนกระเป๋าปิดกลางทาง
    const InvLock = { owner: '' };

    // 🚦 ตัวคุมคิวงานอัตโนมัติ (รวมศูนย์) — ทุกระบบที่ "เปิดหน้าต่างเกม / เดิน / วาร์ป / กดปุ่มในเกม" ต้องถามที่นี่ก่อนเริ่ม
    //    เดิมแต่ละระบบเช็คกันเองคนละแบบ (บางตัวดูแค่กระเป๋า ไม่ดูว่ากำลังเดิน/วาร์ป) → เปิดกระเป๋ากลางทาง / อัพสเตตัสแทรกวาร์ป ฯลฯ
    //    กติกา: มีงานใดทำอยู่ = งานอื่นรอ · งานจบแล้วพัก 2.5 วิ ก่อนงานถัดไป (กันงานต่อกันแล้วชนจังหวะ) · ล็อกค้างเกิน 3 นาที = ปลดเอง
    const Jobs = { lastBusyAt: 0, lastWhy: '', lockName: '', lockSince: 0 };
    function jobsRaw(self) {
        const o = InvLock.owner; if (o && o !== self) return 'ใช้กระเป๋า/หน้าต่าง: ' + o;
        if (Junk.running && self !== 'junk') return 'ทิ้งขยะ';
        if (DropStat.running && self !== 'dropstat') return 'อ่านสเตตัสของดรอป';
        if (Health.running && self !== 'health') return 'ตรวจสุขภาพ';
        if (Boss.opening && self !== 'boss') return 'เปิดหน้าบอส';
        try { const d = Dev && Dev.busy ? Dev.busy(self) : ''; if (d) return d; } catch (e) { /* ignore */ }
        if (State.warpHold && self !== 'warp') return 'วาร์ป';
        return '';
    }
    function autoBusy(self) {
        const r = jobsRaw(self), now = Date.now();
        if (r) { Jobs.lastBusyAt = now; Jobs.lastWhy = r; return r; }
        return now - Jobs.lastBusyAt < 2500 ? 'พักหลัง ' + Jobs.lastWhy : '';
    }
    setInterval(() => {
        try {
            if (jobsRaw('')) Jobs.lastBusyAt = Date.now();
            const o = InvLock.owner;      // ล็อกกระเป๋าค้าง (งานพังกลางทางไม่ได้ปลด) → ปลดเองหลัง 3 นาที
            if (!o) { Jobs.lockName = ''; return; }
            if (o !== Jobs.lockName) { Jobs.lockName = o; Jobs.lockSince = Date.now(); return; }
            if (Date.now() - Jobs.lockSince > 180000 && !(typeof Dev !== 'undefined' && Dev.busy && Dev.busy(''))) { Log.warn('SYS', `🚦 ล็อก "${o}" ค้างเกิน 3 นาที — ปลดล็อกให้ระบบอื่นทำงานต่อ`); InvLock.owner = ''; Jobs.lockName = ''; }
        } catch (e) { /* ignore */ }
    }, 500);

    async function syncInventoryWindow() {
        if (!State.isSyncEnabled || !State.isGameReady || isTyping() || Frame.captcha || autoPaused()) return false;
        if (isVisible(SELECTORS.weight)) return false;
        if (autoBusy('sync')) return false;      // มีงานอื่นทำอยู่ (เดิน/วาร์ป/ทิ้งขยะ/อัพสเตตัส ฯลฯ) — ข้ามรอบนี้ (ค่าจะอัปเดตจากรอบทิ้งขยะเอง)
        InvLock.owner = 'sync';

        pressKey('i', 'KeyI', 73);
        Log.info('SYNC', 'เปิดกระเป๋าเพื่ออ่านค่า');
        const opened = await waitFor(() => isVisible(SELECTORS.weight), 1400);
        if (opened) await sleep(140);
        else InvLock.owner = '';
        return opened;
    }

    function testAndSaveUrl(urlInput) {
        const targetUrl = urlInput.trim();
        if (!targetUrl.startsWith('https://script.google.com/')) {
            showToast('⚠️ กรุณาใส่ Web App URL ให้ถูกต้อง', 'err');
            setStatus('URL ไม่ถูกต้อง', 'err');
            return;
        }

        setStatus('กำลังทดสอบ URL...', 'warn');
        if (uiRefs.saveUrlBtn) uiRefs.saveUrlBtn.disabled = true;

        GM_xmlhttpRequest({
            method: 'POST',
            url: targetUrl,
            headers: { 'Content-Type': 'application/json' },
            data: JSON.stringify({ ping: true, time: new Date().toISOString() }),
            timeout: 10000,
            onload: (res) => {
                if (uiRefs.saveUrlBtn) uiRefs.saveUrlBtn.disabled = false;
                if (res.status >= 200 && res.status < 400) {
                    State.webAppUrl = targetUrl;
                    State.isSettingsOpen = false;
                    savePrefs();
                    updateSettingsVisibility();
                    setStatus('เชื่อมต่อสำเร็จ', 'ok');
                    Log.ok('SHEET', 'ตั้งค่า URL สำเร็จ');
                    showToast('🎉 เชื่อมต่อ Google Sheets สำเร็จ!', 'ok');
                } else {
                    setStatus('เชื่อมต่อล้มเหลว', 'err');
                    Log.err('SHEET', `ทดสอบ URL ไม่สำเร็จ (HTTP ${res.status})`);
                    showToast(`❌ เชื่อมต่อไม่สำเร็จ (Status ${res.status})`, 'err');
                }
            },
            onerror: () => {
                if (uiRefs.saveUrlBtn) uiRefs.saveUrlBtn.disabled = false;
                setStatus('เครือข่ายมีปัญหา', 'err');
                Log.err('SHEET', 'ทดสอบ URL ไม่สำเร็จ (เครือข่าย)');
                showToast('❌ ไม่สามารถเชื่อมต่อกับ URL นี้ได้', 'err');
            },
            ontimeout: () => {
                if (uiRefs.saveUrlBtn) uiRefs.saveUrlBtn.disabled = false;
                setStatus('หมดเวลาเชื่อมต่อ', 'err');
                Log.err('SHEET', 'ทดสอบ URL หมดเวลา');
                showToast('⏰ หมดเวลาการเชื่อมต่อ', 'warn');
            },
        });
    }

    async function sendToSheet(isManual = false) {
        if (State.isSending) return;
        State.isSending = true;
        if (isManual && uiRefs.sendNowBtn) uiRefs.sendNowBtn.classList.add('loading');

        let snapshotObj;
        let weOpened = false;
        try {
            if (Date.now() - State.lastInvSeenAt >= CONFIG.INV_STALE_MS) {
                weOpened = await syncInventoryWindow();
                if (weOpened) State.lastInvSeenAt = Date.now();
            }
            snapshotObj = collectSnapshotData();
        } catch (e) {
            Log.err('SHEET', 'อ่านข้อมูลไม่สำเร็จ: ' + (e && e.message));
        } finally {
            if (weOpened) pressKey('i', 'KeyI', 73);
            if (InvLock.owner === 'sync') InvLock.owner = '';
            State.isSending = false;
            if (isManual && uiRefs.sendNowBtn) uiRefs.sendNowBtn.classList.remove('loading');
        }

        const data = snapshotObj ? snapshotObj.raw : null;
        if (!data || !data.name) {
            if (isManual) showToast('⚠️ ยังไม่พบข้อมูลตัวละคร', 'warn');
            return;
        }

        const jsonStr = JSON.stringify(data);
        if (!isManual && jsonStr === State.lastSentSnapshot) return;

        if (!State.webAppUrl) {
            setStatus('ยังไม่ตั้งค่า URL', 'warn');
            if (isManual) {
                State.isSettingsOpen = true;
                updateSettingsVisibility();
                showToast('⚙️ กรุณาวาง URL และกดบันทึกก่อน', 'warn');
            }
            return;
        }

        setStatus('กำลังส่งข้อมูล...', 'warn');
        const payload = JSON.stringify(Object.assign({}, data, sheetExtras(), CONFIG.API_TOKEN ? { token: CONFIG.API_TOKEN } : {}));

        GM_xmlhttpRequest({
            method: 'POST',
            url: State.webAppUrl,
            headers: { 'Content-Type': 'application/json' },
            data: payload,
            timeout: 15000,
            onload: (res) => {
                let rj = null; try { rj = JSON.parse(res.responseText); } catch (e) { /* ignore */ }
                if (res.status >= 200 && res.status < 300 && rj && rj.ok === false) {      // ส่งถึง Apps Script แต่เขียนลงชีตไม่ได้
                    setStatus('เขียนลงชีตไม่ได้', 'err');
                    Log.err('SHEET', `ส่งถึง Apps Script แต่เขียนลงชีตไม่ได้: ${rj.err || 'ไม่ทราบสาเหตุ'}`);
                    if (isManual) showToast(`❌ เขียนลงชีตไม่ได้: ${rj.err || ''}`, 'err');
                } else if (res.status >= 200 && res.status < 300) {
                    State.lastSentSnapshot = jsonStr;
                    setStatus('ซิงค์ข้อมูลแล้ว', 'ok');
                    Log.ok('SHEET', `ส่งข้อมูลสำเร็จ (HTTP ${res.status})`);
                    if (isManual) showToast('✅ ส่งข้อมูลเข้า Google Sheets สำเร็จ!', 'ok');
                } else {
                    setStatus(`ส่งไม่สำเร็จ (${res.status})`, 'err');
                    Log.err('SHEET', `ส่งไม่สำเร็จ (HTTP ${res.status})`);
                    if (isManual) showToast(`❌ ส่งไม่สำเร็จ (รหัส: ${res.status})`, 'err');
                }
            },
            onerror: () => { setStatus('ส่งข้อมูลล้มเหลว', 'err'); Log.err('SHEET', 'ส่งข้อมูลล้มเหลว (เครือข่าย)'); if (isManual) showToast('❌ เกิดข้อผิดพลาด', 'err'); },
            ontimeout: () => { setStatus('หมดเวลา', 'err'); Log.err('SHEET', 'ส่งข้อมูลหมดเวลา'); if (isManual) showToast('⏰ หมดเวลาการส่งข้อมูล', 'warn'); },
        });
    }

    // ---------------------------------------------------------------
    // Styles (Dark Charcoal + Warm Gold & Coral Red Theme)
    // ---------------------------------------------------------------
    function injectStyles() {
        if (document.getElementById('at-ultra-styles')) return;
        const style = document.createElement('style');
        style.id = 'at-ultra-styles';
        style.textContent = `
            #aetheria-tracker {
                position: fixed; z-index: 999999; width: 300px;
                font-family: 'Inter', 'Noto Sans Thai', system-ui, sans-serif; font-size: 12.5px;
                color: var(--at-text); background: rgba(var(--at-bg-rgb), calc(0.94 * var(--at-op)));
                backdrop-filter: blur(16px); border-radius: 16px;
                border: 1px solid rgba(255, 255, 255, 0.1);
                box-shadow: 0 20px 45px -15px rgba(var(--at-bg0-rgb), calc(0.85 * var(--at-op))); overflow: hidden; user-select: none;
            }
            #aetheria-tracker.minimized { width: 268px; }
            #aetheria-tracker.minimized .at-body { display: none; }
            #aetheria-tracker.minimized .at-badge-pro { display: none; }
            .at-header {
                display: flex; justify-content: space-between; align-items: center;
                padding: 10px 14px; background: linear-gradient(180deg, rgba(var(--at-bg2-rgb), calc(0.95 * var(--at-op))), rgba(var(--at-bg-rgb), calc(0.95 * var(--at-op))));
                border-bottom: 1px solid rgba(255, 255, 255, 0.07); cursor: grab; touch-action: none;
            }
            .at-header:active { cursor: grabbing; }
            .at-brand { display: flex; align-items: center; gap: 8px; font-weight: 700; font-size: 13.5px; color: #fff; }
            .at-badge-pro { font-size: 9px; padding: 2px 6px; border-radius: 5px; background: var(--at-acc); color: var(--at-on); font-weight: 800; letter-spacing: 0.3px; }
            .at-header-actions { display: flex; gap: 3px; }
            .at-icon-btn {
                background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.08);
                color: #d4d4d8; width: 24px; height: 24px; border-radius: 6px; display: flex;
                align-items: center; justify-content: center; cursor: pointer; font-size: 12px; transition: all 0.15s ease;
            }
            .at-icon-btn:hover { background: rgba(255, 255, 255, 0.12); color: #fff; }
            .at-icon-btn.active { background: rgba(var(--at-acc-rgb), 0.18); border-color: var(--at-acc); color: var(--at-acc); }
            .at-statusbar {
                display: flex; justify-content: space-between; align-items: center; gap: 8px;
                padding: 6px 14px; background: rgba(var(--at-bg0-rgb), calc(0.75 * var(--at-op))); font-size: 11px; color: #a1a1aa;
                border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            }
            .at-status-indicator { display: flex; align-items: center; gap: 6px; font-weight: 600; color: #e4e4e7; min-width: 0; }
            .at-status-indicator span:last-child { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .at-dot { width: 7px; height: 7px; border-radius: 50%; display: inline-block; flex: none; }
            .at-dot-ok { background: var(--at-acc); box-shadow: 0 0 8px var(--at-acc); }
            .at-dot-warn { background: #fb923c; box-shadow: 0 0 8px #fb923c; }
            .at-dot-err { background: #f87171; box-shadow: 0 0 8px #f87171; }
            .at-body { padding: 12px; display: flex; flex-direction: column; gap: 10px; }
            .at-hero-card {
                background: linear-gradient(145deg, rgba(var(--at-bg2-rgb), calc(0.75 * var(--at-op))), rgba(var(--at-bg1-rgb), calc(0.75 * var(--at-op))));
                border: 1px solid rgba(255, 255, 255, 0.08); border-radius: 12px; padding: 10px 12px;
                display: flex; justify-content: space-between; align-items: center; gap: 8px;
            }
            .at-char-left { display: flex; align-items: center; gap: 10px; min-width: 0; }
            .at-avatar {
                width: 40px; height: 40px; flex: none; border-radius: 50%; overflow: hidden;
                border: 2px solid var(--at-acc); background: rgba(var(--at-bg0-rgb), calc(0.85 * var(--at-op))); box-shadow: 0 0 0 2px rgba(var(--at-bg0-rgb), calc(0.35 * var(--at-op)));
                display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 800; color: var(--at-acc);
            }
            .at-avatar img { width: 100%; height: 100%; object-fit: cover; display: block; }
            .at-char-main { min-width: 0; }
            .at-char-name { font-size: 14px; font-weight: 700; color: #f87171; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .at-char-class { font-size: 11px; color: var(--at-acc); font-weight: 600; }
            .at-lv-pills { display: flex; gap: 6px; }
            .at-pill {
                background: rgba(var(--at-bg0-rgb), calc(0.75 * var(--at-op))); border: 1px solid rgba(255, 255, 255, 0.08);
                padding: 3px 8px; border-radius: 8px; font-size: 11px; display: flex; flex-direction: column; align-items: center;
            }
            .at-pill span { font-size: 9px; color: #a1a1aa; font-weight: 700; }
            .at-pill b { color: var(--at-text); font-size: 12px; }
            .at-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
            .at-stat-box {
                background: rgba(var(--at-bg2-rgb), calc(0.55 * var(--at-op))); border: 1px solid rgba(255, 255, 255, 0.06);
                border-radius: 10px; padding: 8px 10px; display: flex; flex-direction: column; gap: 3px;
            }
            .at-stat-label { font-size: 10.5px; color: #a1a1aa; }
            .at-stat-val { font-size: 12.5px; font-weight: 700; color: var(--at-text); }
            .at-zeny-val { color: var(--at-acc); }
            .at-weight-card {
                background: rgba(var(--at-bg2-rgb), calc(0.55 * var(--at-op))); border: 1px solid rgba(255, 255, 255, 0.06);
                border-radius: 10px; padding: 8px 10px; display: flex; flex-direction: column; gap: 6px;
            }
            .at-progress-track { width: 100%; height: 6px; background: rgba(var(--at-bg0-rgb), calc(0.85 * var(--at-op))); border-radius: 99px; overflow: hidden; }
            .at-progress-fill {
                height: 100%; width: 0%; border-radius: 99px; background: linear-gradient(90deg, #fbbf24, var(--at-acc));
                transition: width 0.35s ease, background 0.35s ease;
            }
            .at-progress-fill.warn { background: linear-gradient(90deg, var(--at-acc2), #fb923c); }
            .at-progress-fill.danger { background: linear-gradient(90deg, #ef4444, #f87171); }
            .at-info-list {
                background: rgba(var(--at-bg2-rgb), calc(0.45 * var(--at-op))); border: 1px solid rgba(255, 255, 255, 0.06);
                border-radius: 10px; padding: 6px 10px; display: flex; flex-direction: column; gap: 6px;
            }
            .at-info-item { display: flex; justify-content: space-between; align-items: center; font-size: 12px; gap: 8px; }
            .at-info-item span { color: #a1a1aa; font-size: 11.5px; }
            .at-buff-badge {
                display: flex; align-items: center; gap: 5px; padding: 2px 8px; border-radius: 6px; font-weight: 600; font-size: 11.5px;
            }
            .at-buff-badge.active { background: rgba(var(--at-acc-rgb), 0.14); color: var(--at-acc); border: 1px solid rgba(var(--at-acc-rgb), 0.3); }
            .at-buff-badge.empty { background: rgba(248, 113, 113, 0.14); color: #f87171; border: 1px solid rgba(248, 113, 113, 0.3); }
            .at-buff-icon { width: 15px; height: 15px; object-fit: contain; }
            .at-ping { display: flex; align-items: center; gap: 6px; }
            .at-ping b { font-size: 12px; color: var(--at-text); }
            .at-ping-dot { width: 8px; height: 8px; border-radius: 50%; background: #71717a; flex: none; }
            .at-ping-dot.ok { background: var(--at-acc); box-shadow: 0 0 8px var(--at-acc); }
            .at-ping-dot.warn { background: #fb923c; box-shadow: 0 0 8px #fb923c; }
            .at-ping-dot.err { background: #f87171; box-shadow: 0 0 8px #f87171; }
            .at-settings-drawer {
                background: rgba(var(--at-bg0-rgb), calc(0.85 * var(--at-op))); border: 1px solid rgba(var(--at-acc-rgb), 0.35);
                border-radius: 10px; padding: 8px; display: none; flex-direction: column; gap: 6px;
            }
            .at-settings-drawer.open { display: flex; max-height: 70vh; overflow-y: auto; }
            .at-cfg-l { font-size: 10.5px; color: #a1a1aa; }
            .at-fgrid { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; font-size: 11px; color: #d4d4d8; }
            .at-fgrid label { display: flex; align-items: center; gap: 6px; cursor: pointer; }
            .at-fgrid input { accent-color: var(--at-acc); margin: 0; }
            #aetheria-tracker.wide { width: 580px; }
            #aetheria-tracker.wide .at-body { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; align-items: start; }
            #aetheria-tracker.wide .at-settings-drawer, #aetheria-tracker.wide .at-send-btn, #aetheria-tracker.wide .at-r3-btn { grid-column: 1 / -1; }
            .at-url-group { display: flex; gap: 6px; }
            .at-input {
                flex: 1; min-width: 0; background: rgba(var(--at-bg1-rgb), calc(0.95 * var(--at-op))); border: 1px solid rgba(255, 255, 255, 0.12);
                color: var(--at-text); padding: 5px 8px; border-radius: 6px; font-size: 11px; outline: none; user-select: text;
            }
            .at-input:focus { border-color: var(--at-acc); }
            .at-btn-primary {
                background: linear-gradient(180deg, var(--at-acc), var(--at-acc2)); color: var(--at-on); border: none;
                padding: 5px 10px; border-radius: 6px; font-size: 11px; font-weight: 700; cursor: pointer;
            }
            .at-btn-primary:disabled { opacity: .5; cursor: default; }
            .at-btn-ghost {
                background: rgba(255, 255, 255, 0.06); color: #e4e4e7; border: 1px solid rgba(255, 255, 255, 0.12);
                padding: 5px 8px; border-radius: 6px; font-size: 11px; font-weight: 600; cursor: pointer;
            }
            .at-btn-ghost:hover { background: rgba(255, 255, 255, 0.14); }
            .at-toggles {
                display: flex; flex-direction: column; gap: 6px; background: rgba(var(--at-bg2-rgb), calc(0.45 * var(--at-op)));
                border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 10px; padding: 8px 10px;
            }
            .at-toggle-row { display: flex; justify-content: space-between; align-items: center; font-size: 11.5px; color: #e4e4e7; }
            .at-sub-head {
                display: flex; align-items: center; gap: 6px; margin-left: 4px; padding: 4px 8px; border-radius: 8px;
                background: rgba(255, 255, 255, 0.04); font-size: 11px; color: #d4d4d8; cursor: pointer;
            }
            .at-sub-head:hover { background: rgba(255, 255, 255, 0.08); }
            .at-sub-head em { margin-left: auto; font-style: normal; font-size: 10px; color: #a1a1aa; }
            .at-chev { font-style: normal; display: inline-block; transition: transform 0.15s ease; color: var(--at-acc); }
            .at-sub-head.open .at-chev, .ap-sec.open .at-chev { transform: rotate(90deg); }
            .at-sub-body {
                display: none; flex-direction: column; gap: 6px; margin-left: 4px; padding: 8px;
                background: rgba(var(--at-bg0-rgb), calc(0.6 * var(--at-op))); border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 8px;
            }
            .at-sub-body.open { display: flex; }
            .at-sub-label { font-size: 10px; color: #a1a1aa; font-weight: 700; }
            .at-check { display: flex; align-items: center; gap: 6px; font-size: 11px; color: #e4e4e7; cursor: pointer; }
            .at-check input { accent-color: var(--at-acc); margin: 0; }
            .at-switch {
                position: relative; width: 36px; height: 20px; background: rgba(63, 63, 70, 0.7);
                border-radius: 99px; cursor: pointer; transition: background 0.25s ease; border: 1px solid rgba(255, 255, 255, 0.1); flex: none;
            }
            .at-switch::after {
                content: ''; position: absolute; top: 2px; left: 2px; width: 14px; height: 14px;
                background: #e4e4e7; border-radius: 50%; transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1), background 0.25s ease;
            }
            .at-switch.on { background: linear-gradient(135deg, var(--at-acc), var(--at-acc2)); border-color: rgba(var(--at-acc-rgb), 0.5); }
            .at-switch.on::after { transform: translateX(16px); background: #18181b; }
            .at-send-btn {
                width: 100%; background: linear-gradient(180deg, var(--at-acc), #eab308); color: var(--at-on);
                border: 1px solid rgba(255, 255, 255, 0.15); padding: 8px; border-radius: 10px;
                font-size: 12px; font-weight: 800; cursor: pointer; display: flex; justify-content: center;
                align-items: center; gap: 6px; box-shadow: 0 4px 14px rgba(234, 179, 8, 0.25); transition: filter 0.15s ease;
            }
            .at-send-btn:hover { filter: brightness(1.06); }
            .at-send-btn.loading { opacity: .6; }
            #at-toast-container { position: fixed; bottom: 24px; right: 24px; z-index: 1000000; display: flex; flex-direction: column; gap: 8px; pointer-events: none; }
            .at-toast {
                background: rgba(var(--at-bg-rgb), calc(0.96 * var(--at-op))); backdrop-filter: blur(12px); color: var(--at-text);
                padding: 10px 14px; border-radius: 10px; font-size: 12.5px; font-weight: 600;
                box-shadow: 0 10px 25px rgba(var(--at-bg0-rgb), calc(0.65 * var(--at-op))); border-left: 4px solid var(--at-acc);
                transform: translateX(120%); opacity: 0; transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);
            }
            .at-toast.show { transform: translateX(0); opacity: 1; }
            .at-toast-ok { border-left-color: var(--at-acc); }
            .at-toast-warn { border-left-color: #fb923c; }
            .at-toast-err { border-left-color: #f87171; }

            /* ---------- header / config / stats (v4.2) ---------- */
            .at-header { gap: 14px; }
            .at-brand { flex-direction: column; align-items: flex-start; gap: 1px; min-width: 0; }
            .at-brand-t { font-size: 14px; line-height: 1.15; white-space: nowrap; }
            .at-brand-s { font-size: 9px; font-weight: 700; letter-spacing: 0.6px; color: var(--at-acc); opacity: 0.75; white-space: nowrap; }
            #aetheria-tracker.minimized .at-brand-s { display: none; }
            .at-header-actions { flex: none; align-items: center; gap: 4px; }
            .at-icon-btn { width: 26px; height: 26px; flex: none; }
            .at-hsep { width: 1px; height: 16px; background: rgba(255, 255, 255, 0.12); margin: 0 3px; }
            #aetheria-config {
                position: fixed; z-index: 999999; width: 340px; max-width: calc(100vw - 16px); display: none; flex-direction: column;
                font-family: 'Inter', 'Noto Sans Thai', system-ui, sans-serif; font-size: 12px; color: var(--at-text);
                background: rgba(var(--at-bg-rgb), calc(0.97 * var(--at-op))); backdrop-filter: blur(16px); border-radius: 16px;
                border: 1px solid rgba(var(--at-acc-rgb), 0.3); box-shadow: 0 20px 45px -15px rgba(var(--at-bg0-rgb), calc(0.85 * var(--at-op)));
                overflow: hidden; user-select: none; left: 20px; top: 80px;
            }
            #aetheria-config.open { display: flex; }
            .ac-header { display: flex; justify-content: space-between; align-items: center; padding: 10px 12px; font-weight: 700; font-size: 13.5px;
                background: linear-gradient(180deg, rgba(var(--at-bg2-rgb), calc(0.95 * var(--at-op))), rgba(var(--at-bg-rgb), calc(0.95 * var(--at-op)))); border-bottom: 1px solid rgba(255, 255, 255, 0.07); cursor: grab; touch-action: none; }
            .ac-tabs { display: grid; grid-template-columns: repeat(4, 1fr); gap: 4px; padding: 8px 10px 0; }
            .ac-tab { background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.08); color: #a1a1aa; border-radius: 8px;
                padding: 6px 2px; font-size: 11px; font-weight: 600; cursor: pointer; white-space: nowrap; font-family: inherit; }
            .ac-tab:hover { color: #fff; }
            .ac-tab.on { background: rgba(var(--at-acc-rgb), 0.16); border-color: var(--at-acc); color: var(--at-acc); }
            .ac-body { padding: 8px 10px 10px; max-height: calc((100vh - 200px) / var(--at-s, 1)); overflow-y: auto; }
            .ac-pane { display: none; flex-direction: column; gap: 8px; }
            .ac-pane.on { display: flex; }
            .ac-group { background: rgba(var(--at-bg2-rgb), calc(0.5 * var(--at-op))); border: 1px solid rgba(255, 255, 255, 0.07); border-radius: 10px; padding: 8px 10px; display: flex; flex-direction: column; gap: 6px; }
            .ac-title { font-size: 11.5px; font-weight: 700; color: var(--at-acc); display: flex; justify-content: space-between; gap: 8px; }
            .ac-title em { font-style: normal; font-weight: 600; font-size: 10px; color: #a1a1aa; }
            .ac-l { font-size: 10.5px; color: #a1a1aa; line-height: 1.4; }
            .at-hp { display: inline-flex; align-items: center; justify-content: center; min-width: 15px; height: 15px; margin-left: 5px; padding: 0 3px; border-radius: 8px; font-size: 10px; font-weight: 700; line-height: 1; color: #a1a1aa; border: 1px solid #52525b; cursor: help; vertical-align: middle; user-select: none; flex: none; }
            .at-hp:hover, .at-hp.on { color: #fbbf24; border-color: #fbbf24; }
            .at-hp.at-hp-solo { align-self: flex-start; padding: 0 6px; margin: 0; font-weight: 600; }
            #aetheria-config:not(.at-help-full) .at-hp-src { display: none !important; }
            #aetheria-config.at-help-full .at-hp { display: none; }
            #at-tip { position: fixed; z-index: 2147483647; max-width: 300px; background: #18181b; color: #e4e4e7; border: 1px solid #3f3f46; border-radius: 8px; padding: 8px 10px; font-size: 11.5px; line-height: 1.5; box-shadow: 0 8px 24px rgba(0,0,0,.5); pointer-events: none; display: none; }
            .ap-title { white-space: nowrap; }
            #aetheria-profit { max-height: calc(100vh - 12px); }
            .ap-scroll { max-height: none; min-height: 0; }
            .ap-hbtn { background: rgba(255, 255, 255, 0.06); border: 1px solid rgba(255, 255, 255, 0.12); color: #e4e4e7; border-radius: 6px;
                padding: 2px 8px; font-size: 10.5px; font-weight: 700; cursor: pointer; white-space: nowrap; font-family: inherit; flex: none; }
            .ap-hbtn:hover { background: rgba(255, 255, 255, 0.14); }
            .ap-hbtn.on { background: rgba(var(--at-acc-rgb), 0.16); border-color: var(--at-acc); color: var(--at-acc); }
            .ap-header .ap-chip { margin-left: auto; max-width: 48%; }
            .ap-stats { display: flex; flex-direction: column; gap: 6px; padding: 6px 8px 8px; }
            .ap-select { width: 100%; background: rgba(var(--at-bg1-rgb), calc(0.95 * var(--at-op))); color: var(--at-text); border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 8px; padding: 5px 8px; font-size: 11px; font-family: inherit; }
            .ap-pills { display: flex; gap: 4px; }
            .ap-pill { flex: 1; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: #d4d4d8; border-radius: 8px; padding: 4px 2px; font-size: 10.5px; font-weight: 600; cursor: pointer; font-family: inherit; white-space: nowrap; }
            .ap-pill.on { background: rgba(var(--at-acc-rgb), 0.18); border-color: var(--at-acc); color: var(--at-acc); }
            .ap-stinfo { font-size: 10.5px; color: #e4e4e7; font-weight: 600; }
            .ap-chart { background: rgba(var(--at-bg0-rgb), calc(0.6 * var(--at-op))); border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 10px; padding: 6px 4px 2px; min-height: 90px; }
            .ap-stnote { font-size: 9.5px; color: #71717a; line-height: 1.45; }

            .at-header { gap: 12px; }
            .at-header .at-icon-btn { width: 23px; height: 23px; font-size: 11px; }
            .at-header-actions { gap: 3px; }
            .at-hsep { margin: 0 2px; }
            .at-brand-s { font-size: 8.5px; letter-spacing: 0.2px; }
            /* v5.8.9: เว้นระยะปุ่มให้ห่างจากข้อความ */
            #aetheria-tracker { width: 372px; }
            #aetheria-tracker.minimized { width: 354px; }
            .at-header { gap: 22px; padding: 10px 14px; }
            .at-brand { margin-right: 6px; }
            .at-header-actions { gap: 5px; margin-left: auto; }
            .at-hsep { margin: 0 3px; }
            .at-sb-r { display: flex; align-items: center; gap: 8px; }
            .at-town-chip { font-size: 10px; font-weight: 700; color: #fb923c; background: rgba(251, 146, 60, 0.14); border: 1px solid rgba(251, 146, 60, 0.35); border-radius: 99px; padding: 1px 8px; white-space: nowrap; }
            .ap-btn.hot { border-color: rgba(var(--at-acc-rgb), 0.45); color: var(--at-acc); }
            #aetheria-stats {
                position: fixed; z-index: 1000000; width: 1000px; max-width: calc((100vw - 16px) / var(--at-s, 1)); display: none; flex-direction: column;
                font-family: 'Inter', 'Noto Sans Thai', system-ui, sans-serif; font-size: 12.5px; color: var(--at-text);
                background: rgba(var(--at-bg-rgb), calc(0.97 * var(--at-op))); backdrop-filter: blur(16px); border-radius: 16px; border: 1px solid rgba(var(--at-acc-rgb), 0.28);
                box-shadow: 0 24px 60px -15px rgba(var(--at-bg0-rgb), calc(0.9 * var(--at-op))); overflow: hidden; user-select: none; left: 40px; top: 40px;
                max-height: calc((100vh - 16px) / var(--at-s, 1));
            }
            .as-header { display: flex; align-items: center; gap: 12px; padding: 12px 16px; cursor: grab; touch-action: none;
                background: linear-gradient(180deg, rgba(var(--at-bg2-rgb), calc(0.95 * var(--at-op))), rgba(var(--at-bg-rgb), calc(0.95 * var(--at-op)))); border-bottom: 1px solid rgba(255, 255, 255, 0.07); }
            .as-title { font-size: 15px; font-weight: 800; color: var(--at-acc); }
            .as-sub { margin-right: auto; font-size: 11.5px; color: #a1a1aa; }
            .as-maps { display: flex; gap: 4px; padding: 10px 16px 0; overflow-x: auto; border-bottom: 1px solid rgba(255, 255, 255, 0.07); }
            .as-tab { background: transparent; border: none; border-bottom: 2px solid transparent; color: #a1a1aa; padding: 6px 12px 8px; font-size: 12.5px; font-weight: 700; cursor: pointer; white-space: nowrap; font-family: inherit; }
            .as-tab:hover { color: #fff; }
            .as-tab.on { color: var(--at-acc); border-bottom-color: var(--at-acc); }
            .as-empty { font-size: 11.5px; color: #71717a; padding: 8px 4px; }
            .as-ctrl { display: flex; justify-content: space-between; gap: 12px; padding: 10px 16px 0; }
            .as-ctrl .ap-pills { flex: none; }
            .as-ctrl .ap-pill { flex: none; padding: 5px 14px; font-size: 11.5px; }
            .as-main { display: grid; grid-template-columns: minmax(0, 1fr) 270px; gap: 12px; padding: 10px 16px 6px; min-height: 0; overflow-y: auto; }
            .as-info { font-size: 12px; font-weight: 700; color: #e4e4e7; margin-bottom: 6px; }
            .as-chart { min-height: 260px; padding: 10px 8px 4px; }
            .as-kpis { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
            .as-kpis .ap-card b { font-size: 13px; }
            .as-rank-t { font-size: 11.5px; font-weight: 700; color: var(--at-acc); margin: 10px 0 4px; }
            .as-rank { display: flex; flex-direction: column; gap: 3px; max-height: 190px; overflow-y: auto; }
            .as-rrow { display: flex; justify-content: space-between; gap: 8px; background: rgba(var(--at-bg2-rgb), calc(0.5 * var(--at-op))); border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 8px; padding: 5px 8px; color: #e4e4e7; cursor: pointer; font-size: 11px; font-family: inherit; text-align: left; }
            .as-rrow.on { border-color: var(--at-acc); background: rgba(var(--at-acc-rgb), 0.1); }
            .as-rn { font-weight: 700; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .as-rv { color: #a1a1aa; white-space: nowrap; }
            .as-note { padding: 4px 16px 12px; font-size: 10px; color: #71717a; }
            .as-cmp { padding: 2px 16px 6px; overflow-x: auto; max-height: 220px; overflow-y: auto; }
            .as-cmp table { width: 100%; border-collapse: collapse; font-size: 11px; }
            .as-cmp th { position: sticky; top: 0; background: rgba(var(--at-bg2-rgb), .95); color: var(--at-acc); font-weight: 700; text-align: right; padding: 4px 6px; cursor: pointer; white-space: nowrap; }
            .as-cmp th:first-child, .as-cmp td:first-child { text-align: left; }
            .as-cmp td { padding: 3px 6px; text-align: right; border-top: 1px solid rgba(255,255,255,.06); white-space: nowrap; font-variant-numeric: tabular-nums; }
            .as-cmp tr.best td { color: var(--at-acc); font-weight: 700; }

            .ac-tabs { grid-template-columns: repeat(3, 1fr); }
            .at-swatches { display: flex; gap: 8px; flex-wrap: wrap; }
            .at-swatch { width: 34px; height: 34px; border-radius: 10px; border: 2px solid rgba(255, 255, 255, 0.15); cursor: pointer; padding: 0; }
            .at-swatch.on { border-color: #fff; box-shadow: 0 0 0 2px rgba(255, 255, 255, 0.25); }
            .at-colorrow { display: flex; justify-content: space-between; align-items: center; gap: 8px; font-size: 11.5px; color: #e4e4e7; cursor: pointer; }
            .at-colorrow input[type=color] { width: 42px; height: 24px; border: 1px solid rgba(255, 255, 255, 0.2); border-radius: 6px; background: transparent; padding: 0; cursor: pointer; }
            html.at-lowspec #aetheria-tracker, html.at-lowspec #aetheria-profit, html.at-lowspec #aetheria-dps, html.at-lowspec #aetheria-logs,
            html.at-lowspec #aetheria-config, html.at-lowspec #aetheria-stats, html.at-lowspec #at-toast-container * {
                backdrop-filter: none !important; -webkit-backdrop-filter: none !important; box-shadow: none !important;
            }

            /* ---------- Profit side tab ---------- */
            #aetheria-profit {
                position: fixed; z-index: 999998; width: 330px; display: none; flex-direction: column;
                font-family: 'Inter', 'Noto Sans Thai', system-ui, sans-serif; font-size: 12.5px; color: var(--at-text);
                background: rgba(var(--at-bg-rgb), calc(0.94 * var(--at-op))); backdrop-filter: blur(16px);
                border-radius: 16px; border: 1px solid rgba(255, 255, 255, 0.1);
                box-shadow: 0 20px 45px -15px rgba(var(--at-bg0-rgb), calc(0.85 * var(--at-op))); overflow: hidden; user-select: none;
            }
            .ap-header {
                display: flex; justify-content: space-between; align-items: center; gap: 8px;
                padding: 10px 12px; background: linear-gradient(180deg, rgba(var(--at-bg2-rgb), calc(0.95 * var(--at-op))), rgba(var(--at-bg-rgb), calc(0.95 * var(--at-op))));
                border-bottom: 1px solid rgba(255, 255, 255, 0.07); font-weight: 700; font-size: 13.5px; color: #f87171;
            }
            .ap-chip { font-size: 10.5px; font-weight: 700; padding: 2px 8px; border-radius: 99px; white-space: nowrap; max-width: 62%; overflow: hidden; text-overflow: ellipsis; }
            .ap-chip.on { background: rgba(var(--at-acc-rgb), 0.16); color: var(--at-acc); border: 1px solid rgba(var(--at-acc-rgb), 0.35); }
            .ap-chip.off { background: rgba(255, 255, 255, 0.06); color: #a1a1aa; border: 1px solid rgba(255, 255, 255, 0.12); }
            .ap-summary { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 6px; padding: 10px 12px 6px; }
            .ap-card {
                background: rgba(var(--at-bg2-rgb), calc(0.55 * var(--at-op))); border: 1px solid rgba(255, 255, 255, 0.06);
                border-radius: 10px; padding: 6px 8px; display: flex; flex-direction: column; gap: 2px; min-width: 0;
            }
            .ap-card span { font-size: 9.5px; color: #a1a1aa; }
            .ap-card b { font-size: 12px; color: var(--at-text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .ap-card.hot { background: rgba(var(--at-acc-rgb), 0.08); border-color: rgba(var(--at-acc-rgb), 0.22); }
            .ap-card.hot b { color: var(--at-acc); }
            .ap-card b small { display: block; font-size: 9.5px; font-weight: 500; color: #a1a1aa; margin-top: 1px; }
            .ap-card.hot b small { color: rgba(var(--at-acc-rgb), .75); }
            @keyframes at-win-in { from { opacity: 0; translate: 0 -16px; scale: .97; } to { opacity: 1; translate: 0 0; scale: 1; } }
            @keyframes at-slide-down { from { opacity: 0; translate: 0 -10px; } to { opacity: 1; translate: 0 0; } }
            @keyframes at-expand { from { max-height: 0; opacity: 0; overflow: hidden; } to { max-height: 900px; opacity: 1; overflow: hidden; } }
            .at-glide { transition: left .32s cubic-bezier(.2,.8,.2,1), top .32s cubic-bezier(.2,.8,.2,1); }
            html.at-lowspec #aetheria-profit, html.at-lowspec #aetheria-config, html.at-lowspec #aetheria-stats, html.at-lowspec #aetheria-logs,
            html.at-lowspec .ac-pane, html.at-lowspec .ap-sec-body, html.at-lowspec .at-settings-drawer { animation: none !important; }
            @media (prefers-reduced-motion: reduce) { #aetheria-profit, #aetheria-config, #aetheria-stats, #aetheria-logs, .ac-pane, .ap-sec-body { animation: none !important; } }
            .ap-mapbar { display: flex; align-items: center; gap: 8px; padding: 8px 12px 0; font-size: 11px; color: #a1a1aa; }
            .ap-mapbar select {
                flex: 1; min-width: 0; background: rgba(var(--at-bg2-rgb), .8); color: var(--at-text);
                border: 1px solid rgba(255,255,255,.12); border-radius: 8px; padding: 5px 8px; font-size: 11.5px; outline: none;
            }
            .ap-mapbar select:focus { border-color: var(--at-acc); }
            .at-r3-btn { width: 100%; margin-top: 2px; }
            .at-r3-btn.on { border-color: var(--at-acc); color: var(--at-acc); }
            html.at-r3off canvas.at-cv-off { visibility: hidden !important; }
            #aetheria-idle {
                position: absolute; inset: 0; z-index: 0; display: flex; align-items: center; justify-content: center;
                pointer-events: none; background: radial-gradient(ellipse at 50% 35%, #1b1d27 0%, #0b0c10 70%);
                color: var(--at-text); font-family: system-ui, -apple-system, 'Segoe UI', sans-serif;
            }
            #aetheria-idle .ai-card {
                width: min(580px, 92%); padding: 18px 20px; border-radius: 18px;
                background: rgba(var(--at-bg-rgb), .94); border: 1px solid rgba(var(--at-acc-rgb), .28);
                box-shadow: 0 18px 60px rgba(0,0,0,.55); display: flex; flex-direction: column; gap: 12px;
            }
            #aetheria-idle .ai-head { font-size: 14px; font-weight: 700; color: var(--at-acc); }
            #aetheria-idle .ai-head small { font-weight: 500; font-size: 10.5px; color: #a1a1aa; margin-left: 8px; }
            #aetheria-idle .ai-who { display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; }
            #aetheria-idle .ai-who b { font-size: 20px; }
            #aetheria-idle .ai-who span { color: #a1a1aa; font-size: 12px; }
            #aetheria-idle .ai-who em { font-style: normal; font-size: 12px; color: var(--at-acc2); margin-left: auto; }
            #aetheria-idle .ai-status { padding: 9px 12px; border-radius: 10px; font-size: 13px; font-weight: 600; background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.1); }
            #aetheria-idle .ai-status.ok { background: rgba(var(--at-acc-rgb), .14); border-color: rgba(var(--at-acc-rgb), .4); color: var(--at-acc); }
            #aetheria-idle .ai-status.warn { background: rgba(251,146,60,.14); border-color: rgba(251,146,60,.5); color: #fdba74; }
            #aetheria-idle .ai-status.bad { background: rgba(248,113,113,.14); border-color: rgba(248,113,113,.5); color: #fca5a5; }
            #aetheria-idle .ai-bars { font-size: 11.5px; color: #d4d4d8; min-height: 14px; }
            #aetheria-idle .ai-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
            #aetheria-idle .ai-grid .ap-card b { font-size: 13px; }
            #aetheria-idle .ai-grid .ai-wide { grid-column: 1 / -1; }
            #aetheria-idle .ai-grid .ai-prem-on b { color: #fcd34d; }
            #aetheria-idle .ai-btns { display: flex; gap: 8px; justify-content: center; flex-wrap: wrap; }
            #aetheria-idle .ai-btns button { pointer-events: auto; cursor: pointer; padding: 8px 16px; }
            @media (max-width: 520px) { #aetheria-idle .ai-grid { grid-template-columns: repeat(2, 1fr); } }
            .ap-scroll { flex: 1; min-height: 0; overflow-y: auto; padding: 4px 8px 6px; display: flex; flex-direction: column; gap: 6px; }
            .ap-sec { border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 10px; background: rgba(var(--at-bg2-rgb), calc(0.35 * var(--at-op))); }
            .ap-sec-head {
                width: 100%; display: flex; align-items: center; gap: 6px; padding: 7px 10px; background: transparent; border: none;
                color: var(--at-acc); font-size: 12px; font-weight: 700; cursor: pointer; text-align: left;
            }
            .ap-sec-head em { margin-left: auto; font-style: normal; font-size: 11px; color: #e4e4e7; font-weight: 700; }
            #ap-rate, #ai-zh { color: var(--at-acc); }
            #aetheria-wiki { position: fixed; inset: 0; z-index: 1000000; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,.5); backdrop-filter: blur(3px); animation: at-slide-down .18s ease-out; font-family: 'Inter','Noto Sans Thai',system-ui,sans-serif; color: var(--at-text); }
            .aw-card { width: min(760px, 95vw); height: min(640px, 88vh); display: flex; flex-direction: column; background: rgba(var(--at-bg-rgb), .98); border: 1px solid rgba(var(--at-acc-rgb), .35); border-radius: 18px; box-shadow: 0 24px 70px rgba(0,0,0,.6); overflow: hidden; animation: at-win-in .24s cubic-bezier(.2,.8,.2,1); }
            .aw-tabs { display: flex; gap: 6px; padding: 10px 14px 4px; align-items: center; }
            .aw-tab { background: rgba(255,255,255,.05); border: 1px solid rgba(255,255,255,.1); color: #a1a1aa; border-radius: 9px; padding: 5px 12px; font-size: 12px; font-weight: 700; cursor: pointer; font-family: inherit; }
            .aw-tab.on { background: rgba(var(--at-acc-rgb), .16); border-color: var(--at-acc); color: var(--at-acc); }
            .aw-q { flex: 1; min-width: 0; margin-left: 6px; }
            .aw-filt { display: flex; flex-direction: column; gap: 5px; padding: 4px 14px 6px; }
            .aw-list { flex: 1; overflow-y: auto; padding: 2px 10px 12px 14px; display: flex; flex-direction: column; gap: 2px; }
            .aw-row { display: flex; align-items: center; gap: 8px; padding: 4px 6px; border-radius: 8px; background: rgba(255,255,255,.03); font-size: 12px; }
            .aw-row:hover { background: rgba(255,255,255,.06); }
            .aw-row.c, .ai2-row.c, .ap-rowc { cursor: pointer; }
            .ap-rowc:hover { background: rgba(255,255,255,.06); }
            .aw-name { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .aw-mat { font-size: 10.5px; color: #4ade80; white-space: nowrap; }
            .ap-jb { margin-left: 5px; font-size: 10px; }
            #aetheria-config input[type=checkbox], #aetheria-wiki input[type=checkbox], .aj-rar input { accent-color: var(--at-acc); }
            .aj-danger { border-color: rgba(248,113,113,.5) !important; color: #fca5a5 !important; }
            .aj-rars { display: flex; flex-wrap: wrap; gap: 4px 10px; font-size: 11px; font-weight: 700; }
            .aj-rar { display: inline-flex; align-items: center; cursor: pointer; }
            .aj-lk { font-size: 9.5px; color: #4ade80; flex: none; }
            .aj-cats { display: flex; flex-wrap: wrap; gap: 4px; }
            .aj-cat { border-radius: 99px; border: 1px solid rgba(255,255,255,.12); background: rgba(255,255,255,.05); color: #d4d4d8; font-size: 10.5px; padding: 3px 9px; cursor: pointer; font-family: inherit; }
            #at-junk-share.on { border-color: var(--at-acc); color: var(--at-acc); }
            .aj-cat.on { background: rgba(var(--at-acc-rgb), .18); border-color: var(--at-acc); color: var(--at-acc); }
            .aj-cat.zero { opacity: .45; }
            .ac-group.ac-fold > .ac-title { cursor: pointer; user-select: none; display: flex; align-items: center; gap: 6px; }
            .ac-group.ac-fold > .ac-title::after { content: '▾'; margin-left: auto; opacity: .7; font-size: 12px; transition: transform .15s; }
            .ac-group.ac-fold.fold-c > .ac-title::after { transform: rotate(-90deg); }
            .ac-group.ac-fold.fold-c > :not(.ac-title) { display: none !important; }
            .ah-pre { white-space: pre-wrap; font: 10.5px/1.45 ui-monospace, Menlo, Consolas, monospace; background: rgba(0,0,0,.32); border-radius: 8px; padding: 7px 8px; max-height: 240px; overflow: auto; margin: 0; user-select: text; color: #d4d4d8; }
            .ak-list { display: grid; grid-template-columns: 1fr; gap: 3px; max-height: 280px; overflow-y: auto; padding-right: 2px; }
            .ak-row { display: flex; align-items: center; gap: 7px; padding: 3px 6px; border-radius: 8px; background: rgba(255,255,255,.03); cursor: pointer; }
            .ak-lab { flex: 1; font-size: 11.5px; }
            .ak-min { width: 64px; background: rgba(0,0,0,.28); border: 1px solid rgba(255,255,255,.12); color: var(--at-text); border-radius: 6px; padding: 2px 5px; font-size: 11px; }
            .ah-row { display: flex; align-items: baseline; gap: 6px; padding: 2px 4px; border-radius: 6px; background: rgba(255,255,255,.03); font-size: 11px; flex-wrap: wrap; }
            .ah-txt small { color: #a1a1aa; font-size: 10px; }
            .ah-sel { font-size: 10px; color: #fca5a5; word-break: break-all; }
            .ah-note { font-size: 10px; color: #a1a1aa; }
            .aj-list { display: flex; flex-direction: column; gap: 3px; max-height: 260px; overflow-y: auto; padding-right: 2px; }
            .aj-row { display: flex; align-items: center; gap: 7px; padding: 3px 4px; border-radius: 8px; background: rgba(255,255,255,.03); }
            .aj-icon { width: 24px; height: 24px; object-fit: contain; flex: none; border-radius: 5px; }
            .aj-ph { display: inline-flex; align-items: center; justify-content: center; background: rgba(255,255,255,.08); font-size: 11px; }
            .aj-name { flex: 1; min-width: 0; font-size: 11.5px; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .ai2-mapic { display: inline-flex; width: 28px; height: 28px; align-items: center; justify-content: center; font-size: 18px; flex: none; }
            .ai2-rt { display: flex; align-items: center; gap: 8px; flex: none; }
            .at-tip { position: fixed; z-index: 1000010; display: none; max-width: 300px; pointer-events: none; background: rgba(12,10,14,.97); border: 1px solid var(--at-acc); border-radius: 9px; padding: 8px 11px; box-shadow: 0 8px 24px rgba(0,0,0,.55); font-family: 'Inter','Noto Sans Thai',system-ui,sans-serif; color: var(--at-text, #eee); font-size: 12px; line-height: 1.5; }
            .at-tip-name { font-weight: 800; font-size: 13.5px; word-break: break-word; }
            .at-tip-sub { opacity: .7; font-size: 11px; margin-bottom: 3px; }
            .at-tip-row { opacity: .92; }
            .at-tip-hd { margin-top: 5px; font-weight: 700; opacity: .85; }
            .at-tip-line { display: flex; align-items: center; gap: 7px; margin-top: 3px; }
            .at-tip-line .ap-icon { width: 22px; height: 22px; flex: none; }
            .at-tip-ln { flex: 1; min-width: 0; font-weight: 600; }
            .at-tip-rt { opacity: .75; font-size: 11px; white-space: nowrap; }
            .at-tip { max-width: 340px; }
            .aw-star { background: none; border: 1px solid rgba(255,255,255,.12); border-radius: 6px; color: #94a3b8; cursor: pointer; font-size: 14px; padding: 1px 6px; flex: none; }
            .aw-star.on { color: #facc15; border-color: #facc15; }
            .aj-bts { display: flex; gap: 3px; flex: none; }
            .aj-b { width: 26px; height: 24px; border-radius: 6px; border: 1px solid rgba(255,255,255,.1); background: rgba(255,255,255,.04); cursor: pointer; font-size: 12px; opacity: .55; padding: 0; }
            .aj-b:hover { opacity: 1; }
            .aj-b.on { opacity: 1; }
            .aj-b.on.junk { background: rgba(248,113,113,.25); border-color: #f87171; }
            .aj-b.on.keep { background: rgba(96,165,250,.22); border-color: #60a5fa; }
            .aj-b.on.never { background: rgba(74,222,128,.2); border-color: #4ade80; }
            .ap-adv { margin: 8px 12px 0; padding: 7px 9px; border-radius: 10px; font-size: 11px; line-height: 1.55; color: #d4d4d8; background: rgba(var(--at-acc-rgb), .07); border: 1px solid rgba(var(--at-acc-rgb), .22); }
            .ap-adv b { color: var(--at-acc); }
            .ap-adv .up { color: #4ade80; font-weight: 700; }
            .ap-adv .down { color: #fb923c; font-weight: 700; }
            .ap-sec-body { display: none; padding: 0 4px 6px; }
            .ap-sec.open .ap-sec-body { display: block; }
            .ap-row { display: flex; align-items: center; gap: 8px; padding: 5px 6px; border-radius: 8px; }
            .ap-row:hover { background: rgba(255, 255, 255, 0.05); }
            .ap-clickable { cursor: pointer; }
            .ap-icon.ap-clickable:hover { filter: brightness(1.25); transform: scale(1.06); }
            .ap-name.ap-clickable:hover { text-decoration: underline; }
            #aetheria-info { position: fixed; inset: 0; z-index: 1000001; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,.55); backdrop-filter: blur(3px); animation: at-slide-down .18s ease-out; font-family: 'Inter','Noto Sans Thai',system-ui,sans-serif; color: var(--at-text); }
            .ai2-card { width: min(520px, 94vw); max-height: 86vh; display: flex; flex-direction: column; background: rgba(var(--at-bg-rgb), .98); border: 1px solid rgba(var(--at-acc-rgb), .35); border-radius: 18px; box-shadow: 0 24px 70px rgba(0,0,0,.6); overflow: hidden; animation: at-win-in .24s cubic-bezier(.2,.8,.2,1); }
            .ai2-bar { display: flex; align-items: center; gap: 10px; padding: 10px 14px; border-bottom: 1px solid rgba(255,255,255,.08); font-size: 11px; color: #a1a1aa; }
            .ai2-src { flex: 1; }
            .ai2-x, .ai2-back { background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.1); color: var(--at-text); border-radius: 8px; padding: 3px 9px; cursor: pointer; font-size: 11px; }
            .ai2-x:hover, .ai2-back:hover { border-color: var(--at-acc); color: var(--at-acc); }
            .ai2-body { padding: 14px 16px 18px; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; user-select: text; }
            .ai2-title { display: flex; align-items: center; gap: 12px; }
            .ai2-title .ap-icon, .ap-icon.big { width: 46px; height: 46px; }
            .ap-icon.sm { width: 26px; height: 26px; flex: none; }
            .ai2-left { display: flex; align-items: center; gap: 8px; min-width: 0; }
            .ai2-title b { font-size: 17px; display: block; }
            .ai2-title small { color: #a1a1aa; font-size: 11px; }
            .ai2-chips { display: flex; flex-wrap: wrap; gap: 6px; }
            .ai2-chip { background: rgba(255,255,255,.07); border: 1px solid rgba(255,255,255,.1); border-radius: 7px; padding: 2px 8px; font-size: 11px; font-family: ui-monospace, monospace; }
            .ai2-h { font-size: 12.5px; font-weight: 700; color: var(--at-acc); margin-top: 4px; }
            .ai2-list { display: flex; flex-direction: column; gap: 2px; }
            .ai2-row { display: flex; justify-content: space-between; align-items: center; gap: 10px; padding: 5px 8px; border-radius: 8px; background: rgba(255,255,255,.03); font-size: 12px; }
            .ai2-row:hover { background: rgba(255,255,255,.06); }
            .ai2-col { display: flex; flex-direction: column; min-width: 0; }
            .ai2-sub { color: #a1a1aa; font-size: 11px; white-space: nowrap; }
            .ai2-col .ai2-sub { white-space: normal; }
            .ai2-muted { color: #71717a; font-size: 11.5px; padding: 4px 8px; }
            .ai2-link { background: none; border: none; color: var(--at-text); font: inherit; font-weight: 600; cursor: pointer; padding: 0; text-align: left; }
            .ai2-link:hover { text-decoration: underline; color: var(--at-acc); }
            .ap-rm { background: none; border: 1px solid transparent; color: #71717a; font-size: 10px; border-radius: 6px; padding: 2px 5px; cursor: pointer; opacity: 0; }
            .ap-row:hover .ap-rm, .ap-rm.arm { opacity: 1; }
            .ap-rm:hover { color: #fca5a5; border-color: rgba(248,113,113,.4); }
            .ap-rm.arm { color: #fca5a5; border-color: rgba(248,113,113,.6); background: rgba(248,113,113,.12); }
            .ap-icon { width: 30px; height: 30px; object-fit: contain; flex: none; border-radius: 6px; background: rgba(var(--at-bg0-rgb), calc(0.7 * var(--at-op))); border: 1px solid rgba(255, 255, 255, 0.05); }
            .ap-icon-ph { display: flex; align-items: center; justify-content: center; font-size: 11px; color: #a1a1aa; }
            .ap-mid { flex: 1; min-width: 0; }
            .ap-name { font-weight: 700; color: var(--at-text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .ap-sub { font-size: 10.5px; color: #a1a1aa; }
            .ap-sum { font-weight: 700; color: var(--at-acc); white-space: nowrap; font-size: 12px; }
            .ap-empty { padding: 14px 12px; text-align: center; font-size: 11.5px; color: #71717a; line-height: 1.5; white-space: pre-line; }
            .ap-foot { display: flex; gap: 6px; padding: 6px 12px; border-top: 1px solid rgba(255, 255, 255, 0.06); }
            .ap-btn {
                flex: 1; background: rgba(var(--at-bg2-rgb), calc(0.8 * var(--at-op))); color: #e4e4e7; border: 1px solid rgba(255, 255, 255, 0.12);
                padding: 6px; border-radius: 8px; font-size: 11px; font-weight: 600; cursor: pointer; transition: background 0.15s ease;
            }
            .ap-btn:hover { background: rgba(52, 52, 60, 0.9); }
            .ap-btn.danger { color: #f87171; border-color: rgba(248, 113, 113, 0.35); }
            .ap-btn.danger:hover { background: rgba(248, 113, 113, 0.16); }
            .ap-note { padding: 0 14px 10px; font-size: 10px; color: #71717a; line-height: 1.45; }
            .ap-note.warn { color: var(--at-acc); }

            /* ---------- Floating windows (DPS / Logs) ---------- */
            .aw {
                position: fixed; z-index: 999997; display: none; flex-direction: column;
                font-family: 'Inter', 'Noto Sans Thai', system-ui, sans-serif; font-size: 12.5px; color: var(--at-text);
                background: rgba(var(--at-bg-rgb), calc(0.94 * var(--at-op))); backdrop-filter: blur(16px);
                border-radius: 16px; border: 1px solid rgba(255, 255, 255, 0.1);
                box-shadow: 0 20px 45px -15px rgba(var(--at-bg0-rgb), calc(0.85 * var(--at-op))); overflow: hidden; user-select: none;
            }
            #aetheria-dps { left: 20px; top: 120px; width: 300px; }
            #aetheria-logs { left: 20px; top: 420px; width: 400px; max-height: 360px; }
            .aw-header {
                display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 9px 12px;
                background: linear-gradient(180deg, rgba(var(--at-bg2-rgb), calc(0.95 * var(--at-op))), rgba(var(--at-bg-rgb), calc(0.95 * var(--at-op))));
                border-bottom: 1px solid rgba(255, 255, 255, 0.07); font-weight: 700; font-size: 13px; color: #f87171;
                cursor: grab; touch-action: none;
            }
            .aw-header:active { cursor: grabbing; }
            .aw-chip { font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 99px; background: rgba(255, 255, 255, 0.06); color: #a1a1aa; border: 1px solid rgba(255, 255, 255, 0.12); white-space: nowrap; }
            .aw-chip.on { background: rgba(var(--at-acc-rgb), 0.16); color: var(--at-acc); border-color: rgba(var(--at-acc-rgb), 0.35); }
            .aw-x { background: transparent; border: none; color: #a1a1aa; cursor: pointer; font-size: 13px; padding: 0 2px; }
            .aw-x:hover { color: #fff; }
            .ad-setting { padding: 6px 12px; font-size: 10.5px; border-bottom: 1px solid rgba(255, 255, 255, 0.05); }
            .ad-setting.ok { color: var(--at-acc); }
            .ad-setting.warn { color: #fb923c; }
            .ad-body { padding: 10px 12px; display: flex; flex-direction: column; gap: 8px; }
            .ad-big { display: flex; align-items: baseline; gap: 8px; }
            .ad-big b { font-size: 30px; line-height: 1; color: var(--at-acc); font-weight: 800; }
            .ad-big small { color: #a1a1aa; font-size: 11px; }
            .ad-big span { margin-left: auto; color: #a1a1aa; font-size: 11px; }
            .ad-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 4px 12px; }
            .ad-grid div { display: flex; justify-content: space-between; font-size: 11.5px; }
            .ad-grid span { color: #a1a1aa; }
            .ad-grid b { color: var(--at-text); }
            .ad-src { display: flex; flex-direction: column; gap: 4px; }
            .ad-src-row { position: relative; padding: 3px 8px; border-radius: 6px; background: rgba(var(--at-bg2-rgb), calc(0.6 * var(--at-op))); overflow: hidden; display: flex; justify-content: space-between; font-size: 11.5px; }
            .ad-src-row i { position: absolute; left: 0; top: 0; bottom: 0; background: rgba(var(--at-acc-rgb), 0.18); }
            .ad-src-row span, .ad-src-row small { position: relative; }
            .ad-src-row small { color: #d4d4d8; }
            .ad-stats { font-size: 10.5px; color: #a1a1aa; }
            .ad-empty { padding: 14px 6px; text-align: center; color: #71717a; font-size: 11.5px; line-height: 1.5; white-space: pre-line; }
            .ad-note { padding: 0 12px 10px; font-size: 10px; color: #71717a; line-height: 1.45; }
            .al-tools { display: flex; align-items: center; gap: 4px; padding: 6px 10px; border-bottom: 1px solid rgba(255, 255, 255, 0.05); flex-wrap: wrap; }
            .al-chip { background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); color: #d4d4d8; border-radius: 99px; font-size: 10.5px; padding: 2px 8px; cursor: pointer; }
            .al-chip.active { background: rgba(var(--at-acc-rgb), 0.18); border-color: var(--at-acc); color: var(--at-acc); }
            .al-list { flex: 1; min-height: 80px; overflow-y: auto; padding: 4px 8px; font-family: ui-monospace, 'Cascadia Mono', Menlo, monospace; font-size: 11px; user-select: text; }
            .al-row { display: flex; gap: 6px; padding: 1px 0; line-height: 1.45; }
            .al-t { color: #71717a; flex: none; }
            .al-tag { flex: none; min-width: 52px; color: #a1a1aa; font-weight: 700; }
            .al-msg { color: #e4e4e7; word-break: break-word; }
            .al-row.ok .al-msg { color: var(--at-acc); }
            .al-row.warn .al-msg { color: #fb923c; }
            .al-row.err .al-msg { color: #f87171; }
            .al-row.gain .al-msg { color: #86efac; }
            .al-foot { display: flex; gap: 6px; padding: 6px 10px; border-top: 1px solid rgba(255, 255, 255, 0.06); align-items: center; }
            .al-foot .at-btn-ghost { flex: 1; }
            .al-count { font-size: 10.5px; color: #71717a; }
            #aetheria-dps-notice {
                position: fixed; inset: 0; z-index: 1000001; display: flex; align-items: center; justify-content: center;
                background: rgba(var(--at-bg0-rgb), calc(0.55 * var(--at-op))); font-family: 'Inter', 'Noto Sans Thai', system-ui, sans-serif; color: var(--at-text);
            }
            .an-card {
                width: 360px; max-width: calc(100vw - 32px); background: rgba(var(--at-bg1-rgb), calc(0.98 * var(--at-op))); border: 1px solid rgba(var(--at-acc-rgb), 0.35);
                border-radius: 16px; padding: 16px; box-shadow: 0 25px 60px rgba(var(--at-bg0-rgb), calc(0.7 * var(--at-op))); font-size: 12.5px; line-height: 1.55;
            }
            .an-card h3 { margin: 0 0 8px; font-size: 14px; color: var(--at-acc); }
            .an-card p { margin: 0 0 8px; color: #e4e4e7; }
            .an-card small { color: #a1a1aa; display: block; margin-bottom: 8px; }
            .an-actions { display: flex; gap: 8px; margin-top: 10px; }
            .an-actions button { flex: 1; }
        `;
        document.head.appendChild(style);
    }

    // ---------------------------------------------------------------
    // Main panel
    // ---------------------------------------------------------------
    function positionConfig() {
        relayoutAll();
    }

    function updateSettingsVisibility() {
        if (!uiRefs.config || !uiRefs.settingsBtn) return;
        const vis = (v) => uiRefs.config.classList.toggle('open', v);
        if (State.isSettingsOpen === uiRefs.config.classList.contains('open') && uiRefs.config.dataset.closing !== '1') { /* ไม่เปลี่ยน */ }
        else (State.isSettingsOpen ? Anim.show : Anim.hide)(uiRefs.config, vis);
        uiRefs.settingsBtn.classList.toggle('active', State.isSettingsOpen);
        relayoutAll(!State.isSettingsOpen);
    }

    function bindSwitch(id, getter, setter) {
        const el = document.getElementById(id);
        if (!el) return;
        el.addEventListener('click', (e) => {
            e.stopPropagation();
            const next = !getter();
            setter(next);
            el.classList.toggle('on', next);
            updateAutoSum();
        });
    }

    function updateAutoSum() {
        const el = document.getElementById('at-auto-sum');
        if (el) setT(el, `Z ${State.isAutoEnabled ? 'เปิด' : 'ปิด'} · กลับเมือง ${State.isReviveEnabled ? 'เปิด' : 'ปิด'}`);
    }

    function toggleProfit(force) {
        State.isProfitOpen = typeof force === 'boolean' ? force : !State.isProfitOpen;
        savePrefs();
        if (pRefs.panel) (State.isProfitOpen ? Anim.show : Anim.hide)(pRefs.panel, (v) => { pRefs.panel.style.display = v ? 'flex' : 'none'; });
        if (uiRefs.profitBtn) uiRefs.profitBtn.classList.toggle('active', State.isProfitOpen);
        if (State.isProfitOpen) {
            pRefs.secRev = {};
            renderProfit();
            positionProfitPanel();
        }
        relayoutAll(!State.isProfitOpen);
    }

    function updateDiscordUI() {
        if (!uiRefs.swDc) return;
        uiRefs.swDc.classList.toggle('on', State.discordOn);
        const active = Object.keys(State.dcTopics).filter((k) => State.dcTopics[k]).length;
        setT(uiRefs.dcSum, State.discordOn ? `เปิดอยู่ · ${active} หัวข้อ` : 'ปิดอยู่');
        if (uiRefs.config) uiRefs.config.querySelectorAll('input[data-topic]').forEach((cb) => { cb.checked = !!State.dcTopics[cb.dataset.topic]; });
    }

    // กล่องหัวข้อใน Config พับ/กางได้ (กดที่ชื่อหัวข้อ) · จำสถานะไว้ · กล่องออฟชั่นพับไว้ก่อนเพราะยาว
    const FOLD_KEY = 'at_cfg_fold';
    function foldGroups(cfg) {
        let st = {};
        try { st = JSON.parse(localStorage.getItem(FOLD_KEY) || '{}') || {}; } catch (e) { st = {}; }
        cfg.querySelectorAll('.ac-pane').forEach((pane) => {
            pane.querySelectorAll(':scope > .ac-group').forEach((g) => {
                const title = g.querySelector(':scope > .ac-title');
                if (!title) return;
                const key = pane.dataset.pane + ':' + title.textContent.replace(/\s+/g, ' ').trim().slice(0, 40);
                g.classList.add('ac-fold');
                g.classList.toggle('fold-c', key in st ? !!st[key] : /ออฟชั่น \(Option\)/.test(key));
                title.addEventListener('click', (e) => {
                    if (e.target.closest('button, input, a')) return;
                    e.stopPropagation();
                    const c = g.classList.toggle('fold-c');
                    st[key] = c ? 1 : 0;
                    try { lsSet(FOLD_KEY, JSON.stringify(st)); } catch (er) { /* ignore */ }
                });
            });
        });
    }

    function switchCfgTab(tab) {
        State.cfgTab = tab;
        Store.set('at_cfg_tab', tab);
        if (!uiRefs.config) return;
        uiRefs.config.querySelectorAll('.ac-tab').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
        uiRefs.config.querySelectorAll('.ac-pane').forEach((p) => {
            const on = p.dataset.pane === tab;
            const was = p.classList.contains('on');
            p.classList.toggle('on', on);
            if (on && !was && p.dataset.pane === 'junk') { renderJunkList(); renderJunkStat(); }
            if (on && !was && p.dataset.pane === 'health') renderHealth();
            if (on && !was && Anim.ok()) p.animate([{ opacity: 0, transform: 'translateY(-12px)' }, { opacity: 1, transform: 'translateY(0)' }], { duration: 260, easing: 'cubic-bezier(.2,.8,.2,1)' });
        });
    }

    function buildPanel() {
        if (document.getElementById('aetheria-tracker')) return;
        injectStyles();
        applyTheme();
        applyPerf();

        for (const k of Object.keys(renderedState)) delete renderedState[k];
        const oldCfg = document.getElementById('aetheria-config');
        if (oldCfg) oldCfg.remove();

        let toastCont = document.getElementById('at-toast-container');
        if (!toastCont) {
            toastCont = document.createElement('div');
            toastCont.id = 'at-toast-container';
            document.body.appendChild(toastCont);
        }
        uiRefs.toastContainer = toastCont;

        const panel = document.createElement('div');
        panel.id = 'aetheria-tracker';
        if (State.isMinimized) panel.classList.add('minimized');
        panel.style.left = State.panelX;
        panel.style.top = State.panelY;

        panel.innerHTML = `
            <div class="at-header" id="at-drag-handle">
                <div class="at-brand">
                    <span class="at-brand-t">🧭 Aetherack</span>
                    <span class="at-brand-s">BETA v${VERSION} · by JokeeBot</span>
                </div>
                <div class="at-header-actions">
                    <button class="at-icon-btn" id="at-btn-profit" title="Profit / ไอเทม / มอนที่ฆ่า / สถิติ">💰</button>
                    <button class="at-icon-btn" id="at-btn-wiki" title="Wiki ของเกม (ไอเทม / มอนสเตอร์ / ตั้งค่าไอเทมที่ไม่ทิ้ง)">📖</button>
                    <button class="at-icon-btn" id="at-btn-dev" title="Dev Mode: ตรวจช่อง x,z / NPC / จุดมอนเกิด (Alt+D)">🧪</button>
                    <button class="at-icon-btn" id="at-btn-pause" title="หยุด/เริ่มระบบอัตโนมัติทั้งหมด (Alt+X)">⏸️</button>
                    <button class="at-icon-btn" id="at-btn-logs" title="Logs ของสคริปต์ (แท็บแยก ลากได้)">📜</button>
                    <button class="at-icon-btn" id="at-btn-settings" title="Config: Sheets / Discord / ออโต้ / หน้าจอ">⚙️</button>
                    <span class="at-hsep"></span>
                    <button class="at-icon-btn" id="at-btn-min" title="ย่อ/ขยาย"></button>
                </div>
            </div>

            <div class="at-statusbar">
                <div class="at-status-indicator">
                    <span id="at-status-dot" class="at-dot at-dot-warn"></span>
                    <span id="at-status-text"></span>
                </div>
                <span class="at-sb-r"><span id="at-town-chip" class="at-town-chip" style="display:none"></span><span id="at-lastupdate">--:--:--</span></span>
            </div>

            <div class="at-body">
                <div class="at-hero-card">
                    <div class="at-char-left">
                        <div class="at-avatar" id="at-avatar">👤</div>
                        <div class="at-char-main">
                            <div class="at-char-name" id="at-name">—</div>
                            <div class="at-char-class" id="at-class">—</div>
                        </div>
                    </div>
                    <div class="at-lv-pills">
                        <div class="at-pill"><span>Base</span><b id="at-baselv">—</b></div>
                        <div class="at-pill"><span>Job</span><b id="at-joblv">—</b></div>
                    </div>
                </div>

                <div class="at-weight-card">
                    <div class="at-stat-label" style="display:flex; justify-content:space-between;">
                        <span>⚖️ น้ำหนักกระเป๋า</span>
                        <b id="at-weight" style="color:#f4f4f5;">—</b>
                    </div>
                    <div class="at-progress-track">
                        <div class="at-progress-fill" id="at-weight-bar"></div>
                    </div>
                </div>

                <div class="at-grid-2">
                    <div class="at-stat-box">
                        <span class="at-stat-label">💰 Zeny</span>
                        <div class="at-stat-val at-zeny-val" id="at-zeny">—</div>
                    </div>
                    <div class="at-stat-box">
                        <span class="at-stat-label">🎒 ช่องเก็บของ</span>
                        <div class="at-stat-val" id="at-slots">—</div>
                    </div>
                </div>

                <div class="at-info-list">
                    <div class="at-info-item">
                        <span>💎 บัฟพรีเมียม</span>
                        <div class="at-buff-badge empty" id="at-buff-badge">
                            <img id="at-buff-icon" class="at-buff-icon" src="" style="display:none;" />
                            <span id="at-buff-text">ตรวจสอบ...</span>
                        </div>
                    </div>
                    <div class="at-info-item">
                        <span>🗺️ แผนที่</span>
                        <b id="at-map" style="color:#f4f4f5;">—</b>
                    </div>
                    <div class="at-info-item">
                        <span>📡 แชนแนล</span>
                        <b id="at-channel" style="color:var(--at-acc);">—</b>
                    </div>
                    <div class="at-info-item">
                        <span>📶 Ping</span>
                        <div class="at-ping" id="at-ping" title="กำลังวัด…">
                            <i class="at-ping-dot" id="at-ping-dot"></i>
                            <b id="at-ping-text">—</b>
                        </div>
                    </div>
                    <div class="at-info-item">
                        <span>🤖 ออโต้</span>
                        <b id="at-auto-sum" style="color:#a1a1aa;font-weight:600">—</b>
                    </div>
                    <div class="at-info-item" id="at-boss-row" style="display:none">
                        <span>👹 บอสถัดไป</span>
                        <b id="at-boss-next" style="color:#f59e0b;font-size:11px">—</b>
                    </div>
                    <div class="at-info-item" id="at-pause-row" style="display:none">
                        <span>⏸️ ระบบอัตโนมัติ</span>
                        <b id="at-pause-txt" style="color:#fb923c;font-size:11px">—</b>
                    </div>
                    <div class="at-info-item" id="at-town-row" style="display:none">
                        <span>🏙️ อยู่ในเมืองมา</span>
                        <b id="at-town-time" style="color:#fb923c">—</b>
                    </div>
                </div>

                <button class="at-btn-ghost at-r3-btn" id="at-reload-all" type="button" title="รีโหลดหน้าเกมทุกจอ (ทุกแท็บ ทุก Container) เพื่อใช้สคริปต์เวอร์ชันใหม่ — แต่ละจอทยอยรีโหลดภายใน ~20 วินาที">🔄 รีโหลดทุกจอ (อัปเดตสคริปต์)</button>
                <button class="at-btn-ghost at-r3-btn" id="at-resume-btn" type="button" title="วาร์ปไปแมพฟาร์มล่าสุด → ใช้ Fly Wing หาโซน (ถ้าเปิดไว้) → เปิด Auto · ยกเลิกการหยุดชั่วคราวด้วย">▶️ กลับไปฟาร์มต่อ</button>
                <button class="at-btn-ghost at-r3-btn" id="at-r3-btn" type="button">🌙 ปิดภาพ 3D (ประหยัดเครื่อง)</button>
                <button class="at-send-btn" id="at-send-now">
                    <span>🚀 ซิงค์ข้อมูลเข้า Sheet ทันที</span>
                </button>
            </div>
        `;
        document.body.appendChild(panel);

        // ---------- หน้าต่าง Config (แยกเป็นหมวด) ----------
        const cfg = document.createElement('div');
        cfg.id = 'aetheria-config';
        cfg.innerHTML = `
            <div class="ac-header" id="ac-drag">
                <span>⚙️ Config</span>
                <span style="display:flex;gap:4px"><button class="at-icon-btn" id="ac-help" title="แสดง/ซ่อนคำอธิบายแบบเต็ม (ปกติชี้หรือกดที่ ? เพื่อดู)">📖</button><button class="at-icon-btn" id="ac-close" title="ปิด">✕</button></span>
            </div>
            <div class="ac-tabs">
                <button class="ac-tab" data-tab="sheets">📄 Sheets</button>
                <button class="ac-tab" data-tab="discord">🔔 Discord</button>
                <button class="ac-tab" data-tab="auto">🤖 ออโต้</button>
                <button class="ac-tab" data-tab="junk">🗑️ ขยะ</button>
                <button class="ac-tab" data-tab="watch">🛡️ เฝ้าระวัง</button>
                <button class="ac-tab" data-tab="boss">👹 บอส</button>
                <button class="ac-tab" data-tab="theme">🎨 ธีม</button>
                <button class="ac-tab" data-tab="ui">🖥️ หน้าจอ</button>
                <button class="ac-tab" data-tab="health">🩺 ตรวจสุขภาพ</button>
            </div>
            <div class="ac-body">
                <section class="ac-pane" data-pane="sheets">
                    <div class="ac-group">
                        <div class="ac-title">🔗 Google Sheets</div>
                        <span class="ac-l">Google Apps Script Web App URL</span>
                        <div class="at-url-group">
                            <input type="text" class="at-input" id="at-url-input" placeholder="https://script.google.com/macros/s/..." />
                            <button class="at-btn-primary" id="at-url-save">บันทึก</button>
                        </div>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🎒 การซิงค์</div>
                        <div class="at-toggle-row"><span>ซิงค์กระเป๋าอัตโนมัติ</span><div class="at-switch" id="at-sw-sync"></div></div>
                        <span class="ac-l">เปิดหน้าต่างกระเป๋าเองเป็นระยะเพื่ออ่านน้ำหนัก/ช่อง แล้วส่งเข้า Sheet</span>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">💾 สำรอง / กู้คืนข้อมูล</div>
                        <span class="ac-l">⚙️ ส่งออกเฉพาะการตั้งค่า → ไปกด ⬆️ นำเข้า ใน Chrome/โปรไฟล์อื่น = ได้การตั้งค่าทุกตัวละคร (Webhook · โซน · รายการซื้อ · อัพสเตตัส ฯลฯ) ไม่ต้องตั้งใหม่ · </span>
                        <span class="ac-l">สำรองการตั้งค่า (Sheets URL, Webhook, ธีม ฯลฯ) + สถิติ + Profit ทุกตัวละครเป็นไฟล์ JSON</span>
                        <div class="at-url-group">
                            <button class="at-btn-primary" id="at-bk-export" title="ทุกอย่าง: การตั้งค่า + สถิติ + Profit ทุกตัวละคร">⬇️ ส่งออกทั้งหมด</button>
                            <button class="at-btn-primary" id="at-bk-export-set" title="เฉพาะการตั้งค่า (ไม่มี Profit/สถิติ) — ใช้ย้ายไป Chrome หรือโปรไฟล์อื่น ตั้งครั้งเดียวแล้วนำเข้าทุกตัว">⚙️ ส่งออกเฉพาะการตั้งค่า</button>
                            <button class="at-btn-ghost" id="at-bk-import">⬆️ นำเข้า</button>
                        </div>
                        <input type="file" id="at-bk-file" accept="application/json,.json" style="display:none" />
                    </div>
                </section>

                <section class="ac-pane" data-pane="discord">
                    <div class="ac-group">
                        <div class="ac-title">🔗 การเชื่อมต่อ <em id="ac-dc-sum"></em></div>
                        <div class="at-toggle-row"><span>เปิดแจ้งเตือน Discord</span><div class="at-switch" id="at-sw-dc"></div></div>
                        <span class="ac-l">Webhook URL</span>
                        <input type="text" class="at-input" id="at-dc-url" placeholder="https://discord.com/api/webhooks/..." />
                        <div class="at-url-group">
                            <button class="at-btn-primary" id="at-dc-save">💾 บันทึก</button>
                            <button class="at-btn-ghost" id="at-dc-test">📨 ทดสอบ</button>
                        </div>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🛰️ สถานะสดใน Discord</div>
                        <div class="at-toggle-row"><span>แสดงสถานะตัวละครที่ออนไลน์</span><div class="at-switch" data-opt="statusLive"></div></div>
                        <div class="at-toggle-row"><span>⭐ ตั้งตัวนี้เป็นไอดีหลัก (ขึ้นบนสุด + หัวข้อไอดีหลัก)</span><div class="at-switch" data-opt="mainId"></div></div>
                        <button class="at-btn-ghost" id="at-live-peers-btn">👥 ตัวละครที่สคริปต์เห็น ▸</button>
                        <div class="ac-l" id="at-live-peers" style="display:none">…</div>
                        <span class="ac-l">ข้อความเดียวที่แก้ไขทับตลอด (ทุก ~20 วินาที) แสดงชื่อ แมพ สถานะ Profit EXP และบอสที่กำลังจะเกิด · รวมทุกแท็บ/ตัวละครที่เปิดในเบราว์เซอร์นี้</span>
                        <div class="at-toggle-row"><span>📱 แบบย่อ (ตัวละครละ 1 บรรทัด อ่านง่ายบนมือถือ)</span><div class="at-switch" data-opt="statusCompact"></div></div>
                        <div class="at-toggle-row"><span>กล่องบอสเกิด (แยกข้อความ)</span><div class="at-switch" data-opt="bossBoard"></div></div>
                        <div class="at-toggle-row"><span>🖥️ เชื่อมต่อโปรแกรม Aetherack Manager (ในเครื่อง)</span><div class="at-switch" data-opt="hubOn"></div></div>
                        <span class="ac-l">ส่งสถานะตัวละครให้โปรแกรม Aetherack Manager ที่รันในเครื่องนี้ (127.0.0.1:17321) ทุก ~3 วินาที และรับคำสั่งจากหน้ารวม (ปิด/เปิด 3D, หยุด/ทำต่อ, กลับฟาร์ม, ย้าย CH, รีโหลด) · ถ้าไม่ได้เปิดโปรแกรมไว้ สคริปต์จะลองใหม่ห่างขึ้นเรื่อย ๆ ไม่กินเครื่อง</span>
                        <div class="at-toggle-row"><span>🛰️ รวมกล่องสถานะข้าม Chrome/โปรไฟล์ (ผ่าน Apps Script)</span><div class="at-switch" data-opt="relayOn"></div></div>
                        <span class="ac-l">เปิด Chrome หลายตัว (หรือ Firefox หลายโปรไฟล์) ซึ่งข้อมูลไม่แชร์กัน → ส่งสถานะผ่าน Google Apps Script (Web App URL เดียวกับแท็บ 📄 Sheets) ให้กล่องสถานะ Discord รวมเป็นข้อความเดียว · ต้องอัปเดตโค้ด Apps Script เป็นรุ่นใหม่ (ไฟล์ aetherack-zones-sync.gs) แล้ว Deploy ใหม่ · ทุกตัวต้องตั้ง Web App URL เดียวกัน (นำเข้าการตั้งค่าได้)</span>
                        <span class="ac-l">Webhook ห้องสถานะ (เว้นว่าง = ใช้ Webhook ด้านบน)</span>
                        <input type="text" class="at-input" id="at-dc-status-url" placeholder="https://discord.com/api/webhooks/..." />
                        <div class="at-url-group">
                            <button class="at-btn-primary" id="at-dc-status-save">💾 บันทึก</button>
                            <button class="at-btn-primary" id="at-dc-status-now">🔄 อัปเดตกล่องสถานะตอนนี้</button>
                            <button class="at-btn-ghost" id="at-dc-status-reset">♻️ สร้างกล่องสถานะใหม่</button>
                            <button class="at-btn-ghost" id="at-dc-boss-reset">♻️ สร้างกล่องบอสใหม่</button>
                        </div>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🌙 ช่วงเวลาไม่รบกวน</div>
                        <div class="at-toggle-row"><span>ไม่แท็ก (Ping) ในช่วงเวลาที่ตั้ง</span><div class="at-switch" data-opt="quietOn"></div></div>
                        <span class="ac-l">ข้อความยังส่งเข้า Discord ตามปกติ แค่ไม่แท็กคุณ · ยกเว้นเรื่องด่วน (🧩 แคปช่า · ⛓️ ติดคุก · 📡 หลุดการเชื่อมต่อ) ยังแท็กเสมอ · ตั้งแต่ <b data-optv="quietFrom"></b> ถึง <b data-optv="quietTo"></b></span>
                        <input type="range" data-opt="quietFrom" data-unit="นาฬิกา" min="0" max="23" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <input type="range" data-opt="quietTo" data-unit="นาฬิกา" min="0" max="23" step="1" style="width:100%;accent-color:var(--at-acc)" />
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">📅 สรุปประจำวัน</div>
                        <div class="at-toggle-row"><span>ส่งสรุปผลของวันนี้เข้า Discord วันละครั้ง</span><div class="at-switch" data-opt="daily"></div></div>
                        <span class="ac-l">ส่งตอนเวลา ≥ <b data-optv="dailyHour"></b> (ครั้งเดียวต่อวัน ต่อตัวละคร) · สรุป Zeny ฆ่ามอน EXP แมพที่ฟาร์ม และขยะที่ทิ้งไป · ต้องเปิดหัวข้อ 📅 ด้านล่างด้วย</span>
                        <input type="range" data-opt="dailyHour" data-unit="นาฬิกา" min="0" max="23" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <button class="at-btn-ghost" id="at-daily-now">📅 ส่งสรุปวันนี้ตอนนี้</button>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">📣 หัวข้อแจ้งเตือน</div>
                        <label class="at-check"><input type="checkbox" data-topic="death" /> 💀 ตัวละครตาย</label>
                        <label class="at-check"><input type="checkbox" data-topic="town" /> 🏙️ กดกลับเมืองหลวงอัตโนมัติแล้ว</label>
                        <label class="at-check"><input type="checkbox" data-topic="warpback" /> ↩️ วาร์ปกลับแมพเดิมสำเร็จ / ไม่สำเร็จ</label>
                        <label class="at-check"><input type="checkbox" data-topic="lag" /> 📶 เซิร์ฟเวอร์กระตุกหนัก</label>
                        <label class="at-check"><input type="checkbox" data-topic="rare" /> ✨ ไอเทมดรอป (ตามตัวกรองด้านล่าง)</label>
                        <label class="at-check"><input type="checkbox" data-topic="captcha" /> 🧩 เกมขอเช็คผู้เล่น (Captcha) <b style="color:#f87171">สำคัญ</b></label>
                        <label class="at-check"><input type="checkbox" data-topic="jail" /> ⛓️ ตัวละครติดคุก / พ้นโทษ</label>
                        <label class="at-check"><input type="checkbox" data-topic="junk" /> 🗑️ ทิ้งขยะอัตโนมัติ (สรุปรายการ)</label>
                        <label class="at-check"><input type="checkbox" data-topic="stall" /> 🧟 บอทค้างในแมพฟาร์ม</label>
                        <label class="at-check"><input type="checkbox" data-topic="server" /> 📡 หลุดการเชื่อมต่อ / เซิร์ฟเวอร์รีสตาร์ท</label>
                        <label class="at-check"><input type="checkbox" data-topic="supply" /> 🎒 ของใช้/ลูกธนูใกล้หมด</label>
                        <label class="at-check"><input type="checkbox" data-topic="bag" /> 🎒 ช่องเก็บของใกล้เต็ม / เต็ม</label>
                        <label class="at-check"><input type="checkbox" data-topic="wish" /> ⭐ ได้ไอเทมที่ตามหา (Wishlist)</label>
                        <label class="at-check"><input type="checkbox" data-topic="chat" /> 💬 มีคนกระซิบ / GM ทัก</label>
                        <label class="at-check"><input type="checkbox" data-topic="digest" /> 🕒 สรุปผลฟาร์มรายชั่วโมง / ตอนกลับเมือง</label>
                        <label class="at-check"><input type="checkbox" data-topic="boss" /> 👹 บอสใกล้เกิด / เกิดแล้ว</label>
                        <label class="at-check"><input type="checkbox" data-topic="stuck" /> 🔒 กระเป๋าเต็มแต่ทิ้งอัตโนมัติไม่ได้ (วัตถุดิบ/ออฟตรง/ล็อก)</label>
                        <label class="at-check"><input type="checkbox" data-topic="daily" /> 📅 สรุปประจำวัน</label>
                        <label class="at-check"><input type="checkbox" data-topic="premium" /> ⭐ บัฟ Premium ใกล้หมด / หมดแล้ว</label>
                        <label class="at-check"><input type="checkbox" data-topic="gamever" /> 🆕 เกมอัปเดตเวอร์ชันใหม่</label>
                        <label class="at-check"><input type="checkbox" data-topic="health" /> 🩺 สคริปต์หาส่วนของเกมไม่เจอ (เกมอาจอัปเดต)</label>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🎁 ตัวกรองไอเทมที่ดรอป <em>ไม่รวมวัตถุดิบ</em></div>
                        <div class="at-toggle-row"><span>📊 แนบ stat / option ของอุปกรณ์ที่ดรอป</span><div class="at-switch" data-opt="dropStat"></div></div>
                        <span class="ac-l">เมื่ออุปกรณ์ดรอปและผ่านตัวกรองด้านล่าง สคริปต์จะเปิดกระเป๋า เลือกชิ้นนั้นอ่านค่า แล้วแนบ ATK/INT/VIT/option ฯลฯ ไปในข้อความ Discord (ปิด = ส่งทันทีแบบไม่มี stat)</span>
                        <span class="ac-l">ประเภท</span>
                        <div class="at-fgrid" id="at-cat-f">
                            <label><input type="checkbox" data-cat="all" /> ทั้งหมด</label>
                            <label><input type="checkbox" data-cat="equip" /> อุปกรณ์</label>
                            <label><input type="checkbox" data-cat="usable" /> ของใช้</label>
                            <label><input type="checkbox" data-cat="refine" /> แร่/ตีบวก</label>
                            <label><input type="checkbox" data-cat="card" /> การ์ด</label>
                        </div>
                        <span class="ac-l">ระดับความหายาก</span>
                        <div class="at-fgrid" id="at-rar-f">
                            <label><input type="checkbox" data-rar="all" /> ทั้งหมด</label>
                            <label style="color:#f3f0e8"><input type="checkbox" data-rar="common" /> ธรรมดา</label>
                            <label style="color:#86efac"><input type="checkbox" data-rar="uncommon" /> ดี</label>
                            <label style="color:#7cc4ff"><input type="checkbox" data-rar="rare" /> หายาก</label>
                            <label style="color:#c49bff"><input type="checkbox" data-rar="epic" /> มหากาพย์</label>
                            <label style="color:#ffb347"><input type="checkbox" data-rar="legendary" /> ตำนาน</label>
                        </div>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">👤 แท็ก @ ผู้ใช้ (Ping)</div>
                        <span class="ac-l">Discord User ID (ตัวเลข 17–20 หลัก)</span>
                        <input type="text" class="at-input" id="at-dc-ping" placeholder="เช่น 123456789012345678" />
                        <span class="ac-l">แท็กเมื่อ</span>
                        <label class="at-check"><input type="checkbox" data-pingdeath /> 💀 ตัวละครตาย</label>
                        <span class="ac-l">แท็กเมื่อไอเทมที่ผ่านตัวกรองมีระดับ</span>
                        <div class="at-fgrid" id="at-pingrar-f">
                            <label style="color:#f3f0e8"><input type="checkbox" data-pingrar="common" /> ธรรมดา</label>
                            <label style="color:#86efac"><input type="checkbox" data-pingrar="uncommon" /> ดี</label>
                            <label style="color:#7cc4ff"><input type="checkbox" data-pingrar="rare" /> หายาก</label>
                            <label style="color:#c49bff"><input type="checkbox" data-pingrar="epic" /> มหากาพย์</label>
                            <label style="color:#ffb347"><input type="checkbox" data-pingrar="legendary" /> ตำนาน</label>
                        </div>
                        <span class="ac-l">กด "บันทึก" ด้านบนหลังแก้ User ID</span>
                    </div>
                </section>

                <section class="ac-pane" data-pane="auto">
                    <div class="ac-group">
                        <div class="ac-title">🤖 ระบบอัตโนมัติ</div>
                        <div class="at-toggle-row"><span>💀 กลับเมืองเมื่อตาย</span><div class="at-switch" id="at-sw-revive"></div></div>
                        <span class="ac-l">กด "กลับเมืองหลวง" ให้เอง (ถ้ามี Rebirth Feather เกมจะฟื้นให้เองก่อน)</span>
                        <div class="at-toggle-row"><span>⚔️ เปิดบอท (ปุ่ม Z)</span><div class="at-switch" id="at-sw-auto"></div></div>
                        <span class="ac-l">เปิด Auto ให้เมื่ออยู่แมพฟาร์ม ไม่ต้องรอโหลดให้เสร็จ</span>
                        <div class="at-toggle-row"><span>🃏 กด "ตกลง" ป๊อปอัปการ์ดอัตโนมัติ</span><div class="at-switch" data-opt="autoCard"></div></div>
                        <span class="ac-l">เมื่อมีหน้าต่าง "ได้รับการ์ด!" เด้ง จะรอ ~1 วินาทีแล้วกดตกลงให้ (ไม่งั้นบังจอและขวางปุ่มลัด)</span>
                        <div class="at-toggle-row"><span>🎬 กด "ข้าม" ฉากเนื้อเรื่องอัตโนมัติ</span><div class="at-switch" data-opt="storySkip"></div></div>
                        <span class="ac-l">ฉากเนื้อเรื่องภาพเต็มจอที่ขึ้นหลังโหลดเกม/ตอนเข้าแมพใหม่ จะกดปุ่ม "ข้าม" ให้ทันที</span>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">⏸️ หยุดชั่วคราว / เล่นเอง</div>
                        <div class="at-toggle-row"><span>🖐️ ตรวจว่าเล่นเอง → หยุดระบบอัตโนมัติชั่วคราว</span><div class="at-switch" data-opt="manualPause"></div></div>
                        <span class="ac-l">เมื่อคุณกดปุ่มคีย์บอร์ด คลิก หรือเลื่อนล้อเมาส์ในเกมเอง จะหยุด Auto Z · วาร์ป · ซื้อของ · ทิ้งขยะ · อัพสเตตัส ฯลฯ ทันที แล้วกลับมาทำงานต่อเมื่อไม่ได้แตะเกมนาน <b data-optv="manualMin"></b> (การกดในหน้าต่างของสคริปต์ไม่นับ) · ปุ่ม ⏸️ บนแผงหลัก (Alt+X) = หยุดทั้งหมดจนกว่าจะกดอีกครั้ง</span>
                        <input type="range" data-opt="manualMin" data-unit="นาที" min="1" max="30" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <div class="at-toggle-row"><span>🧪 โหมดทดลองสำหรับระบบใหม่ (ไม่ทำจริง · บันทึกลง Logs)</span><div class="at-switch" data-opt="newDry"></div></div>
                        <span class="ac-l">ใช้กับ: 🧴 กลับไปซื้อยา/ของใช้ด้วย Butterfly Wing · 📡 ย้าย CH เมื่อไม่มีความเคลื่อนไหว · 🔄 รีเฟรชหน้าเว็บเมื่อเกมค้าง — ดูใน Logs ว่าระบบจะทำอะไร เมื่อไหร่ ถ้าถูกต้องแล้วค่อยปิดโหมดนี้</span>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🛒 ซื้อของอัตโนมัติ (Shopkeeper)</div>
                        <div class="at-toggle-row"><span>เปิดซื้อของอัตโนมัติ</span><div class="at-switch" data-opt="buyOn"></div></div>
                        <span class="ac-l">ตอนกลับมาเมืองหลวง ก่อนวาร์ปกลับแมพเดิม: ถ้าไอเทมเหลือ ≤ ค่าที่ตั้ง จะเดินไปหา Shopkeeper ซื้อตามจำนวนที่ตั้ง แล้วค่อยวาร์ปต่อ · อ่านจำนวนจากแถบด่วนก่อน ถ้าไม่มีจะเปิดกระเป๋าอ่าน</span>
                        <div style="display:grid;grid-template-columns:1fr 62px 62px 26px;gap:4px;font-size:10.5px;opacity:.75"><span>ไอเทม (ชื่อภาษาอังกฤษ)</span><span>เหลือ ≤</span><span>ซื้อ</span><span></span></div>
                        <div id="at-buy-rows" style="display:grid;grid-template-columns:1fr 62px 62px 26px;gap:4px"></div>
                        <button class="at-btn-ghost" id="at-buy-add" title="เพิ่มบรรทัดสินค้าใหม่ (ซื้อได้หลายประเภทในครั้งเดียว)">＋ เพิ่มรายการ</button>
                        <input type="text" class="at-input" id="at-buy-npc" placeholder="ชื่อ NPC ร้านค้า" title="ชื่อ NPC ร้านค้า (พิมพ์บางส่วนได้) เช่น Shopkeeper" />
                        <div class="at-toggle-row"><span>🧴 ของใช้ในรายการเหลือน้อย → ใช้ Butterfly Wing กลับไปซื้อ แล้ววาร์ปกลับ</span><div class="at-switch" data-opt="supplyRestock"></div></div>
                        <span class="ac-l">ระหว่างฟาร์ม ถ้าไอเทมในรายการด้านบน (เช่น ยา ลูกธนู · ยกเว้น Fly Wing/Butterfly Wing) ในแถบด่วนเหลือ ≤ ค่า "เหลือ ≤" จะใช้ Butterfly Wing กลับเมือง → ซื้อ → วาร์ปกลับแมพเดิม · ไอเทมต้องอยู่ในแถบด่วน (อ่านจำนวนจากตรงนั้น) และต้องมี Butterfly Wing ในแถบด่วน · ใช้ร่วมกับ 🧪 โหมดทดลอง</span>
                        <button class="at-btn-ghost" id="at-buy-now" title="ทดสอบ: เดินไปซื้อทุกรายการที่ตั้งไว้ทันที (ไม่ดูเงื่อนไขจำนวน)">🛒 ซื้อตอนนี้ (ทดสอบ)</button>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">📈 อัพสเตตัสอัตโนมัติ</div>
                        <div class="at-toggle-row"><span>เปิดอัพสเตตัสอัตโนมัติ</span><div class="at-switch" data-opt="statOn"></div></div>
                        <span class="ac-l">เมื่อมีแต้มสถานะเหลือ จะกดปุ่ม "แต้มสถานะ" บนจอ (เปิดหน้าตัวละคร) แล้วกด + ตามลำดับด้านล่าง: อัพตัวแรกจนถึงค่าที่ตั้ง (ค่าฐาน ไม่รวมโบนัส) แล้วไปตัวถัดไป · ถ้าแต้มไม่พอจะกด + ไม่ได้ ก็หยุดเฉยๆ รอแต้มมาใหม่ · ปิดหน้าตัวละครให้เองถ้าเป็นคนเปิด</span>
                        <div style="display:grid;grid-template-columns:1fr 80px 26px;gap:4px;font-size:10.5px;opacity:.75"><span>ลำดับ (บนสุดก่อน)</span><span>อัพถึง</span><span></span></div>
                        <div id="at-stat-rows" style="display:grid;grid-template-columns:1fr 80px 26px;gap:4px"></div>
                        <button class="at-btn-ghost" id="at-stat-add">＋ เพิ่มสเตตัส</button>
                        <button class="at-btn-ghost" id="at-stat-now" title="ทดสอบ: เปิดหน้าตัวละครแล้วอัพตามลำดับทันที">📈 อัพตอนนี้ (ทดสอบ)</button>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🌀 วาร์ปอัตโนมัติ (Alice Service)</div>
                        <span class="ac-l">เดินไปคุย Alice Service → เลือก "วาร์ป (เลือกจากแผนที่โลก)" → เลือกแมพ → กด "วาร์ปไปที่นี่" (ถ้าเคยไปแล้ว) หรือ "เดินไปที่นี่" (ถ้ายังไม่เคยไป) · ระหว่างเดินจะปิดปุ่ม Z ให้ แล้วเปิดคืนเมื่อถึงแมพ · ต้องอยู่แมพที่มี Alice (เมืองหลวง) และซูมเกม 100%</span>
                        <select class="at-input" id="at-warp-sel"><option value="">— เลือกแมพจากรายการ —</option></select>
                        <div id="at-warp-recent" style="display:flex;flex-wrap:wrap;gap:4px"></div>
                        <input type="text" class="at-input" id="at-warp-dest" list="at-warp-list" placeholder="หรือพิมพ์ชื่อแมพ เช่น แกนลาวา" />
                        <datalist id="at-warp-list"></datalist>
                        <div style="display:flex;gap:6px"><button class="at-btn-ghost" id="at-warp-go" style="flex:1">🌀 ไปเลย</button><button class="at-btn-ghost" id="at-warp-stop" style="flex:1">⏹ หยุด</button></div>
                        <select class="at-input" id="at-warp-walk" title="วิธีเดินไปหา Alice"><option value="auto">🚶 เดิน: อัตโนมัติ (คลิกก่อน ไม่ตรงใช้ WASD)</option><option value="click">🖱️ เดิน: คลิกบนจอ (ต้องซูม 100%)</option><option value="wasd">⌨️ เดิน: กดปุ่ม WASD (ไม่ขึ้นกับขนาดจอ/ซูม)</option></select>
                        <div style="display:flex;gap:6px"><input type="text" class="at-input" id="at-walk-npc" value="Shopkeeper" placeholder="ชื่อ NPC" style="flex:1" title="ชื่อ NPC ในแมพปัจจุบัน (พิมพ์บางส่วนได้)" /><button class="at-btn-ghost" id="at-walk-test" style="flex:1" title="เดินไปหา NPC ในแมพนี้ แล้วเปิดหน้าต่างคุย (ทดสอบเดินไกล)">🧪 ทดสอบเดินไปคุย</button></div>
                        <button class="at-btn-ghost" id="at-warp-scan">📋 โหลดรายชื่อแมพจากแผนที่โลก (🌀 = เคยไป วาร์ปได้ · 🚶 = ต้องเดิน)</button>
                        <div class="at-toggle-row"><span>🦋 เลือกแมพใหม่ระหว่างฟาร์ม → ใช้ Butterfly Wing กลับเมืองแล้ววาร์ปทันที</span><div class="at-switch" data-opt="pickBw"></div></div>
                        <span class="ac-l">ใช้กับปุ่ม 🌀 ไปเลย / เลือกแมพจากรายการ / ปุ่มแมพล่าสุด ขณะอยู่นอกเมือง · ต้องมี Butterfly Wing ในแถบด่วน (ไม่มี = รอจนกว่าจะกลับเมืองเอง) · ถ้าเปิดซื้อของอัตโนมัติไว้ จะเช็คซื้อของก่อนวาร์ปด้วย</span>
                        <div class="at-toggle-row"><span>↩️ กลับแมพเดิมเอง (ตาย/กลับเมือง)</span><div class="at-switch" data-opt="warpBack"></div></div>
                        <span class="ac-l">จำแมพฟาร์มล่าสุดไว้ เมื่อกลับมาเมืองหลวง (ตาย/กลับเมือง/อื่น ๆ) และเปิดบอท Z อยู่ จะวาร์ปกลับให้เองหลังรอ ~8 วินาที · ถ้าปิดอยู่ ต้องกด "ไปเลย" เอง</span>
                        <div class="at-toggle-row"><span>🩹 รักษาตัวฟรี (ข้อ 4) ก่อนวาร์ป</span><div class="at-switch" data-opt="warpHeal"></div></div>
                        <span class="ac-l">ก่อนเลือกวาร์ป จะเลือก "ขอรักษาหน่อย (ฟรี)" กับ Alice ให้ก่อน (เติม HP/SP) แล้วคุยใหม่เพื่อวาร์ปต่อ — ใช้ทั้งตอนกดไปเลยและตอนกลับแมพเดิมอัตโนมัติ</span>
                        <div class="at-toggle-row"><span>🎯 ใช้ Fly Wing จนเข้าโซนฟาร์ม แล้วเปิด Auto</span><div class="at-switch" data-opt="warpZone"></div></div>
                        <span class="ac-l">หลังวาร์ปถึงแมพฟาร์ม ถ้าตัวเรายังไม่อยู่ในโซนที่ลากไว้ จะใช้ Fly Wing สุ่มไปเรื่อยๆ จนตัวเรา (จุดเขียว) เข้าโซนใดโซนหนึ่ง แล้วหยุดและกด Auto (Z) ทันที · ใช้ได้ทุกขนาดจอ (อ่านตำแหน่งจากพิกัดมินิแมพ) · ต้องมี Fly Wing ในแถบด่วน</span>
                        <div class="at-toggle-row"><span>🔁 จำนวนรอบสุ่มสูงสุด (0 = ไม่จำกัด จนกว่า Fly Wing หมด)</span><input type="number" class="at-input" id="at-zone-max" min="0" max="999" style="width:70px;flex:none" /></div>
                        <div class="at-toggle-row"><span>⭕ ปรับระยะล่าของ Auto ให้วงล่าอยู่ในโซน</span><div class="at-switch" data-opt="zoneFit"></div></div>
                        <span class="ac-l">Auto ของเกมล่ามอนในวงกลมรอบ "จุดที่เปิด Auto" (ระยะล่า 3–30 ช่อง) · เปิดตัวเลือกนี้แล้ว Fly Wing จะยอมลงเฉพาะจุดที่วงล่ากว้างได้อย่างน้อย <b data-optv="zoneMinR"></b> โดยไม่ล้นออกนอกโซน (กำแพง/สิ่งกีดขวางนอกโซนไม่นับ) แล้วตั้งค่า "ระยะล่า" ในหน้าต่างต่อสู้อัตโนมัติให้พอดีโซนเอง ก่อนกดเปิด Auto · ถ้าโซนเล็กกว่าที่ตั้ง จะหาจุดลงไม่เจอ — ลดค่านี้หรือวาดโซนให้ใหญ่ขึ้น</span>
                        <input type="range" data-opt="zoneMinR" data-unit="ช่อง" min="3" max="30" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <div class="at-toggle-row"><span>🚶 ใกล้โซนอยู่แล้ว → เดินเข้าโซนแทนการใช้ Fly Wing</span><div class="at-switch" data-opt="zoneWalk"></div></div>
                        <span class="ac-l">ถ้าตัวละครอยู่นอกโซนแต่เดินเข้าได้ภายใน <b data-optv="zoneWalkMax"></b> (นับตามทางเดินจริง เลี่ยงกำแพงและโซนห้ามเข้า) จะเดินเข้าไปเอง ใช้ทั้งตอนเริ่มหาโซนและหลังใช้ Fly Wing ลงใกล้ ๆ</span>
                        <input type="range" data-opt="zoneWalkMax" data-unit="ช่อง" min="2" max="30" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <div class="at-toggle-row"><span>🧲 หลุดโซนระหว่างฟาร์ม → เดินกลับจุดยืนตี/เข้าโซน</span><div class="at-switch" data-opt="zoneGuard"></div></div>
                        <span class="ac-l">ระหว่าง Auto ฟาร์มอยู่ ถ้าตัวละครอยู่นอกโซนฟาร์ม (หรือในโซนห้ามเข้า) ติดต่อกันเกิน <b data-optv="zoneGuardSec"></b> จะปิด Auto → เดินกลับจุดยืนตี (หรือเข้าโซน) → เปิด Auto ใหม่ ให้วงล่าเริ่มจากจุดเดิม · ใช้การเดินเท่านั้น ไม่ใช้ Fly Wing (ถ้าเดินกลับไม่ได้จะปล่อยให้ฟาร์มต่อ) · ไม่ทำตอนกดพัก/เล่นเอง</span>
                        <input type="range" data-opt="zoneGuardSec" data-unit="วินาที" min="10" max="180" step="5" style="width:100%;accent-color:var(--at-acc)" />
                        <div class="at-toggle-row"><span>📍 ไปยืนตีที่จุดที่เลือกในโซน</span><div class="at-switch" data-opt="spotOn"></div></div>
                        <span class="ac-l">วาง 📍 จุดยืนตี ในหน้าต่าง 🗺️ กำหนดโซนฟาร์ม (วางได้หลายจุด) · หลังวาร์ป/Fly Wing จะเดินไปจุดที่ใกล้ที่สุด แล้วเปิด Auto ตรงนั้น (วงล่ามีศูนย์กลางที่จุดนั้น) · ถ้าจุดยืนตีไกลเกิน <b data-optv="spotMax"></b> (นับตามทางเดินจริง) จะใช้ Fly Wing สุ่มให้ใกล้ขึ้นก่อน · แมพที่ไม่ได้วางจุด = ใช้โซนแบบเดิม</span>
                        <input type="range" data-opt="spotMax" data-unit="ช่อง" min="5" max="80" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <div class="at-toggle-row"><span>👹 เข้าโซนห้ามเข้า / จุดเกิดมอนอันตราย → หลบกลับเข้าโซน</span><div class="at-switch" data-opt="dangerFlee"></div></div>
                        <span class="ac-l">วาด ⛔ โซนห้ามเข้า และเลือก 👹 มอนอันตราย ได้ในหน้าต่าง 🗺️ กำหนดโซนฟาร์ม · ระบบหาโซน/วงล่า/การเดิน จะเลี่ยงพื้นที่เหล่านี้เสมอ · เปิดสวิตช์นี้ = ถ้าตัวละครเข้าไปในพื้นที่นั้นระหว่างฟาร์ม (เช่น Auto ไล่มอนเข้าไป) จะปิด Auto แล้วเดิน/ใช้ Fly Wing กลับเข้าโซน · จุดเกิดมอนอันตรายขยายออก <b data-optv="dangerPad"></b> รอบจุดเกิด · ใช้ร่วมกับ 🧪 โหมดทดลอง</span>
                        <input type="range" data-opt="dangerPad" data-unit="ช่อง" min="0" max="15" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <span class="ac-l">⚠️ ถ้าเปิด "ใช้ Fly Wing" ในหน้าต่างต่อสู้อัตโนมัติของเกม เกมจะสุ่ม Fly Wing เองเมื่อไม่มีมอนในวง แล้วอาจพาออกนอกโซน — ถ้าใช้ระบบโซนนี้ แนะนำให้ปิดตัวเลือกนั้นในเกม</span>
                        <button class="at-btn-ghost" id="at-zone-edit" title="เปิดแผนที่ แล้วลากเป็นกรอบเพื่อเลือกโซน (ต้องยืนอยู่ในแมพฟาร์มนั้น)">🗺️ กำหนดโซนฟาร์มบนแผนที่</button>
                        <span class="ac-l" id="at-zone-info"></span>
                        <div class="at-toggle-row"><span>🦋 Fly Wing ใกล้หมด → ใช้ Butterfly Wing กลับเมืองไปซื้อ แล้ววาร์ปกลับหาโซนต่อ</span><div class="at-switch" data-opt="flyRestock"></div></div>
                        <span class="ac-l">ใช้คู่กับ "🎯 ใช้ Fly Wing จนเข้าโซนฟาร์ม" · เมื่อ Fly Wing ในแถบด่วนเหลือ ≤ ค่า "เหลือ ≤" ของ Fly Wing ในรายการ 🛒 ซื้อของอัตโนมัติ (ทั้งระหว่างสุ่มหาโซนและระหว่างฟาร์ม) จะใช้ Butterfly Wing กลับเมืองหลวงทันที → เดินไปหา NPC ร้านค้าที่ตั้งไว้ ซื้อทุกรายการที่เหลือ ≤ ค่าที่ตั้ง → วาร์ปกลับแมพเดิม → ใช้ Fly Wing หาโซน → เปิด Auto · ต้องมี Butterfly Wing และ Fly Wing ในแถบด่วน และมี Fly Wing ในรายการซื้อของ · ถ้าซื้อไม่สำเร็จจะอยู่ในเมือง ไม่วาร์ปกลับ</span>
                        <div class="at-url-group"><button class="at-btn-ghost" id="at-zone-push" title="ส่งโซนฟาร์มทุกแมพขึ้น Google Sheets (ต้องเพิ่มโค้ดใน Apps Script ก่อน)">⬆️ ส่งโซนขึ้น Sheets</button><button class="at-btn-ghost" id="at-zone-pull" title="ดึงโซนฟาร์มจาก Google Sheets มาใช้ในเครื่องนี้">⬇️ ดึงโซนจาก Sheets</button></div>
                        <span class="ac-l">ซิงค์โซนข้ามเครื่องผ่าน Web App URL เดียวกับแท็บ Sheets · ต้องเพิ่มโค้ดซิงค์โซน (ไฟล์ aetherack-zones-sync.gs) ใน Apps Script แล้ว Deploy ใหม่ก่อน</span>
                        <div class="at-toggle-row"><span>📡 ไม่มีความเคลื่อนไหว → ย้ายไป CH ที่คนน้อยสุด</span><div class="at-switch" data-opt="chSwitch"></div></div>
                        <span class="ac-l">เปิด Auto อยู่ในแมพฟาร์ม แต่ไม่ได้ฆ่ามอน/ไม่มีของดรอปนาน <b data-optv="chMin"></b> (มีคนแย่งมอน/มอนน้อย) → ย้าย CH ไปห้องที่คนน้อยสุด แล้วใช้ Fly Wing หาโซนต่อ (ถ้าเปิดไว้) · ย้ายได้ไม่เกิน 3 ครั้ง/ชม. ห่างกันอย่างน้อย 10 นาที · ใช้ร่วมกับ 🧪 โหมดทดลอง</span>
                        <input type="range" data-opt="chMin" data-unit="นาที" min="2" max="30" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <div class="at-toggle-row"><span>👥 กระจาย CH (ตัวเราหลายตัวอยู่ CH เดียวกัน)</span><div class="at-switch" data-opt="chSpread"></div></div>
                        <span class="ac-l">ตัวละครของเราหลายตัวฟาร์มแมพเดียวกันใน CH เดียวกัน (แย่งมอนกันเอง) → ทยอยย้ายให้อยู่คนละ CH (ตัวที่ชื่อเรียงก่อนอยู่ที่เดิม ตัวอื่นย้ายทีละตัว) · เลี่ยง CH ที่ตัวเราตัวอื่นอยู่ และเลือก CH คนน้อย · ใช้ข้อมูลจากกล่องสถานะ (ต้องเปิดใช้ข้อมูลร่วมทุก Container ถ้าแยก Container)</span>
                        <div class="at-toggle-row"><span>🪽 ใช้ Fly Wing 1 ครั้งหลังถึงแมพ</span><div class="at-switch" data-opt="warpFly"></div></div>
                        <span class="ac-l">ต้องลาก Fly Wing จากกระเป๋าไปใส่แถบด่วน (ช่องไหนก็ได้) ก่อน · ไม่ใช้ในเมือง/แมพปลอดภัย</span>
                        <span class="ac-l" id="at-warp-st">พร้อม</span>
                    </div>
                </section>

                <section class="ac-pane" data-pane="junk">
                    <div class="ac-group">
                        <div class="ac-title">🗑️ ทิ้งขยะอัจฉริยะในกระเป๋า</div>
                        <button class="at-btn-ghost" id="at-junk-share">🔗 ใช้ค่าร่วมกันทุกโปรไฟล์: ปิด</button>
                        <span class="ac-l">เปิดแล้วรายการไอเทม 🗑️/📦/🔒 ระดับที่ล็อก และเกณฑ์น้ำหนัก (เริ่ม/เป้า/ต่อรอบ/ทิ้งให้หมด) ใช้ชุดเดียวกันทุกตัวละคร แก้จากโปรไฟล์ไหนก็อัปเดตทุกโปรไฟล์ทันที · เปิด/ปิดระบบ และโหมดทดลอง ยังแยกรายตัวละคร</span>
                        <div class="at-toggle-row"><span>เปิดระบบทิ้งขยะอัตโนมัติ</span><div class="at-switch" data-opt="junkOn"></div></div>
                        <span class="ac-l">เมื่อน้ำหนักถึงเกณฑ์: เปิดกระเป๋า (I) → กดจัดเรียง → เลือกไอเทมที่ตั้งเป็น 🗑️ ขยะ → กดทิ้ง → ยืนยัน ทีละชิ้นแบบช้า ๆ แล้วปิดกระเป๋า · ไอเทมที่ไม่ได้ตั้งไว้ ล็อกอยู่ หรือตีบวกแล้ว จะไม่ถูกแตะ</span>
                        <div class="at-toggle-row"><span>🧪 โหมดทดลอง (ไม่ทิ้งจริง ลงบันทึกใน Logs)</span><div class="at-switch" data-opt="junkDry"></div></div>
                        <span class="ac-l">แนะนำให้ลองโหมดทดลองก่อน ดูใน Logs ว่าเลือกถูกชิ้น แล้วค่อยปิดโหมดนี้</span>
                        <span class="ac-l">เริ่มทิ้งเมื่อน้ำหนัก ≥ <b data-optv="junkAt"></b></span>
                        <input type="range" data-opt="junkAt" data-unit="%" min="50" max="99" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <span class="ac-l">ทิ้งจนน้ำหนักเหลือ ≤ <b data-optv="junkTo"></b></span>
                        <input type="range" data-opt="junkTo" data-unit="%" min="10" max="98" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <div class="at-toggle-row"><span>♻️ ทิ้งให้หมดทุกชิ้นที่ตั้งเป็น 🗑️ ขยะ (ไม่สนเป้าน้ำหนักด้านบน)</span><div class="at-switch" data-opt="junkAll"></div></div>
                        <span class="ac-l">เปิดแล้วเมื่อน้ำหนักถึงเกณฑ์เริ่มทิ้ง จะทิ้งไอเทมขยะที่ตั้งไว้ให้ครบทุกชิ้น (ยังจำกัดตามจำนวนต่อรอบและตัวล็อกทั้งหมด) · ปิด = ทิ้งจนน้ำหนักเหลือตามเป้าแล้วหยุด</span>
                        <div class="at-toggle-row"><span>🎒 ทิ้งเมื่อช่องเก็บของใกล้เต็ม/เต็ม (ไม่รอน้ำหนัก)</span><div class="at-switch" data-opt="junkSlotOn"></div></div>
                        <span class="ac-l">เริ่มทิ้งเมื่อช่องว่างเหลือ ≤ <b data-optv="junkSlotFree"></b> (0 = เต็มพอดี) · นับเป็น "ช่องว่าง" จึงใช้ได้กับกระเป๋าทุกขนาด (100 / 200 ช่อง)</span>
                        <input type="range" data-opt="junkSlotFree" data-unit="ช่อง" min="0" max="30" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <span class="ac-l">ทิ้งจนช่องว่าง ≥ <b data-optv="junkSlotGoal"></b> (ถ้าของขยะหมดก่อนก็หยุดแค่นั้น)</span>
                        <input type="range" data-opt="junkSlotGoal" data-unit="ช่อง" min="1" max="60" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <span class="ac-l">ทิ้งไม่เกิน <b data-optv="junkMax"></b> ต่อรอบ</span>
                        <input type="range" data-opt="junkMax" data-unit="รายการ" min="1" max="200" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <button class="at-btn-ghost" id="at-junk-now">▶️ ทิ้งขยะตอนนี้ (ตามที่ตั้งไว้ · ทำงานตามโหมดทดลอง)</button>
                        <button class="at-btn-ghost aj-danger" id="at-junk-real">💥 ทิ้งทันที (ทิ้งจริง ไม่รอเกณฑ์น้ำหนัก · ใช้ทดสอบ)</button>
                        <span class="ac-l">ปุ่มทิ้งทันทีจะทิ้งจริงเฉพาะไอเทม 🗑️ ขยะ ที่ผ่านการล็อกทุกชั้น ไม่เกินจำนวนต่อรอบที่ตั้งไว้ · กดสองครั้งเพื่อยืนยัน</span>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">📊 สถิติการทิ้งขยะ</div>
                        <div id="at-junk-stat"></div>
                        <button class="at-btn-ghost" id="at-junk-stat-reset">↺ ล้างสถิติการทิ้งของตัวละครนี้</button>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🎲 ออฟชั่น (Option) ที่ไม่ทิ้ง</div>
                        <span class="ac-l">ติ๊ก option ที่อยากเก็บ — อุปกรณ์ที่ตั้งเป็น 🗑️ ขยะ แต่มี option นี้ จะถูกข้ามไม่ทิ้ง (ช่อง "ตั้งแต่" = ค่าต่ำสุดที่ถือว่าดี ว่าง = ค่าเท่าไรก็เก็บ) · สคริปต์อ่านจากกรอบรายละเอียดไอเทมในกระเป๋าก่อนทิ้งทุกชิ้น ถ้าอ่านไม่ได้จะข้ามไว้ก่อน · ตรวจว่าอ่านถูกไหมที่แท็บ 🩺 ตรวจสุขภาพ</span>
                        <div class="ak-list" id="at-keepopts"></div>
                        <div class="at-toggle-row"><span>🗑️ ทิ้งอุปกรณ์ที่ออฟไม่ตรงที่ติ๊กไว้ (ตอนดรอป + ตอนทิ้งขยะในกระเป๋า)</span><div class="at-switch" data-opt="dropDiscard"></div></div>
                        <span class="ac-l">ใช้ได้เมื่อติ๊ก option ด้านบนอย่างน้อย 1 อย่าง · ตอนดรอป: ทิ้งทันทีเฉพาะระดับที่ติ๊กด้านล่าง · ในกระเป๋า: อุปกรณ์ที่คุณตั้งเป็น 🗑️ ขยะ ระดับที่ติ๊กด้านล่างจะไม่ถูก "ล็อกตามระดับ" อีก ให้ออฟตัดสินแทน (ออฟตรง = เก็บ · ไม่ตรง = ทิ้ง) · ติ๊กมหากาพย์/ตำนานได้ · ไม่ทิ้งของ Wishlist ของล็อก หรือตีบวกแล้ว · ถ้าอุปกรณ์ชื่อเดียวกันหลายชิ้นในกระเป๋า จะทิ้งก็ต่อเมื่อทุกชิ้นออฟไม่ตรง · ออฟไม่ตรงจะแจ้ง Discord แบบไม่แท็ก/ปิง</span>
                        <span class="ac-l">💡 แนะนำ: เริ่มจากติ๊ก ธรรมดา–หายาก ก่อน (ค่าเริ่มต้น) ลองดูใน Discord/Logs สักพักว่าตัดสินถูกชิ้น แล้วค่อยติ๊กมหากาพย์/ตำนาน · ปุ่มนี้ปิดอยู่ตั้งแต่แรก ต้องเปิดเอง</span>
                        <div class="at-fgrid" id="at-ddrar-f">
                            <label style="color:#f3f0e8"><input type="checkbox" data-ddrar="common" /> ธรรมดา</label>
                            <label style="color:#86efac"><input type="checkbox" data-ddrar="uncommon" /> ดี</label>
                            <label style="color:#7cc4ff"><input type="checkbox" data-ddrar="rare" /> หายาก</label>
                            <label style="color:#c49bff"><input type="checkbox" data-ddrar="epic" /> มหากาพย์</label>
                            <label style="color:#ffb347"><input type="checkbox" data-ddrar="legendary" /> ตำนาน</label>
                        </div>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">📋 จัดกลุ่มไอเทม</div>
                        <button class="at-btn-ghost" id="at-junk-scan">🔄 สแกนกระเป๋าตอนนี้ (เปิดกระเป๋า อ่านของ แล้วปิด) — ให้ไอเทมในกระเป๋าขึ้นในรายการ</button>
                        <input type="text" class="at-input" id="at-junk-q" placeholder="🔍 ค้นหาไอเทมจาก wiki (ว่าง = ที่เคยดรอป/อยู่ในกระเป๋า)" />
                        <span class="ac-l">🔒 ติ๊กระดับที่ต้องการล็อก (ไอเทมระดับนี้จะไม่ถูกทิ้งเลย แม้ตั้งเป็น 🗑️ ขยะ)</span>
                        <button class="at-btn-ghost" id="at-junk-wiki">📖 เปิด Wiki เลือกไอเทมที่จะไม่ทิ้ง / จะทิ้ง</button>
                        <div class="aj-rars" id="at-junk-rar"></div>
                        <div class="aj-cats" id="at-junk-cats"></div>
                        <div class="aj-list" id="at-junk-list"></div>
                        <span class="ac-l" id="at-junk-note"></span>
                        <span class="ac-l">🗑️ ขยะ = ทิ้งได้เมื่อน้ำหนักถึงเกณฑ์ · 📦 เก็บทำของ และ 🔒 ห้ามทิ้ง = ไม่แตะเด็ดขาด</span>
                    </div>
                </section>

                <section class="ac-pane" data-pane="watch">
                    <div class="ac-group">
                        <div class="ac-title">🔊 เสียงเตือน</div>
                        <div class="at-toggle-row"><span>เปิดเสียง</span><div class="at-switch" data-opt="sound"></div></div>
                        <button class="at-btn-ghost" id="at-snd-test">🔈 ทดสอบเสียง</button>
                        <span class="ac-l">เตือนบนหน้าจอ/เสียงได้แม้ไม่ตั้ง Discord · ส่งเข้า Discord ต้องติ๊กหัวข้อในแท็บ Discord ด้วย (และกำหนด User ID ถ้าต้องการแท็ก)</span>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🧩 ตรวจสอบผู้เล่น (Captcha)</div>
                        <div class="at-toggle-row"><span>เตือนเมื่อเกมขอตรวจสอบ</span><div class="at-switch" data-opt="captcha"></div></div>
                        <span class="ac-l">เตือนทันที + หยุดการคลิก/กดปุ่มอัตโนมัติของสคริปต์ระหว่างมีหน้าต่างตรวจสอบ · สคริปต์ไม่ตอบให้ ต้องตอบเอง</span>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🧟 บอทค้างในแมพฟาร์ม</div>
                        <div class="at-toggle-row"><span>เตือนเมื่อไม่มีความเคลื่อนไหว</span><div class="at-switch" data-opt="stall"></div></div>
                        <span class="ac-l">เปิด Auto อยู่ในแมพฟาร์ม แต่ไม่มีดรอป/ไม่ได้ฆ่ามอนนาน <b data-optv="stallMin"></b></span>
                        <input type="range" data-opt="stallMin" data-unit="นาที" min="2" max="15" step="1" style="width:100%;accent-color:var(--at-acc)" />
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">📡 การเชื่อมต่อ</div>
                        <div class="at-toggle-row"><span>เตือนเมื่อหลุด/รีสตาร์ท/เกม crash</span><div class="at-switch" data-opt="conn"></div></div>
                        <div class="at-toggle-row"><span>🔄 รีเฟรชหน้าเว็บเองเมื่อเกมค้าง/หลุดนาน</span><div class="at-switch" data-opt="autoReload"></div></div>
                        <span class="ac-l">ถ้าเกมขึ้นหน้าจอ crash หรือหลุดการเชื่อมต่อนานเกิน <b data-optv="reloadMin"></b> จะแจ้ง Discord แล้วรีโหลดหน้าเว็บ (ไม่เกิน 3 ครั้ง/30 นาที) · เข้าเกมได้ = ฟาร์มต่อ (กลับแมพเดิมเองถ้าเปิดไว้) · เข้าไม่ได้ใน 3 นาทีหลังรีโหลด = แจ้ง Discord · ใช้ร่วมกับ 🧪 โหมดทดลอง</span>
                        <input type="range" data-opt="reloadMin" data-unit="นาที" min="1" max="15" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <div class="at-toggle-row"><span>🆕 เตือนเมื่อเกมอัปเดตเวอร์ชัน + ตรวจสุขภาพสคริปต์</span><div class="at-switch" data-opt="verWatch"></div></div>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">⭐ บัฟ Premium</div>
                        <div class="at-toggle-row"><span>เตือนเมื่อบัฟ Premium ใกล้หมด / หมดแล้ว</span><div class="at-switch" data-opt="premWarn"></div></div>
                        <span class="ac-l">เตือนเมื่อเหลือ ≤ <b data-optv="premHrs"></b> (ครั้งเดียวต่อรอบ) และเตือนอีกครั้งเมื่อหมด</span>
                        <input type="range" data-opt="premHrs" data-unit="ชม." min="1" max="48" step="1" style="width:100%;accent-color:var(--at-acc)" />
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🎒 ของใช้ใกล้หมด</div>
                        <div class="at-toggle-row"><span>เตือนเมื่อไอเทมช่องด่วน/ลูกธนูต่ำกว่า</span><div class="at-switch" data-opt="supply"></div></div>
                        <span class="ac-l">ต่ำกว่า <b data-optv="supplyMin"></b> (ลูกธนูอ่านได้เมื่อเปิดหน้าต่างตัวละครอยู่)</span>
                        <input type="range" data-opt="supplyMin" data-unit="ชิ้น" min="5" max="100" step="5" style="width:100%;accent-color:var(--at-acc)" />
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">💬 แชท & สรุปผล</div>
                        <div class="at-toggle-row"><span>เตือนเมื่อมีคนกระซิบ / GM ทัก</span><div class="at-switch" data-opt="chat"></div></div>
                        <div class="at-toggle-row"><span>สรุปผลฟาร์มรายชั่วโมง / ตอนกลับเมือง</span><div class="at-switch" data-opt="digest"></div></div>
                    </div>
                </section>

                <section class="ac-pane" data-pane="theme">
                    <div class="ac-group">
                        <div class="ac-title">🎨 ธีมสำเร็จรูป</div>
                        <div class="at-swatches" id="at-theme-presets"></div>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🖌️ ปรับสีเอง</div>
                        <label class="at-colorrow"><span>สีหลัก (ปุ่ม/หัวข้อ/เน้น)</span><input type="color" id="at-th-acc" /></label>
                        <label class="at-colorrow"><span>สีรอง (ไล่เฉดปุ่ม/กราฟ)</span><input type="color" id="at-th-acc2" /></label>
                        <label class="at-colorrow"><span>สีพื้นหลังแผง</span><input type="color" id="at-th-bg" /></label>
                        <label class="at-colorrow"><span>สีตัวอักษรหลัก</span><input type="color" id="at-th-text" /></label>
                        <span class="ac-l">ความทึบของพื้นหลัง <b id="at-th-opv"></b></span>
                        <input type="range" id="at-th-op" min="30" max="130" step="5" style="width:100%;accent-color:var(--at-acc)" />
                        <button class="at-btn-ghost" id="at-th-reset">↺ กลับเป็นธีมทอง (ค่าเดิม)</button>
                    </div>
                </section>

                <section class="ac-pane" data-pane="boss">
                    <div class="ac-group">
                        <div class="ac-title">👹 แจ้งเตือนบอส</div>
                        <span class="ac-l">สคริปต์อ่านเวลาเกิดจากหน้า "ประกาศล่า MVP" ของเกม (ปุ่ม บอส / กด U) เปิดหน้านั้นครั้งหนึ่งแล้วสคริปต์จำเวลาเกิดเป๊ะไว้ แจ้งเตือนในเกมทุกขีดที่เลือก ส่วน Discord ส่งเฉพาะตอนบอส "เกิดแล้ว" (เปิดหัวข้อ 👹 ในแท็บ Discord) และมีกล่องบอสแยกต่างหากที่อัปเดตตลอด</span>
                        <div class="at-toggle-row"><span>แจ้งก่อนเกิด 60 นาที</span><div class="at-switch" data-opt="bossM60"></div></div>
                        <div class="at-toggle-row"><span>แจ้งก่อนเกิด 30 นาที</span><div class="at-switch" data-opt="bossM30"></div></div>
                        <div class="at-toggle-row"><span>แจ้งก่อนเกิด 10 นาที</span><div class="at-switch" data-opt="bossM10"></div></div>
                        <div class="at-toggle-row"><span>แจ้งก่อนเกิด 5 นาที</span><div class="at-switch" data-opt="bossM5"></div></div>
                        <div class="at-toggle-row"><span>แจ้งก่อนเกิด 1 นาที</span><div class="at-switch" data-opt="bossM1"></div></div>
                        <div class="at-toggle-row"><span>แจ้งตอนบอสเกิดแล้ว</span><div class="at-switch" data-opt="bossSpawn"></div></div>
                        <div class="at-toggle-row"><span>แท็ก (Ping) ตอนแจ้งบอส</span><div class="at-switch" data-opt="bossPing"></div></div>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🔄 อัปเดตเวลาบอสอัตโนมัติ</div>
                        <div class="at-toggle-row"><span>เปิดหน้าบอสเองทุก 10 นาที</span><div class="at-switch" data-opt="bossAuto"></div></div>
                        <span class="ac-l">สคริปต์จะกดเปิดหน้า "บอส" แล้วปิดเองหลังอ่านเวลาเสร็จ (ไม่ทำตอนพิมพ์แชท/ตาย/โดนเช็คผู้เล่น) · ปิดไว้ได้ถ้าไม่อยากให้หน้าต่างเด้ง แล้วเปิดดูเองเป็นครั้งคราวแทน</span>
                    </div>
                </section>

                <section class="ac-pane" data-pane="health">
                    <div class="ac-group">
                        <div class="ac-title">🩺 ตรวจสุขภาพสคริปต์</div>
                        <span class="ac-l">เช็คว่าส่วนของเกมที่สคริปต์ต้องอ่าน/กด ยังอยู่ครบไหม ใช้หลังเกมอัปเดต · ข้อไหนเป็น ❌ แปลว่าฟีเจอร์นั้นอาจพัง (ส่งภาพหน้านี้ให้ผู้พัฒนาแก้ได้ทันที) · 🟡 = ไม่พบแต่อาจเป็นเรื่องปกติ</span>
                        <div class="at-toggle-row"><span>เตือนอัตโนมัติ (แจ้งบนจอ + Discord) เมื่อหาไม่เจอต่อเนื่อง</span><div class="at-switch" data-opt="healthAlert"></div></div>
                        <button class="at-btn-ghost" id="at-health-run">🩺 ตรวจตอนนี้ (ตรวจการตั้งค่า → เปิดกระเป๋า → เลือกไอเทมช่องแรก → ปิด)</button>
                        <div id="at-health-list"></div>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🔬 ทดสอบอ่านสเตตัสไอเทม</div>
                        <span class="ac-l">เลือกอุปกรณ์ชิ้นแรกในกระเป๋าแล้วแสดงข้อความที่สคริปต์อ่านได้ + stat/option ที่แยกได้ — ใช้ตรวจว่าระบบ "แนบ stat ใน Discord" และ "ไม่ทิ้งตามออฟ" อ่านถูกไหม (ถ้าไม่ตรง ส่งภาพช่องนี้มาให้แก้ได้เลย)</span>
                        <button class="at-btn-ghost" id="at-card-run">🔬 ทดสอบอ่านไอเทมในกระเป๋า</button>
                        <pre class="ah-pre" id="at-card-test">ยังไม่ได้ทดสอบ</pre>
                    </div>
                </section>

                <section class="ac-pane" data-pane="ui">
                    <div class="ac-group">
                        <div class="ac-title">📐 ขนาด & รูปแบบ</div>
                        <span class="ac-l">ขนาด UI <b id="at-scale-label"></b></span>
                        <input type="range" id="at-scale" min="70" max="130" step="5" style="width:100%;accent-color:var(--at-acc)" />
                        <div class="at-toggle-row"><span>รูปแบบแผงหลัก</span><button class="at-btn-ghost" id="at-layout-btn"></button></div>
                        <div class="at-toggle-row"><span>🏷️ ชื่อแท็บ = ชื่อตัวละคร · แมพ</span><div class="at-switch" data-opt="tabTitle"></div></div>
                        <span class="ac-l">เปลี่ยนชื่อแท็บ/หน้าต่างบนทาสก์บาร์เป็น เช่น "RogueGuy03 · หนองพิษ · 3D ปิด" · ถ้าไม่ได้ฟาร์มจะมีจุดสีนำหน้า (🟠 อยู่เมือง · 🟡 ยังไม่ฟาร์ม · 🔴 ตาย/ตรวจผู้เล่น) · ปิดแล้วรีโหลดหน้าเพื่อคืนชื่อเดิมของเกม</span>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">⚡ ประสิทธิภาพ</div>
                        <div class="at-toggle-row"><span>โหมดประหยัดเครื่อง</span><div class="at-switch" data-opt="lowSpec"></div></div>
                        <span class="ac-l">ปิดเอฟเฟกต์เบลอพื้นหลัง/เงา ของหน้าต่างสคริปต์ — ช่วยลดภาระ GPU เวลาเปิดเกมหลายจอ</span>
                        <div class="at-toggle-row"><span>🎮 กราฟิกประหยัด (เปิดหลายจอ)</span><div class="at-switch" data-opt="lowGfx"></div></div>
                        <span class="ac-l">ปรับกราฟิกของเกมให้เบา: จำกัด 30 FPS · ความละเอียด 1x · ปิดเอฟเฟกต์สกิล ตัวเลขดาเมจ ป้าย แสงหมวก สั่นจอ · แสดงผู้เล่นอื่นไม่เกิน 5 คน → การ์ดจอ/โปรเซส GPU ทำงานน้อยลงมาก (คอขวดตอนเปิด 10+ จอ) · ตัวละครฟาร์มเหมือนเดิม · เปิด/ปิดแล้วกด 🔄 รีโหลดทุกจอ · ปิดแล้วคืนค่าเดิมของเกม</span>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🗺️ ภาพซ้อนบนจอ</div>
                        <span class="ac-l">วาดทับบนจอให้ดูอย่างเดียว ไม่ส่งคำสั่งเข้าเกม · คลิกมินิแมพ/พื้นได้ตามปกติ</span>
                        <div class="at-toggle-row"><span>🟨 โซนฟาร์ม · 📍 จุดยืนตี · ⛔ โซนห้ามเข้า บนมินิแมพของเกม</span><div class="at-switch" data-opt="ovMini"></div></div>
                        <span class="ac-l">กรอบเหลือง + เลขโซน = โซนฟาร์มที่ลากไว้ · จุดเขียว = จุดยืนตี · กรอบแดง = โซนห้ามเข้า / รอบจุดเกิดมอนอันตราย</span>
                        <div class="at-toggle-row"><span>〰️ เส้นทางที่ระบบเดินวางไว้</span><div class="at-switch" data-opt="ovPath"></div></div>
                        <span class="ac-l">ตอนระบบเดินไปหา NPC / Alice / เข้าโซน จะวาดเส้นทางสีฟ้าบนมินิแมพ บนพื้นในเกม และบนแผนที่ 🧪 · วงฟ้า = ช่องปลายทาง · ถ้าเดินติดจะเห็นว่าติดตรงไหน</span>
                        <div class="at-toggle-row"><span>🧭 ลูกศรชี้ทางกลับโซน</span><div class="at-switch" data-opt="ovArrow"></div></div>
                        <span class="ac-l">อยู่แมพฟาร์มที่มีโซน แต่ตัวละครอยู่นอกโซน → มีลูกศรรอบตัวละครชี้ไปโซนที่ใกล้ที่สุด พร้อมระยะ (ช่อง) · ยืนอยู่ในโซนห้ามเข้าจะขึ้นเตือนสีแดง · แสดงเมื่อห่างโซนตั้งแต่ <b data-optv="ovArrowMin"></b> (หลุดขอบนิดเดียวไม่ต้องขึ้น)</span>
                        <input type="range" data-opt="ovArrowMin" data-unit="ช่อง" min="1" max="15" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <div class="at-toggle-row"><span>🧱 แสดงกำแพงที่ระบบใช้คำนวณทางเดิน</span><div class="at-switch" data-opt="ovWall"></div></div>
                        <span class="ac-l">ระบายช่องบนพื้น: 🟥 กำแพง/สิ่งกีดขวางจากไฟล์แมพ · 🟧 ช่องที่เคยเดินติด (ระบบจำไว้ชั่วคราว) · 🟦 NPC · กรอบแดงประ = โซนห้ามเข้า · ใช้ดูว่าทำไมระบบเดินอ้อมหรือติด (เปิดเฉพาะตอนตรวจ)</span>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">📅 แถบเวลารอบฟาร์ม</div>
                        <span class="ac-l">บันทึกทุก 10 วินาที (เก็บย้อนหลัง 48 ชม. แยกต่อตัวละคร) · ชี้ที่แถบเพื่อดูเวลา/แมพของช่วงนั้น</span>
                        <div class="at-toggle-row"><span>ช่วงเวลา</span><select class="at-input" id="at-tl-rng" style="width:auto"><option value="3">3 ชม.</option><option value="6">6 ชม.</option><option value="12">12 ชม.</option><option value="24">24 ชม.</option><option value="48">48 ชม.</option></select></div>
                        <div id="at-tl"></div>
                        <button class="at-btn-ghost" id="at-tl-clear">🗑️ ล้างประวัติแถบเวลา (ตัวละครนี้)</button>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">👤 โปรไฟล์ตัวละคร</div>
                        <span class="ac-l">การตั้งค่าทั้งหมด (Sheets, Discord, ออโต้, ธีม, ขนาด/ตำแหน่งหน้าต่าง ฯลฯ) แยกเก็บต่อตัวละคร · ตอนนี้: <b id="at-prof-name">—</b></span>
                        <div class="at-toggle-row"><span>🔗 ใช้ข้อมูลร่วมกันทุก Container (Firefox)</span><div class="at-switch" id="at-share-sw"></div></div>
                        <span class="ac-l">เปิดเกมหลาย Container (คนละ IP) ใช้การตั้งค่า โปรไฟล์ตัวละคร โซนฟาร์ม จุดยืนตี มอนอันตราย รายการซื้อ และกล่องสถานะ Discord ชุดเดียวกัน · แก้ที่ไหนก็อัปเดตทุก Container ทันที · <b id="at-share-info"></b></span>
                        <div class="at-toggle-row"><span>🆕 ตัวละครใหม่ใช้การตั้งค่าของตัวล่าสุดอัตโนมัติ</span><div class="at-switch" id="at-prof-inherit"></div></div>
                        <span class="ac-l">เข้าเกมด้วยตัวละครที่ยังไม่เคยตั้งค่า จะคัดลอกการตั้งค่าทั้งหมดจากตัวที่เล่นล่าสุดในเบราว์เซอร์นี้ให้ทันที (ครั้งแรกครั้งเดียว) · กล่องสถานะ Discord ใช้ช่องเดิมของแท็บ: เปลี่ยนตัวละครในแท็บเดิม = ช่องเดิมแสดงตัวใหม่</span>
                        <button class="at-btn-ghost" id="at-prof-reset">↺ รีเซ็ตโปรไฟล์ตัวละครนี้ (กลับเป็นค่าเริ่มต้น)</button>
                        <span class="ac-l">คัดลอกการตั้งค่าของตัวนี้ (ยกเว้นตำแหน่งหน้าต่าง) ไปให้ตัวละครอื่นในเบราว์เซอร์นี้</span>
                        <div class="at-url-group"><select class="at-input" id="at-prof-copy-sel"></select><button class="at-btn-ghost" id="at-prof-copy">📋 คัดลอกไป</button><button class="at-btn-ghost" id="at-prof-pull" title="ดึงการตั้งค่าของตัวที่เลือกมาใช้กับตัวนี้">📥 ดึงมาใช้</button></div>
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">🌙 ปิดภาพ 3D</div>
                        <div class="at-toggle-row"><span>ปิดภาพ 3D (ตัวละครยังฟาร์มต่อ)</span><div class="at-switch" data-opt="renderOff"></div></div>
                        <div class="at-toggle-row"><span>⚡ โหมดใหม่: เกมเดินเต็มความเร็ว ไม่วาดภาพ</span><div class="at-switch" data-opt="r3Gpu"></div></div>
                        <span class="ac-l">เปิด (แนะนำ): ตอนปิดภาพ 3D เกมยังคำนวณเต็มความเร็ว แต่การ์ดจอไม่ต้องวาด และพักเสียงเกม → เดิน/วาร์ป/Auto ทำงานปกติ · ปิด = แบบเดิม (หน่วงทั้งเกมตามความถี่ด้านล่าง ประหยัด CPU กว่าแต่เกมเดินช้าลง)</span>
                        <div class="at-toggle-row"><span>💤 ไม่ได้แตะจอนาน → ปิดภาพ 3D เอง</span><div class="at-switch" data-opt="r3Idle"></div></div>
                        <span class="ac-l">ไม่ได้คลิก/กดปุ่ม/เลื่อนในแท็บนี้นาน <b data-optv="r3IdleMin"></b> → ปิดภาพ 3D ให้เอง (ประหยัดเครื่อง ตัวละครยังฟาร์มต่อ) · คลิกหรือกดปุ่มในแท็บนั้นอีกครั้ง → เปิดภาพกลับเอง</span>
                        <input type="range" data-opt="r3IdleMin" data-unit="นาที" min="1" max="60" step="1" style="width:100%;accent-color:var(--at-acc)" />
                        <span class="ac-l">ซ่อนภาพเกม แล้วแสดงหน้าสถานะ + Profit แทน · ลดการวาดภาพของเกมลงเหลือไม่กี่เฟรม/วินาที · UI ของเกมและสคริปต์ยังใช้งานได้ · ปิดตรงนี้หรือกดปุ่ม 🌙 บนแผงหลักได้เลย</span>
                        <span class="ac-l">(แบบเดิมเท่านั้น) ความถี่อัปเดตตอนปิดภาพ <b data-optv="renderFps"></b> <small>(ต่ำมาก = ประหยัดสุด แต่เกมอาจหน่วงตอนเปิดกลับ)</small></span>
                        <input type="range" data-opt="renderFps" data-unit="เฟรม/วิ" min="3" max="30" step="1" style="width:100%;accent-color:var(--at-acc)" />
                    </div>
                    <div class="ac-group">
                        <div class="ac-title">💰 หน้าต่าง Profit</div>
                        <div class="at-toggle-row"><span>ตำแหน่ง</span><button class="at-btn-ghost" id="at-dock-btn"></button></div>
                        <span class="ac-l">ลากหัว Profit เพื่อแยกออกมาวางที่ไหนก็ได้ · กดปุ่มนี้หรือ 📌 บนหัว Profit เพื่อติดกลับ</span>
                        <button class="at-btn-ghost" id="at-reset-pos">↺ รีเซ็ตตำแหน่งทุกหน้าต่าง</button>
                    </div>
                </section>
            </div>
        `;
        document.body.appendChild(cfg);
        foldGroups(cfg);

        const $id = (id) => document.getElementById(id);
        uiRefs.panel = panel;
        uiRefs.config = cfg;
        uiRefs.statusDot = $id('at-status-dot');
        uiRefs.statusText = $id('at-status-text');
        uiRefs.lastUpdate = $id('at-lastupdate');
        uiRefs.avatar = $id('at-avatar');
        uiRefs.name = $id('at-name');
        uiRefs.class = $id('at-class');
        uiRefs.baseLv = $id('at-baselv');
        uiRefs.jobLv = $id('at-joblv');
        uiRefs.weight = $id('at-weight');
        uiRefs.weightBar = $id('at-weight-bar');
        uiRefs.zeny = $id('at-zeny');
        uiRefs.slots = $id('at-slots');
        uiRefs.buffBadge = $id('at-buff-badge');
        uiRefs.buffIcon = $id('at-buff-icon');
        uiRefs.buffText = $id('at-buff-text');
        uiRefs.map = $id('at-map');
        uiRefs.channel = $id('at-channel');
        uiRefs.ping = $id('at-ping');
        uiRefs.pingDot = $id('at-ping-dot');
        uiRefs.pingText = $id('at-ping-text');
        uiRefs.settingsBtn = $id('at-btn-settings');
        uiRefs.profitBtn = $id('at-btn-profit');
        uiRefs.logsBtn = $id('at-btn-logs');
        uiRefs.minBtn = $id('at-btn-min');
        uiRefs.urlInput = $id('at-url-input');
        uiRefs.saveUrlBtn = $id('at-url-save');
        uiRefs.sendNowBtn = $id('at-send-now');
        uiRefs.dcUrl = $id('at-dc-url');
        uiRefs.dcPing = $id('at-dc-ping');
        uiRefs.dcSum = $id('ac-dc-sum');
        uiRefs.swDc = $id('at-sw-dc');

        uiRefs.urlInput.value = State.webAppUrl;
        uiRefs.dcUrl.value = State.discordUrl;
        uiRefs.dcPing.value = State.dcPing;
        uiRefs.minBtn.textContent = State.isMinimized ? '+' : '−';
        uiRefs.profitBtn.classList.toggle('active', State.isProfitOpen);
        uiRefs.logsBtn.classList.toggle('active', State.isLogsOpen);
        setUI('statusText', State.statusText);
        uiRefs.statusDot.className = `at-dot at-dot-${State.statusType}`;
        renderedState.statusType = State.statusType;
        for (const [id, on] of [
            ['at-sw-revive', State.isReviveEnabled],
            ['at-sw-auto', State.isAutoEnabled],
            ['at-sw-sync', State.isSyncEnabled],
        ]) $id(id).classList.toggle('on', on);
        updateDiscordUI();
        updateAutoSum();
        switchCfgTab(State.cfgTab);

        // พิมพ์ในช่อง input แล้วไม่ให้ปุ่มลัดของเกมทำงาน
        for (const inp of [uiRefs.urlInput, uiRefs.dcUrl, uiRefs.dcPing]) {
            inp.addEventListener('keydown', (e) => e.stopPropagation());
            inp.addEventListener('keyup', (e) => e.stopPropagation());
        }

        uiRefs.profitBtn.addEventListener('click', (e) => { e.stopPropagation(); toggleProfit(); });
        uiRefs.logsBtn.addEventListener('click', (e) => { e.stopPropagation(); toggleLogs(); });
        $id('at-btn-pause').addEventListener('click', (e) => { e.stopPropagation(); setPauseAll(!Pause.manual); });
        $id('at-reload-all').addEventListener('click', (e) => { e.stopPropagation(); reloadAll(); });
        $id('at-resume-btn').addEventListener('click', (e) => { e.stopPropagation(); Pause.manual = false; Pause.userUntil = 0; renderPause(); Dev.resumeFarm(); });
        $id('at-btn-wiki').addEventListener('click', (e) => { e.stopPropagation(); if (Wiki.el) closeWiki(); else openWiki(); });

        uiRefs.settingsBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            State.isSettingsOpen = !State.isSettingsOpen;
            updateSettingsVisibility();
        });
        $id('ac-close').addEventListener('click', (e) => {
            e.stopPropagation();
            State.isSettingsOpen = false;
            updateSettingsVisibility();
        });
        cfg.querySelectorAll('.ac-tab').forEach((b) => b.addEventListener('click', (e) => { e.stopPropagation(); switchCfgTab(b.dataset.tab); }));

        uiRefs.minBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            State.isMinimized = !State.isMinimized;
            panel.classList.toggle('minimized', State.isMinimized);
            uiRefs.minBtn.textContent = State.isMinimized ? '+' : '−';
            savePrefs();
            positionProfitPanel();
        });

        uiRefs.saveUrlBtn.addEventListener('click', (e) => { e.stopPropagation(); testAndSaveUrl(uiRefs.urlInput.value); });
        uiRefs.sendNowBtn.addEventListener('click', (e) => { e.stopPropagation(); sendToSheet(true); });

        // ----- หน้าจอ: ขนาด / เลย์เอาต์ / ตำแหน่ง Profit -----
        const scaleEl = $id('at-scale'), layoutBtn = $id('at-layout-btn');
        const applyLook = () => {
            let st = document.getElementById('at-look-style');
            if (!st) { st = document.createElement('style'); st.id = 'at-look-style'; document.head.appendChild(st); }
            st.textContent = `#aetheria-tracker,#aetheria-profit,#aetheria-dps,#aetheria-logs,#aetheria-config,#aetheria-stats{transform:scale(${State.uiScale});transform-origin:top left}#aetheria-config,#aetheria-stats{--at-s:${State.uiScale}}`;
            panel.classList.toggle('wide', State.wideLayout);
            setT($id('at-scale-label'), Math.round(State.uiScale * 100) + '%');
            layoutBtn.textContent = State.wideLayout ? '↔ กว้าง' : '↕ แคบ';
            scaleEl.value = Math.round(State.uiScale * 100);
            positionProfitPanel();
            positionConfig(true);
        };
        scaleEl.addEventListener('input', () => { State.uiScale = scaleEl.value / 100; savePrefs(); applyLook(); });
        layoutBtn.addEventListener('click', (e) => { e.stopPropagation(); State.wideLayout = !State.wideLayout; savePrefs(); applyLook(); });
        $id('at-dock-btn').addEventListener('click', (e) => { e.stopPropagation(); toggleDock(); });
        $id('at-reset-pos').addEventListener('click', (e) => {
            e.stopPropagation();
            for (const k of ['at_profit_pos', 'at_dps_pos', 'at_logs_pos', 'at_config_pos', 'at_stats_pos']) Store.remove(k);
            for (const [w, y] of [[dRefs.panel, 120], [lRefs.panel, 160]]) if (w) { w.style.left = '20px'; w.style.top = y + 'px'; }
            cfg.dataset.placed = '0';
            for (const id of WIN_IDS) { const el = document.getElementById(id); if (el) el.dataset.user = ''; }
            relayoutAll();
            if (sRefs.panel) positionStats(true);
            toggleDock(true);
            showToast('↺ รีเซ็ตตำแหน่งหน้าต่างแล้ว', 'ok');
        });

        // ----- ตัวกรอง / แท็ก -----
        const bindChecks = (sel, attr, store) => cfg.querySelectorAll(sel).forEach((cb) => {
            const k = cb.dataset[attr];
            cb.checked = !!store[k];
            cb.addEventListener('click', (e) => e.stopPropagation());
            cb.addEventListener('change', () => { store[k] = cb.checked; savePrefs(); });
        });
        bindChecks('#at-cat-f input', 'cat', State.filter.cats);
        bindChecks('#at-rar-f input', 'rar', State.filter.rars);
        bindChecks('#at-pingrar-f input', 'pingrar', State.pingRars);
        const pd = cfg.querySelector('input[data-pingdeath]');
        pd.checked = State.pingDeath;
        pd.addEventListener('click', (e) => e.stopPropagation());
        pd.addEventListener('change', () => { State.pingDeath = pd.checked; savePrefs(); });
        applyLook();
        updateDockUI();
        bindConfigExtras(cfg);

        // ----- Discord -----
        uiRefs.swDc.addEventListener('click', (e) => {
            e.stopPropagation();
            if (!State.discordOn && !REGEX.discordUrl.test(State.discordUrl)) {
                showToast('⚠️ วาง Discord Webhook URL แล้วกดบันทึกก่อน', 'warn');
                return;
            }
            State.discordOn = !State.discordOn;
            savePrefs();
            updateDiscordUI();
            Log.info('DISCORD', State.discordOn ? 'เปิดแจ้งเตือน Discord' : 'ปิดแจ้งเตือน Discord');
        });
        const saveDc = (quiet) => {
            const v = uiRefs.dcUrl.value.trim();
            const id = uiRefs.dcPing.value.replace(/\D/g, '');
            if (v && !REGEX.discordUrl.test(v)) {
                showToast('⚠️ Webhook URL ไม่ถูกต้อง (ต้องขึ้นต้น https://discord.com/api/webhooks/...)', 'err');
                return false;
            }
            State.discordUrl = v;
            State.dcPing = id;
            uiRefs.dcPing.value = id;
            if (!v) State.discordOn = false;
            savePrefs();
            updateDiscordUI();
            if (!quiet) showToast(v ? '✅ บันทึก Discord แล้ว' : '🗑️ ล้าง Webhook แล้ว', 'ok');
            Log.ok('DISCORD', v ? `บันทึก Webhook${id ? ' + User ID' : ''}` : 'ล้าง Webhook');
            return true;
        };
        $id('at-dc-save').addEventListener('click', (e) => { e.stopPropagation(); saveDc(false); });
        cfg.querySelectorAll('input[data-topic]').forEach((cb) => {
            cb.addEventListener('click', (e) => e.stopPropagation());
            cb.addEventListener('change', () => {
                State.dcTopics[cb.dataset.topic] = cb.checked;
                savePrefs();
                updateDiscordUI();
            });
        });
        $id('at-dc-test').addEventListener('click', (e) => {
            e.stopPropagation();
            if (!saveDc(true) || !State.discordUrl) { showToast('⚠️ ใส่ Webhook URL ก่อน', 'warn'); return; }
            sendDiscord('death', {
                title: '📨 ทดสอบการแจ้งเตือน',
                description: `ระบบแจ้งเตือนของ **${Profit.charName || 'Aetheria Tracker'}** ทำงานปกติ`,
                color: 0xfcd34d,
            }, {
                force: true, ping: true,
                onDone: (ok, status) => showToast(ok ? '✅ ส่งทดสอบไป Discord แล้ว' : `❌ ส่งไม่สำเร็จ (${status || 'เครือข่าย'})`, ok ? 'ok' : 'err'),
            });
        });

        bindSwitch('at-sw-revive', () => State.isReviveEnabled, (v) => { State.isReviveEnabled = v; savePrefs(); });
        bindSwitch('at-sw-auto', () => State.isAutoEnabled, (v) => { State.isAutoEnabled = v; State.autoAttempts = 0; savePrefs(); });
        { const wi = $id('at-warp-dest'); if (wi) { wi.value = Store.get('at_warp_dest') || ''; wi.addEventListener('change', () => { const v = wi.value.trim(); Store.set('at_warp_dest', v); try { const known = JSON.parse(localStorage.getItem('at_warp_names') || '[]'); if (v && known.some((n) => String(n).toLowerCase() === v.toLowerCase())) Dev.warpPick(v); } catch (e) { /* ignore */ } }); wi.addEventListener('focus', () => { try { Dev.warpNames(); } catch (e) { /* ignore */ } }, { once: true }); }
          const wsel = $id('at-warp-sel'); wsel.addEventListener('change', () => { if (wsel.value) { wi.value = wsel.value; Store.set('at_warp_dest', wi.value); try { Dev.warpPick(wsel.value); } catch (e) { /* ignore */ } wsel.value = ''; } });
          const wwk = $id('at-warp-walk'); wwk.value = State.opt.walkMode || 'auto'; wwk.addEventListener('change', () => { State.opt.walkMode = wwk.value; savePrefs(); });
          $id('at-warp-scan').addEventListener('click', () => Dev.warpScan());
          try { Dev.warpSel(); } catch (e) { /* ignore */ }
          $id('at-warp-go').addEventListener('click', () => { const v = (wi.value || '').trim(); Store.set('at_warp_dest', v); Dev.warpPick(v); });
          $id('at-warp-stop').addEventListener('click', () => Dev.warpStop());
          // ช่องเลือกจากรายการ: โฟกัส/พิมพ์แล้วมีตัวเลือกขึ้นมา (กรองตามตัวอักษรที่พิมพ์) · รองรับรูปไอเทม
          const attachPicker = (inp, getOpts, hint) => {
            const doc0 = inp.ownerDocument; let box = null; const close = () => { if (box) { box.remove(); box = null; } };
            let retried = false;
            const open = () => {
              let opts = []; try { opts = getOpts() || []; } catch (e) { /* ignore */ }
              if (!opts.length && !retried && hint) { retried = true; setTimeout(() => { retried = false; if (doc0.activeElement === inp) open(); }, 1800); }
              const q = (inp.value || '').trim().toLowerCase();
              const list = opts.filter((o) => !q || o.label.toLowerCase().includes(q)).slice(0, 40);
              close(); box = document.createElement('div');
              const r = inp.getBoundingClientRect();
              box.style.cssText = `position:fixed;left:${r.left}px;top:${r.bottom + 2}px;width:${Math.max(r.width, 220)}px;max-height:240px;overflow:auto;background:#17151f;border:1px solid #a78bfa;border-radius:8px;z-index:2147483600;box-shadow:0 8px 24px rgba(0,0,0,.6);font:12px system-ui,sans-serif;color:#eee`;
              if (!list.length) { box.innerHTML = `<div style="padding:8px;opacity:.7">${hint || 'ไม่พบรายการ — พิมพ์ชื่อเองได้'}</div>`; }
              for (const o of list) {
                const row = document.createElement('div'); row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:5px 8px;cursor:pointer';
                row.onmouseenter = () => { row.style.background = 'rgba(167,139,250,.25)'; }; row.onmouseleave = () => { row.style.background = ''; };
                if (o.img) { const im = document.createElement('img'); im.src = o.img; im.style.cssText = 'width:24px;height:24px;object-fit:contain;image-rendering:pixelated'; im.onerror = () => { im.style.visibility = 'hidden'; }; row.appendChild(im); }
                const t = document.createElement('span'); t.textContent = o.label; t.style.flex = '1'; row.appendChild(t);
                if (o.sub) { const sb = document.createElement('span'); sb.textContent = o.sub; sb.style.opacity = '.6'; row.appendChild(sb); }
                row.addEventListener('mousedown', (e) => { e.preventDefault(); inp.value = o.label; inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true })); close(); });
                box.appendChild(row);
              }
              document.body.appendChild(box);
            };
            inp.addEventListener('focus', open); inp.addEventListener('input', open); inp.addEventListener('blur', () => setTimeout(close, 150));
            inp.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
          };
          const npcOpts = () => Dev.npcNames().map((n) => ({ label: n }));
          const itemOpts = () => { const its = (Profit.db && Profit.db.items) || {}; return Object.keys(its).sort((a, b) => a.localeCompare(b)).map((n) => { const id = its[n] && its[n][0]; return { label: n, img: id ? (itemIconSrc(id) || `/art/icons/i/${id}.webp`) : '' }; }); };
          { const wn = $id('at-walk-npc'); if (wn) attachPicker(wn, npcOpts, 'ไม่พบ NPC ในแมพนี้ (ต้องโหลดแผนที่ก่อน) — พิมพ์ชื่อเองได้'); const bnp = $id('at-buy-npc'); if (bnp) attachPicker(bnp, npcOpts, 'ไม่พบ NPC ในแมพนี้ — ไปที่เมืองหลวงก่อน หรือพิมพ์ชื่อเองได้'); }
          { const zm = $id('at-zone-max'); if (zm) { zm.value = State.opt.warpZoneMax == null ? 80 : State.opt.warpZoneMax; zm.addEventListener('change', () => { State.opt.warpZoneMax = Math.max(0, Math.min(999, parseInt(zm.value, 10) || 0)); zm.value = State.opt.warpZoneMax; savePrefs(); }); } }
          { const ze = $id('at-zone-edit'); if (ze) ze.addEventListener('click', () => Dev.zoneEdit()); }
          $id('at-walk-test').addEventListener('click', () => Dev.walkTalk($id('at-walk-npc').value));
          { const sr = $id('at-stat-rows');
            const SK = ['STR', 'AGI', 'VIT', 'INT', 'DEX', 'LUK'];
            const renderStat = () => {
              if (!sr) return; sr.innerHTML = '';
              if (!Array.isArray(State.opt.stat)) State.opt.stat = [];
              State.opt.stat.forEach((r, i) => {
                const sel = document.createElement('select'); sel.className = 'at-input'; SK.forEach((k) => { const o = document.createElement('option'); o.value = k; o.textContent = k; sel.appendChild(o); }); sel.value = r.s || 'STR';
                const t = document.createElement('input'); t.type = 'number'; t.min = '0'; t.max = '999'; t.className = 'at-input'; t.value = r.t || 0;
                const save = () => { State.opt.stat[i] = { s: sel.value, t: Math.max(0, parseInt(t.value, 10) || 0) }; savePrefs(); };
                sel.addEventListener('change', save); t.addEventListener('change', save);
                const x = document.createElement('button'); x.className = 'at-btn-ghost'; x.textContent = '✕'; x.style.cssText = 'padding:0;width:26px'; x.addEventListener('click', () => { State.opt.stat.splice(i, 1); savePrefs(); renderStat(); });
                sr.append(sel, t, x);
              });
            };
            renderStat();
            const sa = $id('at-stat-add'); if (sa) sa.addEventListener('click', () => { if (State.opt.stat.length >= 6) return; State.opt.stat.push({ s: SK.find((k) => !State.opt.stat.some((r) => r.s === k)) || 'STR', t: 99 }); savePrefs(); renderStat(); });
            const sn = $id('at-stat-now'); if (sn) sn.addEventListener('click', () => Dev.statRun(true)); }
          { const rows = $id('at-buy-rows');
            const renderBuy = () => {
              if (!rows) return; rows.innerHTML = '';
              if (!Array.isArray(State.opt.buy) || !State.opt.buy.length) State.opt.buy = [{ n: '', min: 0, q: 0 }];
              State.opt.buy.forEach((b, i) => {
                const mk = (ph, v, num) => { const e = document.createElement('input'); e.className = 'at-input'; e.type = num ? 'number' : 'text'; if (num) e.min = '0'; e.placeholder = ph; e.value = num ? (v || 0) : (v || ''); return e; };
                const n = mk('เช่น Fly Wing', b.n, false), m = mk('0', b.min, true), q = mk('0', b.q, true);
                const save = () => { State.opt.buy[i] = { n: n.value.trim(), min: Math.max(0, parseInt(m.value, 10) || 0), q: Math.max(0, parseInt(q.value, 10) || 0) }; savePrefs(); };
                [n, m, q].forEach((e) => e.addEventListener('change', save)); attachPicker(n, itemOpts, 'ไม่พบไอเทม — พิมพ์ชื่อภาษาอังกฤษเองได้');
                const x = document.createElement('button'); x.className = 'at-btn-ghost'; x.textContent = '✕'; x.title = 'ลบบรรทัดนี้'; x.style.cssText = 'padding:0;width:26px'; x.addEventListener('click', () => { State.opt.buy.splice(i, 1); savePrefs(); renderBuy(); });
                rows.append(n, m, q, x);
              });
            };
            renderBuy();
            const ba = $id('at-buy-add'); if (ba) ba.addEventListener('click', () => { if (State.opt.buy.length >= 12) return; State.opt.buy.push({ n: '', min: 0, q: 0 }); savePrefs(); renderBuy(); });
            const bn = $id('at-buy-npc'); if (bn) { bn.value = State.opt.buyNpc || 'Shopkeeper'; bn.addEventListener('change', () => { State.opt.buyNpc = bn.value.trim() || 'Shopkeeper'; savePrefs(); }); }
            const bb = $id('at-buy-now'); if (bb) bb.addEventListener('click', () => Dev.buyRun({ force: true })); } }
        bindSwitch('at-sw-sync', () => State.isSyncEnabled, (v) => { State.isSyncEnabled = v; savePrefs(); });

        makeDraggable(panel, $id('at-drag-handle'));
        const hadPos = !!Store.getJSON('at_config_pos');
        makeWindowDraggable(cfg, $id('ac-drag'), 'at_config_pos');
        if (hadPos) cfg.dataset.placed = '1';
        updateSettingsVisibility();
    }

    // ไอคอนตัวละคร: คัดลอกจากภาพหน้า (.hud-head .portrait) ของเกม
    function renderAvatar() {
        const box = uiRefs.avatar;
        if (!box) return;
        const el = queryGame(SELECTORS.portrait);
        let key = renderedState.avatarKey || 'none';
        if (el) key = el.tagName === 'IMG' ? 'img:' + (el.getAttribute('src') || '') : 'txt:' + norm(el.textContent);
        if (renderedState.avatarKey === key) return;
        renderedState.avatarKey = key;
        box.textContent = '';
        if (key.startsWith('img:') && key.length > 4) {
            const img = h('img');
            img.src = key.slice(4);
            img.alt = '';
            img.draggable = false;
            box.appendChild(img);
        } else if (key.startsWith('txt:') && key.length > 4) {
            box.textContent = key.slice(4, 6);
        } else {
            box.textContent = '👤';
        }
    }

    function renderPing() {
        const sum = Ping.summary || summarizePing();
        setUI('pingText', sum.text);
        if (renderedState.pingLevel !== sum.level && uiRefs.pingDot) {
            renderedState.pingLevel = sum.level;
            uiRefs.pingDot.className = `at-ping-dot ${sum.level}`;
        }
        if (uiRefs.ping && renderedState.pingTip !== sum.tip) {
            renderedState.pingTip = sum.tip;
            uiRefs.ping.title = sum.tip;
        }
    }

    function renderUI() {
        const { raw, meta } = collectSnapshotData();

        setUI('name', raw.name);
        setUI('class', raw.class);
        setUI('baseLv', raw.baseLv);
        setUI('jobLv', raw.jobLv);
        setUI('weight', raw.weight);
        setUI('zeny', raw.zeny);
        setUI('slots', raw.slots);
        if (uiRefs.slots) {
            const m = /(\d+)\s*\/\s*(\d+)/.exec(raw.slots || '');
            const r = m && +m[2] > 0 ? +m[1] / +m[2] : -1;
            uiRefs.slots.style.color = r < 0 ? '' : r >= 1 ? '#ef4444' : r >= 0.85 ? '#fb923c' : r >= 0.5 ? '#facc15' : '#4ade80';
        }
        setUI('map', raw.map);
        setUI('channel', raw.channel);
        setUI('buffText', raw.premiumBuff);
        setUI('lastUpdate', fmtClock(Date.now()));

        if (renderedState.weightPct !== meta.weightPct && uiRefs.weightBar) {
            renderedState.weightPct = meta.weightPct;
            uiRefs.weightBar.style.width = `${meta.weightPct}%`;
            uiRefs.weightBar.className = 'at-progress-fill' + (meta.weightPct >= 90 ? ' danger' : meta.weightPct >= 50 ? ' warn' : '');
        }

        if (renderedState.buffActive !== meta.buffActive && uiRefs.buffBadge) {
            renderedState.buffActive = meta.buffActive;
            uiRefs.buffBadge.className = `at-buff-badge ${meta.buffActive ? 'active' : 'empty'}`;
            if (uiRefs.buffIcon) uiRefs.buffIcon.style.display = meta.buffActive && meta.buffIcon ? 'inline-block' : 'none';
        }
        if (meta.buffActive && meta.buffIcon && renderedState.buffIcon !== meta.buffIcon && uiRefs.buffIcon) {
            renderedState.buffIcon = meta.buffIcon;
            uiRefs.buffIcon.src = meta.buffIcon;
            uiRefs.buffIcon.style.display = 'inline-block';
        }

        renderAvatar();
        renderPing();
    }

    function makeDraggable(panel, handle) {
        let ox = 0, oy = 0, dragging = false, rafId = null;
        let curX = State.panelX, curY = State.panelY;

        handle.addEventListener('pointerdown', (e) => {
            if (e.target.closest('button')) return;
            dragging = true;
            const r = panel.getBoundingClientRect();
            ox = e.clientX - r.left;
            oy = e.clientY - r.top;
            handle.setPointerCapture(e.pointerId);
        });

        handle.addEventListener('pointermove', (e) => {
            if (!dragging) return;
            const maxX = Math.max(0, window.innerWidth - panel.offsetWidth);
            const maxY = Math.max(0, window.innerHeight - 44);
            curX = Math.min(Math.max(0, e.clientX - ox), maxX) + 'px';
            curY = Math.min(Math.max(0, e.clientY - oy), maxY) + 'px';

            if (!rafId) {
                rafId = requestAnimationFrame(() => {
                    panel.style.left = curX;
                    panel.style.top = curY;
                    positionProfitPanel();
                    rafId = null;
                });
            }
        });

        const stopDrag = () => {
            if (!dragging) return;
            dragging = false;
            if (rafId) { cancelAnimationFrame(rafId); rafId = null; }
            panel.style.left = curX;
            panel.style.top = curY;
            positionProfitPanel();
            savePos(curX, curY);
        };

        handle.addEventListener('pointerup', stopDrag);
        handle.addEventListener('pointercancel', stopDrag);
    }

    // หน้าต่างลอยอิสระ (DPS / Logs): ลากไปไหนในจอก็ได้ จำตำแหน่งไว้
    function clampWindow(win) {
        const r = win.getBoundingClientRect();
        const x = Math.min(Math.max(0, r.left), Math.max(0, window.innerWidth - Math.min(r.width, window.innerWidth)));
        const y = Math.min(Math.max(0, r.top), Math.max(0, window.innerHeight - 44));
        win.style.left = x + 'px';
        win.style.top = y + 'px';
    }

    function makeWindowDraggable(win, handle, posKey, onStart) {
        const saved = Store.getJSON(posKey);
        if (saved && typeof saved.x === 'number') {
            win.style.left = saved.x + 'px';
            win.style.top = saved.y + 'px';
        }
        let ox = 0, oy = 0, dragging = false;
        handle.addEventListener('pointerdown', (e) => {
            if (e.target.closest('button')) return;
            if (onStart) onStart();
            dragging = true;
            const r = win.getBoundingClientRect();
            ox = e.clientX - r.left;
            oy = e.clientY - r.top;
            handle.setPointerCapture(e.pointerId);
        });
        handle.addEventListener('pointermove', (e) => {
            if (!dragging) return;
            win.dataset.user = '1';
            win.classList.remove('at-glide');
            const maxX = Math.max(0, window.innerWidth - win.getBoundingClientRect().width);
            const maxY = Math.max(0, window.innerHeight - 44);
            win.style.left = Math.min(Math.max(0, e.clientX - ox), maxX) + 'px';
            win.style.top = Math.min(Math.max(0, e.clientY - oy), maxY) + 'px';
        });
        const stop = () => {
            if (!dragging) return;
            dragging = false;
            Store.set(posKey, JSON.stringify({ x: parseInt(win.style.left, 10) || 0, y: parseInt(win.style.top, 10) || 0 }));
        };
        handle.addEventListener('pointerup', stop);
        handle.addEventListener('pointercancel', stop);
    }

    // ---------------------------------------------------------------
    // Profit panel (แท็บข้างแผงหลัก): วัตถุดิบ / Item Drops / Monster Kills (พับได้)
    // ---------------------------------------------------------------
    const SECTIONS = [
        { key: 'mats', title: '💎 วัตถุดิบ' },
        { key: 'drops', title: '📦 Item Drops' },
        { key: 'kills', title: '⚔️ Monster Kills' },
    ];

    function toggleSection(key) {
        State.secOpen[key] = !State.secOpen[key];
        savePrefs();
        const s = pRefs.sec[key];
        pRefs.secRev[key] = -1;
        if (key === 'kills' && State.secOpen.kills) ensureMonsterManifest();
        if (State.secOpen[key]) {
            s.el.classList.add('open');
            renderProfit();
            Anim.slide(s.body, true);
        } else {
            Anim.slide(s.body, false, () => s.el.classList.remove('open'));
            renderProfit();
        }
    }

    function buildProfitPanel() {
        if (document.getElementById('aetheria-profit')) return;
        injectStyles();

        const p = document.createElement('div');
        p.id = 'aetheria-profit';
        p.style.display = State.isProfitOpen ? 'flex' : 'none';
        p.innerHTML = `
            <div class="ap-header">
                <span class="ap-title">💰 Profit</span>
                <span class="ap-chip off" id="ap-chip">⏸️ หยุดนับ</span>
                <button class="ap-hbtn" id="ap-dock" type="button"></button>
            </div>
            <div class="ap-mapbar"><span>🗺️ แมพ</span><select id="ap-map" title="เลือกดู Profit แยกรายแมพ — ไม่รวมกันระหว่างแมพ"></select></div>
            <div class="ap-adv" id="ap-adv" style="display:none"></div>
            <div class="ap-summary">
                <div class="ap-card"><span>⏱️ เวลาฟาร์ม</span><b id="ap-time">00:00:00</b></div>
                <div class="ap-card"><span>💰 รวมวัตถุดิบ</span><b id="ap-total">0 z</b></div>
                <div class="ap-card hot"><span>📈 ต่อชั่วโมง</span><b id="ap-rate">—</b></div>
                <div class="ap-card"><span>⚔️ ฆ่ามอน</span><b id="ap-kills">0 ตัว</b></div>
                <div class="ap-card"><span>🎯 ฆ่า/ชม.</span><b id="ap-krate">—</b></div>
                <div class="ap-card"><span>🪙 Zeny/ตัว</span><b id="ap-perkill">—</b></div>
                <div class="ap-card"><span>✨ Base EXP</span><b id="ap-bexp">—</b></div>
                <div class="ap-card"><span>✨ Job EXP</span><b id="ap-jexp">—</b></div>
                <div class="ap-card"><span>🎯 ถึง Lv 99</span><b id="ap-ttl">—</b></div>
            </div>
            <div class="ap-scroll" id="ap-scroll"></div>
            <div class="ap-foot">
                <button class="ap-btn" id="ap-refresh">🔄 ราคา</button>
                <button class="ap-btn hot" id="ap-stats">📈 สถิติ</button>
                <button class="ap-btn danger" id="ap-clear">🗑️ ล้างแมพนี้</button>
            </div>
            <div class="ap-note" id="ap-note"></div>
        `;
        document.body.appendChild(p);

        const $id = (id) => document.getElementById(id);
        pRefs.panel = p;
        pRefs.chip = $id('ap-chip');
        pRefs.time = $id('ap-time');
        pRefs.total = $id('ap-total');
        pRefs.rate = $id('ap-rate');
        pRefs.kills = $id('ap-kills');
        pRefs.krate = $id('ap-krate');
        pRefs.perkill = $id('ap-perkill');
        pRefs.bexp = $id('ap-bexp');
        pRefs.jexp = $id('ap-jexp');
        pRefs.ttl = $id('ap-ttl');
        pRefs.map = $id('ap-map');
        pRefs.adv = $id('ap-adv');
        pRefs.advAt = 0;
        pRefs.advSig = '';
        pRefs.mapSig = '';
        pRefs.lastView = null;
        pRefs.map.addEventListener('click', (e) => e.stopPropagation());
        pRefs.map.addEventListener('change', () => { Profit.viewMap = pRefs.map.value; pRefs.mapSig = ''; pRefs.lastView = null; Profit.rev++; renderProfit(); });
        pRefs.scroll = $id('ap-scroll');
        pRefs.refresh = $id('ap-refresh');
        pRefs.clear = $id('ap-clear');
        pRefs.note = $id('ap-note');
        pRefs.dock = $id('ap-dock');
        $id('ap-stats').addEventListener('click', (e) => { e.stopPropagation(); toggleStats(); });
        pRefs.secRev = {};
        pRefs.sec = {};

        for (const def of SECTIONS) {
            const el = h('section', 'ap-sec' + (State.secOpen[def.key] ? ' open' : ''));
            const head = h('button', 'ap-sec-head');
            head.type = 'button';
            head.appendChild(h('i', 'at-chev', '▸'));
            head.appendChild(h('span', '', def.title));
            const sum = h('em', '', '');
            head.appendChild(sum);
            const body = h('div', 'ap-sec-body');
            el.appendChild(head);
            el.appendChild(body);
            pRefs.scroll.appendChild(el);
            pRefs.sec[def.key] = { el, head, body, sum };
            head.addEventListener('click', (e) => { e.stopPropagation(); toggleSection(def.key); });
        }
        pRefs.dock.addEventListener('click', (e) => { e.stopPropagation(); toggleDock(); });
        makeWindowDraggable(p, p.querySelector('.ap-header'), 'at_profit_pos', () => { if (State.profitDocked) toggleDock(false); });
        updateDockUI();

        pRefs.refresh.addEventListener('click', async (e) => {
            e.stopPropagation();
            pRefs.refresh.disabled = true;
            await loadPriceDB(true);
            pRefs.refresh.disabled = false;
            const ok = Profit.db.status === 'ok';
            showToast(ok ? '✅ อัปเดตราคา/ข้อมูลไอเทมแล้ว' : '⚠️ โหลดข้อมูลไม่สำเร็จ (ใช้ข้อมูลเดิม)', ok ? 'ok' : 'warn');
        });

        pRefs.clear.addEventListener('click', (e) => {
            e.stopPropagation();
            const now = Date.now();
            if (now < Profit.confirmClearUntil) {
                clearProfit();
                return;
            }
            Profit.confirmClearUntil = now + 4000;
            pRefs.clear.textContent = '⚠️ กดอีกครั้งเพื่อยืนยัน';
            setTimeout(() => {
                if (Date.now() >= Profit.confirmClearUntil && pRefs.clear) pRefs.clear.textContent = '🗑️ ล้างแมพนี้';
            }, 4100);
        });

        if (State.secOpen.kills) ensureMonsterManifest();
    }

    function updateDockUI() {
        const t = State.profitDocked ? '🔓 แยก' : '📌 ติดกลับ';
        if (pRefs.dock) {
            pRefs.dock.textContent = t;
            pRefs.dock.title = State.profitDocked ? 'แยกหน้าต่าง Profit (หรือลากหัวหน้าต่าง)' : 'ติดกลับกับแผงหลัก';
            pRefs.dock.classList.toggle('on', !State.profitDocked);
        }
        const b = document.getElementById('at-dock-btn');
        if (b) b.textContent = State.profitDocked ? '📌 ติดกับแผงหลัก (กดเพื่อแยก)' : '🔓 แยกอิสระ (กดเพื่อติดกลับ)';
    }

    function toggleDock(force) {
        State.profitDocked = typeof force === 'boolean' ? force : !State.profitDocked;
        savePrefs();
        updateDockUI();
        if (State.profitDocked) positionProfitPanel();
        else if (pRefs.panel) { pRefs.panel.dataset.user = ''; clampWindow(pRefs.panel); }
        relayoutAll();
    }

    // ติดด้านซ้ายของแผงหลัก (ถ้าที่ไม่พอ ย้ายไปด้านขวา) · คำนวณด้วยขนาดจริงหลังย่อ/ขยาย เพื่อให้ชิดทุกระดับ UI
    function positionProfitPanel() {
        const p = pRefs.panel;
        const main = uiRefs.panel;
        if (!p || !main || !State.isProfitOpen || !State.profitDocked) return;
        const r = main.getBoundingClientRect();
        const pw = p.getBoundingClientRect().width || 330 * State.uiScale;
        const sig = `${Math.round(r.left)},${Math.round(r.top)},${Math.round(pw)},${window.innerWidth},${window.innerHeight},${State.uiScale}`;
        if (p._posSig === sig) return; // ไม่มีอะไรเปลี่ยน ไม่ต้องเขียน style ซ้ำทุกวินาที
        p._posSig = sig;
        const gap = 6 * State.uiScale;
        let left = r.left - pw - gap;
        if (left < 4) left = Math.min(r.right + gap, Math.max(4, window.innerWidth - pw - 4));
        p.style.left = Math.max(4, left) + 'px';
        p.style.top = Math.max(4, r.top) + 'px';
        p.style.maxHeight = Math.max(260, (window.innerHeight - r.top - 12) / State.uiScale) + 'px';
    }

    function makeRow({ icon, name, nameColor, sub, right, rightColor, onRemove, info }) {
        const row = h('div', 'ap-row');
        let ic;
        if (icon) {
            ic = h('img', 'ap-icon');
            ic.src = icon;
            ic.alt = '';
            ic.draggable = false;
        } else {
            ic = h('span', 'ap-icon ap-icon-ph', name.slice(0, 2));
        }
        if (info) {
            ic.classList.add('ap-clickable');
            ic.title = 'กดดูข้อมูลจาก wiki';
            ic.addEventListener('click', (e) => { e.stopPropagation(); openInfo(info, name); });
        }
        const mid = h('div', 'ap-mid');
        const nm = h('div', 'ap-name', name);
        if (info === 'item' && Info.byItemName) { const wi = Info.byItemName.get(norm(name)); const jc = wi && junkGet()[wi.id]; if (jc) { const em = JUNK_CLS.find((c) => c[0] === jc.c); if (em) { const bg = h('span', 'ap-jb', em[1]); bg.title = em[2]; nm.appendChild(bg); } } }
        if (info) { nm.classList.add('ap-clickable'); nm.addEventListener('click', (e) => { e.stopPropagation(); openInfo(info, name); }); }
        if (nameColor) nm.style.color = nameColor;
        mid.appendChild(nm);
        mid.appendChild(h('div', 'ap-sub', sub));
        const sum = h('div', 'ap-sum', right);
        if (rightColor) sum.style.color = rightColor;
        row.appendChild(ic);
        row.appendChild(mid);
        row.appendChild(sum);
        if (info) {
            attachTip(row, nameTipBuilder(info, name));
            row.classList.add('ap-rowc');
            row.addEventListener('click', (e) => { if (e.target.closest('.ap-rm')) return; openInfo(info, name); });
        }
        if (onRemove) {
            const x = h('button', 'ap-rm', '✕');
            x.type = 'button';
            x.title = 'ลบรายการนี้ออกจากแมพนี้ (กดสองครั้งเพื่อยืนยัน)';
            let armed = 0;
            x.addEventListener('click', (e) => {
                e.stopPropagation();
                if (Date.now() < armed) { onRemove(); return; }
                armed = Date.now() + 3000;
                x.textContent = 'ลบ?';
                x.classList.add('arm');
                setTimeout(() => { x.textContent = '✕'; x.classList.remove('arm'); }, 3100);
            });
            row.appendChild(x);
        }
        return row;
    }

    function fillSection(key, rows, emptyText) {
        const body = pRefs.sec[key].body;
        body.textContent = '';
        if (!rows.length) {
            body.appendChild(h('div', 'ap-empty', emptyText));
            return;
        }
        const frag = document.createDocumentFragment();
        for (const r of rows) frag.appendChild(makeRow(r));
        body.appendChild(frag);
    }

    function renderSectionBody(key, t) {
        const lgv = Profit.data;
        const rmItem = (bag, k) => () => { delete lgv[bag][k]; Profit.dirty = true; Profit.rev++; Log.warn('PROFIT', `ลบ ${k} ออกจากแมพ "${viewMapName()}"`); };
        if (key === 'mats') {
            const rows = Object.values(Profit.data.items)
                .sort((a, b) => b.qty * b.price - a.qty * a.price)
                .map((e) => ({
                    icon: e.icon,
                    name: e.name,
                    nameColor: rarityOf(e.rarity).color,
                    sub: e.price > 0 ? `${fmt(e.price)} z × ${fmt(e.qty)}` : `ไม่มีราคา × ${fmt(e.qty)}`,
                    right: `${fmt(e.qty * e.price)} z`,
                    onRemove: rmItem('items', e.name),
                    info: 'item',
                }));
            fillSection('mats', rows, 'ยังไม่มีวัตถุดิบที่ดรอป\nออกไปฟาร์มที่แมพนอกเมือง ระบบจะเริ่มนับให้เอง');
        } else if (key === 'drops') {
            const rows = Object.values(Profit.data.drops)
                .sort((a, b) => rarityOf(b.rarity).rank - rarityOf(a.rarity).rank || b.qty - a.qty)
                .map((e) => {
                    const r = rarityOf(e.rarity);
                    return {
                        icon: e.icon,
                        name: e.name,
                        nameColor: r.color,
                        sub: e.price > 0 ? `${r.label} · ขายร้าน ${fmt(e.price)} z` : r.label,
                        right: `x${fmt(e.qty)}`,
                        rightColor: r.color,
                        onRemove: rmItem('drops', e.name),
                        info: 'item',
                    };
                });
            fillSection('drops', rows, 'ยังไม่มีไอเทมอื่นที่ดรอป (อุปกรณ์ / เจม / การ์ด ฯลฯ)');
        } else {
            const by = Profit.data.kills.by;
            const total = t.kills || 1;
            const hours = Profit.data.farmMs / 3600000;
            const rows = Object.keys(by)
                .sort((a, b) => by[b].count - by[a].count)
                .map((name) => {
                    const c = by[name].count;
                    const pct = ((c / total) * 100).toFixed(c / total >= 0.1 ? 0 : 1);
                    const perHr = Profit.data.farmMs >= CONFIG.MIN_FARM_MS_FOR_RATE ? ` · ${fmt(c / hours)}/ชม.` : '';
                    return {
                        icon: monsterIcon(name), name, sub: `${pct}%${perHr}`, right: `${fmt(c)} ตัว`, info: 'monster',
                        onRemove: () => { lgv.kills.total = Math.max(0, lgv.kills.total - c); delete lgv.kills.by[name]; Profit.dirty = true; Profit.rev++; Log.warn('PROFIT', `ลบมอน ${name} (${c} ตัว) ออกจากแมพ "${viewMapName()}"`); },
                    };
                });
            fillSection('kills', rows, 'ยังไม่มีข้อมูลการฆ่ามอน\nระบบอ่านจากแชทหมวด "ระบบ" (ชื่อมอน: Base EXP …) ตอนอยู่แมพฟาร์ม');
        }
    }

    function syncMapSelect() {
        const maps = Profit.all.maps;
        if (Profit.viewMap && !maps[Profit.viewMap]) Profit.viewMap = '';
        const names = Object.keys(maps).sort((a, b) => maps[b].farmMs - maps[a].farmMs);
        const auto = (Profit.farming ? getMapName() : '') || Profit.all.lastMap || '';
        const sig = names.join('|') + '#' + auto + '#' + Profit.viewMap;
        if (pRefs.mapSig === sig) return;
        pRefs.mapSig = sig;
        const sel = pRefs.map;
        sel.textContent = '';
        const add = (v, t) => { const o = document.createElement('option'); o.value = v; o.textContent = t; sel.appendChild(o); };
        add('', `🎯 ตามแมพที่ฟาร์มอยู่ (${auto || '—'})`);
        for (const n of names) add(n, n);
        sel.value = Profit.viewMap;
    }

    // ผู้ช่วยแมพ: มอนหลักในแมพ + ธาตุที่มอนแพ้ (จากตารางธาตุของเกม) + เทียบ Zeny/ชม. กับแมพอื่นที่เคยฟาร์ม
    const escapeHtml = (v) => String(v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const advCache = { key: '', res: null };
    function monsterElement(m) {
        const mt = String(m.element || '').toLowerCase().match(/^([a-z]+)(\d+)?$/);
        return mt ? { id: mt[1], lv: +(m.elementLevel || mt[2] || 1) } : null;
    }
    function mapMonsterInfo(vname) {
        const D = Info.data;
        const key = vname + '|' + (D ? D.monsters.length : 0);
        if (advCache.key === key) return advCache.res;
        const list = [];
        for (const m of D.monsters || []) {
            let n = 0;
            const seen = new Set();
            for (const sp of m.spawns || []) {
                const k = `${sp.map}|${sp.count}|${sp.kinds}|${sp.fixed}`;
                if (seen.has(k)) continue;
                seen.add(k);
                if (sp.map === vname) n += sp.count || 0;
            }
            if (n > 0) list.push({ m, n });
        }
        list.sort((a, b) => b.n - a.n);
        const ew = new Map();
        for (const { m, n } of list) {
            const e = monsterElement(m);
            if (!e) continue;
            const k = e.id + '|' + e.lv;
            ew.set(k, (ew.get(k) || 0) + n);
        }
        let topEl = null, best = 0;
        for (const [k, w] of ew) if (w > best) { best = w; const [id, lv] = k.split('|'); topEl = { id, lv: +lv }; }
        let weak = [];
        const E = D.elements;
        if (topEl && E && E.list && E.matrix) {
            for (const a of E.list) {
                const v = E.matrix[a.id] && E.matrix[a.id][topEl.id] ? E.matrix[a.id][topEl.id][topEl.lv - 1] : 1;
                if (v > 1) weak.push({ id: a.id, thai: a.thai || a.name || a.id, v });
            }
            weak.sort((x, y) => y.v - x.v);
        }
        const elThai = (id) => { const f = E && E.list && E.list.find((x) => x.id === id); return (f && (f.thai || f.name)) || (EL_INFO[id] && EL_INFO[id][1]) || id; };
        advCache.key = key;
        advCache.res = { top: list.slice(0, 3), topEl, weak, elThai, total: list.length };
        return advCache.res;
    }

    function renderAdvisor(vname, t) {
        const box = pRefs.adv;
        if (!box) return;
        const now = Date.now();
        if (now - pRefs.advAt < 4000) return;
        pRefs.advAt = now;
        if (!vname || CONFIG.NO_COUNT_MAPS.some((x) => vname.startsWith(x))) {
            if (box.style.display !== 'none') box.style.display = 'none';
            return;
        }
        if (!Info.data && !Info.loading && !Info.err) infoLoad().then(() => { pRefs.advAt = 0; Profit.rev++; }, () => { /* ไม่มี wiki ก็ยังเทียบ Zeny ได้ */ });
        const lines = [];
        if (Info.data) {
            const r = mapMonsterInfo(vname);
            if (r.top.length) {
                lines.push(`🎯 มอนหลัก: ${r.top.map((x) => `<b>${escapeHtml(x.m.name)}</b> ×${x.n}`).join(' · ')}`);
                if (r.topEl) {
                    const el = EL_INFO[r.topEl.id];
                    const weak = r.weak.slice(0, 4).map((w) => `${(EL_INFO[w.id] || ['🔮'])[0]} ${escapeHtml(w.thai)}`).join(' · ');
                    lines.push(`${el ? el[0] : '🔮'} ธาตุหลัก <b>${escapeHtml(r.elThai(r.topEl.id))}</b> Lv.${r.topEl.lv}${weak ? ` · แพ้: ${weak} <span style="opacity:.7">(ลูกธนู/ใบเคลือบธาตุนี้)</span>` : ''}`);
                }
            }
        }
        // เทียบ Zeny/ชม. กับแมพอื่นที่เคยฟาร์ม (ข้อมูล Profit ที่เก็บไว้ของตัวละครนี้)
        if (t.perHour !== null) {
            const others = [];
            for (const [name, lg] of Object.entries(Profit.all.maps)) {
                if (name === vname) continue;
                const ph = profitTotals(lg).perHour;
                if (ph !== null && ph > 0) others.push(ph);
            }
            if (others.length) {
                const avg = others.reduce((a, b) => a + b, 0) / others.length;
                const pct = Math.round((t.perHour / avg - 1) * 100);
                lines.push(pct >= 0
                    ? `💡 แมพนี้ทำเงินได้ <span class="up">+${pct}%</span> มากกว่าค่าเฉลี่ยแมพอื่นที่คุณเคยฟาร์ม (${others.length} แมพ)`
                    : `💡 แมพนี้ทำเงินได้ <span class="down">${pct}%</span> น้อยกว่าค่าเฉลี่ยแมพอื่นที่คุณเคยฟาร์ม (${others.length} แมพ)`);
            }
        }
        const html = lines.join('<br>');
        if (pRefs.advSig !== html) { pRefs.advSig = html; box.innerHTML = html; }
        const d = html ? '' : 'none';
        if (box.style.display !== d) box.style.display = d;
    }

    function renderProfit() {
        if (!State.isProfitOpen || !pRefs.panel) return;

        syncMapSelect();
        const vname = viewMapName();
        if (pRefs.lastView !== vname) { pRefs.lastView = vname; Profit.rev++; }
        const lg = Profit.data;
        const t = profitTotals(lg);
        setT(pRefs.time, fmtDuration(lg.farmMs));
        setNum(pRefs.total, fmt(t.total), 'z');
        t.perHour === null ? setNum(pRefs.rate, 'รอข้อมูล…') : setNum(pRefs.rate, fmt(t.perHour), 'z/ชม.');
        setNum(pRefs.kills, fmt(t.kills), 'ตัว');
        t.killsPerHour === null ? setNum(pRefs.krate, 'รอข้อมูล…') : setNum(pRefs.krate, fmt(t.killsPerHour), 'ตัว/ชม.');
        t.perKill === null ? setNum(pRefs.perkill, '—') : setNum(pRefs.perkill, fmt(t.perKill), 'z/ตัว');
        {
            const ex = expPerHour(lg);
            if (ex) { setNum(pRefs.bexp, fmt(ex.base), 'exp/ชม.'); setNum(pRefs.jexp, fmt(ex.job), 'exp/ชม.'); }
            else { setNum(pRefs.bexp, 'รอข้อมูล…'); setNum(pRefs.jexp, 'รอข้อมูล…'); }
            const cap = levelCapInfo();
            setT(pRefs.ttl, cap.text);
            const card = pRefs.ttl.parentElement;
            if (card && card.title !== cap.title) card.title = cap.title;
        }

        renderAdvisor(vname, t);
        setT(pRefs.chip, Profit.farming ? `🟢 กำลังนับ · ${getMapName() || 'แมพฟาร์ม'}` : '⏸️ หยุดนับ');
        const chipCls = 'ap-chip ' + (Profit.farming ? 'on' : 'off');
        if (pRefs.chip.className !== chipCls) pRefs.chip.className = chipCls;

        // หัวข้อที่พับอยู่ยังโชว์ยอดรวม / หัวข้อที่เปิดอยู่สร้างรายการเมื่อข้อมูลเปลี่ยนเท่านั้น
        setT(pRefs.sec.mats.sum, `${fmt(t.pieces)} ชิ้น · ${fmt(t.total)} z`);
        setT(pRefs.sec.drops.sum, `${fmt(t.dropPieces)} ชิ้น`);
        setT(pRefs.sec.kills.sum, `${fmt(t.kills)} ตัว`);
        for (const def of SECTIONS) {
            if (!State.secOpen[def.key]) continue;
            if (pRefs.secRev[def.key] === Profit.rev) continue;
            pRefs.secRev[def.key] = Profit.rev;
            renderSectionBody(def.key, t);
        }

        const db = Profit.db;
        let note = 'วัตถุดิบ = ราคาขายให้ร้านจาก wiki ของเกม · สีชื่อไอเทม = ระดับ (ขาว ธรรมดา / เขียว ดี / ฟ้า หายาก / ม่วง มหากาพย์ / ส้ม ตำนาน)';
        let warn = false;
        if (db.status === 'loading' || db.status === 'idle') note = '⏳ กำลังโหลดข้อมูลไอเทม…';
        else if (db.status === 'error') { note = `⚠️ โหลดข้อมูลไม่ได้ (${db.error}) · กด "อัปเดตราคา" เพื่อลองใหม่`; warn = true; }
        else if (db.status === 'stale') { note = '⚠️ ใช้ข้อมูลเก่า (โหลดใหม่ไม่สำเร็จ)'; warn = true; }
        else if (!Profit.farming) {
            const last = Profit.all.lastMap ? ` · ฟาร์มล่าสุด: ${Profit.all.lastMap}` : '';
            note = `หยุดนับ (อยู่ในเมือง)${last} · ดูประวัติ/ล้างได้ · ` + note;
        }
        if (Profit.viewMap && Profit.farming && Profit.viewMap !== getMapName()) note = `📂 กำลังดูแมพ "${Profit.viewMap}" (ไม่ใช่แมพที่อยู่ตอนนี้) · ` + note;
        setT(pRefs.note, note);
        const noteCls = 'ap-note' + (warn ? ' warn' : '');
        if (pRefs.note.className !== noteCls) pRefs.note.className = noteCls;
    }

    // ---------------------------------------------------------------
    // DPS window (อ่านจากมิเตอร์ของเกม) + แจ้งเตือนก่อนเปิด
    // ---------------------------------------------------------------
    function buildDpsWindow() {
        if (document.getElementById('aetheria-dps')) return;
        injectStyles();
        const w = document.createElement('div');
        w.id = 'aetheria-dps';
        w.className = 'aw';
        w.style.display = State.isDpsOpen ? 'flex' : 'none';
        w.innerHTML = `
            <div class="aw-header" id="ad-drag">
                <span>📊 DPS ของฉัน</span>
                <span class="aw-chip" id="ad-chip">ไม่มีข้อมูล</span>
                <button class="aw-x" id="ad-close" title="ปิด">✕</button>
            </div>
            <div class="ad-setting" id="ad-setting"></div>
            <div class="ad-body" id="ad-body"></div>
            <div class="ad-note">ค่าทั้งหมดอ่านจากมิเตอร์ DPS ของเกม (เฉพาะตัวเรา ไม่นับคนอื่น) · มิเตอร์ขึ้นตอนทดสอบดาเมจ เช่นที่ห้องทดสอบดาเมจ · ผลล่าสุดจะค้างไว้ในแท็บนี้</div>
        `;
        document.body.appendChild(w);
        dRefs.panel = w;
        dRefs.chip = document.getElementById('ad-chip');
        dRefs.setting = document.getElementById('ad-setting');
        dRefs.body = document.getElementById('ad-body');
        dRefs.sig = '';
        document.getElementById('ad-close').addEventListener('click', (e) => { e.stopPropagation(); toggleDps(false); });
        makeWindowDraggable(w, document.getElementById('ad-drag'), 'at_dps_pos');
        if (State.isDpsOpen) clampWindow(w);
    }

    function renderDps() {
        if (!State.isDpsOpen || !dRefs.panel) return;
        const setting = readDamageSetting();
        const data = Dps.live || Dps.last;
        const sig = JSON.stringify([data, setting, !!Dps.live]);
        if (sig === dRefs.sig) return;
        dRefs.sig = sig;

        const label = { all: 'แสดงทั้งหมด', mine: 'เฉพาะของฉัน', off: 'ปิด' }[setting];
        dRefs.setting.className = 'ad-setting ' + (setting === 'mine' ? 'ok' : 'warn');
        dRefs.setting.textContent = setting === 'mine'
            ? '✅ ตั้งค่าเกม: ตัวเลขดาเมจ = เฉพาะของฉัน'
            : `⚠️ ตั้งค่าเกม: ตัวเลขดาเมจ = ${label} (แนะนำ "เฉพาะของฉัน")`;

        const body = dRefs.body;
        body.textContent = '';
        if (!data) {
            dRefs.chip.textContent = 'ไม่มีข้อมูล';
            dRefs.chip.className = 'aw-chip';
            body.appendChild(h('div', 'ad-empty', 'ยังไม่มีข้อมูล DPS\nไปที่ห้องทดสอบดาเมจ แล้วตีหุ่นทดสอบ\nค่าจะขึ้นที่นี่อัตโนมัติ'));
            return;
        }
        if (Dps.live) {
            dRefs.chip.textContent = data.done ? 'ผลทดสอบ' : 'กำลังทดสอบ…';
            dRefs.chip.className = 'aw-chip' + (data.done ? '' : ' on');
        } else {
            dRefs.chip.textContent = `ผลล่าสุด ${fmtClock(data.at)}`;
            dRefs.chip.className = 'aw-chip';
        }

        const big = h('div', 'ad-big');
        big.appendChild(h('b', '', data.dps || '—'));
        big.appendChild(h('small', '', 'ดาเมจต่อวิ (DPS)'));
        big.appendChild(h('span', '', data.seconds || ''));
        body.appendChild(big);

        if (data.grid.length) {
            const g = h('div', 'ad-grid');
            for (const it of data.grid) {
                const row = h('div');
                row.appendChild(h('span', '', it.label));
                const b = h('b', '', it.value);
                if (it.tip) b.title = it.tip;
                row.appendChild(b);
                g.appendChild(row);
            }
            body.appendChild(g);
        }
        if (data.sources.length) {
            const src = h('div', 'ad-src');
            const top = Math.max(1, ...data.sources.map((s) => s.pct));
            for (const s of data.sources) {
                const row = h('div', 'ad-src-row');
                const bar = h('i');
                bar.style.width = `${Math.max(2, (s.pct / top) * 100)}%`;
                row.appendChild(bar);
                row.appendChild(h('span', '', s.name));
                row.appendChild(h('small', '', s.text));
                src.appendChild(row);
            }
            body.appendChild(src);
        }
        if (data.stats) body.appendChild(h('div', 'ad-stats', data.stats));
    }

    function openDps() {
        State.isDpsOpen = true;
        savePrefs();
        if (dRefs.panel) {
            dRefs.panel.style.display = 'flex';
            clampWindow(dRefs.panel);
        }
        if (uiRefs.dpsBtn) uiRefs.dpsBtn.classList.add('active');
        if (dRefs) dRefs.sig = '';
        startDpsPolling();
        Log.info('DPS', 'เปิดแท็บ DPS');
    }

    function closeDps() {
        State.isDpsOpen = false;
        savePrefs();
        if (dRefs.panel) dRefs.panel.style.display = 'none';
        if (uiRefs.dpsBtn) uiRefs.dpsBtn.classList.remove('active');
        stopDpsPolling();
        Log.info('DPS', 'ปิดแท็บ DPS (หยุดอ่านค่า)');
    }

    function showDpsNotice() {
        if (document.getElementById('aetheria-dps-notice')) return;
        const setting = readDamageSetting();
        const label = { all: 'แสดงทั้งหมด', mine: 'เฉพาะของฉัน', off: 'ปิด' }[setting];
        const m = document.createElement('div');
        m.id = 'aetheria-dps-notice';
        m.innerHTML = `
            <div class="an-card">
                <h3>⚠️ ก่อนเปิดแท็บ DPS</h3>
                <p>ตอนนี้ตัวเลขดาเมจในเกมตั้งเป็น <b>"${label}"</b> (จะเห็นตัวเลขของคนอื่นปนบนจอ)</p>
                <p>แนะนำให้ไปที่ <b>ตั้งค่าเกม (ปุ่ม O) → การแสดงผล → ตัวเลขดาเมจ</b> แล้วเลือก <b>"เฉพาะของฉัน"</b> (ที่ฉันตี โดนตี และฮีลที่ได้)</p>
                <small>สีตัวเลข: เขียว = ฮีล · แดง = ดาเมจจากมอนสเตอร์ · แท็บ DPS นี้อ่านค่าจากมิเตอร์ DPS ของเกม (เฉพาะตัวเรา ไม่ดึงของคนอื่น) และเริ่มทำงานเมื่อเปิดแท็บเท่านั้น</small>
                <label class="at-check"><input type="checkbox" id="an-never" /> ไม่ต้องแจ้งเตือนอีก</label>
                <div class="an-actions">
                    <button class="at-btn-ghost" id="an-settings">⚙️ เปิดตั้งค่าเกมให้</button>
                    <button class="at-btn-primary" id="an-go">เปิดแท็บ DPS</button>
                </div>
            </div>`;
        document.body.appendChild(m);
        const close = () => m.remove();
        m.addEventListener('click', (e) => { if (e.target === m) close(); });
        document.getElementById('an-settings').addEventListener('click', () => {
            if (!isTyping()) pressKey('o', 'KeyO', 79);
        });
        document.getElementById('an-go').addEventListener('click', () => {
            if (document.getElementById('an-never').checked) {
                State.dpsNoticeOff = true;
                savePrefs();
            }
            close();
            openDps();
        });
    }

    function toggleDps(force) {
        const want = typeof force === 'boolean' ? force : !State.isDpsOpen;
        if (!want) { closeDps(); return; }
        if (State.isDpsOpen) return;
        if (readDamageSetting() !== 'mine' && !State.dpsNoticeOff) { showDpsNotice(); return; }
        openDps();
    }

    // ---------------------------------------------------------------
    // Logs window
    // ---------------------------------------------------------------
    const LogUI = { filter: 'all', renderedSeq: 0, stick: true };

    function logMatches(e) {
        const f = LogUI.filter;
        return f === 'all' || (f === 'gain' && e.level === 'gain') || (f === 'warn' && (e.level === 'warn' || e.level === 'err')) || (f === 'err' && e.level === 'err');
    }

    function logText(list) {
        return list.map((e) => `[${fmtClock(e.t)}] [${e.tag}] ${e.msg}`).join('\n');
    }

    function copyText(text) {
        const fallback = () => {
            const ta = h('textarea');
            ta.value = text;
            ta.style.cssText = 'position:fixed;opacity:0;left:-999px';
            document.body.appendChild(ta);
            ta.select();
            let ok = false;
            try { ok = document.execCommand('copy'); } catch (e) { /* ignore */ }
            ta.remove();
            return ok;
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            return navigator.clipboard.writeText(text).then(() => true, () => fallback());
        }
        return Promise.resolve(fallback());
    }

    function buildLogsWindow() {
        if (document.getElementById('aetheria-logs')) return;
        injectStyles();
        const w = document.createElement('div');
        w.id = 'aetheria-logs';
        w.className = 'aw';
        w.style.display = State.isLogsOpen ? 'flex' : 'none';
        w.innerHTML = `
            <div class="aw-header" id="al-drag">
                <span>📜 Logs</span>
                <span class="al-count" id="al-count"></span>
                <button class="aw-x" id="al-close" title="ปิด">✕</button>
            </div>
            <div class="al-tools">
                <button class="al-chip active" data-f="all">ทั้งหมด</button>
                <button class="al-chip" data-f="gain">ดรอป</button>
                <button class="al-chip" data-f="warn">เตือน</button>
                <button class="al-chip" data-f="err">ผิดพลาด</button>
                <button class="al-chip active" id="al-stick" title="เลื่อนตามรายการใหม่">⏬ ตาม</button>
            </div>
            <div class="al-list" id="al-list"></div>
            <div class="al-foot">
                <button class="at-btn-ghost" id="al-copy">📋 คัดลอก</button>
                <button class="at-btn-ghost" id="al-clear">🗑️ ล้าง</button>
            </div>
        `;
        document.body.appendChild(w);
        lRefs.panel = w;
        lRefs.list = document.getElementById('al-list');
        lRefs.count = document.getElementById('al-count');
        lRefs.stick = document.getElementById('al-stick');

        document.getElementById('al-close').addEventListener('click', (e) => { e.stopPropagation(); toggleLogs(false); });
        w.querySelectorAll('.al-chip[data-f]').forEach((b) => {
            b.addEventListener('click', () => {
                LogUI.filter = b.dataset.f;
                w.querySelectorAll('.al-chip[data-f]').forEach((x) => x.classList.toggle('active', x === b));
                renderLogs(true);
            });
        });
        lRefs.stick.addEventListener('click', () => {
            LogUI.stick = !LogUI.stick;
            lRefs.stick.classList.toggle('active', LogUI.stick);
            if (LogUI.stick) lRefs.list.scrollTop = lRefs.list.scrollHeight;
        });
        document.getElementById('al-copy').addEventListener('click', async () => {
            const ok = await copyText(logText(Log.entries.filter(logMatches)));
            showToast(ok ? '📋 คัดลอก Logs แล้ว' : '⚠️ คัดลอกไม่สำเร็จ', ok ? 'ok' : 'warn');
        });
        document.getElementById('al-clear').addEventListener('click', () => {
            Log.entries.length = 0;
            Log.save();
            renderLogs(true);
        });
        makeWindowDraggable(w, document.getElementById('al-drag'), 'at_logs_pos');
        if (State.isLogsOpen) clampWindow(w);
    }

    function renderLogs(force) {
        if (!State.isLogsOpen || !lRefs.panel) return;
        const list = lRefs.list;
        if (force) {
            list.textContent = '';
            LogUI.renderedSeq = 0;
        }
        const last = Log.entries[Log.entries.length - 1];
        if (!force && (!last || last.id <= LogUI.renderedSeq)) return;
        const fresh = Log.entries.filter((e) => e.id > LogUI.renderedSeq);
        if (fresh.length) {
            const frag = document.createDocumentFragment();
            for (const e of fresh) {
                LogUI.renderedSeq = e.id;
                if (!logMatches(e)) continue;
                const row = h('div', `al-row ${e.level}`);
                row.appendChild(h('span', 'al-t', fmtClock(e.t)));
                row.appendChild(h('span', 'al-tag', e.tag));
                row.appendChild(h('span', 'al-msg', e.msg));
                frag.appendChild(row);
            }
            list.appendChild(frag);
            while (list.childElementCount > CONFIG.LOG_MAX) list.removeChild(list.firstChild);
            if (LogUI.stick) list.scrollTop = list.scrollHeight;
        } else if (force && LogUI.stick) {
            list.scrollTop = list.scrollHeight;
        }
        setT(lRefs.count, `${Log.entries.length} รายการ`);
    }

    function toggleLogs(force) {
        State.isLogsOpen = typeof force === 'boolean' ? force : !State.isLogsOpen;
        savePrefs();
        if (lRefs.panel) (State.isLogsOpen ? Anim.show : Anim.hide)(lRefs.panel, (v) => { lRefs.panel.style.display = v ? 'flex' : 'none'; });
        if (uiRefs.logsBtn) uiRefs.logsBtn.classList.toggle('active', State.isLogsOpen);
        if (State.isLogsOpen) {
            renderLogs(true);
        }
        relayoutAll(!State.isLogsOpen);
    }

    // ---------------------------------------------------------------
    // Boss: อ่านเวลาเกิดบอสจากหน้า "ประกาศล่า MVP" ของเกม (เปิดหน้านั้นแล้วสคริปต์จำเวลาเป๊ะไว้) -> แจ้งเตือนก่อนเกิด/ตอนเกิด
    // ---------------------------------------------------------------
    const BOSS_KEY = 'at_boss_v1', BOSS_FIRED_KEY = 'at_boss_fired_v1';
    const Boss = { list: [], at: 0, fired: {}, loadedAt: 0, autoAt: 0, opening: 0, logged: false };
    const fmtThClock = (ts) => { const d = new Date(ts); return `${pad2(d.getHours())}.${pad2(d.getMinutes())}`; };
    const fmtCountdown = (ms) => {
        const t = Math.max(0, Math.ceil(ms / 1000)), hh = Math.floor(t / 3600), mm = Math.floor((t % 3600) / 60), ss = t % 60;
        return hh ? `${hh}:${pad2(mm)}:${pad2(ss)}` : `${mm}:${pad2(ss)}`;
    };
    const fmtRel = (min) => (min >= 60 ? `${+(min / 60).toFixed(1)} ชม.` : `${min} นาที`);

    function bossLoad() {
        const d = Store.getJSON(BOSS_KEY);
        if (d && Array.isArray(d.list) && (d.at || 0) >= Boss.at) { Boss.list = d.list; Boss.at = d.at || 0; }
        Boss.loadedAt = Date.now();
    }
    function bossSave() {
        Store.set(BOSS_KEY, JSON.stringify({ at: Boss.at, list: Boss.list }));
    }

    function bossRead(now) {
        const lis = [...document.querySelectorAll('.boss-board li')];
        if (!lis.length) return false;
        const out = [];
        for (const li of lis) {
            const name = norm((li.querySelector('.boss-wanted-text b') || {}).textContent || '');
            const map = norm((li.querySelector('.boss-wanted-text small') || {}).textContent || '');
            const pill = li.querySelector('.boss-pill');
            if (!name || !pill) continue;
            const txt = norm(pill.textContent);
            if (pill.classList.contains('here')) { out.push({ name, map, at: 0, here: true, seen: now }); continue; }
            const m = /^(\d+):(\d{2})(?::(\d{2}))?$/.exec(txt);
            if (!m) continue;
            const secs = m[3] !== undefined ? (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) : (+m[1]) * 60 + (+m[2]);
            out.push({ name, map, at: Math.round((now + secs * 1000) / 1000) * 1000, here: false, seen: now });
        }
        if (!out.length) return false;
        Boss.list = out;
        Boss.at = now;
        bossSave();
        if (!Boss.logged) { Boss.logged = true; Log.ok('BOSS', `อ่านเวลาบอสจากเกม ${out.length} ตัว`); }
        return true;
    }

    function bossUpcoming(now) {
        return Boss.list.filter((b) => !b.here && b.at > now).sort((a, b) => a.at - b.at);
    }

    function bossFire(b, kind, mins, idx, now) {
        const clock = fmtThClock(b.at);
        const s = Math.floor(b.at / 1000);
        const head = kind === 'spawn' ? `👹 บอส ${b.name} ปรากฏตัวแล้ว!` : `👹 บอสตัวที่ ${idx} ${b.name} จะเกิดในอีก ${fmtRel(mins)} · เวลา ${clock} น.`;
        showToast(head, 'warn');
        beep('beep');
        Log.warn('BOSS', head);
        if (kind === 'spawn' && State.opt.bossSpawn) {
            // ส่ง Discord เฉพาะตอนบอสเกิดแล้ว และให้แท็บเดียวส่ง (ไม่ซ้ำเมื่อเปิดหลายแอคเคานต์)
            const key = `${b.name}|${Math.round(b.at / 10000)}`;
            const sent = Store.getJSON('at_boss_dc_v1', {}) || {};
            if (!sent[key]) {
                sent[key] = now;
                for (const k of Object.keys(sent)) if (now - sent[k] > 86400000) delete sent[k];
                Store.set('at_boss_dc_v1', JSON.stringify(sent));
                const fresh = Store.getJSON('at_boss_dc_v1', {}) || {};
                if (fresh[key] === now) {
                    sendDiscord('boss', {
                        title: '👹 บอสเกิดแล้ว!',
                        description: `**${b.name}** ปรากฏตัวแล้ว`,
                        color: 0xf87171,
                        fields: [{ name: 'แมพ', value: b.map || '—', inline: true }, { name: 'กำหนดเกิด', value: `${clock} น.`, inline: true }],
                    }, { ping: !!State.opt.bossPing, force: false });
                }
            }
        }
    }

    function bossTick(now) {
        if (now - Boss.loadedAt > 5000) bossLoad();
        if (bossRead(now) && Boss.opening) {
            const c = document.querySelector('.boss-close');
            if (c) c.click();
            Boss.opening = 0;
        }
        if (Boss.opening && now - Boss.opening > 7000) {
            const c = document.querySelector('.boss-close');
            if (c) c.click();
            Boss.opening = 0;
        }
        // เปิดหน้าบอสเองเป็นระยะ (ทางเลือก)
        if (State.opt.bossAuto && State.isGameReady && !autoPaused() && !Boss.opening && !autoBusy('boss') && now - Boss.autoAt >= 600000 && now - (Boss.at || 0) >= 540000 && !isTyping() && !Frame.dead && !Frame.captcha && !document.querySelector('.boss-board')) {
            Boss.autoAt = now;
            const btn = [...document.querySelectorAll('.menu-btn')].find((b) => /^บอส/.test(b.getAttribute('title') || ''));
            if (btn) { btn.click(); Boss.opening = now; }
            else {
                try { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'u', code: 'KeyU', bubbles: true })); Boss.opening = now; } catch (e) { /* ignore */ }
            }
        }

        let dirty = false;
        const marks = [[60, 'bossM60'], [30, 'bossM30'], [10, 'bossM10'], [5, 'bossM5'], [1, 'bossM1']];
        const up = bossUpcoming(now);
        up.forEach((b, i) => {
            const rem = b.at - now;
            // เลือกขีดที่ "ล่าสุดที่ผ่านมา" ที่ยังไม่เคยแจ้ง: ถ้าอยู่ในช่วง 2 นาทีหลังข้ามขีด ค่อยแจ้ง ไม่งั้นข้ามเงียบ ๆ
            for (const [m] of marks) {
                const key = `${b.name}|${Math.round(b.at / 10000)}|${m}`;
                if (rem <= m * 60000 && !Boss.fired[key]) {
                    Boss.fired[key] = now; dirty = true;
                    if (State.opt['bossM' + m] && rem > m * 60000 - 120000) bossFire(b, 'pre', m, i + 1, now);
                }
            }
        });
        for (const b of Boss.list) {
            if (!b.here && b.at && b.at <= now) {
                const key = `${b.name}|${Math.round(b.at / 10000)}|spawn`;
                if (!Boss.fired[key]) {
                    Boss.fired[key] = now; dirty = true;
                    if (State.opt.bossSpawn && now - b.at < 180000) bossFire(b, 'spawn', 0, 0, now);
                }
                if (now - b.at > 1800000) b.stale = true;
            }
        }
        if (dirty) {
            for (const k of Object.keys(Boss.fired)) if (now - Boss.fired[k] > 86400000) delete Boss.fired[k];
        }
    }

    function renderBoss(now) {
        const row = document.getElementById('at-boss-row'), v = document.getElementById('at-boss-next');
        if (!row || !v) return;
        const up = bossUpcoming(now);
        if (!up.length) {
            const here = Boss.list.find((b) => b.here || (b.at && b.at <= now && !b.stale));
            row.style.display = here ? '' : 'none';
            if (here) setT(v, `${here.name} · ปรากฏตัวแล้ว`);
            return;
        }
        row.style.display = '';
        const b = up[0];
        setT(v, `${b.name} · ${fmtThClock(b.at)} น. (อีก ${fmtCountdown(b.at - now)})`);
        if (v.title !== up.slice(0, 6).map((x, i) => `${i + 1}. ${x.name} (${x.map}) ${fmtThClock(x.at)} น.`).join('\n')) v.title = up.slice(0, 6).map((x, i) => `${i + 1}. ${x.name} (${x.map}) ${fmtThClock(x.at)} น.`).join('\n');
    }

    // ---------------------------------------------------------------
    // Live status: ข้อความเดียวใน Discord (แก้ไขทับตลอด) แสดงตัวละครที่ออนไลน์ทุกแท็บของเบราว์เซอร์นี้ + บอสที่กำลังจะเกิด
    // แท็บต่าง ๆ ส่งข้อมูลหากันผ่าน BroadcastChannel · แท็บที่ id น้อยสุดเป็นผู้อัปเดต Discord
    // ---------------------------------------------------------------
    const TAB_ID = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    // ช่องของแท็บนี้ในกล่องสถานะ (จำใน sessionStorage: รีโหลด/เปลี่ยนตัวละครในแท็บเดิม = ช่องเดิม → เปลี่ยนตัวในไอดีเดียวกัน ไม่ต้องเพิ่มช่องใหม่)
    const newSlot = () => 'S' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    let SLOT = (() => { let v = ''; try { v = sessionStorage.getItem('at_slot') || ''; } catch (e) { /* ignore */ } if (!v) { v = newSlot(); try { sessionStorage.setItem('at_slot', v); } catch (e) { /* ignore */ } } return v; })();
    const Live = { snap: null, snapAt: 0, ch: null, peers: {}, sentAt: 0, bossAt: 0, pubAt: 0, busy: {}, last: {}, lastOk: 0 };
    const LIVE_MSG_KEY = 'at_status_msg';

    const isJailMap = (m) => /^คุก/.test(String(m || ''));
    // 🟢 ฟาร์ม · 🟠 เมือง/คุก/แมพที่ไม่ใช่แมพฟาร์ม · 🟡 อยู่แมพฟาร์มแต่ยังไม่ฟาร์ม · 🔴 ตาย/ติดเช็คผู้เล่น
    function charKind() {
        if (Frame.captcha) return { k: 'captcha', dot: '🔴' };
        if (Frame.dead) return { k: 'dead', dot: '🔴' };
        const map = getMapName();
        if (isJailMap(map)) return { k: 'jail', dot: '🟠' };
        if (map && !isFarmMap()) return { k: 'town', dot: '🟠' };
        if (Profit.farming) return { k: 'farm', dot: '🟢' };
        return { k: 'idle', dot: '🟡' };
    }

    // 🏷️ ชื่อแท็บ/หน้าต่าง = "ชื่อตัวละคร · แมพ" (มีปัญหา/ไม่ได้ฟาร์ม ขึ้นจุดสีนำหน้า) — หาจอที่ต้องการบนทาสก์บาร์ได้ง่าย
    const TabTitle = { last: '', obs: null };
    function tabTitleTick() {
        if (State.opt.tabTitle === false) return;
        const name = Profit.charName || readField(SELECTORS.charName, 'name'); if (!name) return;
        const map = (getMapName() || '').replace(/\s*Lv\.?[\d\-–\s]+$/i, '').trim();
        let pre = ''; try { const k = charKind(); if (k.k !== 'farm') pre = k.dot + ' '; } catch (e) { /* ignore */ }
        const t = `${pre}${name}${map ? ' · ' + map : ''} · 3D ${r3Off() ? 'ปิด' : R3T.force ? 'เปิดชั่วคราว' : 'เปิด'}`;
        TabTitle.last = t;
        // ตั้งผ่าน document ของหน้าเกมจริง (unsafeWindow) — Firefox + Tampermonkey: ตั้งผ่าน document ของสคริปต์อาจไม่มีผลกับแท็บ
        const docs = [PW.document, document];
        for (const d of docs) { try { if (d.title !== t) d.title = t; } catch (e) { /* ignore */ } }
        try { const te = PW.document.querySelector('title'); if (te && te.textContent !== t) te.textContent = t; } catch (e) { /* ignore */ }
        if (!TabTitle.obs) {      // เกมเปลี่ยนชื่อแท็บเองตอนย้ายแมพ → ตั้งกลับทันที
            try {
                const head = PW.document.head || PW.document.documentElement;
                if (head && typeof MutationObserver !== 'undefined') { TabTitle.obs = new MutationObserver(() => { if (State.opt.tabTitle !== false && PW.document.title !== TabTitle.last) tabTitleTick(); }); TabTitle.obs.observe(head, { childList: true, characterData: true, subtree: true }); }
            } catch (e) { TabTitle.obs = 1; }
        }
    }
    setInterval(() => { try { tabTitleTick(); } catch (e) { /* ignore */ } }, 2000);

    // 🔄 รีโหลดทุกจอ: ส่งคำสั่งผ่านพื้นที่ของ Tampermonkey (ถึงทุกแท็บ ทุก Container) → แต่ละจอสุ่มหน่วง 1–20 วิ แล้วรีโหลด (ไม่โหลดพร้อมกันจนเครื่องค้าง)
    function reloadNow() { try { profitSave(true); Log.save(); } catch (e) { /* ignore */ } location.reload(); }
    function reloadAll() {
        const viaRelay = !!relayUrl();
        if (!confirm(`รีโหลดหน้าเกมทุกจอ (ทุกแท็บ ทุก Container${viaRelay ? ' + Chrome อื่นทุกตัวผ่าน Apps Script' : ''}) เพื่อใช้สคริปต์เวอร์ชันใหม่?\nแต่ละจอจะทยอยรีโหลดภายใน ~20 วินาที${viaRelay ? ' (Chrome อื่น ~1 นาที)' : '\n\n⚠️ Chrome อื่นจะไม่รีโหลด — ต้องตั้ง Web App URL (แท็บ 📄 Sheets) และอัปเดตโค้ด Apps Script ก่อน'}`)) return;
        const at = Date.now();
        try { GM_setValue('reload_all', { at, src: TAB_ID, v: VERSION }); GM_setValue('reload_seen', at); } catch (e) { showToast('ส่งคำสั่งไปจออื่นไม่ได้ — รีโหลดเฉพาะจอนี้', 'warn'); }
        if (viaRelay) relayKvPut('reload_all', { at, src: TAB_ID });
        Log.info('SYS', `🔄 สั่งรีโหลดทุกจอ${viaRelay ? ' (รวม Chrome อื่น)' : ''}`); showToast('🔄 สั่งรีโหลดทุกจอแล้ว — จอนี้รีโหลดใน 3 วิ', 'ok');
        setTimeout(reloadNow, 3000);
    }
    try {
        if (typeof GM_addValueChangeListener === 'function') GM_addValueChangeListener('reload_all', (n, o, v, remote) => {
            if (!remote || !v || v.src === TAB_ID || Date.now() - (v.at || 0) > 60000) return;
            const d = 1000 + Math.floor(Math.random() * 20000);
            Log.info('SYS', `🔄 ได้รับคำสั่งรีโหลดทุกจอ — รีโหลดใน ${Math.round(d / 1000)} วิ`); showToast(`🔄 รีโหลดตามคำสั่ง (อัปเดตสคริปต์) ใน ${Math.round(d / 1000)} วิ`, 'info');
            setTimeout(reloadNow, d);
        });
    } catch (e) { /* ignore */ }

    function charStatusText() {
        if (Frame.captcha) return '🧩 เกมขอตรวจสอบผู้เล่น!';
        if (Frame.dead) return '💀 ตัวละครตาย';
        if (isJailMap(getMapName())) return `⛓️ ติดคุก${Town.map ? ' มา ' + fmtTown(Date.now() - Town.since) : ''}`;
        if (Profit.farming) return `🟢 กำลังฟาร์ม · ${getMapName() || '—'}`;
        if (Town.map) return `🏙️ อยู่ที่ ${Town.map} มา ${fmtTown(Date.now() - Town.since)}`;
        return `⏸️ ${getMapName() || '—'}`;
    }

    function liveSnapshot() {
        const sn = collectSnapshotData();
        const d = sn.raw;
        if (!d.name) return null;
        const lg = curLedger();
        const t = lg ? profitTotals(lg) : null;
        const ex = lg ? expPerHour(lg) : null;
        return {
            tab: TAB_ID, slot: SLOT, name: d.name, cls: d.class, blv: d.baseLv, jlv: d.jobLv, map: getMapName() || '', ch: d.channel || '',
            st: charStatusText(), kd: charKind(), z: t ? t.total : 0, zh: t && t.perHour ? Math.round(t.perHour) : 0, k: t ? t.kills : 0,
            bx: ex ? Math.round(ex.base) : 0, eta: levelCapInfo().text, ping: Ping.summary && typeof Ping.summary.ms === 'number' ? Ping.summary.ms : 0,
            w: d.weight && d.weight !== '-' && d.weight !== '—' ? d.weight : '', wp: typeof sn.meta.weightPct === 'number' ? Math.round(sn.meta.weightPct) : null,
            sl: d.slots && /\d/.test(d.slots) ? String(d.slots).replace(/\s+/g, '') : '',
            main: !!State.opt.mainId,
            zn: d.zeny && /\d/.test(d.zeny) ? String(d.zeny).trim() : '',
            r3: !!State.opt.renderOff, live: !!(State.opt.statusLive || State.opt.bossBoard), fs: !!State.opt.statusLive, fb: !!State.opt.bossBoard, hk: REGEX.discordUrl.test(String(Store.get('at_dc_status_url') || State.discordUrl || '').split('?')[0]), vis: document.visibilityState !== 'hidden', ts: Date.now(),
        };
    }

    function liveInit() {
        try {
            if (typeof BroadcastChannel === 'undefined') return;
            Live.ch = new BroadcastChannel('aetherack-live');
            try {      // ล้างข้อมูลช่องแบบเก่า (ผูกกับชื่อตัวละคร) — จะขึ้นใหม่เป็นช่องต่อแท็บเอง
                const old = []; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i) || ''; if (k.indexOf('at_peer:') === 0 && k.indexOf('at_peer:@') !== 0) old.push(k); }
                old.forEach((k) => lsDel(k));
            } catch (e) { /* ignore */ }
            Live.ch.onmessage = (e) => {
                const p = e.data; if (!p || !p.tab || !p.name) return;
                // แท็บที่ถูก "ทำซ้ำ" (Duplicate tab) จะได้ช่องเดียวกันมาด้วย → แท็บหนึ่งเปลี่ยนไปใช้ช่องใหม่
                if (p.slot && p.slot === SLOT && p.tab !== TAB_ID && Date.now() - p.ts < 30000 && TAB_ID > p.tab) { SLOT = newSlot(); try { sessionStorage.setItem('at_slot', SLOT); } catch (er) { /* ignore */ } }
                Live.peers[p.tab] = p;
            };
        } catch (e) { Live.ch = null; }
    }

    function liveTick(now) {
        if (!State.isGameReady) return;
        if (!Live.snap || now - Live.snapAt >= 2000) { Live.snapAt = now; Live.snap = liveSnapshot(); } // อ่าน DOM ทุก ~2 วิ พอ
        const snap = Live.snap;
        if (snap) Live.peers[TAB_ID] = snap;
        if (snap && Live.ch && now - Live.pubAt >= 8000) {
            Live.pubAt = now;
            try { Live.ch.postMessage(snap); } catch (e) { /* ignore */ }
        }
        // สำรองผ่าน localStorage (ใช้ร่วมกันทุกแท็บของเบราว์เซอร์เดียวกัน) กันแท็บที่ถูกพัก/ส่งข้อความไม่ทัน
        if (snap && now - (Live.lsAt || 0) >= 10000) {
            Live.lsAt = now;
            try { lsSet('at_peer:@' + SLOT, JSON.stringify(snap)); } catch (e) { /* ignore */ }
        }
        // 🔗 แท็บใน Container อื่นส่งข้อมูลผ่าน BroadcastChannel ไม่ถึง → แลกกันผ่านพื้นที่ของ Tampermonkey (gp:<ช่อง>)
        if (lsShareOn()) {
            if (snap && now - (Live.gpAt || 0) >= 8000) { Live.gpAt = now; try { GM_setValue('gp:' + SLOT, snap); } catch (e) { /* ignore */ } }
            if (now - (Live.gpRead || 0) >= 5000) {
                Live.gpRead = now;
                try { for (const g of GM_listValues()) { if (g.indexOf('gp:') !== 0) continue; const p = GM_getValue(g); if (!p || !p.tab || !p.ts) continue; if (now - p.ts > 43200000) { if (typeof GM_deleteValue === 'function') GM_deleteValue(g); continue; } if (p.tab !== TAB_ID) Live.peers[p.tab] = p; } } catch (e) { /* ignore */ }
            }
        }
        if (now - (Live.diagAt || 0) >= 3000) {
            Live.diagAt = now;
            const el = document.getElementById('at-live-peers');
            if (el) {
                const ps = livePeers(now);
                el.textContent = ps.length ? ps.map((p) => `${p.main ? '⭐' : ''}${p.off ? '⚫' : '🟢'} ${p.name}`).join(' · ') : 'ยังไม่เห็นตัวละครใด';
                const bt = document.getElementById('at-live-peers-btn');
                if (bt) bt.textContent = `👥 ตัวละครที่สคริปต์เห็น (${ps.filter((p) => !p.off).length}) ${el.style.display === 'none' ? '▸' : '▾'}`;
            }
        }
        if (!snap) return;
        const hook = String(Store.get('at_dc_status_url') || State.discordUrl || '').split('?')[0];
        if (!REGEX.discordUrl.test(hook)) { Live.force = {}; return; }
        // เลือกผู้อัปเดต "แยกตามชนิดกล่อง" — ต้องเป็นแท็บที่ส่งได้จริง (มี Webhook + เปิดกล่องชนิดนั้น) · ให้แท็บที่เปิดอยู่หน้าจอก่อน
        relayTick(now, snap);
        const fresh = Object.values(Live.peers).filter((p) => now - p.ts < (p.via ? 120000 : 30000) && p.hk !== false);
        const lead = (flag) => fresh.filter((p) => p[flag]).sort((a, b) => (b.vis !== false ? 1 : 0) - (a.vis !== false ? 1 : 0) || (a.tab > b.tab ? 1 : -1))[0];
        const sLead = lead('fs'), bLead = lead('fb');
        const force = Live.force || {};
        if ((force.status || (State.opt.statusLive && sLead && sLead.tab === TAB_ID)) && now - Live.sentAt >= (force.status ? 0 : 20000)) {
            Live.sentAt = now;
            liveSend('status', hook, liveEmbed(now), false, !!force.status);
            force.status = false;
        }
        if ((force.boss || (State.opt.bossBoard && bLead && bLead.tab === TAB_ID)) && now - Live.bossAt >= (force.boss ? 0 : 20000) && (force.boss || Boss.list.length || Store.getJSON('at_boss_msg'))) {
            Live.bossAt = now;
            liveSend('boss', hook, bossEmbed(now), !force.boss, !!force.boss);
            force.boss = false;
        }
        Live.force = force;
    }

    // 🛰️ รวมกล่องสถานะข้าม Chrome / โปรไฟล์ Firefox (ข้อมูลไม่แชร์กัน) ผ่าน Google Apps Script ตัวเดียวกับ Sheets
    //    ทุกแท็บส่งสถานะของตัวเองทุก ~45–55 วิ · แท็บที่เป็นผู้ส่งกล่องสถานะของเครื่องนั้นดึงสถานะทุกตัวทุก 30 วิ → เลือกผู้ส่งตัวเดียวจากทุกเครื่อง
    //    id ข้อความ Discord เก็บไว้ที่ Apps Script ด้วย → ทุกเครื่องแก้ข้อความเดียวกัน · ต้องใช้โค้ด aetherack-zones-sync.gs รุ่นใหม่
    const Relay = { putAt: 0, getAt: 0, kv: {}, busy: false, okAt: 0, warnAt: 0, jit: Math.floor(Math.random() * 10000), n: 0 };
    const relayUrl = () => { const u = String(State.webAppUrl || ''); return State.opt.relayOn !== false && /^https:\/\/script\.google\.com\//.test(u) ? u : ''; };
    function relayKvPut(key, val) {
        const u = relayUrl(); if (!u) return;
        Relay.kv[key] = val;
        try { GM_xmlhttpRequest({ method: 'POST', url: u, headers: { 'Content-Type': 'text/plain;charset=utf-8' }, data: JSON.stringify({ action: 'kv_put', key, val }), timeout: 15000 }); } catch (e) { /* ignore */ }
    }
    function relayTick(now, snap) {
        const u = relayUrl(); if (!u || !snap || !(State.opt.statusLive || State.opt.bossBoard)) return;
        if (now - Relay.putAt >= 45000 + Relay.jit) {
            Relay.putAt = now;
            try { GM_xmlhttpRequest({ method: 'POST', url: u, headers: { 'Content-Type': 'text/plain;charset=utf-8' }, data: JSON.stringify({ action: 'peer_put', peer: snap }), timeout: 15000 }); } catch (e) { /* ignore */ }
        }
        const local = Object.values(Live.peers).filter((p) => !p.via && now - p.ts < 30000 && p.hk !== false && (p.fs || p.fb));
        const ll = local.sort((a, b) => (b.vis !== false ? 1 : 0) - (a.vis !== false ? 1 : 0) || (a.tab > b.tab ? 1 : -1))[0];
        if (!ll || ll.tab !== TAB_ID || Relay.busy || now - Relay.getAt < 30000) return;
        Relay.getAt = now; Relay.busy = true;
        const fail = (why) => { Relay.busy = false; if (Date.now() - Relay.warnAt > 600000) { Relay.warnAt = Date.now(); Log.warn('STATUS', `🛰️ รวมกล่องสถานะข้าม Chrome ไม่ได้ (${why}) — อัปเดตโค้ดใน Apps Script เป็นรุ่นใหม่ (aetherack-zones-sync.gs) แล้ว Deploy ใหม่`); } };
        try {
            GM_xmlhttpRequest({
                method: 'GET', url: u + (u.includes('?') ? '&' : '?') + 'action=peers_get&t=' + now, timeout: 15000,
                onload: (res) => {
                    let j = null; try { j = JSON.parse(res.responseText); } catch (e) { j = null; }
                    if (!j || !j.ok || !Array.isArray(j.peers)) { fail(`HTTP ${res.status}`); return; }
                    Relay.busy = false; Relay.okAt = Date.now(); Relay.kv = Object.assign({}, j.kv || {});
                    const t = Date.now(); let n = 0;
                    for (const p of j.peers) {
                        if (!p || !p.tab || !p.name || p.tab === TAB_ID) continue;
                        const cur = Live.peers[p.tab]; if (cur && !cur.via && t - cur.ts < 30000) continue;      // แท็บในเครื่องนี้เห็นสดกว่าอยู่แล้ว
                        Live.peers[p.tab] = Object.assign({}, p, { via: 'relay', ts: t - Math.max(0, +p.age || 0) }); n++;
                    }
                    if (n !== Relay.n) { Relay.n = n; Log.info('STATUS', `🛰️ เห็นตัวละครจาก Chrome/โปรไฟล์อื่น ${n} ตัว (รวมผ่าน Apps Script)`); }
                },
                onerror: () => fail('เครือข่าย'), ontimeout: () => fail('หมดเวลา'),
            });
        } catch (e) { fail(e && e.message); }
    }

    // 🔄 รับคำสั่ง "รีโหลดทุกจอ" จาก Chrome อื่น: เลือกแท็บเดียวต่อเบราว์เซอร์ (ล็อกใน Tampermonkey) เช็ค Apps Script ทุก ~25 วิ
    function relayReloadCheck(kv) {
        const r = kv && kv.reload_all; if (!r || !r.at) return;
        let seen; try { seen = GM_getValue('reload_seen'); } catch (e) { return; }
        if (seen === undefined || seen === null) { try { GM_setValue('reload_seen', r.at); } catch (e) { /* ignore */ } return; }      // เปิดครั้งแรก: จำไว้เฉย ๆ ไม่รีโหลดตามคำสั่งเก่า
        if (r.at <= seen) return;
        try { GM_setValue('reload_seen', r.at); } catch (e) { /* ignore */ }
        if (Date.now() - r.at > 180000) return;
        try { GM_setValue('reload_all', { at: Date.now(), src: TAB_ID, v: VERSION }); } catch (e) { /* ignore */ }      // ส่งต่อให้ทุกแท็บในเบราว์เซอร์นี้
        const d = 2000 + Math.floor(Math.random() * 25000);
        Log.info('SYS', `🔄 ได้รับคำสั่งรีโหลดทุกจอจาก Chrome อื่น — รีโหลดใน ${Math.round(d / 1000)} วิ`); showToast(`🔄 รีโหลดตามคำสั่งจาก Chrome อื่น ใน ${Math.round(d / 1000)} วิ`, 'info');
        setTimeout(reloadNow, d);
    }
    setInterval(() => {
        try {
            const u = relayUrl(); if (!u || typeof GM_getValue !== 'function') return;
            const now = Date.now(); const L = GM_getValue('reload_poller');
            if (L && L.tab !== TAB_ID && now - (L.at || 0) < 70000) return;      // มีแท็บอื่นในเบราว์เซอร์นี้คอยเช็คอยู่แล้ว
            GM_setValue('reload_poller', { tab: TAB_ID, at: now });
            if (now - Relay.getAt < 20000) { relayReloadCheck(Relay.kv); return; }      // กล่องสถานะเพิ่งดึงมาแล้ว ใช้ค่านั้น
            GM_xmlhttpRequest({
                method: 'GET', url: u + (u.includes('?') ? '&' : '?') + 'action=peers_get&t=' + now, timeout: 15000,
                onload: (res) => { let j = null; try { j = JSON.parse(res.responseText); } catch (e) { j = null; } if (j && j.ok && j.kv) { Relay.kv = Object.assign({}, j.kv); relayReloadCheck(j.kv); } },
            });
        } catch (e) { /* ignore */ }
    }, 25000 + Math.floor(Math.random() * 5000));

    // 🖥️ Aetherack Manager (โปรแกรมคุม Chrome ในเครื่อง): ส่งสถานะทุก ~3 วิ → ได้คำสั่งที่ค้างกลับมาในคำตอบเดียวกัน
    // ld = รุ่นของตัวโหลดจาก Aetherack Manager (ตัวโหลดประกาศ AETH_LOADER ไว้รอบโค้ดนี้) — ว่าง = ติดตั้งสคริปต์ตรง ๆ แบบเดิม
    const Hub = { at: 0, fails: 0, busy: false, okAt: 0, grp: '', ld: typeof AETH_LOADER !== 'undefined' ? String(AETH_LOADER) : '' };      // eslint-disable-line no-undef
    // หน้าต่างที่ Aetherack Manager เปิดให้ มี #aeth=<กลุ่ม> ต่อท้าย → จำไว้ในแท็บนี้ (รีโหลดก็ยังรู้) แล้วลบออกจากแถบที่อยู่
    try {
        const m = /(?:^#|&)aeth=([\w-]{1,32})/.exec(PW.location.hash || '');
        if (m) { sessionStorage.setItem('at_grp', m[1]); PW.history.replaceState(PW.history.state, '', PW.location.pathname + PW.location.search); }
        Hub.grp = sessionStorage.getItem('at_grp') || '';
    } catch (e) { /* ignore */ }
    const hubBase = () => { const u = String(State.opt.hubUrl || 'http://127.0.0.1:17321').replace(/\/+$/, ''); return /^http:\/\/(127\.0\.0\.1|localhost):\d+$/.test(u) ? u : ''; };
    // "hello" ตอนเปิดหน้าเกม (ยังไม่ล็อกอินก็ส่ง) + ทุก 1 นาที → โปรแกรมรู้ว่า Chrome กลุ่มนี้มีสคริปต์รุ่นไหนทำงานอยู่
    function hubHello() {
        try {
            const u = hubBase(); if (State.opt.hubOn === false || !u || !Hub.grp) return;
            GM_xmlhttpRequest({ method: 'POST', url: u + '/api/hello', headers: { 'Content-Type': 'application/json', 'X-Aeth': '1' }, timeout: 4000, data: JSON.stringify({ grp: Hub.grp, v: VERSION, tab: TAB_ID, ld: Hub.ld }) });
        } catch (e) { /* ignore */ }
    }
    setTimeout(hubHello, 1500); setInterval(hubHello, 60000);
    // 🆕 อัปเดตตัวเอง: ถามโปรแกรมทุก 1 นาทีว่ามีรุ่นใหม่ไหม → รอจังหวะว่าง (ไม่วาร์ป/ซื้อ/ทิ้งขยะ/ตาย/Captcha/ไม่ได้เล่นเอง) + หน่วงสุ่มต่อจอ → รีโหลด (ตัวโหลดดึงรุ่นใหม่มาให้)
    //    ใช้ได้เฉพาะติดตั้งผ่านตัวโหลด · ปิดได้ที่โปรแกรม (ตั้งค่า → อัตโนมัติ) · กันรีโหลดวน: รุ่นเดียวกันลองซ้ำได้ทุก 30 นาที
    const Upd = { want: '', safeSince: 0, jit: 5000 + Math.floor(Math.random() * 90000) };
    const verN = (v) => String(v || '0').split('.').reduce((a, x) => a * 1000 + (parseInt(x, 10) || 0), 0);
    function updCheck() {
        try {
            const u = hubBase(); if (State.opt.hubOn === false || !u || !Hub.ld) return;
            GM_xmlhttpRequest({
                method: 'GET', url: u + '/api/ver?t=' + Date.now(), headers: { 'X-Aeth': '1' }, timeout: 4000,
                onload: (r) => {
                    let j = null; try { j = JSON.parse(r.responseText); } catch (e) { return; }
                    const newer = j && j.ok && j.auto && j.core && verN(j.core) > verN(VERSION);
                    if (newer && Upd.want !== j.core) { Upd.want = j.core; Upd.safeSince = 0; Log.info('HUB', `🆕 มีสคริปต์ใหม่ v${j.core} — จะอัปเดตเองตอนตัวละครว่าง`); }
                    else if (!newer) Upd.want = '';
                },
            });
        } catch (e) { /* ignore */ }
    }
    setTimeout(updCheck, 20000); setInterval(updCheck, 60000);
    setInterval(() => {
        try {
            if (!Upd.want && !Upd.rl) return;
            let tried = null; try { tried = JSON.parse(sessionStorage.getItem('aeth_upd_try') || 'null'); } catch (e) { /* ignore */ }
            if (Upd.want && !Upd.rl && tried && tried.v === Upd.want && Date.now() - tried.at < 1800000) return;
            const busy = Frame.captcha || Frame.dead || InvLock.owner || autoBusy('upd') || isTyping() || Date.now() < Pause.userUntil;
            if (busy) { Upd.safeSince = 0; return; }
            if (!Upd.safeSince) Upd.safeSince = Date.now();
            if (Date.now() - Upd.safeSince < Upd.jit) return;      // ว่างต่อเนื่องสักพัก + หน่วงสุ่ม → ทุกจอไม่รีโหลดพร้อมกัน
            if (Upd.want) try { sessionStorage.setItem('aeth_upd_try', JSON.stringify({ v: Upd.want, at: Date.now() })); } catch (e) { /* ignore */ }
            const why = Upd.want ? `อัปเดตสคริปต์ v${VERSION} → v${Upd.want}` : Upd.rl;
            Log.ok('HUB', `🔄 ${why} (รีโหลดหน้าเกมตอนว่าง)`);
            showToast(`🔄 ${why} — รีโหลดใน 2 วิ`, 'info');
            Upd.want = ''; Upd.rl = ''; setTimeout(reloadNow, 2000);
        } catch (e) { /* ignore */ }
    }, 5000);
    const HUB_CMD = { r3off: 'ปิดภาพ 3D', r3on: 'เปิดภาพ 3D', pause: 'หยุดระบบอัตโนมัติ', resume: 'ทำต่อ', farm: 'กลับไปฟาร์มต่อ', reload: 'รีโหลด', send: 'ส่งข้อมูลเข้า Sheets', ch: 'ย้าย CH', inv: 'ดูของในกระเป๋า', maps: 'ส่งรายชื่อแมพ', reloadsafe: 'รีโหลดตอนว่าง', lowgfx: 'เปิดกราฟิกประหยัด', lowgfxoff: 'ปิดกราฟิกประหยัด', equip: 'สวมใส่อุปกรณ์', statset: 'ตั้งสเตตัส', statrun: 'อัพสเตตัสตอนนี้' };
    function hubBars() {
        const out = {};
        try {
            [...document.querySelectorAll('.bar:not(.bar-exp)')].slice(0, 2).forEach((b, i) => {
                const fill = b.querySelector('.bar-fill'), w = fill ? parseFloat(fill.style.width) : NaN, num = norm((b.querySelector('.bar-num') || {}).textContent || ''), k = i === 0 ? 'hp' : 'sp';
                if (isFinite(w)) out[k + 'P'] = Math.round(w); if (num) out[k + 'T'] = num;
            });
            const e = readExpPct(); if (e.base !== null) out.exB = Math.round(e.base * 10) / 10; else if (e.baseMax) out.exB = 100;
        } catch (e) { /* ignore */ }
        return out;
    }
    // 🎒 ส่งของในกระเป๋าให้หน้ารวม: เปิดกระเป๋า (ถ้ายังไม่เปิด) → แท็บแรก (ทั้งหมด) → อ่านทุกช่อง → ปิดคืน
    async function hubInv(eq) {
        const post = (o) => { const u = hubBase(); if (!u) return; GM_xmlhttpRequest({ method: 'POST', url: u + '/api/inv', headers: { 'Content-Type': 'application/json', 'X-Aeth': '1' }, timeout: 6000, data: JSON.stringify(Object.assign({ tab: TAB_ID }, o)) }); };
        // กำลังวาร์ป/ซื้อของ/ตาย ฯลฯ → บอกหน้ารวมว่ารออยู่ แล้วทำทันทีที่ว่าง (สูงสุด 3 นาที)
        const why = () => (!State.isGameReady ? 'ยังไม่เข้าเกม' : Frame.captcha ? 'มี Captcha' : Frame.dead ? 'ตัวละครตาย' : InvLock.owner || autoBusy('hubinv') || '');
        if (why()) {
            post({ pending: `รอ${why().replace(/^กำลัง/, '')}เสร็จ แล้วจะอ่านให้ทันที` });
            if (!(await waitFor(() => !why(), 180000, 1000))) { post({ err: `รอเกิน 3 นาที (${why()}) — ลองใหม่อีกครั้ง` }); return; }
            await sleep(800);
        }
        let msg = '';
        const was = isVisible(SELECTORS.weight);
        let prevTab = null;
        InvLock.owner = 'hubinv';
        try {
            if (!was) { pressKey('i', 'KeyI', 73); if (!(await waitFor(() => invSlots().length > 0, 2500))) { post({ err: 'เปิดกระเป๋าไม่ขึ้น' }); return; } await sleep(250); }
            const tabs = [...document.querySelectorAll('.inventory .inv-tabs button')];
            prevTab = tabs.find((t) => t.getAttribute('aria-selected') === 'true') || null;
            if (tabs[0] && tabs[0] !== prevTab) { tabs[0].click(); await sleep(350); }
            if (eq) {      // 🛡️ สวมใส่จากหน้ารวม: หาช่องเดิม (ตรวจรูปไอคอนให้ตรง กันกระเป๋าเลื่อน) → เลือก → กด "สวมใส่"
                const key = (u) => String(u || '').split('?')[0].replace(/^.*\/art\/icons\//, '');
                const slots = invSlots(); let el = slots[eq.idx];
                if (!el || key(slotIcon(el)) !== key(eq.ic)) el = slots.find((x) => key(slotIcon(x)) === key(eq.ic));
                if (!el) msg = `❌ ไม่พบ ${eq.n || 'ไอเทม'} ในกระเป๋า (อาจถูกใช้/ย้ายไปแล้ว)`;
                else {
                    const r = el.getBoundingClientRect(), o = { bubbles: true, cancelable: true, view: VIEW, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0 };
                    for (const t of ['pointerdown', 'mousedown', 'pointerup', 'mouseup']) { try { el.dispatchEvent(/^pointer/.test(t) ? new PointerEvent(t, o) : new MouseEvent(t, o)); } catch (e) { /* ignore */ } }
                    el.click(); await sleep(400);
                    const findBtn = () => [...document.querySelectorAll('.inventory button, .inv-detail button, .item-detail button')].find((b) => /^\s*สวมใส่\s*$/.test(b.textContent || '') && b.offsetParent !== null && !b.disabled);
                    const b = await waitFor(findBtn, 1500) ? findBtn() : null;
                    if (!b) msg = `❌ ${eq.n || 'ไอเทมนี้'} สวมใส่ไม่ได้ (ไม่มีปุ่มสวมใส่ — อาจไม่ใช่อุปกรณ์ หรือเลเวล/อาชีพไม่ถึง)`;
                    else { b.click(); await sleep(800); msg = `🛡️ สวมใส่ ${eq.n || 'ไอเทม'} แล้ว`; Log.ok('HUB', msg + ' (สั่งจาก Aetherack Manager)'); }
                }
            }
            const names = {}; for (const [n, a] of Object.entries((Profit.db && Profit.db.items) || {})) if (a && !names[a[0]]) names[a[0]] = n;
            try { await infoLoad(); } catch (e) { /* ไม่มี wiki ก็ส่งเท่าที่มี */ }
            const wikiOf = (iid) => {
                const it = Info.itemById && Info.itemById.get(iid); if (!it) return null;
                const drops = [...(it.droppedBy || [])].sort((a, b) => b.chance - a.chance).slice(0, 5).map((d) => { const m = Info.monById && Info.monById.get(d.monsterId); return { m: m ? `${m.name} (Lv.${m.level})` : `#${d.monsterId}`, c: fmtChance(d.chance), maps: m && m.spawns ? [...new Set(m.spawns.map((x) => x.map))].slice(0, 3).join(', ') : '' }; });
                return { id: it.id, type: it.type, eq: it.equipmentType && it.equipmentType !== 'None' ? it.equipmentType : '', rar: rarityOf(it.rarity).label, sell: it.sellPrice || 0, w: it.weight, el: it.element || '', desc: String(it.description || it.desc || '').slice(0, 300), drops, sold: (it.soldBy || []).slice(0, 3).map((x) => ({ shop: x.shop, price: x.price })), uses: (it.uses || []).slice(0, 4) };
            };
            const items = [];
            for (const el of invSlots()) {
                const src = slotIcon(el); if (!src && !el.classList.contains('filled')) continue;
                const ids = iconCands(src), id = ids.length === 1 ? ids[0] : 0;
                const n = id ? (names[id] || `#${id}`) : ids.length ? `${names[ids[0]] || '?'} (?)` : (norm(el.getAttribute('title') || el.getAttribute('aria-label') || '') || '?');
                const a = (Profit.db.items || {})[n.replace(/ \(\?\)$/, '')];
                const q = parseInt(((el.querySelector('.inv-qty') || {}).textContent || '1').replace(/,/g, ''), 10) || 1;
                const ref = norm((el.querySelector('.inv-refine') || {}).textContent || '');
                let ic = ''; try { ic = src ? new URL(src, location.href).href : ''; } catch (e) { /* ignore */ }
                items.push({ n: ref ? `${ref} ${n}` : n, q, ic, r: a ? a[2] : '', t: a ? ITEM_TYPE_TH[a[1]] || a[1] || '' : '', wk: wikiOf(id || (a && a[0]) || 0) });
            }
            const sn = collectSnapshotData().raw;
            post({ items, w: sn.weight || '', sl: sn.slots || '', z: sn.zeny || '', tabName: tabs[0] ? norm(tabs[0].textContent) : '', msg });
            Log.info('HUB', `🎒 ส่งของในกระเป๋า ${items.length} ช่องให้ Aetherack Manager`);
        } finally {      // คืนสภาพเดิม: แท็บหมวดเดิม · ปิดกระเป๋าถ้าเปิดให้เอง (กด I ไม่ปิด → กดปุ่มปิดของหน้าต่าง)
            try { if (was && prevTab && prevTab.isConnected && prevTab.getAttribute('aria-selected') !== 'true') prevTab.click(); } catch (e) { /* ignore */ }
            if (!was && isVisible(SELECTORS.weight)) {
                pressKey('i', 'KeyI', 73);
                if (!(await waitFor(() => !isVisible(SELECTORS.weight), 1200))) { const x = document.querySelector('.inventory .win-close, .inventory [aria-label*="ปิด"], .inventory .close-btn'); if (x) x.click(); }
            }
            if (InvLock.owner === 'hubinv') InvLock.owner = '';
        }
    }
    // 🗺️ รายชื่อแมพทั้งหมด (ไว้เลือก "กลับฟาร์ม" ในหน้ารวม): ใช้ที่เคยเก็บไว้ · ยังไม่มี → อ่านจากแผนที่โลกของเกมแล้วเก็บไว้
    // ข้อมูลแมพ: เลเวลมอนต่ำสุด–สูงสุดที่เกิดในแมพ (จาก /wiki-data) + หมวด (เมือง / ดันเจี้ยน / สนาม)
    async function hubMapInfo(names) {
        const out = {};
        try {
            const d = await infoLoad();
            for (const m of d.monsters || []) for (const sp of m.spawns || []) {
                const k = norm(sp.map || ''); if (!k || typeof m.level !== 'number') continue;
                const o = out[k] || (out[k] = [m.level, m.level]); o[0] = Math.min(o[0], m.level); o[1] = Math.max(o[1], m.level);
            }
        } catch (e) { /* ignore */ }
        const cat = (n) => (CONFIG.SAFE_MAPS.some((x) => n.includes(x)) || /เมือง|ตลาด|ปลอดภัย|คุก/.test(n) ? 'town' : /ถ้ำ|ดันเจี้ยน|หอคอย|ชั้น|ใต้ดิน|สุสาน|ปราสาท|วิหาร|เหมือง|คุกใต้|ซากปรักหักพัง|dungeon|tower|cave/i.test(n) ? 'dungeon' : 'field');
        const res = {};
        for (const n of names) { const lv = out[norm(n)]; res[n] = [lv ? lv[0] : 0, lv ? lv[1] : 0, cat(n)]; }
        return res;
    }
    async function hubMapNames(force) {
        let names = []; try { names = JSON.parse(localStorage.getItem('at_warp_names') || '[]') || []; } catch (e) { /* ignore */ }
        if ((names.length && !force) || Hub.mapsLoading) return names;
        Hub.mapsLoading = true;
        try {
            const get = async (u) => { const r = await PW.fetch(u, { credentials: 'same-origin' }); if (!r.ok) throw new Error(r.status); return r.json(); };
            const ids = new Set(); const at = await get('/world/atlas'); (at.links || []).forEach((l) => l.forEach((x) => ids.add(String(x).replace(/^aet_/, ''))));
            const got = [];
            for (const id of ids) { try { const j = await get(`/maps/${id}.json`); const pr = j.properties; const d = Array.isArray(pr) ? (pr.find((q) => q.name === 'displayName') || {}).value : pr && pr.displayName; if (d) got.push(String(d)); } catch (e) { /* ignore */ } }
            if (got.length) { names = got; try { lsSet('at_warp_names', JSON.stringify(names)); } catch (e) { /* ignore */ } Log.info('HUB', `🗺️ อ่านรายชื่อแมพ ${names.length} แมพ`); }
        } catch (e) { Log.warn('HUB', 'อ่านรายชื่อแมพไม่สำเร็จ: ' + (e && e.message)); } finally { Hub.mapsLoading = false; }
        return names;
    }
    function hubExec(c) {
        const cmd = c && c.cmd; if (!HUB_CMD[cmd]) return;
        Log.info('HUB', `🖥️ คำสั่งจาก Aetherack Manager: ${HUB_CMD[cmd]}`);
        try {
            if (cmd === 'r3off') setRenderOff(true);
            else if (cmd === 'r3on') setRenderOff(false);
            else if (cmd === 'pause') setPauseAll(true);
            else if (cmd === 'resume') setPauseAll(false);
            else if (cmd === 'farm') {
                Pause.manual = false; Pause.userUntil = 0; renderPause();
                const map = norm(c.map || '');
                if (map) { Log.info('HUB', `🗺️ ไปฟาร์มที่ ${map}`); Promise.resolve(Dev.warpPick(map)).catch((e) => Log.warn('HUB', 'ไปแมพที่เลือกไม่สำเร็จ: ' + (e && e.message))); }
                else Dev.resumeFarm();
            }
            else if (cmd === 'reload') setTimeout(reloadNow, 300);
            else if (cmd === 'send') {      // สั่งจากหน้ารวม: ไม่เปิดหน้าต่างตั้งค่าของสคริปต์ค้างไว้
                if (!State.webAppUrl) Log.warn('HUB', 'ยังไม่ได้ตั้ง Web App URL ของ Sheets ในตัวละครนี้ — ข้ามการส่ง');
                else { State.lastSentSnapshot = ''; sendToSheet(false); }
            }
            else if (cmd === 'reloadsafe') { Upd.rl = c.why ? String(c.why).slice(0, 80) : 'สั่งรีโหลดจาก Aetherack Manager'; Upd.safeSince = 0; }
            else if (cmd === 'lowgfx' || cmd === 'lowgfxoff') {
                State.opt.lowGfx = cmd === 'lowgfx'; savePrefs();
                const ch = lowGfxSet(State.opt.lowGfx);
                if (ch) { Upd.rl = State.opt.lowGfx ? 'เปิดกราฟิกประหยัด' : 'ปิดกราฟิกประหยัด'; Upd.safeSince = 0; }      // ค่าของเกมเปลี่ยน ต้องรีโหลดถึงมีผล → รอตอนว่าง
            }
            else if (cmd === 'maps') { Hub.mapsAt = 0; hubMapNames(true).finally(() => { Hub.at = 0; }); }
            else if (cmd === 'equip') hubInv({ idx: +c.idx || 0, ic: String(c.ic || ''), n: String(c.n || '') }).catch((e) => Log.warn('HUB', 'สวมใส่ไม่สำเร็จ: ' + (e && e.message)));
            else if (cmd === 'statset') {      // ตั้งลำดับ/ค่าเป้าสเตตัส + เปิด/ปิดอัพอัตโนมัติ (ระบบอัพเดิมไม่อัพเกินค่าเป้า)
                const KS = ['STR', 'AGI', 'VIT', 'INT', 'DEX', 'LUK'];
                if (Array.isArray(c.plan)) State.opt.stat = c.plan.filter((r) => r && KS.includes(r.s)).slice(0, 6).map((r) => ({ s: r.s, t: Math.max(0, Math.min(999, parseInt(r.t, 10) || 0)) }));
                if (typeof c.on === 'boolean') State.opt.statOn = c.on;
                savePrefs(); Log.info('HUB', `📈 ตั้งสเตตัสจาก Aetherack Manager: ${(State.opt.stat || []).map((r) => r.s + ' ' + r.t).join(' → ') || '-'} · อัตโนมัติ ${State.opt.statOn ? 'เปิด' : 'ปิด'}`);
            }
            else if (cmd === 'statrun') Promise.resolve(Dev.statRun(true)).catch((e) => Log.warn('HUB', 'อัพสเตตัสไม่สำเร็จ: ' + (e && e.message)));
            else if (cmd === 'inv') hubInv().catch((e) => Log.warn('HUB', 'อ่านกระเป๋าไม่สำเร็จ: ' + (e && e.message)));
            else if (cmd === 'ch') Promise.resolve(Dev.switchCh()).catch((e) => Log.warn('HUB', 'ย้าย CH ไม่สำเร็จ: ' + (e && e.message)));
        } catch (e) { Log.warn('HUB', `ทำคำสั่ง "${HUB_CMD[cmd]}" ไม่สำเร็จ: ${e && e.message}`); }
    }
    setInterval(() => {
        try {
            if (State.opt.hubOn === false || !State.isGameReady || Hub.busy) return;
            const now = Date.now(); if (now - Hub.at < (Hub.fails ? Math.min(60000, 5000 * Hub.fails) : 3000)) return;      // ไม่ได้เปิดโปรแกรม → ลองห่างขึ้นเรื่อย ๆ (สูงสุดนาทีละครั้ง)
            Hub.at = now;
            const snap = Live.snap || liveSnapshot(); if (!snap) return;
            const url = hubBase(); if (!url) return;
            let ttl = ''; try { ttl = PW.document.title; } catch (e) { /* ignore */ }
            const extra = { pause: autoPaused(), ttl, v: VERSION, grp: Hub.grp, ld: Hub.ld, lg: !!State.opt.lowGfx, busy: InvLock.owner || autoBusy('hub') || '', stOn: !!State.opt.statOn, stPlan: State.opt.stat || [], stPts: (() => { try { return Dev.statPts(); } catch (e) { return -1; } })() };
            try { extra.fm = localStorage.getItem('at_warp_last@' + (Store.char || '-')) || ''; } catch (e) { /* ignore */ }
            if (now - (Hub.mapsAt || 0) > 60000) {      // รายชื่อแมพ (ไว้เลือกในหน้ารวม) ส่งนาทีละครั้งพอ
                Hub.mapsAt = now;
                try {
                    const set = new Set(JSON.parse(localStorage.getItem('at_warp_names') || '[]') || []);
                    if (!set.size && !Hub.mapsTried) { Hub.mapsTried = true; hubMapNames().finally(() => { Hub.mapsAt = 0; }); }      // ยังไม่เคยเก็บ → อ่านจากเกม (รอบหน้าค่อยส่ง)
                    Object.keys(JSON.parse(localStorage.getItem('at_fly_zones') || '{}') || {}).forEach((k) => set.add(k));
                    if (extra.fm) set.add(extra.fm);
                    extra.maps = [...set].filter((m) => typeof m === 'string' && m && !/เมืองหลวง|ตลาดคาราวาน|คุก/.test(m)).slice(0, 300);
                    if (Hub.mapInfo && Hub.mapInfo.n === extra.maps.length) extra.mapInfo = Hub.mapInfo.d;
                    else hubMapInfo(extra.maps).then((d) => { Hub.mapInfo = { n: extra.maps.length, d }; Hub.mapsAt = 0; }).catch(() => {});      // คำนวณเสร็จ → ส่งรอบหน้า
                } catch (e) { /* ignore */ }
            }
            Hub.busy = true;
            GM_xmlhttpRequest({
                method: 'POST', url: url + '/api/peer', headers: { 'Content-Type': 'application/json', 'X-Aeth': '1' }, timeout: 4000,
                data: JSON.stringify({ snap: Object.assign({}, snap, hubBars(), extra) }),
                onload: (r) => {
                    Hub.busy = false; let j = null; try { j = JSON.parse(r.responseText); } catch (e) { /* ignore */ }
                    if (r.status === 200 && j && j.ok) { if (!Hub.okAt || Hub.fails) Log.ok('HUB', '🖥️ เชื่อมต่อ Aetherack Manager แล้ว'); Hub.okAt = Date.now(); Hub.fails = 0; (j.cmds || []).forEach(hubExec); }
                    else Hub.fails++;
                },
                onerror: () => { Hub.busy = false; Hub.fails++; }, ontimeout: () => { Hub.busy = false; Hub.fails++; },
            });
        } catch (e) { Hub.busy = false; }
    }, 1000);

    function livePeers(now) {
        const best = {};
        const all = Object.values(Live.peers).slice();
        try {
            for (let i = 0; i < localStorage.length; i++) {
                const k = localStorage.key(i);
                if (!k || k.indexOf('at_peer:') !== 0) continue;
                const p = JSON.parse(localStorage.getItem(k) || 'null');
                if (p && p.name && p.ts) all.push(p);
            }
        } catch (e) { /* ignore */ }
        // 1 ช่องต่อแท็บ (slot): เปลี่ยนตัวละครในแท็บเดิม → ช่องเดิมแสดงตัวใหม่ · ตัวเดียวกันโผล่ในหลายช่อง (ปิดแท็บแล้วเปิดใหม่) → ใช้อันล่าสุด
        for (const p of all) {
            if (now - p.ts >= 43200000) continue;      // เก็บไว้แสดงเป็น ⚫ ออฟไลน์ได้ 12 ชม.
            const k = p.slot ? '@' + p.slot : p.name;
            if (!best[k] || p.ts > best[k].ts) best[k] = p;
        }
        const byName = {};
        for (const p of Object.values(best)) if (!byName[p.name] || p.ts > byName[p.name].ts) byName[p.name] = p;
        const list = Object.values(byName);
        return list.sort((a, b) => (b.main ? 1 : 0) - (a.main ? 1 : 0) || (a.name > b.name ? 1 : -1)).map((p) => Object.assign({ off: now - p.ts >= (p.via ? 120000 : 30000) }, p));
    }

    // แปลงตัวเลข/จุลภาคเป็นตัวเต็มความกว้าง (ใหญ่กว่าปกติ)
    const wide = (t) => String(t).replace(/[0-9]/g, (c) => String.fromCharCode(c.charCodeAt(0) + 0xFEE0)).replace(/,/g, '，');

    function liveEmbed(now) {
        const nowS = Math.floor(now / 1000);
        const allP = livePeers(now), onAll = allP.filter((p) => !p.off).length;
        if (State.opt.statusCompact || onAll > 10 || allP.length > 12) return liveEmbedMany(now, allP);      // หลายจอ: แบบย่อ หลายกล่อง (แบบเต็มใส่ได้แค่ 10 ตัว)
        const peers = allP.slice(0, 10);
        const on = peers.filter((p) => !p.off).length;
        if (State.opt.statusCompact) {
            const lines = peers.map((p) => (p.off
                ? `⚫ **${p.name}** · ออฟไลน์ · เห็นล่าสุด <t:${Math.floor(p.ts / 1000)}:R>`
                : `${p.main ? '⭐' : ''}${(p.kd && p.kd.dot) || '🟢'} **${p.name}** · ${p.map || '—'}${p.ch ? ' ' + p.ch : ''} · ${p.zh ? fmtShort(p.zh) + ' z/ชม.' : '— z/ชม.'} · ⚔️${fmt(p.k)}${p.wp !== null && p.wp !== undefined ? ` · 🎒${p.wp}%` : ''}${p.kd && p.kd.k !== 'farm' ? `\n　└ ${p.st}` : ''}`));
            const color = !on ? 0x71717a : peers.some((p) => !p.off && p.kd && p.kd.k !== 'farm') ? 0xf59e0b : 0x3ddc84;
            return { title: '🛰️ Aetherack · สถานะ (ย่อ)', description: (`อัปเดต <t:${nowS}:R> · ออนไลน์ **${on}** ตัว\n\n` + (lines.join('\n') || 'ยังไม่เห็นตัวละครใด')).slice(0, 4000), color, footer: { text: `Aetherack v${VERSION} · อัปเดตทุก ~20 วินาที` }, timestamp: new Date(now).toISOString(), extra: [] };
        }
        const mains = peers.filter((p) => p.main);
        const groups = [];      // ตัวละครละกลุ่ม แล้วค่อยแบ่งใส่หลายกล่อง (Discord จำกัด 25 ช่อง/กล่อง · 10 กล่อง · รวม ~6000 ตัวอักษร)
        peers.forEach((p) => {
            const fields = [];
            groups.push(fields);
            if (p.off) {
                fields.push({ name: `⚫ ${p.name} · ออฟไลน์`, value: `เห็นล่าสุด <t:${Math.floor(p.ts / 1000)}:R>`, inline: false });
                return;
            }
            fields.push({ name: `${p.main ? '⭐ ' : ''}${(p.kd && p.kd.dot) || '🟢'} ${p.name}  ➜  📍 ${p.map || '—'}${p.ch ? ' ' + p.ch : ''}`.slice(0, 250), value: `📌 ${p.st}`, inline: false });
            fields.push({ name: 'ข้อมูล', value: [p.cls || '—', `Base ${p.blv || '—'} / Job ${p.jlv || '—'}`, p.w ? `🎒 น้ำหนัก ${p.w}${p.wp !== null && !/%/.test(p.w) ? ` (${p.wp}%)` : ''}` : '', typeof p.sl === 'string' && p.sl ? `📦 ช่องเก็บของ ${p.sl}` : '', p.r3 ? '🌙 ปิดภาพ 3D' : ''].filter(Boolean).join('\n'), inline: true });
            fields.push({ name: '💰 Profit', value: [`${fmt(p.z)} z`, p.zh ? `${fmt(p.zh)} z/ชม.` : 'รอข้อมูล…', `⚔️ ${fmt(p.k)} ตัว`].join('\n'), inline: true });
            fields.push({ name: '✨ EXP', value: [p.bx ? `Base ${fmt(p.bx)}/ชม.` : 'Base —', `🎯 Lv 99: ${p.eta}`, p.ping ? `📶 ${p.ping} ms` : ''].filter(Boolean).join('\n'), inline: true });
            if (p.zn) fields.push({ name: '🪙 เงินในกระเป๋า', value: `**${wide(p.zn)}** z`, inline: false }); // ตัวเลขเต็มความกว้าง (fullwidth) ใหญ่กว่าปกติ
        });
        const color = !on ? 0x71717a : peers.some((p) => !p.off && p.kd && p.kd.k !== 'farm') ? 0xf59e0b : 0x3ddc84;
        const embeds = [];
        let cur = [], used = 0, chars = 0;
        const sep = () => ({ name: '\u200b', value: '▬'.repeat(30), inline: false });
        const flush = () => { if (cur.length) embeds.push(cur); cur = []; used = 0; };
        for (const g of groups) {
            const len = g.reduce((a, f) => a + f.name.length + f.value.length, 0);
            if (chars + len > 5200 || embeds.length >= 9) break;
            if (cur.length && used + 1 + g.length > 24) flush();
            if (cur.length) { cur.push(sep()); used++; }
            cur.push(...g); used += g.length; chars += len;
        }
        flush();
        if (!embeds.length) embeds.push([{ name: '\u200b', value: 'ยังไม่เห็นตัวละครใด', inline: false }]);
        const mk = (fields, i) => {
            const e = { color, fields };
            if (i === 0) {
                e.title = '🛰️ Aetherack · สถานะตัวละคร';
                e.description = `อัปเดตล่าสุด <t:${nowS}:R> · ออนไลน์ **${on}** ตัว${mains.length ? `\n## ⭐ ไอดีหลัก: ${mains.map((p) => p.name).join(', ')}` : ''}`;
            }
            if (i === embeds.length - 1) { e.footer = { text: `Aetherack v${VERSION} · อัปเดตอัตโนมัติ ทุก ~20 วินาที` }; e.timestamp = new Date(now).toISOString(); }
            return e;
        };
        const out = mk(embeds[0], 0);
        out.extra = embeds.slice(1).map((f, i) => mk(f, i + 1));
        return out;
    }

    // กล่องสถานะสำหรับเปิดหลายจอ (30+ ตัว): บรรทัดละตัว เรียงตัวที่มีปัญหาขึ้นก่อน · แบ่งหลายกล่อง (Discord จำกัดรวม ~6000 ตัวอักษร/ข้อความ)
    function liveEmbedMany(now, all) {
        const nowS = Math.floor(now / 1000);
        const rank = (p) => (p.off ? 4 : !p.kd ? 2 : ['captcha', 'dead', 'jail'].includes(p.kd.k) ? 0 : p.kd.k === 'farm' ? 3 : 1);
        const list = all.slice().sort((a, b) => rank(a) - rank(b) || (b.main ? 1 : 0) - (a.main ? 1 : 0) || (a.name > b.name ? 1 : -1));
        const on = list.filter((p) => !p.off), farm = on.filter((p) => p.kd && p.kd.k === 'farm').length, bad = on.filter((p) => rank(p) === 0).length;
        const zh = on.reduce((a, p) => a + (+p.zh || 0), 0);
        const line = (p) => (p.off
            ? `⚫ ${p.name} · ออฟไลน์ <t:${Math.floor(p.ts / 1000)}:R>`
            : `${p.main ? '⭐' : ''}${(p.kd && p.kd.dot) || '🟢'} **${p.name}** · ${(p.map || '—').slice(0, 18)}${p.ch ? ' ' + p.ch : ''} · ${p.zh ? fmtShort(p.zh) + '/ชม.' : '—'}${p.wp !== null && p.wp !== undefined ? ` · 🎒${p.wp}%` : ''}${p.kd && p.kd.k !== 'farm' ? ` · ${String(p.st || '').slice(0, 40)}` : ''}`);
        const head = `อัปเดต <t:${nowS}:R> · ออนไลน์ **${on.length}** · 🟢 ฟาร์ม ${farm} · 🟡🟠 อื่น ๆ ${on.length - farm - bad}${bad ? ` · 🔴 **มีปัญหา ${bad}**` : ''} · 💰 รวม **${fmtShort(zh)}** z/ชม.`;
        const color = !on.length ? 0x71717a : bad ? 0xef4444 : on.some((p) => p.kd && p.kd.k !== 'farm') ? 0xf59e0b : 0x3ddc84;
        const boxes = []; let cur = [], len = 0, total = head.length + 120, cut = 0;
        for (let i = 0; i < list.length; i++) {
            const l = line(list[i]);
            if (total + l.length + 1 > 5600 || boxes.length >= 9) { cut = list.length - i; break; }
            if (len + l.length + 1 > 3900) { boxes.push(cur); cur = []; len = 0; }
            cur.push(l); len += l.length + 1; total += l.length + 1;
        }
        if (cur.length) boxes.push(cur);
        if (!boxes.length) boxes.push(['ยังไม่เห็นตัวละครใด']);
        if (cut) boxes[boxes.length - 1].push(`…และอีก ${cut} ตัว (ไม่พอที่ในข้อความเดียว)`);
        const mk = (ls, i) => {
            const e = { color, description: (i === 0 ? head + '\n\n' : '') + ls.join('\n') };
            if (i === 0) e.title = `🛰️ Aetherack · สถานะ ${list.length} ตัว`;
            if (i === boxes.length - 1) { e.footer = { text: `Aetherack v${VERSION} · หลายจอ: แสดงแบบย่ออัตโนมัติ · อัปเดตทุก ~20 วินาที` }; e.timestamp = new Date(now).toISOString(); }
            return e;
        };
        const out = mk(boxes[0], 0);
        out.extra = boxes.slice(1).map((b, i) => mk(b, i + 1));
        return out;
    }

    function bossEmbed(now) {
        const up = bossUpcoming(now).slice(0, 10);
        const here = Boss.list.filter((b) => b.here);
        const fields = [];
        up.forEach((b, i) => fields.push({
            name: `${i + 1}. ${b.name}`.slice(0, 250),
            value: `\`📍 ${b.map || '—'}\` \`⏰ ${fmtThClock(b.at)} น.\`\n<t:${Math.floor(b.at / 1000)}:R>`,
            inline: false,
        }));
        for (const b of here.slice(0, 8)) fields.push({ name: `🔴 ${b.name}`, value: `\`📍 ${b.map || '—'}\` \`ปรากฏตัวแล้ว\``, inline: false });
        return {
            title: '👹 บอสที่กำลังจะเกิด',
            description: Boss.at ? `เวลาเป๊ะจากหน้า "ประกาศล่า MVP" ของเกม · อ่านเมื่อ <t:${Math.floor(Boss.at / 1000)}:R>` : 'ยังไม่มีข้อมูล — เปิดหน้า "บอส" ในเกมหนึ่งครั้ง',
            color: 0xf59e0b,
            fields,
            footer: { text: `Aetherack v${VERSION}` },
        };
    }

    // ส่ง/แก้ไขข้อความของ webhook (แยก 2 กล่อง: status กับ boss ใช้ webhook เดียวกันได้)
    function liveSend(kind, hook, embed, skipSame, manual) {
        const msgKey = kind === 'boss' ? 'at_boss_msg' : LIVE_MSG_KEY;
        if (Live.busy[kind]) return;
        const extra = embed.extra || [];
        const sig = JSON.stringify([embed.fields, extra.map((x) => x.fields)]) + (embed.description || '') + hook;
        if (skipSame && Live.last[kind] && Live.last[kind].sig === sig && Date.now() - Live.last[kind].at < 300000) return;
        Live.busy[kind] = true;
        const rk = Relay.kv && Relay.kv[msgKey];
        const saved = (rk && rk.hook === hook && rk.id ? rk : null) || Store.getJSON(msgKey);
        const body = JSON.stringify({ username: kind === 'boss' ? 'Aetherack Boss' : 'Aetherack Status', embeds: [embed].concat(extra).map((x) => { const y = prettyEmbed(x); delete y.extra; return y; }), allowed_mentions: { parse: [] } });
        const done = () => { Live.busy[kind] = false; };
        const markOk = () => { Live.lastOk = Date.now(); Live.last[kind] = { sig, at: Date.now() }; };
        if (saved && saved.hook === hook && saved.id) {
            dcRequest({
                method: 'PATCH', url: `${hook}/messages/${saved.id}`, headers: { 'Content-Type': 'application/json' }, data: body, timeout: 10000,
                onload: (res) => {
                    done();
                    if (res.status === 404) { Store.set(msgKey, ''); relayKvPut(msgKey, null); if (kind === 'boss') Live.bossAt = 0; else Live.sentAt = 0; Log.warn('STATUS', `ข้อความ ${kind} ถูกลบ จะสร้างใหม่`); }
                    else if (res.status >= 200 && res.status < 300) { markOk(); if (manual) showToast(`✅ อัปเดตกล่อง${kind === 'boss' ? 'บอส' : 'สถานะ'}ใน Discord แล้ว`, 'ok'); }
                    else { Log.err('STATUS', `อัปเดต ${kind} ไม่สำเร็จ (HTTP ${res.status}) ${String(res.responseText || '').slice(0, 160)}`); if (manual) showToast(`⚠️ อัปเดตกล่อง${kind === 'boss' ? 'บอส' : 'สถานะ'}ไม่สำเร็จ (HTTP ${res.status}) ดูใน Logs`, 'warn'); }
                },
                onerror: done, ontimeout: done,
            });
        } else {
            dcRequest({
                method: 'POST', url: `${hook}?wait=true`, headers: { 'Content-Type': 'application/json' }, data: body, timeout: 10000,
                onload: (res) => {
                    done();
                    try {
                        const j = JSON.parse(res.responseText);
                        if (j && j.id) { Store.set(msgKey, JSON.stringify({ hook, id: j.id })); relayKvPut(msgKey, { hook, id: j.id }); markOk(); Log.ok('STATUS', `สร้างกล่องข้อความ ${kind} ใน Discord แล้ว (จะแก้ไขทับตลอด)`); if (manual) showToast(`✅ สร้างกล่อง${kind === 'boss' ? 'บอส' : 'สถานะ'}ใหม่ใน Discord แล้ว`, 'ok'); }
                        else { Log.err('STATUS', `สร้าง ${kind} ไม่สำเร็จ (HTTP ${res.status}) ${String(res.responseText || '').slice(0, 160)}`); if (manual) showToast(`⚠️ สร้างกล่อง${kind === 'boss' ? 'บอส' : 'สถานะ'}ไม่สำเร็จ (HTTP ${res.status}) ดูใน Logs`, 'warn'); }
                    } catch (e) { Log.err('STATUS', `สร้าง ${kind} ไม่สำเร็จ (HTTP ${res.status})`); if (manual) showToast(`⚠️ สร้างกล่อง${kind === 'boss' ? 'บอส' : 'สถานะ'}ไม่สำเร็จ (HTTP ${res.status})`, 'warn'); }
                },
                onerror: done, ontimeout: done,
            });
        }
    }

    // ---------------------------------------------------------------
    // จัดวางหน้าต่างไม่ให้ทับกัน: หาตำแหน่งที่ซ้อนทับหน้าต่างอื่นน้อยที่สุด (ถ้าไม่ทับเลยก็อยู่ที่เดิม)
    // ---------------------------------------------------------------
    const WIN_IDS = ['aetheria-tracker', 'aetheria-profit', 'aetheria-config', 'aetheria-stats', 'aetheria-logs'];
    const Anim = {
        ok() { return !State.opt.lowSpec && typeof Element.prototype.animate === 'function' && !(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches); },
        show(el, vis) {
            if (el._anim) { try { el._anim.cancel(); } catch (e) { /* ignore */ } el._anim = null; }
            el.dataset.closing = '';
            vis(true);
            if (!Anim.ok()) return;
            el.dataset.fresh = '1';
            setTimeout(() => { el.dataset.fresh = ''; }, 500);
            el._anim = el.animate([{ opacity: 0, marginTop: '-30px' }, { opacity: 1, marginTop: '0px' }], { duration: 360, easing: 'cubic-bezier(.2,.9,.25,1)' });
        },
        hide(el, vis) {
            if (el._anim) { try { el._anim.cancel(); } catch (e) { /* ignore */ } el._anim = null; }
            if (!Anim.ok() || getComputedStyle(el).display === 'none') { vis(false); return; }
            el.dataset.closing = '1';
            const a = el.animate([{ opacity: 1, marginTop: '0px' }, { opacity: 0, marginTop: '-24px' }], { duration: 240, easing: 'ease-in', fill: 'forwards' });
            el._anim = a;
            a.onfinish = () => { if (el.dataset.closing === '1') { el.dataset.closing = ''; vis(false); } try { a.cancel(); } catch (e) { /* ignore */ } };
        },
        slide(b, open, done) {
            if (!Anim.ok()) { if (done) done(); return; }
            const hgt = b.scrollHeight;
            b.style.overflow = 'hidden';
            const a = b.animate(open ? [{ height: '0px', opacity: 0 }, { height: hgt + 'px', opacity: 1 }] : [{ height: hgt + 'px', opacity: 1 }, { height: '0px', opacity: 0 }], { duration: 300, easing: 'cubic-bezier(.2,.8,.2,1)', fill: open ? 'none' : 'forwards' });
            a.onfinish = () => { b.style.overflow = ''; if (done) done(); try { if (!open) a.cancel(); } catch (e) { /* ignore */ } };
        },
    };

    function geom(el) {
        const br = el.getBoundingClientRect();
        const sc = State.uiScale || 1;
        const l = parseFloat(el.style.left), t = parseFloat(el.style.top);
        const W = (el.offsetWidth ? el.offsetWidth * sc : br.width), H = (el.offsetHeight ? el.offsetHeight * sc : br.height);
        return { left: isFinite(l) ? l : br.left, top: isFinite(t) ? t : br.top, W, H };
    }
    const toRect = (g) => ({ left: g.left, top: g.top, right: g.left + g.W, bottom: g.top + g.H });
    const rectGap = (a, b) => Math.hypot(Math.max(0, a.left - b.right, b.left - a.right), Math.max(0, a.top - b.bottom, b.top - a.bottom));

    // จัดตำแหน่งหน้าต่าง: ไม่ทับหน้าต่างอื่น และ (ถ้าไม่ได้ลากเอง) ชิดแผงหลักที่สุดเท่าที่ทำได้
    function autoPlace(w) {
        if (!w) return;
        const vw = window.innerWidth, vh = window.innerHeight, g = 8;
        const me = geom(w);
        const W = me.W, H = me.H;
        if (!W || !H) return;
        const userPlaced = w.dataset.user === '1';
        const others = WIN_IDS.map((id) => document.getElementById(id))
            .filter((el) => el && el !== w && el.dataset.closing !== '1' && getComputedStyle(el).display !== 'none')
            .map((el) => toRect(geom(el))).filter((r) => r.right > r.left);
        const mainEl = document.getElementById('aetheria-tracker');
        const main = mainEl && mainEl !== w ? toRect(geom(mainEl)) : null;
        const cx = (x) => Math.max(4, Math.min(x, vw - W - 4));
        const cy = (y) => Math.max(4, Math.min(y, vh - H - 4));
        const cands = [];
        if (userPlaced) cands.push([me.left, me.top]);
        for (const r of others) {
            cands.push([r.right + g, r.top], [r.left - W - g, r.top], [r.left, r.bottom + g], [r.left, r.top - H - g], [r.right + g, r.bottom - H], [r.left - W - g, r.bottom - H]);
        }
        cands.push([4, 4], [vw - W - 4, 4], [4, vh - H - 4], [vw - W - 4, vh - H - 4]);
        const overlap = (x, y) => {
            let a = 0;
            for (const r of others) {
                const ox = Math.min(x + W + 2, r.right) - Math.max(x - 2, r.left);
                const oy = Math.min(y + H + 2, r.bottom) - Math.max(y - 2, r.top);
                if (ox > 0 && oy > 0) a += ox * oy;
            }
            return a;
        };
        let best = null;
        for (const [x0, y0] of cands) {
            const x = cx(x0), y = cy(y0);
            const me2 = { left: x, top: y, right: x + W, bottom: y + H };
            let sc = overlap(x, y);
            if (userPlaced) sc += Math.hypot(x - me.left, y - me.top) * 0.01;
            else sc += (main ? rectGap(me2, main) * 0.8 : 0) + Math.abs(y - (main ? main.top : 80)) * 0.05;
            if (!best || sc < best.sc) best = { x, y, sc };
        }
        const nl = Math.round(best.x) + 'px', nt = Math.round(best.y) + 'px';
        if (w.dataset.fresh !== '1' && (w.style.left !== nl || w.style.top !== nt) && Anim.ok()) {
            w.classList.add('at-glide');
            clearTimeout(w._glide);
            w._glide = setTimeout(() => w.classList.remove('at-glide'), 450);
        }
        w.style.left = nl;
        w.style.top = nt;
        w.dataset.placed = '1';
    }

    // เรียกทุกครั้งที่เปิด/ปิดหน้าต่าง: ที่ว่างเกิดขึ้น หน้าต่างอื่นจะขยับเข้ามาชิดแผงหลัก
    function relayoutAll(closing) {
        try {
            if (closing) for (const id of WIN_IDS) { const el = document.getElementById(id); if (el) el.dataset.user = ''; }
            if (State.isProfitOpen && State.profitDocked) positionProfitPanel();
            const list = [];
            if (State.isProfitOpen && !State.profitDocked) list.push(pRefs.panel);
            if (State.isSettingsOpen) list.push(uiRefs.config);
            if (State.isLogsOpen) list.push(lRefs.panel);
            if (State.isStatsOpen) list.push(sRefs.panel);
            for (const w of list) if (w && getComputedStyle(w).display !== 'none') autoPlace(w);
        } catch (e) { Log.warn('SYS', 'จัดหน้าต่างไม่สำเร็จ: ' + (e && e.message)); }
    }

    // ---------------------------------------------------------------
    // หน้าต่างข้อมูลมอน/ไอเทม (กดที่รูปในหน้า Profit) : ข้อมูลจาก wiki ของเกม (/wiki-data)
    // ---------------------------------------------------------------
    const Info = { data: null, loading: null, err: '', byItemName: null, byMonName: null, itemById: null, monById: null, el: null, stack: [] };

    function infoLoad() {
        if (Info.data) return Promise.resolve(Info.data);
        if (Info.loading) return Info.loading;
        Info.loading = httpGetJSON('/wiki-data').then((d) => {
            Info.data = d;
            Info.itemById = new Map((d.items || []).map((x) => [x.id, x]));
            Info.monById = new Map((d.monsters || []).map((x) => [x.id, x]));
            Info.byItemName = new Map((d.items || []).map((x) => [norm(x.name), x]));
            Info.byMonName = new Map((d.monsters || []).map((x) => [norm(x.name), x]));
            return d;
        }).catch((e) => { Info.err = (e && e.message) || 'โหลดไม่สำเร็จ'; Info.loading = null; throw e; });
        return Info.loading;
    }

    const fmtChance = (c) => {
        if (typeof c !== 'number') return '—';
        const p = c <= 1 ? c * 100 : c;
        return `${+p.toFixed(p >= 10 ? 1 : p >= 1 ? 2 : 3)}%`;
    };
    const fmtRange = (a, b) => (a === b || b === undefined ? fmt(a || 0) : `${fmt(a || 0)}–${fmt(b || 0)}`);

    function closeInfo() {
        if (Info.el) { Info.el.remove(); Info.el = null; }
        Info.stack = [];
        document.removeEventListener('keydown', infoKey, true);
    }
    function infoKey(e) { if (e.key === 'Escape') { e.stopPropagation(); closeInfo(); } }

    function openInfo(kind, key) {
        Info.stack.push({ kind, key });
        showInfo();
    }

    function showInfo() {
        if (!Info.el) {
            const bd = document.createElement('div');
            bd.id = 'aetheria-info';
            bd.addEventListener('click', (e) => { if (e.target === bd) closeInfo(); });
            const card = document.createElement('div');
            card.className = 'ai2-card';
            bd.appendChild(card);
            document.body.appendChild(bd);
            Info.el = bd;
            ensureMonsterManifest();
            document.addEventListener('keydown', infoKey, true);
        }
        const card = Info.el.querySelector('.ai2-card');
        const top = Info.stack[Info.stack.length - 1];
        card.textContent = '';
        const head = h('div', 'ai2-bar');
        if (Info.stack.length > 1) {
            const b = h('button', 'ai2-back', '‹ ย้อนกลับ');
            b.type = 'button';
            b.addEventListener('click', () => { Info.stack.pop(); showInfo(); });
            head.appendChild(b);
        }
        head.appendChild(h('span', 'ai2-src', '📖 ข้อมูลจาก wiki ของเกม'));
        const wkb = h('button', 'ai2-back', '📚 Wiki ทั้งหมด');
        wkb.type = 'button';
        wkb.addEventListener('click', () => { closeInfo(); openWiki(top.kind === 'monster' || top.kind === 'map' ? top.kind : 'item'); });
        head.appendChild(wkb);
        const x = h('button', 'ai2-x', '✕');
        x.type = 'button';
        x.addEventListener('click', closeInfo);
        head.appendChild(x);
        card.appendChild(head);
        const body = h('div', 'ai2-body');
        card.appendChild(body);
        if (!Info.data) {
            body.appendChild(h('div', 'ap-empty', Info.err ? `⚠️ โหลดข้อมูล wiki ไม่ได้ (${Info.err})` : '⏳ กำลังโหลดข้อมูล wiki…'));
            infoLoad().then(() => { if (Info.el && Info.stack[Info.stack.length - 1] === top) showInfo(); }, () => { if (Info.el) showInfo(); });
            return;
        }
        if (top.kind === 'monster') renderMonsterInfo(body, top.key); else if (top.kind === 'map') renderMapInfo(body, top.key); else renderItemInfo(body, top.key);
        body.querySelectorAll('.ai2-row').forEach((r) => { if (r.querySelector('.ai2-link')) r.classList.add('c'); });
        body.addEventListener('click', (e) => {
            const r = e.target.closest('.ai2-row.c');
            if (!r || e.target.closest('.ai2-link') || e.target.closest('.aj-bts')) return;
            const l = r.querySelector('.ai2-link');
            if (l) l.click();
        });
    }

    function infoSection(body, title) {
        body.appendChild(h('div', 'ai2-h', title));
        const box = h('div', 'ai2-list');
        body.appendChild(box);
        return box;
    }
    function infoChips(parent, arr) {
        const w = h('div', 'ai2-chips');
        for (const t of arr) w.appendChild(h('span', 'ai2-chip', t));
        parent.appendChild(w);
    }
    function infoLink(row, text, kind, key, color) {
        const a = h('button', 'ai2-link', text);
        a.type = 'button';
        if (color) a.style.color = color;
        a.addEventListener('click', () => openInfo(kind, key));
        row.appendChild(a);
    }
    const EL_INFO = { neutral: ['⚪', 'กลาง'], water: ['💧', 'น้ำ'], earth: ['🌍', 'ดิน'], fire: ['🔥', 'ไฟ'], wind: ['🌪️', 'ลม'], poison: ['☠️', 'พิษ'], holy: ['✨', 'แสง'], shadow: ['🌑', 'มืด'], dark: ['🌑', 'มืด'], ghost: ['👻', 'ผี'], undead: ['💀', 'อันเดด'] };
    const RACE_INFO = { formless: ['🫧', 'ไร้รูป'], undead: ['💀', 'อันเดด'], brute: ['🐗', 'สัตว์'], plant: ['🌿', 'พืช'], insect: ['🐛', 'แมลง'], fish: ['🐟', 'ปลา'], demon: ['😈', 'ปีศาจ'], demihuman: ['🧑', 'มนุษย์'], human: ['🧑', 'มนุษย์'], angel: ['😇', 'เทวดา'], dragon: ['🐉', 'มังกร'] };
    const SIZE_INFO = { small: ['🐜', 'เล็ก'], medium: ['🐕', 'กลาง'], large: ['🐘', 'ใหญ่'] };
    const TYPE_EMOJI = { Equipment: '⚔️', Card: '🃏', Consumable: '🧪', Enchantment: '🔮', AwakeningStone: '💠', Miscellaneous: '📦' };
    const RARITY_EMOJI = { common: '⚪', uncommon: '🟢', rare: '🔵', epic: '🟣', legendary: '🟠' };
    const tagOf = (map, v) => { const k = String(v || '').toLowerCase(); const m = map[k]; return m ? `${m[0]} ${m[1]}` : (v ? String(v) : ''); };
    function monEmoji(m) {
        const k = String(m.element || '').toLowerCase().replace(/\d+$/, '');
        if (EL_INFO[k] && k !== 'neutral') return EL_INFO[k][0];
        const r = RACE_INFO[String(m.race || '').toLowerCase()];
        return r ? r[0] : '👹';
    }
    function elementText(el, lv) {
        if (!el) return '';
        const m = String(el).match(/^([a-z]+)(\d+)?$/i);
        const key = m ? m[1].toLowerCase() : String(el).toLowerCase();
        const level = lv || (m && m[2]) || '';
        const e = EL_INFO[key];
        return e ? `${e[0]} ธาตุ${e[1]}${level ? ' Lv.' + level : ''}` : `🔮 ธาตุ ${el}${level ? ' Lv.' + level : ''}`;
    }

    function infoItemIcon(id, name, cls) {
        const src = itemIconSrc(id);
        if (src) { const i = h('img', cls || 'ap-icon'); i.src = src; i.alt = ''; i.draggable = false; return i; }
        return h('span', (cls || 'ap-icon') + ' ap-icon-ph', (name || '?').slice(0, 2));
    }
    function infoMonIcon(m, cls) {
        if (!Icons.monsters) ensureMonsterManifest();      // ยังไม่โหลดรูปมอนสเตอร์ → สั่งโหลด (แถวจะวาดใหม่เมื่อโหลดเสร็จ)
        const f = Icons.monsters && Icons.monsters[m.id] && Icons.monsters[m.id].file;
        if (!f) return h('span', (cls || 'ap-icon') + ' ap-icon-ph', monEmoji(m));      // เกมไม่มีรูปมอนตัวนี้ → ใช้อีโมจิตามธาตุ/เผ่าแทนตัวอักษรย่อ
        const i = h('img', cls || 'ap-icon');
        i.src = `/art/monsters/${f}`;
        i.alt = '';
        i.draggable = false;
        return i;
    }

    function renderMonsterInfo(body, key) {
        const m = typeof key === 'number' ? Info.monById.get(key) : Info.byMonName.get(norm(key));
        if (!m) { body.appendChild(h('div', 'ap-empty', `ไม่พบ "${key}" ใน wiki`)); return; }
        const hd = h('div', 'ai2-title');
        hd.appendChild(infoMonIcon(m, 'ap-icon big'));
        const t = h('div', '');
        t.appendChild(h('b', '', `${monEmoji(m)} ${m.name}`));
        t.appendChild(h('small', '', `#${m.id} · Lv.${m.level}`));
        hd.appendChild(t);
        body.appendChild(hd);
        infoChips(body, [`❤️ HP ${fmt(m.hp || 0)}`, `✨ EXP ${fmt(m.exp || 0)}`, `🎓 Job EXP ${fmt(m.jobExp || 0)}`,
            m.size ? `${tagOf(SIZE_INFO, m.size)}` : '', m.race ? tagOf(RACE_INFO, m.race) : '', elementText(m.element, m.elementLevel)].filter(Boolean));
        const sp = infoSection(body, '🗺️ พบได้ที่แมพ');
        const seen = new Set();
        const spawns = (m.spawns || []).filter((s) => { const k = `${s.map}|${s.count}|${s.kinds}|${s.fixed}`; if (seen.has(k)) return false; seen.add(k); return true; });
        if (!spawns.length) sp.appendChild(h('div', 'ai2-muted', '🚫 ยังไม่มีในแผนที่ไหน'));
        for (const s of spawns) {
            const r = h('div', 'ai2-row');
            const mlk = h('div', 'ai2-left');
            infoLink(mlk, `📍 ${s.map}`, 'map', s.map, '');
            r.appendChild(mlk);
            r.appendChild(h('span', 'ai2-name', ''));
            r.appendChild(h('span', 'ai2-sub', s.fixed ? `${s.count} ตัว` : s.kinds > 1 ? `ในพื้นที่ ${s.count} ตัว (${s.kinds} ชนิด)` : `${s.count} ตัว`));
            sp.appendChild(r);
        }
        const dr = infoSection(body, '🎁 ของที่ดรอป');
        const drops = [...(m.drops || [])].sort((a, b) => b.chance - a.chance);
        if (!drops.length) dr.appendChild(h('div', 'ai2-muted', '🚫 ไม่ดรอปไอเทม'));
        for (const d of drops) {
            const it = Info.itemById.get(d.itemId);
            const r = h('div', 'ai2-row');
            const left = h('div', 'ai2-left');
            left.appendChild(infoItemIcon(d.itemId, it && it.name, 'ap-icon sm'));
            infoLink(left, it ? it.name : '#' + d.itemId, 'item', d.itemId, it ? rarityOf(it.rarity).color : '');
            r.appendChild(left);
            const rt = h('div', 'ai2-rt');
            rt.appendChild(h('span', 'ai2-sub', `🎲 ${fmtChance(d.chance)} · x${fmtRange(d.min, d.max)}`));
            if (it) {
                if (itemCat(it) === 'material') { const lk = h('span', 'aw-mat', '🔒'); lk.title = 'วัตถุดิบ — ไม่ทิ้ง'; rt.appendChild(lk); }
                else rt.appendChild(junkButtons(it));
            }
            r.appendChild(rt);
            dr.appendChild(r);
        }
    }

    function mapIndex() {
        if (Info.maps && Info.maps.src === Info.data) return Info.maps.map;
        const mp = new Map();
        for (const m of Info.data.monsters || []) {
            for (const sp of m.spawns || []) {
                if (!sp.map) continue;
                let e = mp.get(sp.map);
                if (!e) { e = { name: sp.map, mons: new Map() }; mp.set(sp.map, e); }
                const o = e.mons.get(m.id);
                if (!o) e.mons.set(m.id, { m, count: sp.count || 0, kinds: sp.kinds || 1, fixed: sp.fixed });
                else o.count += sp.count || 0;
            }
        }
        Info.maps = { src: Info.data, map: mp };
        return mp;
    }

    function renderMapInfo(body, key) {
        const e = mapIndex().get(key);
        if (!e) { body.appendChild(h('div', 'ap-empty', `ไม่พบแมพ "${key}" ใน wiki`)); return; }
        const list = [...e.mons.values()].sort((a, b) => (a.m.level || 0) - (b.m.level || 0));
        const hd = h('div', 'ai2-title');
        hd.appendChild(h('span', 'ai2-mapic', '🗺️'));
        const t = h('div', '');
        t.appendChild(h('b', '', e.name));
        const lv = list.map((x) => x.m.level || 0);
        t.appendChild(h('small', '', `มอนสเตอร์ ${list.length} ชนิด${lv.length ? ` · Lv.${Math.min(...lv)}–${Math.max(...lv)}` : ''}`));
        hd.appendChild(t);
        body.appendChild(hd);
        const sec = infoSection(body, '👹 มอนสเตอร์ในแมพนี้ (กดเพื่อดูข้อมูล)');
        for (const x of list) {
            const r = h('div', 'ai2-row');
            const left = h('div', 'ai2-left');
            left.appendChild(infoMonIcon(x.m, 'ap-icon sm'));
            infoLink(left, `${monEmoji(x.m)} ${x.m.name}`, 'monster', x.m.id, '');
            r.appendChild(left);
            r.appendChild(h('span', 'ai2-sub', `Lv.${x.m.level} · ${elementText(x.m.element, x.m.elementLevel)} · ${x.count} ตัว`));
            sec.appendChild(r);
        }
    }

    function renderItemInfo(body, key) {
        const it = typeof key === 'number' ? Info.itemById.get(key) : Info.byItemName.get(norm(key));
        if (!it) { body.appendChild(h('div', 'ap-empty', `ไม่พบ "${key}" ใน wiki`)); return; }
        const r0 = rarityOf(it.rarity);
        const hd = h('div', 'ai2-title');
        hd.appendChild(infoItemIcon(it.id, it.name, 'ap-icon big'));
        const t = h('div', '');
        const nm = h('b', '', it.name);
        nm.style.color = r0.color;
        t.appendChild(nm);
        t.appendChild(h('small', '', `#${it.id} · ${it.type}${it.equipmentType && it.equipmentType !== 'None' ? ' · ' + it.equipmentType : ''} · ${r0.label}`));
        hd.appendChild(t);
        body.appendChild(hd);
        infoChips(body, [it.sellPrice ? `🪙 ขายร้าน ${fmt(it.sellPrice)} z` : '🚫 ไม่มีราคาขายร้าน', it.weight !== undefined ? `⚖️ น้ำหนัก ${it.weight}` : '', it.element ? elementText(it.element) : ''].filter(Boolean));
        {
            const ws = infoSection(body, '⭐ ตามหาไอเทมนี้ (แจ้งเตือนเมื่อดรอป)');
            const wr = h('div', 'ai2-row');
            wr.appendChild(h('span', 'ai2-sub', wishHas(it.name) ? 'อยู่ในรายการที่ตามหา — ได้ของชิ้นนี้เมื่อไหร่จะแจ้งเตือน' : 'ยังไม่ได้ตามหา — กดดาวเพื่อให้แจ้งเตือนเมื่อดรอป (ดูแหล่งดรอปด้านล่าง)'));
            wr.appendChild(starButton(it));
            ws.appendChild(wr);
            const js = infoSection(body, '🗑️ ทิ้งอัตโนมัติ (ซิงค์กับหน้า Wiki / ทิ้งขยะ)');
            const jr = h('div', 'ai2-row');
            const cur = (junkGet()[it.id] || {}).c || '';
            const lab = JUNK_CLS.find((c) => c[0] === cur);
            jr.appendChild(h('span', 'ai2-sub', itemCat(it) === 'material' ? 'วัตถุดิบ — ไม่ทิ้งเด็ดขาด' : lab ? `ตั้งไว้: ${lab[1]} ${lab[2]}` : 'ยังไม่ตั้ง (ไม่ทิ้ง)'));
            jr.appendChild(junkButtons(it));
            js.appendChild(jr);
        }
        const dr = infoSection(body, '⚔️ ดรอปจากมอนสเตอร์');
        const by = [...(it.droppedBy || [])].sort((a, b) => b.chance - a.chance);
        if (!by.length) dr.appendChild(h('div', 'ai2-muted', '🚫 ไม่มีมอนสเตอร์ดรอป'));
        for (const d of by) {
            const m = Info.monById.get(d.monsterId);
            const r = h('div', 'ai2-row');
            const left = h('div', 'ai2-left');
            if (m) left.appendChild(infoMonIcon(m, 'ap-icon sm'));
            const col = h('div', 'ai2-col');
            const row1 = h('div', '');
            infoLink(row1, m ? `${m.name} (Lv.${m.level})` : `#${d.monsterId}`, 'monster', d.monsterId);
            col.appendChild(row1);
            if (m && m.spawns && m.spawns.length) col.appendChild(h('small', 'ai2-sub', '📍 ' + [...new Set(m.spawns.map((s) => s.map))].join(', ')));
            left.appendChild(col);
            r.appendChild(left);
            r.appendChild(h('span', 'ai2-sub', `🎲 ${fmtChance(d.chance)} · x${fmtRange(d.min, d.max)}`));
            dr.appendChild(r);
        }
        const sb = infoSection(body, '🛒 ขายที่ร้าน');
        if (!it.soldBy || !it.soldBy.length) sb.appendChild(h('div', 'ai2-muted', '🚫 ไม่มีร้านขาย'));
        for (const s of it.soldBy || []) {
            const r = h('div', 'ai2-row');
            r.appendChild(h('span', 'ai2-name', `🏪 ${s.shop}${s.npcs && s.npcs.length ? ' (' + s.npcs.join(', ') + ')' : ''}`));
            r.appendChild(h('span', 'ai2-sub', `🪙 ${fmt(s.price)} z`));
            sb.appendChild(r);
        }
        if (it.uses && it.uses.length) {
            const us = infoSection(body, '🔧 ใช้ทำอะไร');
            for (const u of it.uses) us.appendChild(h('div', 'ai2-row', `🔨 ${u}`));
        }
    }

    // ---------------------------------------------------------------
    // ทิ้งขยะอัจฉริยะ: น้ำหนักถึงเกณฑ์ → เปิดกระเป๋า (I) → จัดเรียง → เลือกไอเทมที่ตั้งเป็น "ขยะ" → ทิ้ง → ยืนยัน
    // ปลอดภัยไว้ก่อน: ไม่ได้ตั้งค่า/ล็อก/ตีบวกแล้ว/ชื่อไม่ตรง = ไม่แตะ · มีโหมดทดลอง · ทำช้าแบบคนกด
    // ---------------------------------------------------------------
    const JUNK_KEY = 'at_junk_v1';
    const Junk = { map: null, running: false, nextAt: 0, q: '' };
    const JUNK_CLS = [['junk', '🗑️', 'ขยะ'], ['keep', '📦', 'เก็บทำของ'], ['never', '🔒', 'ห้ามทิ้ง']];

    // ค่าร่วมทุกโปรไฟล์: map ไอเทม + เกณฑ์/ล็อกระดับ เก็บที่คีย์กลางเดียว (ไม่ผูกชื่อตัวละคร)
    const JUNK_SH_KEY = 'at_junk_shared_data';
    const JUNK_SH_OPTS = ['junkLock', 'junkAt', 'junkTo', 'junkMax', 'junkAll', 'junkSlotOn', 'junkSlotFree', 'junkSlotGoal', 'keepOpts'];
    const junkShared = () => Store.get('at_junk_sh') === '1';
    function junkShRead() {
        try { const d = JSON.parse(localStorage.getItem(JUNK_SH_KEY) || 'null'); return d && typeof d === 'object' ? d : null; } catch (e) { return null; }
    }
    function junkShSave(d) { try { lsSet(JUNK_SH_KEY, JSON.stringify(d)); } catch (e) { /* ignore */ } }
    function junkShareWrite() {
        if (!junkShared() || Junk.applying) return;
        const d = junkShRead() || { map: {} };
        d.cfg = {};
        for (const k of JUNK_SH_OPTS) d.cfg[k] = State.opt[k];
        junkShSave(d);
    }
    function junkShareApply() {
        if (!junkShared()) return;
        const d = junkShRead();
        if (!d) return;
        Junk.map = null;
        if (d.cfg) for (const k of JUNK_SH_OPTS) if (d.cfg[k] !== undefined) State.opt[k] = d.cfg[k];
    }
    function junkShareToggle(on) {
        if (on) {
            const d = junkShRead();
            Store.set('at_junk_sh', '1');
            if (!d) {
                const nd = { map: Store.getJSON(JUNK_KEY, {}) || {}, cfg: {} };
                for (const k of JUNK_SH_OPTS) nd.cfg[k] = State.opt[k];
                junkShSave(nd);
            } else if (window.confirm('มีค่ากลางที่ใช้ร่วมกันอยู่แล้ว\nตกลง = ใช้ค่ากลางที่มีอยู่ (ค่าของโปรไฟล์นี้จะถูกแทนที่)\nยกเลิก = เขียนทับค่ากลางด้วยค่าของโปรไฟล์นี้')) {
                junkShareApply();
            } else {
                const nd = { map: Store.getJSON(JUNK_KEY, {}) || {}, cfg: {} };
                for (const k of JUNK_SH_OPTS) nd.cfg[k] = State.opt[k];
                junkShSave(nd);
            }
        } else {
            // ปิด: คัดลอกค่ากลางมาเป็นของโปรไฟล์นี้ แล้วแยกกันต่อ
            const d = junkShRead();
            if (d && d.map) Store.set(JUNK_KEY, JSON.stringify(d.map));
            Store.set('at_junk_sh', '0');
        }
        Junk.map = null;
        savePrefs();
        junkChanged();
        junkRefreshCfg();
    }
    function junkRefreshCfg() {
        const cfg = document.getElementById('aetheria-config');
        if (!cfg) return;
        for (const k of ['junkAt', 'junkTo', 'junkMax', 'junkSlotFree', 'junkSlotGoal']) {
            const el = cfg.querySelector(`input[type=range][data-opt="${k}"]`);
            if (el) { el.value = State.opt[k]; el.dispatchEvent(new Event('input')); }
        }
        for (const k of ['junkAll', 'junkSlotOn']) { const sw = cfg.querySelector(`.at-switch[data-opt="${k}"]`); if (sw) sw.classList.toggle('on', !!State.opt[k]); }
        renderKeepOpts();
        const rb = cfg.querySelector('#at-junk-rar');
        if (rb) rb.querySelectorAll('input').forEach((cb, i) => { cb.checked = rarityLocked(['common', 'uncommon', 'rare', 'epic', 'legendary'][i]); });
        const shb = cfg.querySelector('#at-junk-share');
        if (shb) { shb.classList.toggle('on', junkShared()); shb.textContent = junkShared() ? '🔗 ใช้ค่าร่วมกันทุกโปรไฟล์: เปิด' : '🔗 ใช้ค่าร่วมกันทุกโปรไฟล์: ปิด'; }
    }
    window.addEventListener('storage', (e) => {
        if (e.key !== JUNK_SH_KEY || !junkShared()) return;
        Junk.applying = true;
        try { junkShareApply(); junkChanged(); junkRefreshCfg(); } finally { Junk.applying = false; }
    });

    function junkGet() {
        if (junkShared()) { const d = junkShRead(); if (d) { if (!Junk.map) Junk.map = d.map || {}; return Junk.map; } }
        if (!Junk.map) Junk.map = Store.getJSON(JUNK_KEY, {}) || {};
        return Junk.map;
    }
    function junkSet(id, name, cls) {
        const wi = Info.itemById && Info.itemById.get(+id);
        if (wi && wi.type === 'Miscellaneous') return;      // วัตถุดิบตั้งเป็นขยะไม่ได้
        if (junkShared()) {
            const d = junkShRead() || { map: {} };      // อ่านใหม่ทุกครั้ง กันเขียนทับการแก้จากโปรไฟล์อื่น
            d.map = d.map || {};
            if (!cls) delete d.map[id]; else d.map[id] = { c: cls, n: name };
            junkShSave(d);
            Junk.map = d.map;
            return;
        }
        const m = junkGet();
        if (!cls) delete m[id]; else m[id] = { c: cls, n: name };
        Store.set(JUNK_KEY, JSON.stringify(m));
    }

    const invSlots = () => { const g = document.querySelector('.inventory .inv-grid'); return g ? [...g.children] : []; };
    const slotIcon = (el) => { const im = el && el.querySelector('img.inv-icon'); return im ? im.getAttribute('src') || '' : ''; };
    function invWeightPct() {
        const el = document.querySelector('.inv-weight .bar-num');
        const m = el && REGEX.weight.exec(el.textContent);
        if (!m) return null;
        const c = parseInt(m[1].replace(/,/g, ''), 10), x = parseInt(m[2].replace(/,/g, ''), 10);
        return x > 0 ? (c / x) * 100 : null;
    }

    async function junkRun(manual, real) {
        if (Junk.running) return;
        if (InvLock.owner) {      // กำลังซิงค์กระเป๋าส่ง Sheet อยู่ — รอรอบหน้า
            if (manual) showToast('กำลังซิงค์กระเป๋าอยู่ ลองใหม่อีกครั้งในไม่กี่วินาที', 'warn');
            Junk.nextAt = Date.now() + 8000;
            return;
        }
        Junk.running = true;
        InvLock.owner = 'junk';
        const rnd = (a, b) => a + Math.random() * (b - a);
        const pause = (a = 350, b = 800) => sleep(rnd(a, b));
        const dry = !!State.opt.junkDry && !real;      // real = ปุ่มทิ้งทันที: ทิ้งจริงเสมอ ไม่รอเกณฑ์น้ำหนัก
        const done = [];
        let skipped = 0, opened = false, pctA = null, pctB = null, slotOnly = false, trigS = false, trigW = false, keptOpt = 0, noJunkSet = false, planned = false;
        const ok = () => State.isGameReady && !Frame.dead && !Frame.captcha && isVisible(SELECTORS.weight);
        try {
            if (!isVisible(SELECTORS.weight)) {
                pressKey('i', 'KeyI', 73);
                opened = true;
                if (!(await waitFor(() => isVisible(SELECTORS.weight), 2000))) {
                    Log.warn('JUNK', 'เปิดกระเป๋าไม่สำเร็จ');
                    await sleep(900);
                    if (isVisible(SELECTORS.weight)) pressKey('i', 'KeyI', 73);      // เปิดช้าแต่ขึ้นมาแล้ว ปิดคืน
                    return;
                }
            }
            await pause(300, 600);
            const pct0 = invWeightPct();
            if (pct0 === null) { Log.warn('JUNK', 'อ่านน้ำหนักไม่ได้'); return; }
            pctA = pct0;
            const sl0 = slotInfoDom();
            const slotTrig = !!(State.opt.junkSlotOn && sl0 && sl0.free <= State.opt.junkSlotFree);      // ช่องเก็บของเต็ม/ใกล้เต็ม (ไม่ขึ้นกับขนาดกระเป๋า 100/200 ช่อง)
            const wTrig = !!manual || Math.round(pct0) >= State.opt.junkAt;      // เทียบแบบปัดเศษเหมือนที่แสดงบนหน้าจอ (89.9% แสดงเป็น 90%)
            slotOnly = slotTrig && !wTrig;
            trigS = slotTrig; trigW = !manual && !real && Math.round(pct0) >= State.opt.junkAt;
            if (!wTrig && !slotTrig) {
                if (Date.now() - (Junk.waitLogAt || 0) > 300000) { Junk.waitLogAt = Date.now(); Log.info('JUNK', `น้ำหนัก ${Math.round(pct0)}% ยังไม่ถึงเกณฑ์ ${State.opt.junkAt}%${sl0 ? ` · ช่องว่าง ${sl0.free}/${sl0.max}` : ''} — รอ`); }
                return;
            }
            const hasJunk = Object.values(junkGet()).some((x) => x.c === 'junk');
            if (!hasJunk) { noJunkSet = true; if (manual) showToast('ยังไม่ได้ตั้งไอเทมเป็น 🗑️ ขยะ', 'warn'); return; }
            const search = document.querySelector('.inventory .inv-filter input[type=search]');
            if (search && search.value) { Log.warn('JUNK', 'ช่องค้นหาในกระเป๋ามีข้อความ — ข้ามรอบนี้'); return; }
            const tabs = [...document.querySelectorAll('.inventory .inv-tabs button')];
            if (tabs[0] && tabs[0].getAttribute('aria-selected') !== 'true') { tabs[0].click(); await pause(); }
            Log.info('JUNK', `${slotTrig ? `ช่องเก็บของเหลือว่าง ${sl0.free}/${sl0.max} (≤ ${State.opt.junkSlotFree}) · ` : ''}น้ำหนัก ${Math.round(pct0)}%${wTrig ? ` ถึงเกณฑ์ (${State.opt.junkAt}%)` : ''} → เริ่มทิ้งขยะ${dry ? ' [โหมดทดลอง]' : real ? ' [ทิ้งทันที]' : ''}`);
            const sortBtn = document.querySelector('.inventory .inv-sort');
            if (sortBtn) { sortBtn.click(); await pause(900, 1500); }
            await infoLoad().catch(() => null);
            const map = junkGet();
            const plan = [];
            const why = { gameLock: 0, refined: 0, unknownIcon: 0, material: 0, rarity: 0, shared: 0 };
            invSlots().forEach((el, idx) => {
                if (!el.classList.contains('filled')) return;
                const cands = iconCands(slotIcon(el));
                if (!cands.length) { why.unknownIcon++; return; }
                const id = cands.length === 1 ? cands[0] : 0;
                if (id ? !(map[id] && map[id].c === 'junk') : !cands.some((c) => map[c] && map[c].c === 'junk')) return;
                if (el.querySelector('.inv-lock')) { why.gameLock++; return; }       // ไอเทมถูกล็อกในเกม
                if (el.querySelector('.inv-refine')) { why.refined++; return; }      // ตีบวกแล้ว
                const q = parseInt(((el.querySelector('.inv-qty') || {}).textContent || '1').replace(/,/g, ''), 10) || 1;
                if (!id) { why.shared++; plan.push({ idx, probe: true, id: 0, name: '', qty: q, w: q }); return; }      // รูปซ้ำหลายไอเทม → ต้องกดเลือกอ่านชื่อจริงก่อน
                const ent = map[id];
                const it = Info.itemById && Info.itemById.get(id);
                if (it && itemCat(it) === 'material') { why.material++; return; }      // วัตถุดิบ ห้ามทิ้งเด็ดขาด
                let gate = false;
                if (it && rarityLocked(it.rarity) && optRuleOk(it)) gate = true;      // ระดับถูกล็อก แต่เปิด "ให้ออฟตัดสิน" → ผ่านไปอ่านออฟก่อนทิ้ง (ออฟตรง = เก็บ)
                if (!it || (rarityLocked(it.rarity) && !gate)) { why.rarity++; return; }        // ล็อกตามระดับ / ไม่รู้ระดับ
                plan.push({ idx, id, name: (it && it.name) || ent.n, qty: q, w: ((it && it.weight) || 1) * q, gate });
            });
            plan.sort((a, b) => b.w - a.w);
            planned = true;
            Log.info('JUNK', `พบ ${plan.length} ช่องที่จะทิ้ง` + (why.gameLock ? ` · ข้ามเพราะล็อกในเกม ${why.gameLock}` : '') + (why.refined ? ` · ตีบวกแล้ว ${why.refined}` : '') + (why.rarity ? ` · ล็อกตามระดับ ${why.rarity}` : '') + (why.unknownIcon ? ` · จับคู่ไอคอนไม่ได้ ${why.unknownIcon}` : '') + (why.shared ? ` · รูปซ้ำหลายไอเทม (ตรวจชื่อจริงก่อนทิ้ง) ${why.shared}` : ''));
            const target = Math.min(State.opt.junkTo, State.opt.junkAt - 1);
            for (const it of plan) {
                if (!ok() || !State.opt.junkOn && !manual) break;
                if (done.length >= State.opt.junkMax) break;
                const pct = invWeightPct();
                if (!dry && !real && !State.opt.junkAll) {
                    const si = slotInfoDom();
                    const wDone = !wTrig || (pct !== null && pct <= target);
                    const sDone = !slotTrig || (!!si && si.free >= State.opt.junkSlotGoal);
                    if (wDone && sDone) break;
                }
                const el = invSlots()[it.idx];
                if (!el || !el.classList.contains('filled') || (it.probe ? iconCands(slotIcon(el)).length < 2 : itemIdFromIcon(slotIcon(el)) !== it.id)) { Log.warn('JUNK', `ช่องของ ${it.name || 'ไอเทมรูปซ้ำ'} เปลี่ยนตำแหน่ง — ข้าม`); skipped++; continue; }
                el.click();
                await pause(350, 750);
                const selNow = () => { const e = invSlots()[it.idx]; return !!e && e.classList.contains('selected'); };
                await waitFor(() => document.querySelector('.inventory .inv-detail-name') && selNow(), 1500);
                if (it.probe) {
                    // รูปซ้ำ: อ่านชื่อจริงจากกรอบรายละเอียด (ต้องเป็นช่องที่เราเพิ่งเลือก) แล้วเทียบกับ wiki + ตั้งค่า
                    const realName = norm((document.querySelector('.inventory .inv-detail-name') || {}).textContent);
                    const wi = selNow() && realName ? wikiByNameLC(realName) : null;
                    if (!wi) { Log.warn('JUNK', `อ่านชื่อไอเทมรูปซ้ำไม่ได้ (${realName || '—'}) — ข้าม`); skipped++; continue; }
                    const e2 = map[wi.id];
                    const gate2 = rarityLocked(wi.rarity) && optRuleOk(wi);
                    if (!e2 || e2.c !== 'junk' || itemCat(wi) === 'material' || (rarityLocked(wi.rarity) && !gate2)) { skipped++; continue; }      // ช่องนี้ไม่ใช่ขยะที่ตั้งไว้
                    it.gate = gate2;
                    it.id = wi.id; it.name = wi.name; it.w = (wi.weight || 1) * it.qty;
                }
                const dn = norm((document.querySelector('.inventory .inv-detail-name') || {}).textContent).toLowerCase();
                if (!dn || !dn.includes(String(it.name).toLowerCase())) { Log.warn('JUNK', `ชื่อไม่ตรง (${dn || '—'} ≠ ${it.name}) — ข้าม`); skipped++; continue; }
                if (Object.keys(State.opt.keepOpts || {}).length) {
                    const wi2 = Info.itemById && Info.itemById.get(it.id);
                    if (wi2 && ['weapon', 'armor', 'accessory'].includes(itemCat(wi2))) {      // ออฟที่ตั้งไว้ว่า "ไม่ทิ้ง" → อ่านจากกรอบรายละเอียดก่อนทิ้งทุกครั้ง
                        const card = await readItemCard(invSlots()[it.idx], it.name, it.idx, itemCat(wi2));
                        if (!card.ok) { Log.warn('JUNK', `${it.name}: อ่านรายละเอียด/ออฟไม่ได้ — ข้ามเพื่อความปลอดภัย`); skipped++; continue; }
                        const hit = keepOptHit(card);
                        if (hit) {
                            const lk = it.name + '|' + hit.def.k, now = Date.now(); Junk._optLog = Junk._optLog || {};
                            if (!Junk._optLog[lk] || now - Junk._optLog[lk] > 600000) { Junk._optLog[lk] = now; Log.info('JUNK', `${it.name}: มีออฟ ${hit.def.k} +${fmtStat(hit.val)}${hit.pct ? '%' : ''} ที่ตั้งไว้ว่าไม่ทิ้ง — ข้าม (จะไม่แจ้งซ้ำภายใน 10 นาที)`); }
                            skipped++; keptOpt++; continue;
                        }
                    }
                }
                const findBtn = () => {
                    const all = [...document.querySelectorAll('.inventory .inv-actions button, .inventory .inv-detail button')];
                    return all.find((b) => b.classList.contains('danger') && /ทิ้ง/.test(b.textContent)) || all.find((b) => /ทิ้ง/.test(b.textContent)) || document.querySelector('.inventory .inv-actions button.danger');
                };
                await waitFor(() => { const b = findBtn(); return b && !b.disabled; }, 1500);
                const btn = findBtn();
                if (!btn || btn.disabled) {
                    const labels = [...document.querySelectorAll('.inventory .inv-actions button, .inventory .inv-detail button')].map((b) => `${norm(b.textContent)}${b.disabled ? '(ปิด)' : ''}`).join(' | ');
                    Log.warn('JUNK', `${it.name}: ${btn ? 'ปุ่มทิ้งกดไม่ได้ (ถูกปิดโดยเกม — อาจถูกล็อก/ทิ้งไม่ได้)' : 'ไม่พบปุ่มทิ้ง'} · ปุ่มที่เห็น: ${labels || '—'}`);
                    skipped++; continue;
                }
                if (dry) { Log.info('JUNK', `[ทดลอง] จะทิ้ง ${it.name} x${it.qty}`); done.push(it); await pause(250, 500); continue; }
                btn.click();
                if (!(await waitFor(() => document.querySelector('.confirm-dialog'), 4000))) { await sleep(600); await dismissConfirm(); Log.warn('JUNK', `${it.name}: กดทิ้งแล้วแต่ไม่มีกล่องยืนยันขึ้น — ข้าม`); skipped++; continue; }
                const dlg = document.querySelector('.confirm-dialog');
                if (!norm(dlg.textContent).toLowerCase().includes(String(it.name).toLowerCase())) {
                    const cancel = [...dlg.querySelectorAll('button')].find((b) => !b.classList.contains('danger'));
                    if (cancel) cancel.click();
                    Log.warn('JUNK', `กล่องยืนยันไม่ตรงชื่อ ${it.name} — ยกเลิก`);
                    skipped++;
                    await pause();
                    continue;
                }
                await pause(300, 650);
                const yes = dlg.querySelector('button.danger');
                if (yes) yes.click();
                await waitFor(() => !document.querySelector('.confirm-dialog'), 2000);
                done.push(it);
                Log.ok('JUNK', `ทิ้ง ${it.name} x${it.qty}`);
                await pause(700, 1300);
            }
        } catch (e) {
            Log.err('JUNK', 'ผิดพลาด: ' + (e && e.message));
        } finally {
            try { if (!dry && isVisible(SELECTORS.weight)) pctB = invWeightPct(); } catch (e) { /* ignore */ }
            try {      // กระเป๋ายังเต็ม แต่รอบนี้ไม่ได้ทิ้งอะไรเลย → แจ้งว่าติดเพราะอะไร (วัตถุดิบ / ออฟที่ตั้งไว้ / ล็อก)
                if (!dry && !real && !done.length && (planned || noJunkSet) && isVisible(SELECTORS.weight)) {
                    const sl = slotInfoDom(), pc = invWeightPct();
                    const stillS = trigS && !!sl && sl.free <= State.opt.junkSlotFree;
                    const stillW = trigW && pc !== null && Math.round(pc) >= State.opt.junkAt;
                    if ((stillS || stillW) && Date.now() - (Junk.stuckAt || 0) > 1800000) { Junk.stuckAt = Date.now(); junkStuckAlert(bagBreakdown(keptOpt), sl, pc, noJunkSet); }
                }
            } catch (e) { /* ignore */ }
            try {
                await dismissConfirm();
                if (opened && isVisible(SELECTORS.weight)) {
                    pressKey('i', 'KeyI', 73);
                    await sleep(450);
                    if (isVisible(SELECTORS.weight)) { const c = document.querySelector('.inventory .inv-close'); if (c) c.click(); }
                }
            } catch (e) { /* ignore */ }
            Junk.running = false;
            if (InvLock.owner === 'junk') InvLock.owner = '';
            Junk.nextAt = Date.now() + (dry ? 300000 : done.length ? 45000 : slotOnly ? 600000 : 120000);      // ช่องเต็มแต่ไม่มีอะไรให้ทิ้ง → ไม่เปิดกระเป๋าถี่ๆ
            if (done.length) {
                const list = done.slice(0, 15).map((x) => `${x.name} x${fmt(x.qty)}`).join('\n');
                const title = dry ? '🧪 [ทดลอง] จะทิ้งขยะ' : '🗑️ ทิ้งขยะแล้ว';
                Log.ok('JUNK', `${title} ${done.length} รายการ${skipped ? ` (ข้าม ${skipped})` : ''}`);
                showToast(`${dry ? '🧪' : '🗑️'} ${dry ? 'ทดลอง' : 'ทิ้งขยะ'} ${done.length} รายการ`, 'info');
                if (!dry) { JunkStat.rec(done, pctA, pctB); renderJunkStat(); }
                if (!dry) sendDiscord('junk', { title, description: `**${charLabel()}** ทิ้งขยะอัตโนมัติ ${done.length} รายการ`, color: 0x71717a, fields: [{ name: 'รายการ', value: list, inline: false }] }, { ping: false });
            }
        }
    }

    // นับของในกระเป๋าที่ทิ้งไม่ได้ แยกตามสาเหตุ (เรียกตอนกระเป๋ายังเปิดอยู่)
    function bagBreakdown(optKeep) {
        const map = junkGet();
        const r = { filled: 0, mat: 0, gameLock: 0, refined: 0, setLock: 0, rarity: 0, optKeep: optKeep || 0, unknown: 0 };
        invSlots().forEach((el) => {
            if (!el.classList.contains('filled')) return;
            r.filled++;
            const cands = iconCands(slotIcon(el));
            if (cands.length !== 1) { r.unknown++; return; }
            const id = cands[0], it = Info.itemById && Info.itemById.get(id);
            if (it && itemCat(it) === 'material') { r.mat++; return; }
            if (el.querySelector('.inv-lock')) { r.gameLock++; return; }
            if (el.querySelector('.inv-refine')) { r.refined++; return; }
            const c = map[id] && map[id].c;
            if (c === 'keep' || c === 'never') { r.setLock++; return; }
            if (c === 'junk' && it && rarityLocked(it.rarity)) r.rarity++;
        });
        return r;
    }
    function junkStuckAlert(b, sl, pct, noJunk) {
        const rows = [
            ['📦 วัตถุดิบ (ทิ้งไม่ได้)', b.mat], ['🎲 มีออฟที่ตั้งไว้ว่าไม่ทิ้ง', b.optKeep], ['🔒 ล็อกในเกม', b.gameLock],
            ['🛡️ ตั้งเป็น 📦 เก็บ / 🔒 ห้ามทิ้ง', b.setLock], ['⭐ ล็อกตามระดับความหายาก', b.rarity], ['⚒️ ตีบวกแล้ว', b.refined], ['❓ อ่านไอคอนไม่ได้', b.unknown],
        ].filter((x) => x[1] > 0);
        const fields = [];
        if (noJunk) fields.push({ name: 'สาเหตุ', value: 'ยังไม่ได้ตั้งไอเทมไหนเป็น 🗑️ ขยะ', inline: false });
        if (rows.length) fields.push({ name: 'ของที่ทิ้งไม่ได้ในกระเป๋า', value: rows.map((x) => `${x[0]}: ${x[1]} ช่อง`).join('\n'), inline: false });
        fields.push({ name: 'แนะนำ', value: 'เก็บของเข้าคลัง/ขาย หรือปรับตั้งค่าในแท็บ ขยะ', inline: false });
        raiseAlert('stuck', {
            title: '🔒 กระเป๋าเต็ม แต่ทิ้งอัตโนมัติไม่ได้',
            desc: `**${charLabel()}** — ${sl ? `ช่องว่าง ${sl.free}/${sl.max} · ` : ''}น้ำหนัก ${pct !== null ? Math.round(pct) + '%' : '—'} แต่ไม่มีไอเทมที่ทิ้งได้เลย`,
            fields, color: 0xef4444, ping: true, sound: 'beep',
            toast: '🔒 กระเป๋าเต็ม ทิ้งอัตโนมัติไม่ได้ (ดูสาเหตุที่ Logs/Discord)',
        });
    }

    function junkTick(now) {
        if (!State.opt.junkOn || Junk.running || now < Junk.nextAt || autoPaused() || autoBusy('junk')) return;
        if (!State.isGameReady || Frame.dead || Frame.captcha || isTyping() || Frame.invOpen) return;
        if (!Object.values(junkGet()).some((x) => x.c === 'junk')) return;
        const fresh = now - State.lastInvSeenAt < 60000;
        if (fresh) {
            const p = parseWeight().percent;
            const sh = slotInfoHud();
            const slotTrig = !!(State.opt.junkSlotOn && sh && sh.free <= State.opt.junkSlotFree);
            if (p && p < State.opt.junkAt && !slotTrig) { Junk.nextAt = now + 15000; return; }
        }
        Junk.nextAt = now + (fresh ? 60000 : 120000);
        junkRun(false);
    }

    // ----- หน้าตั้งค่า: จัดกลุ่มไอเทม (🗑️ ขยะ / 📦 เก็บทำของ / 🔒 ห้ามทิ้ง) · หมวดเดียวกับแท็บในกระเป๋าของเกม -----
    const JUNK_CATS = [['weapon', 'อาวุธ'], ['armor', 'ชุดเกราะ'], ['accessory', 'ประดับ/เจม'], ['usable', 'ใช้ได้'], ['card', 'การ์ด'], ['refine', 'แร่/ตีบวก'], ['material', 'วัตถุดิบ'], ['stone', 'ศิลา'], ['other', 'อื่นๆ']];
    function itemCat(it) {
        const t = it.type, e = it.equipmentType;
        return t === 'Card' ? 'card' : t === 'Equipment' ? (e === 'Weapon' || e === 'Ammo' ? 'weapon' : e === 'Acc' || e === 'Gem' ? 'accessory' : 'armor')
            : t === 'Consumable' ? 'usable' : t === 'Enchantment' ? 'refine' : t === 'Miscellaneous' ? 'material' : t === 'AwakeningStone' ? 'stone' : 'other';
    }
    Junk.cat = 'all';
    // ล็อกตามระดับ: ไอเทมระดับที่ติ๊กไว้จะไม่ถูกทิ้งแม้ตั้งเป็นขยะ (ระดับไม่รู้ = ล็อกไว้ก่อน)
    const rarityLocked = (r) => { const L = State.opt.junkLock || {}; return r ? L[r] !== undefined ? !!L[r] : r !== 'common' && r !== 'uncommon' : true; };

    // อ่านไอเทมในกระเป๋าที่เปิดอยู่ → จำไว้ต่อโปรไฟล์ (ไม่ต้องรอฟาร์มให้ดรอปก่อนถึงจะขึ้นในรายการ)
    function seenGet() {
        if (!Junk.seen) Junk.seen = Store.getJSON('at_inv_seen', {}) || {};
        return Junk.seen;
    }
    function invScan() {
        const slots = invSlots();
        if (!slots.length || !Info.itemById) return { found: 0, unknown: 0, filled: 0, changed: false };
        const seen = seenGet();
        Junk.ambigIdx = [];
        let found = 0, unknown = 0, filled = 0, changed = false;
        for (const el of slots) {
            if (!el.classList.contains('filled')) continue;
            filled++;
            const src = slotIcon(el);
            if (!src) { unknown++; continue; }
            const cs = iconCands(src);
            if (cs.length > 1) { (Junk.ambigIdx || (Junk.ambigIdx = [])).push(slots.indexOf(el)); continue; }
            const id = cs.length === 1 ? cs[0] : 0;
            const it = id && Info.itemById.get(id);
            if (!it) { unknown++; continue; }
            found++;
            if (!seen[id]) { seen[id] = it.name; changed = true; }
        }
        Junk.unk = unknown;
        if (changed) Store.set('at_inv_seen', JSON.stringify(seen));
        return { found, unknown, filled, changed };
    }
    function junkInvWatch(now) {
        if (now - (Junk.watchAt || 0) < 1500 || !document.getElementById('at-junk-list') || !isVisible(SELECTORS.weight) || !Info.data) return;
        Junk.watchAt = now;
        const sig = invSlots().map(slotIcon).join('|');
        if (sig === Junk.invSig) return;
        Junk.invSig = sig;
        invScan();
        renderJunkList();
    }
    async function junkScanNow() {
        if (Junk.running || InvLock.owner) { showToast('กำลังใช้กระเป๋าอยู่ ลองใหม่อีกครั้ง', 'warn'); return; }
        await infoLoad().catch(() => {});
        InvLock.owner = 'scan';
        try {
            let opened = false;
            if (!isVisible(SELECTORS.weight)) {
                pressKey('i', 'KeyI', 73);
                opened = true;
                if (!(await waitFor(() => isVisible(SELECTORS.weight), 2500))) { showToast('เปิดกระเป๋าไม่สำเร็จ', 'warn'); return; }
            }
            await sleep(700);
            const r = invScan();
            // ไอเทมที่ใช้รูปซ้ำกัน (เช่น เจม): กดเลือกทีละช่องอ่านชื่อจริงจากกรอบรายละเอียด
            const seen = seenGet();
            let probed = 0;
            const amb = Junk.ambigIdx || [];
            r.unknown += Math.max(0, amb.length - 80);      // เกินเพดานที่อ่านต่อรอบ
            for (const ix of amb.slice(0, 80)) {
                if (!isVisible(SELECTORS.weight)) break;
                const el0 = invSlots()[ix];
                if (!el0) continue;
                el0.click();
                await sleep(320);
                const selOk = () => { const e = invSlots()[ix]; return !!e && e.classList.contains('selected'); };
                await waitFor(() => selOk() && document.querySelector('.inventory .inv-detail-name'), 1200);
                const nm = norm((document.querySelector('.inventory .inv-detail-name') || {}).textContent);
                const wi = selOk() && nm ? wikiByNameLC(nm) : null;
                if (wi) { r.found++; if (!seen[wi.id]) { seen[wi.id] = wi.name; probed++; } } else r.unknown++;
            }
            if (probed) Store.set('at_inv_seen', JSON.stringify(seen));
            if (amb.length) {      // เลิกเลือกไอเทมที่กดค้างไว้ (กดช่องว่างช่องแรก) ไม่ให้กรอบรายละเอียดค้างที่ไอเทมสุดท้าย
                const empty = invSlots().find((e) => !e.classList.contains('filled'));
                if (empty) { empty.click(); await sleep(250); }
            }
            renderJunkList();
            Junk.unk = r.unknown;
            showToast(`สแกนกระเป๋า: อ่านได้ ${r.found}/${r.filled} ช่อง${r.unknown ? ` · ไม่รู้จัก ${r.unknown} ช่อง` : ''}`, r.unknown ? 'warn' : 'info');
            Log.info('JUNK', `สแกนกระเป๋า: อ่านได้ ${r.found}/${r.filled} ช่อง · ไม่รู้จัก ${r.unknown} ช่อง`);
            // สแกนเสร็จปิดกระเป๋าเสมอ (ปุ่ม I ก่อน ถ้ายังไม่ปิดค่อยกดปุ่มปิดของหน้าต่าง)
            await sleep(500);
            await dismissConfirm();
            if (isVisible(SELECTORS.weight)) { pressKey('i', 'KeyI', 73); await sleep(500); }
            if (isVisible(SELECTORS.weight)) { const c = document.querySelector('.inventory .inv-close'); if (c) c.click(); }
        } finally { InvLock.owner = ''; }
    }

    // ===== ทูลทิปเมื่อเอาเมาส์ชี้ (รายการในหน้าทิ้งขยะ / Wiki ที่ชื่อยาวถูกตัด) =====
    let tipEl = null;
    document.addEventListener('mousemove', () => { if (tipEl && tipEl.style.display === 'block' && tipEl._el && !tipEl._el.isConnected) tipHide(); }, true);      // แถวถูกวาดใหม่ระหว่างชี้ (Profit อัปเดตบ่อย) → ซ่อนกล่องค้าง
    function tipHide() { if (tipEl) tipEl.style.display = 'none'; }
    function tipShow(e, build) {
        if (!tipEl || !tipEl.isConnected) { tipEl = h('div', 'at-tip'); document.body.appendChild(tipEl); }
        if (tipEl.style.display !== 'block' || tipEl._for !== build) {
            tipEl.textContent = '';
            build(tipEl);
            tipEl._for = build;
        }
        tipEl.style.display = 'block';
        const pad = 14, w = tipEl.offsetWidth, hgt = tipEl.offsetHeight;
        let x = e.clientX + pad, y = e.clientY + pad;
        if (x + w > window.innerWidth - 6) x = Math.max(6, e.clientX - w - pad);
        if (y + hgt > window.innerHeight - 6) y = Math.max(6, window.innerHeight - hgt - 6);
        tipEl.style.left = x + 'px';
        tipEl.style.top = y + 'px';
    }
    function attachTip(el, build) {
        el.addEventListener('mouseenter', (e) => { tipShow(e, build); tipEl._el = el; });
        el.addEventListener('mousemove', (e) => { tipShow(e, build); tipEl._el = el; });
        el.addEventListener('mouseleave', tipHide);
        el.addEventListener('click', tipHide);
    }
    function itemTipBuilder(it) {
        return (box) => {
            const r = rarityOf(it.rarity);
            const t = h('div', 'at-tip-name', it.name);
            t.style.color = r.color;
            box.appendChild(t);
            const meta = [`#${it.id}`, (typeof ITEM_TYPE_TH !== 'undefined' && ITEM_TYPE_TH[it.type]) || it.type, it.equipmentType && it.equipmentType !== 'None' ? it.equipmentType : '', r.label].filter(Boolean).join(' · ');
            box.appendChild(h('div', 'at-tip-sub', meta));
            const cat = (JUNK_CATS.find((c) => c[0] === itemCat(it)) || [0, ''])[1];
            box.appendChild(h('div', 'at-tip-row', `หมวด ${cat}${it.weight !== undefined ? ` · ⚖️ ${it.weight}` : ''}${it.sellPrice ? ` · 🪙 ${fmt(it.sellPrice)} z` : ''}`));
            const cur = (junkGet()[it.id] || {}).c || '';
            const lab = JUNK_CLS.find((c) => c[0] === cur);
            box.appendChild(h('div', 'at-tip-row', itemCat(it) === 'material' ? '🔒 วัตถุดิบ — ไม่ทิ้งเด็ดขาด' : lab ? `ตั้งไว้: ${lab[1]} ${lab[2]}` : 'ยังไม่ตั้ง (ไม่ทิ้ง)'));
            if (itemCat(it) !== 'material' && rarityLocked(it.rarity)) box.appendChild(h('div', 'at-tip-row', '🔒 ระดับนี้ถูกล็อกไว้ — ไม่ถูกทิ้ง'));
            const dm = dropIndex().get(it.id);
            if (dm && dm.length) {
                box.appendChild(h('div', 'at-tip-hd', '👹 ดรอปจาก'));
                for (const m of dm.slice(0, 6)) {
                    const ln = h('div', 'at-tip-line');
                    ln.appendChild(infoMonIcon(m, 'ap-icon sm'));
                    ln.appendChild(h('span', 'at-tip-ln', m.name));
                    const d = (m.drops || []).find((x) => x.itemId === it.id);
                    ln.appendChild(h('span', 'at-tip-rt', `Lv.${m.level}${d ? ` · ${fmtChance(d.chance)}` : ''}`));
                    box.appendChild(ln);
                }
                if (dm.length > 6) box.appendChild(h('div', 'at-tip-sub', `… และอีก ${dm.length - 6} ตัว`));
            }
        };
    }
    function dropIndex() {
        if (Info.dropIdx && Info.dropIdxSrc === Info.data) return Info.dropIdx;
        const mp = new Map();
        for (const m of (Info.data && Info.data.monsters) || []) for (const d of m.drops || []) { if (!mp.has(d.itemId)) mp.set(d.itemId, []); mp.get(d.itemId).push(m); }
        for (const v of mp.values()) v.sort((a, b) => (a.level || 0) - (b.level || 0));
        Info.dropIdx = mp; Info.dropIdxSrc = Info.data;
        return mp;
    }
    // ทูลทิปจากชื่อ (ใช้กับแถวใน Profit ที่รู้แค่ชื่อ) — ถ้ายังไม่โหลด wiki จะโหลดแล้วอัปเดตให้เอง
    function nameTipBuilder(kind, name) {
        const self = (box) => {
            if (!Info.data) {
                box.appendChild(h('div', 'at-tip-name', name));
                box.appendChild(h('div', 'at-tip-row', '⏳ กำลังโหลดข้อมูลจาก wiki…'));
                infoLoad().then(() => { if (tipEl && tipEl._for === self && tipEl.style.display === 'block') { tipEl.textContent = ''; self(tipEl); } }, () => {});
                return;
            }
            const rec = kind === 'monster' ? Info.byMonName.get(norm(name)) : Info.byItemName.get(norm(name));
            if (!rec) { box.appendChild(h('div', 'at-tip-name', name)); box.appendChild(h('div', 'at-tip-row', 'ไม่พบในข้อมูล wiki')); return; }
            (kind === 'monster' ? monTipBuilder(rec) : itemTipBuilder(rec))(box);
        };
        return self;
    }
    function monTipBuilder(m) {
        return (box) => {
            box.appendChild(h('div', 'at-tip-name', `${monEmoji(m)} ${m.name}`));
            box.appendChild(h('div', 'at-tip-sub', `#${m.id} · Lv.${m.level}`));
            box.appendChild(h('div', 'at-tip-row', `❤️ ${fmt(m.hp || 0)} · ✨ ${fmt(m.exp || 0)} · 🎓 ${fmt(m.jobExp || 0)} · ${elementText(m.element, m.elementLevel)}`));
            const maps = [...new Set((m.spawns || []).map((x) => x.map).filter(Boolean))];
            if (maps.length) box.appendChild(h('div', 'at-tip-row', `📍 ${maps.slice(0, 4).join(', ')}${maps.length > 4 ? ` +${maps.length - 4}` : ''}`));
            const top = [...(m.drops || [])].sort((a, b) => b.chance - a.chance);
            if (top.length) {
                box.appendChild(h('div', 'at-tip-hd', '🎁 ของที่ดรอป'));
                for (const d of top.slice(0, 8)) {
                    const x = Info.itemById.get(d.itemId);
                    const ln = h('div', 'at-tip-line');
                    ln.appendChild(infoItemIcon(d.itemId, x && x.name, 'ap-icon sm'));
                    const nmEl = h('span', 'at-tip-ln', x ? x.name : '#' + d.itemId);
                    if (x) nmEl.style.color = rarityOf(x.rarity).color;
                    ln.appendChild(nmEl);
                    ln.appendChild(h('span', 'at-tip-rt', fmtChance(d.chance)));
                    box.appendChild(ln);
                }
                if (top.length > 8) box.appendChild(h('div', 'at-tip-sub', `… และอีก ${top.length - 8} ชิ้น`));
            }
        };
    }

    function wikiByNameLC(name) {
        if (!Info.data) return null;
        if (!Info.byNameLC || Info.byNameLCsrc !== Info.data) { Info.byNameLCsrc = Info.data; Info.byNameLC = new Map((Info.data.items || []).map((x) => [String(x.name).toLowerCase(), x])); }
        const k = String(name).toLowerCase().trim();
        // ชื่อในกรอบรายละเอียดของอุปกรณ์มีส่วนต่อท้าย เช่น "Earring [1]" (จำนวนช่องการ์ด) หรือ "+3 " นำหน้า → ตัดออกก่อนเทียบ
        const base = k.replace(/\s*\[\d+\]\s*$/, '').replace(/^\+\d+\s+/, '').trim();
        return Info.byNameLC.get(k) || Info.byNameLC.get(base) || null;
    }

    function junkRows(q) {
        const map = junkGet();
        const rows = new Map();
        const add = (it, fallbackName) => {
            const id = it ? it.id : 0;
            if (!id || rows.has(id)) return;
            const cat = itemCat(it);
            if (cat === 'material') return;      // วัตถุดิบ: ไม่ทิ้งเด็ดขาด ไม่มีให้เลือก
            rows.set(id, { id, name: it.name || fallbackName, rarity: it.rarity, cat, cls: map[id] ? map[id].c : '' });
        };
        for (const [id, e] of Object.entries(map)) { const it = Info.itemById && Info.itemById.get(+id); if (it) add(it, e.n); }
        if (Info.data) {
            if (q) { for (const it of Info.data.items || []) if (String(it.name).toLowerCase().includes(q)) add(it); }
            else {
                for (const lg of Object.values(Profit.all.maps)) {
                    for (const e of [...Object.values(lg.items), ...Object.values(lg.drops)]) { const it = Info.byItemName.get(norm(e.name)); if (it) add(it); }
                }
                if (isVisible(SELECTORS.weight)) invScan();
                for (const id of Object.keys(seenGet())) { const it = Info.itemById.get(+id); if (it) add(it); }
            }
        }
        let arr = [...rows.values()];
        if (q) arr = arr.filter((r) => String(r.name).toLowerCase().includes(q));
        const counts = { all: arr.length };
        for (const r of arr) counts[r.cat] = (counts[r.cat] || 0) + 1;
        if (Junk.cat !== 'all') arr = arr.filter((r) => r.cat === Junk.cat);
        const ord = { junk: 0, keep: 1, never: 2, '': 3 };
        arr.sort((a, b) => ord[a.cls] - ord[b.cls] || String(a.name).localeCompare(String(b.name)));
        return { rows: arr.slice(0, 250), counts };
    }

    function renderJunkList() {
        tipHide();
        const box = document.getElementById('at-junk-list');
        if (!box) return;
        const note = document.getElementById('at-junk-note');
        if (!Info.data) {
            box.textContent = '';
            box.appendChild(h('div', 'ap-empty', Info.err ? `⚠️ โหลด wiki ไม่ได้ (${Info.err})` : '⏳ กำลังโหลดข้อมูลไอเทมจาก wiki…'));
            if (!Info.loading && !Info.err) infoLoad().then(renderJunkList, renderJunkList);
            else if (Info.loading) Info.loading.then(renderJunkList, renderJunkList);
            return;
        }
        const { rows, counts } = junkRows(Junk.q);
        const cats = document.getElementById('at-junk-cats');
        if (cats) {
            cats.textContent = '';
            const mk = (id, label, n) => {
                const b = h('button', 'aj-cat' + (Junk.cat === id ? ' on' : '') + (n === 0 && id !== 'all' ? ' zero' : ''), `${label} ${n}`);
                b.type = 'button';
                b.addEventListener('click', (e) => { e.stopPropagation(); Junk.cat = id; renderJunkList(); });
                cats.appendChild(b);
            };
            mk('all', 'ทั้งหมด', counts.all || 0);
            for (const [id, label] of JUNK_CATS) mk(id, label, id === 'material' ? 0 : counts[id] || 0);
        }
        box.textContent = '';
        if (Junk.cat === 'material') { box.appendChild(h('div', 'ap-empty', '🔒 วัตถุดิบไม่ถูกทิ้งเด็ดขาด — ไม่มีให้เลือก')); if (note) note.textContent = ''; return; }
        if (!rows.length) box.appendChild(h('div', 'ap-empty', Junk.q ? 'ไม่พบไอเทมที่ค้นหา' : 'ยังไม่มีไอเทมให้จัดกลุ่ม — พิมพ์ชื่อไอเทมในช่องค้นหา หรือฟาร์มให้มีของดรอปก่อน'));
        for (const r of rows) {
            const row = h('div', 'aj-row');
            { const wi = Info.itemById && Info.itemById.get(r.id); if (wi) attachTip(row, itemTipBuilder(wi)); }
            const src = itemIconSrc(r.id);
            if (src) { const im = h('img', 'aj-icon'); im.src = src; im.alt = ''; im.draggable = false; row.appendChild(im); } else row.appendChild(h('span', 'aj-icon aj-ph', String(r.name).slice(0, 1)));
            const nm = h('span', 'aj-name', r.name);
            if (r.rarity) nm.style.color = rarityOf(r.rarity).color;
            row.appendChild(nm);
            if (rarityLocked(r.rarity)) { const lk = h('span', 'aj-lk', '🔒ระดับ'); lk.title = 'ระดับนี้ถูกล็อกไว้ — ไม่ถูกทิ้ง'; row.appendChild(lk); }
            const bt = h('div', 'aj-bts');
            for (const [c, em, lab] of JUNK_CLS) {
                const b = h('button', 'aj-b' + (r.cls === c ? ' on ' + c : ''), em);
                b.type = 'button';
                b.title = lab;
                b.addEventListener('click', (e) => {
                    e.stopPropagation();
                    junkSet(r.id, r.name, r.cls === c ? '' : c);
                    renderJunkList();
                });
                bt.appendChild(b);
            }
            row.appendChild(bt);
            box.appendChild(row);
        }
        if (note) {
            const m = junkGet();
            const n = (c) => Object.values(m).filter((x) => x.c === c).length;
            note.textContent = `ตั้งไว้แล้ว: 🗑️ ${n('junk')} · 📦 ${n('keep')} · 🔒 ${n('never')} · ไอเทมที่ไม่ได้ตั้ง = ไม่ทิ้ง (กดปุ่มที่เลือกซ้ำเพื่อยกเลิก)${Junk.unk ? ` · ⚠️ ในกระเป๋ามี ${Junk.unk} ช่องที่จับคู่ไอคอนกับ wiki ไม่ได้ (ไอเทมนั้นจะไม่ถูกทิ้ง) — ค้นหาชื่อเองได้` : ''}`;
        }
    }

    // กดที่ตัวเลขเพื่อพิมพ์ค่าเองได้ (เช่น ทิ้งต่อรอบเกิน 200)
    function bindEditableNumber(cfg, k, lo, hi) {
        const b = cfg.querySelector(`[data-optv="${k}"]`);
        const sl = cfg.querySelector(`input[type=range][data-opt="${k}"]`);
        if (!b || !sl) return;
        b.style.cursor = 'text';
        b.style.textDecoration = 'underline dotted';
        b.title = 'กดเพื่อพิมพ์ตัวเลขเอง';
        b.addEventListener('click', (e) => {
            e.stopPropagation();
            if (b.querySelector('input')) return;
            const unit = sl.dataset.unit || '';
            const inp = document.createElement('input');
            inp.type = 'number';
            inp.min = lo;
            inp.max = hi;
            inp.value = State.opt[k];
            inp.style.cssText = 'width:64px;background:rgba(255,255,255,.08);color:inherit;border:1px solid var(--at-acc);border-radius:6px;padding:1px 4px;font:inherit';
            b.textContent = '';
            b.appendChild(inp);
            inp.focus();
            inp.select();
            const commit = () => {
                if (!b.contains(inp)) return;
                const v = Math.min(hi, Math.max(lo, Math.round(Number(inp.value)) || State.opt[k]));
                State.opt[k] = v;
                savePrefs();
                sl.value = v;
                b.textContent = `${v} ${unit}`;
            };
            inp.addEventListener('keydown', (ev) => { ev.stopPropagation(); if (ev.key === 'Enter') commit(); if (ev.key === 'Escape') { b.textContent = `${State.opt[k]} ${unit}`; } });
            inp.addEventListener('keyup', (ev) => ev.stopPropagation());
            inp.addEventListener('click', (ev) => ev.stopPropagation());
            inp.addEventListener('blur', commit);
        });
    }

    function bindJunkUI(cfg) {
        const shb = cfg.querySelector('#at-junk-share');
        if (shb) {
            shb.addEventListener('click', (e) => { e.stopPropagation(); junkShareToggle(!junkShared()); });
            shb.classList.toggle('on', junkShared());
            shb.textContent = junkShared() ? '🔗 ใช้ค่าร่วมกันทุกโปรไฟล์: เปิด' : '🔗 ใช้ค่าร่วมกันทุกโปรไฟล์: ปิด';
        }
        bindEditableNumber(cfg, 'junkAt', 1, 99);
        bindEditableNumber(cfg, 'junkTo', 1, 98);
        bindEditableNumber(cfg, 'junkMax', 1, 999);
        const rb = cfg.querySelector('#at-junk-rar');
        if (rb) {
            for (const k of ['common', 'uncommon', 'rare', 'epic', 'legendary']) {
                const lab = document.createElement('label');
                lab.className = 'aj-rar';
                const cb = document.createElement('input');
                cb.type = 'checkbox';
                cb.checked = rarityLocked(k);
                cb.addEventListener('change', () => {
                    State.opt.junkLock = Object.assign({}, State.opt.junkLock || {}, { [k]: cb.checked });
                    savePrefs();
                    renderJunkList();
                });
                const sp = document.createElement('span');
                sp.textContent = ' ' + rarityOf(k).label;
                sp.style.color = rarityOf(k).color;
                lab.appendChild(cb);
                lab.appendChild(sp);
                rb.appendChild(lab);
            }
        }
        const q = cfg.querySelector('#at-junk-q');
        if (q) {
            q.addEventListener('keydown', (e) => e.stopPropagation());
            q.addEventListener('keyup', (e) => e.stopPropagation());
            q.addEventListener('input', () => { Junk.q = q.value.trim().toLowerCase(); renderJunkList(); });
        }
        const wk = cfg.querySelector('#at-junk-wiki');
        if (wk) wk.addEventListener('click', (e) => { e.stopPropagation(); openWiki('item'); });
        const rl = cfg.querySelector('#at-junk-real');
        if (rl) rl.addEventListener('click', (e) => {
            e.stopPropagation();
            if (Junk.running) { showToast('กำลังทำงานอยู่', 'warn'); return; }
            if (!rl.dataset.arm) {
                rl.dataset.arm = '1';
                const old = rl.textContent;
                rl.textContent = '⚠️ กดอีกครั้งเพื่อทิ้งจริงตอนนี้';
                setTimeout(() => { rl.dataset.arm = ''; rl.textContent = old; }, 4000);
                return;
            }
            rl.dataset.arm = '';
            rl.textContent = '💥 ทิ้งทันที (ทิ้งจริง ไม่รอเกณฑ์น้ำหนัก · ใช้ทดสอบ)';
            junkRun(true, true);
        });
        const scb = cfg.querySelector('#at-junk-scan');
        if (scb) scb.addEventListener('click', (e) => { e.stopPropagation(); junkScanNow(); });
        const now = cfg.querySelector('#at-junk-now');
        if (now) now.addEventListener('click', (e) => {
            e.stopPropagation();
            if (Junk.running) { showToast('กำลังทำงานอยู่', 'warn'); return; }
            junkRun(true);
        });
    }

    // ---------------------------------------------------------------
    // Wiki ของเกม (หน้าต่างกลางจอ): ไอเทม / มอนสเตอร์ ดึงจาก /wiki-data · ตั้ง 🗑️📦🔒 ของระบบทิ้งขยะอัตโนมัติได้จากที่นี่ (ซิงค์กับหน้าทิ้งขยะ/หน้าข้อมูลใน Profit)
    // ---------------------------------------------------------------
    const Wiki = { el: null, tab: 'item', q: '', cat: 'all', rar: 'all', st: 'all', limit: 100, refs: {} };
    const WIKI_ST = [['all', 'ทุกสถานะ'], ['junk', '🗑️ ขยะ'], ['keep', '📦 เก็บทำของ'], ['never', '🔒 ห้ามทิ้ง'], ['none', 'ยังไม่ตั้ง'], ['wish', '⭐ ตามหา']];

    function starButton(it) {
        const on = wishHas(it.name);
        const b = h('button', 'aw-star' + (on ? ' on' : ''), on ? '⭐' : '☆');
        b.type = 'button';
        b.title = on ? 'เอาออกจากรายการที่ตามหา' : 'ตามหาไอเทมนี้ (แจ้งเตือนเมื่อดรอป)';
        b.addEventListener('click', (e) => { e.stopPropagation(); wishToggle(it.name); });
        return b;
    }

    // ปุ่ม 🗑️📦🔒 (ใช้ทั้งใน Wiki และหน้าข้อมูลไอเทม) — วัตถุดิบไม่มีตัวเลือก
    function junkButtons(it) {
        if (itemCat(it) === 'material') { const s = h('span', 'aw-mat', '🔒 วัตถุดิบ — ไม่ทิ้ง'); return s; }
        const cur = (junkGet()[it.id] || {}).c || '';
        const bt = h('div', 'aj-bts');
        for (const [c, em, lab] of JUNK_CLS) {
            const b = h('button', 'aj-b' + (cur === c ? ' on ' + c : ''), em);
            b.type = 'button';
            b.title = lab;
            b.addEventListener('click', (e) => { e.stopPropagation(); junkSet(it.id, it.name, cur === c ? '' : c); junkChanged(); });
            bt.appendChild(b);
        }
        return bt;
    }

    // ตั้งค่าขยะเปลี่ยน -> อัปเดตทุกหน้าที่แสดงอยู่ให้ตรงกัน
    function junkChanged() {
        Profit.rev++;
        if (Wiki.el) renderWikiList();
        renderJunkList();
        if (Info.el) {
            const sb = Info.el.querySelector('.ai2-body');
            const st = sb ? sb.scrollTop : 0;
            showInfo();
            const nb = Info.el && Info.el.querySelector('.ai2-body');
            if (nb) nb.scrollTop = st;
        }
    }

    function closeWiki() {
        if (Wiki.el) { Wiki.el.remove(); Wiki.el = null; }
        document.removeEventListener('keydown', wikiKey, true);
        const b = document.getElementById('at-btn-wiki');
        if (b) b.classList.remove('active');
    }
    function wikiKey(e) { if (e.key === 'Escape' && !Info.el) { e.stopPropagation(); closeWiki(); } }

    function openWiki(tab) {
        if (tab) Wiki.tab = tab;
        if (!Wiki.el) {
            const bd = document.createElement('div');
            bd.id = 'aetheria-wiki';
            bd.addEventListener('click', (e) => { if (e.target === bd) closeWiki(); });
            const card = h('div', 'aw-card');
            const bar = h('div', 'ai2-bar');
            bar.appendChild(h('span', 'ai2-src', '📖 Wiki ของเกม · ข้อมูลจาก wiki · ตั้งค่าไอเทมที่ไม่ทิ้งได้ที่นี่'));
            const x = h('button', 'ai2-x', '✕');
            x.type = 'button';
            x.addEventListener('click', closeWiki);
            bar.appendChild(x);
            card.appendChild(bar);
            const tabs = h('div', 'aw-tabs');
            for (const [k, lab] of [['item', '🎒 ไอเทม'], ['monster', '👹 มอนสเตอร์'], ['map', '🗺️ แมพ']]) {
                const b = h('button', 'aw-tab', lab);
                b.type = 'button';
                b.dataset.tab = k;
                b.addEventListener('click', () => { Wiki.tab = k; Wiki.limit = 100; renderWiki(); });
                tabs.appendChild(b);
            }
            const inp = h('input', 'at-input aw-q');
            inp.type = 'text';
            inp.placeholder = '🔍 ค้นหาชื่อ…';
            inp.addEventListener('keydown', (e) => e.stopPropagation());
            inp.addEventListener('keyup', (e) => e.stopPropagation());
            inp.addEventListener('input', () => { Wiki.q = inp.value.trim().toLowerCase(); Wiki.limit = 100; renderWikiList(); });
            tabs.appendChild(inp);
            card.appendChild(tabs);
            const filt = h('div', 'aw-filt');
            const list = h('div', 'aw-list');
            card.appendChild(filt);
            card.appendChild(list);
            bd.appendChild(card);
            document.body.appendChild(bd);
            Wiki.el = bd;
            Wiki.refs = { inp, filt, list, tabs };
            document.addEventListener('keydown', wikiKey, true);
            ensureMonsterManifest();
            const wb = document.getElementById('at-btn-wiki');
            if (wb) wb.classList.add('active');
        }
        renderWiki();
        if (!Info.data && !Info.loading && !Info.err) infoLoad().then(renderWiki, renderWiki);
        else if (Info.loading) Info.loading.then(renderWiki, renderWiki);
    }

    function renderWiki() {
        if (!Wiki.el) return;
        const r = Wiki.refs;
        r.tabs.querySelectorAll('.aw-tab').forEach((b) => b.classList.toggle('on', b.dataset.tab === Wiki.tab));
        if (r.inp.value !== Wiki.q && document.activeElement !== r.inp) r.inp.value = Wiki.q;
        renderWikiList();
    }

    function pill(parent, label, on, onClick, zero) {
        const b = h('button', 'aj-cat' + (on ? ' on' : '') + (zero ? ' zero' : ''), label);
        b.type = 'button';
        b.addEventListener('click', (e) => { e.stopPropagation(); onClick(); });
        parent.appendChild(b);
    }

    function renderWikiList() {
        if (!Wiki.el) return;
        tipHide();
        const { filt, list } = Wiki.refs;
        filt.textContent = '';
        const top = list.scrollTop;
        list.textContent = '';
        if (!Info.data) {
            list.appendChild(h('div', 'ap-empty', Info.err ? `⚠️ โหลดข้อมูล wiki ไม่ได้ (${Info.err})` : '⏳ กำลังโหลดข้อมูลจาก wiki ของเกม…'));
            return;
        }
        if (Wiki.tab === 'map') {
            let arr = [...mapIndex().values()];
            if (Wiki.q) arr = arr.filter((e) => e.name.toLowerCase().includes(Wiki.q) || [...e.mons.values()].some((x) => String(x.m.name).toLowerCase().includes(Wiki.q)));
            arr.sort((a, b) => String(a.name).localeCompare(String(b.name)));
            filt.appendChild(h('span', 'ac-l', `พบ ${fmt(arr.length)} แมพ · กดเพื่อดูมอนสเตอร์ในแมพ · ค้นหาชื่อมอนก็ได้`));
            for (const e of arr.slice(0, Wiki.limit)) {
                const row = h('div', 'aw-row c');
                row.appendChild(h('span', 'ai2-mapic', '🗺️'));
                const nm = h('button', 'ai2-link aw-name', e.name);
                nm.type = 'button';
                row.addEventListener('click', () => openInfo('map', e.name));
                row.appendChild(nm);
                const lv = [...e.mons.values()].map((x) => x.m.level || 0);
                row.appendChild(h('span', 'ai2-sub', `${e.mons.size} ชนิด · Lv.${Math.min(...lv)}–${Math.max(...lv)}`));
                list.appendChild(row);
            }
            if (arr.length > Wiki.limit) { const more = h('button', 'at-btn-ghost', `แสดงเพิ่ม (${fmt(arr.length - Wiki.limit)})`); more.type = 'button'; more.addEventListener('click', () => { Wiki.limit += 150; renderWikiList(); }); list.appendChild(more); }
            list.scrollTop = top;
            return;
        }
        if (Wiki.tab === 'monster') {
            let arr = Info.data.monsters || [];
            if (Wiki.q) arr = arr.filter((m) => String(m.name).toLowerCase().includes(Wiki.q));
            arr = [...arr].sort((a, b) => (a.level || 0) - (b.level || 0));
            filt.appendChild(h('span', 'ac-l', `พบ ${fmt(arr.length)} ตัว · กดชื่อเพื่อดูข้อมูล/ของดรอป/แมพ`));
            for (const m of arr.slice(0, Wiki.limit)) {
                const row = h('div', 'aw-row');
                attachTip(row, monTipBuilder(m));
                row.appendChild(infoMonIcon(m, 'ap-icon sm'));
                const nm = h('button', 'ai2-link aw-name', `${monEmoji(m)} ${m.name}`);
                nm.type = 'button';
                nm.addEventListener('click', () => openInfo('monster', m.id));
                row.classList.add('c');
                row.addEventListener('click', (e) => { if (e.target !== nm) openInfo('monster', m.id); });
                row.appendChild(nm);
                row.appendChild(h('span', 'ai2-sub', `Lv.${m.level} · ${elementText(m.element, m.elementLevel)}`));
                list.appendChild(row);
            }
            if (arr.length > Wiki.limit) { const more = h('button', 'at-btn-ghost', `แสดงเพิ่ม (${fmt(arr.length - Wiki.limit)})`); more.type = 'button'; more.addEventListener('click', () => { Wiki.limit += 150; renderWikiList(); }); list.appendChild(more); }
            list.scrollTop = top;
            return;
        }
        // ----- ไอเทม -----
        const map = junkGet();
        const base = [];
        for (const it of Info.data.items || []) {
            if (Wiki.q && !String(it.name).toLowerCase().includes(Wiki.q)) continue;
            if (Wiki.rar !== 'all' && it.rarity !== Wiki.rar) continue;
            const cls = map[it.id] ? map[it.id].c : '';
            if (Wiki.st === 'wish') { if (!wishHas(it.name)) continue; } else if (Wiki.st === 'none' ? cls : Wiki.st !== 'all' && cls !== Wiki.st) continue;
            base.push({ it, cat: itemCat(it), cls });
        }
        const counts = { all: base.length };
        for (const b of base) counts[b.cat] = (counts[b.cat] || 0) + 1;
        const rows = Wiki.cat === 'all' ? base : base.filter((b) => b.cat === Wiki.cat);
        const g1 = h('div', 'aj-cats'), g2 = h('div', 'aj-cats'), g3 = h('div', 'aj-cats');
        pill(g1, `ทั้งหมด ${counts.all}`, Wiki.cat === 'all', () => { Wiki.cat = 'all'; Wiki.limit = 100; renderWikiList(); });
        for (const [id, label] of JUNK_CATS) pill(g1, `${label} ${counts[id] || 0}`, Wiki.cat === id, () => { Wiki.cat = id; Wiki.limit = 100; renderWikiList(); }, !counts[id]);
        pill(g2, 'ทุกระดับ', Wiki.rar === 'all', () => { Wiki.rar = 'all'; Wiki.limit = 100; renderWikiList(); });
        for (const k of ['common', 'uncommon', 'rare', 'epic', 'legendary']) {
            pill(g2, rarityOf(k).label, Wiki.rar === k, () => { Wiki.rar = k; Wiki.limit = 100; renderWikiList(); });
            g2.lastChild.style.color = rarityOf(k).color;
        }
        for (const [k, lab] of WIKI_ST) pill(g3, lab, Wiki.st === k, () => { Wiki.st = k; Wiki.limit = 100; renderWikiList(); });
        filt.appendChild(g1); filt.appendChild(g2); filt.appendChild(g3);
        filt.appendChild(h('span', 'ac-l', `พบ ${fmt(rows.length)} ชิ้น · 🗑️ ขยะ (ทิ้งอัตโนมัติ) · 📦 เก็บทำของ · 🔒 ห้ามทิ้ง · วัตถุดิบไม่ทิ้งเด็ดขาด · ระดับที่ล็อกไว้ในหน้าทิ้งขยะจะไม่ถูกทิ้งด้วย`));
        rows.sort((a, b) => rarityOf(b.it.rarity).rank - rarityOf(a.it.rarity).rank || String(a.it.name).localeCompare(String(b.it.name)));
        for (const { it, cat } of rows.slice(0, Wiki.limit)) {
            const row = h('div', 'aw-row');
            attachTip(row, itemTipBuilder(it));
            row.appendChild(infoItemIcon(it.id, it.name, 'ap-icon sm'));
            const nm = h('button', 'ai2-link aw-name', it.name);
            nm.type = 'button';
            nm.style.color = rarityOf(it.rarity).color;
            nm.addEventListener('click', () => openInfo('item', it.id));
            row.classList.add('c');
            row.addEventListener('click', (e) => { if (e.target !== nm && !e.target.closest('.aj-bts') && !e.target.closest('.aw-star')) openInfo('item', it.id); });
            row.appendChild(nm);
            if (cat !== 'material' && rarityLocked(it.rarity)) { const lk = h('span', 'aj-lk', '🔒ระดับ'); lk.title = 'ระดับนี้ถูกล็อกไว้ในหน้าทิ้งขยะ'; row.appendChild(lk); }
            row.appendChild(h('span', 'ai2-sub', `${(JUNK_CATS.find((c) => c[0] === cat) || [0, ''])[1]}${it.sellPrice ? ` · ${fmt(it.sellPrice)} z` : ''}`));
            row.appendChild(starButton(it));
            row.appendChild(junkButtons(it));
            list.appendChild(row);
        }
        if (rows.length > Wiki.limit) { const more = h('button', 'at-btn-ghost', `แสดงเพิ่ม (${fmt(rows.length - Wiki.limit)})`); more.type = 'button'; more.addEventListener('click', () => { Wiki.limit += 150; renderWikiList(); }); list.appendChild(more); }
        list.scrollTop = top;
    }

    // ---------------------------------------------------------------
    // Main loop
    // ---------------------------------------------------------------
    function tick() {
        try {
            const now = Date.now();
            refreshFrame(now);

            if (!uiRefs.panel || !uiRefs.panel.isConnected) buildPanel();
            if (!pRefs.panel || !pRefs.panel.isConnected) buildProfitPanel();
            if (!lRefs.panel || !lRefs.panel.isConnected) buildLogsWindow();
            if (!sRefs.panel || !sRefs.panel.isConnected) buildStatsWindow();
            ensureObservers(false);

            if (Frame.invOpen) State.lastInvSeenAt = now;

            deathWatch();
            profitTick(now);
            townTick(now);
            bossTick(now);
            liveTick(now);
            watchTick(now);
            junkTick(now);

            if (State.isGameReady && now - State.lastChatAt >= CONFIG.CHAT_POLL_MS) {
                State.lastChatAt = now;
                pollChat();
            }

            if (State.isGameReady && now - State.lastPingAt >= CONFIG.PING_INTERVAL_MS) {
                State.lastPingAt = now;
                pingOnce();
            }

            if (!document.hidden) {
                renderUI();
                renderTown();
                renderProfit();
                renderStatsWin();
                positionProfitPanel();
                renderLogs(false);
                renderIdle();
                renderBoss(now);
                renderPause();
            }

            runAutomations(now);

            if (now - State.lastAnnounceAt >= CONFIG.ANNOUNCE_SCAN_MS) {
                State.lastAnnounceAt = now;
                closeAnnouncements();
            }

            if (State.isGameReady && now - State.lastSendAt >= CONFIG.SEND_INTERVAL_MS) {
                State.lastSendAt = now;
                sendToSheet(false);
            }
        } catch (e) {
            Log.err('SYS', 'Tick Error: ' + (e && e.message));
            setStatus('ระบบเกิดข้อผิดพลาด', 'err');
        }
    }

    async function init() {
        installRafThrottle();
        liveInit();
        bossLoad();
        Log.load();
        Log.info('SYS', `เริ่มทำงาน v${VERSION}`);
        if (IMPORTED) {
            const I = IMPORTED;
            Log.ok('BACKUP', `นำเข้าแล้ว ${I.n} รายการ · ตัวละครในไฟล์: ${I.chars.join(', ') || '-'} · โซนฟาร์ม ${I.zones} แมพ${I.src && I.to.length ? ` · ใช้การตั้งค่าของ ${I.src} ให้ ${I.to.join(', ')}` : ''}`);
            setTimeout(() => showToast(`✅ นำเข้าการตั้งค่าแล้ว ${I.n} รายการ${I.src && I.to.length ? ` (ใช้ของ ${I.src})` : ''}`, 'ok'), 2500);
        }
        buildPanel();
        buildProfitPanel();
        buildLogsWindow();
        buildStatsWindow();
        applyRender();
        const r3Restore = () => { if (State.opt.renderOff) { applyRender(); Log.info('SYS', 'คืนค่าสถานะ: ปิดภาพ 3D (จำไว้จากครั้งก่อน · ใช้งานหลังโหลดหน้าเว็บเสร็จ)'); } };
        if (document.readyState === 'complete') r3Restore(); else window.addEventListener('load', r3Restore, { once: true });
        closeAnnouncements();
        loadPriceDB();
        loadIconManifest();

        const saveAll = () => { profitSave(true); Log.save(); };
        window.addEventListener('pagehide', saveAll);
        window.addEventListener('beforeunload', saveAll);
        window.addEventListener('resize', () => {
            positionProfitPanel();
            if (State.isDpsOpen && dRefs.panel) clampWindow(dRefs.panel);
            if (State.isLogsOpen && lRefs.panel) clampWindow(lRefs.panel);
        });

        setInterval(tick, CONFIG.TICK_MS);
        setTimeout(() => {      // รีโหลดแล้วเข้าเกมไม่ได้ภายใน 3 นาที → แจ้ง Discord
            try {
                const pd = JSON.parse(localStorage.getItem('at_reload_pending') || 'null');
                if (pd && !State.isGameReady && Date.now() - pd.at < 900000) { lsDel('at_reload_pending'); sendDiscord('server', { title: '❌ รีโหลดแล้วยังเข้าเกมไม่ได้', description: `**${pd.name || 'ตัวละคร'}** — รีโหลดเพราะ ${pd.why} แต่ผ่านไป 3 นาทียังไม่เห็นหน้าจอตัวละคร (อาจต้องล็อกอินใหม่) ต้องเข้าไปดูเอง`, color: 0xef4444 }, { ping: true, force: !!REGEX.discordUrl.test(State.discordUrl) && State.discordOn }); }
            } catch (e) { /* ignore */ }
        }, 180000);

        await waitFor(() => queryGame(SELECTORS.charName), Infinity, 500);
        await sleep(500);
        State.isGameReady = true;
        profitLoad();
        ensureObservers(true);
        if (State.isLogsOpen) renderLogs(true);
        Log.ok('SYS', `พร้อมใช้งาน · ตัวละคร ${Profit.charName || '—'}`);
        try {
            const pd = JSON.parse(localStorage.getItem('at_reload_pending') || 'null');
            if (pd && Date.now() - pd.at < 900000) { lsDel('at_reload_pending'); Log.ok('RELOAD', 'กลับเข้าเกมได้แล้วหลังรีโหลด'); sendDiscord('server', { title: '✅ กลับเข้าเกมแล้วหลังรีโหลด', description: `**${charLabel()}** — สาเหตุที่รีโหลด: ${pd.why}`, color: 0x3ddc84 }, { ping: false, once: 'reload-ok', onceMs: 180000 }); }
        } catch (e) { /* ignore */ }

        if (State.webAppUrl) setStatus('ทำงานปกติ', 'ok');
        else setStatus('กรุณาตั้งค่า URL', 'warn');
    }

    // 🛰️ Net sniffer (ใช้กับ Dev Mode): จดรูปแบบข้อความ WebSocket / fetch ที่เห็นหลังสคริปต์โหลด เพื่อดูว่าเซิร์ฟเวอร์ส่งตำแหน่ง/ขนาดแมพมายังไง
    const Net = { ws: [], sig: new Map(), res: 0 };
    (function hookNet() {
        const short = (d) => { try { if (typeof d === 'string') return d.slice(0, 700); if (d instanceof ArrayBuffer) return `[binary ${d.byteLength}B]`; if (d && d.size !== undefined) return `[blob ${d.size}B]`; } catch (e) { /* ignore */ } return String(d).slice(0, 200); };
        const rec = (dir, url, d) => {
            try {
                const s = short(d); const sig = `${dir} ${String(url).replace(/\?.*$/, '').slice(-40)} ${s.slice(0, 40).replace(/\d+/g, '#')}`;
                let e = Net.sig.get(sig);
                if (!e) { if (Net.sig.size >= 60) return; e = { n: 0, dir, url: String(url).slice(0, 120), sample: s }; Net.sig.set(sig, e); }
                e.n++; if (s.length > e.sample.length && s.length < 900) e.sample = s;
            } catch (x) { /* ignore */ }
        };
        try {
            const W = PW.WebSocket;
            if (W && !W.__atHooked) {
                const P = new Proxy(W, { construct(t, a) {
                    const ws = new t(...a); Net.ws.push(String(a[0]).slice(0, 120));
                    try { ws.addEventListener('message', (e) => rec('ws-in', a[0], e.data)); const snd = ws.send.bind(ws); ws.send = (d) => { rec('ws-out', a[0], d); return snd(d); }; } catch (x) { /* ignore */ }
                    return ws;
                } });
                P.__atHooked = true; PW.WebSocket = P;
            }
        } catch (e) { /* ignore */ }
        try {
            const F = PW.fetch;
            if (F && !F.__atHooked) {
                const H = function (...a) {
                    const url = String((a[0] && a[0].url) || a[0]); const p = F.apply(this, a);
                    try { p.then((r) => { const ct = r.headers.get('content-type') || ''; if (/json|text/.test(ct)) r.clone().text().then((t) => rec('fetch', url, t)).catch(() => {}); else rec('fetch', url, `[${r.status} ${ct}]`); }).catch(() => {}); } catch (x) { /* ignore */ }
                    return p;
                };
                H.__atHooked = true; PW.fetch = H;
            }
        } catch (e) { /* ignore */ }
    })();

    // ═══════════════════════════════════════════════════════════════
    // 🧪 Dev Mode — เครื่องมือตรวจช่อง (x,z) ในเกม: ช่องที่เมาส์ชี้ · ขนาดแมพ · NPC · จุดมอนเกิด · ตำแหน่งเรา
    // หาเอนจินเกม (Phaser) เองอัตโนมัติ ถ้าไม่เจอจะถอยไปใช้พิกัดจากมินิแมพ + ขนาดช่อง px ที่ตั้งเอง
    // ═══════════════════════════════════════════════════════════════
    const Dev = (() => {
        const LS = (k, d) => { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } };
        const D = { on: LS('at_dev_on', '0') === '1', el: null, ov: null, game: null, scene: null, cam: null, mx: 0, my: 0, tile: null,
            px: Number(LS('at_dev_px', '0')) || 0, grid: LS('at_dev_grid2', '0') === '1', marks: LS('at_dev_marks2', '0') === '1', zoom: Number(LS('at_dev_zoom', '48')) || 48, mini: null, mv: null, mh: null, target: null, walking: false, abort: false, msg: '', msgAt: 0,
            maps: {}, seen: new WeakMap(), tm: null, tmFor: '', tmState: '', mapFiles: {}, off: { x: Number(LS('at_dev_ox', '0')) || 0, z: Number(LS('at_dev_oz', '0')) || 0 }, hobj: [], lastFind: 0, timer: 0, calib: null, how: '', ents: [], hover: null, me: null, mapName: '' };
        try { D.maps = JSON.parse(LS('at_dev_maps', '{}')) || {}; } catch (e) { D.maps = {}; }
        const save = () => { try { lsSet('at_dev_maps', JSON.stringify(D.maps)); } catch (e) { /* ignore */ } };
        const looksGame = (o) => { try { return !!(o && typeof o === 'object' && o.scene && Array.isArray(o.scene.scenes) && o.canvas); } catch (e) { return false; } };
        function findGame() {
            if (looksGame(D.game)) return D.game;
            D.game = null; D.how = '';
            if (Date.now() - D.lastFind < 4000) return null;
            D.lastFind = Date.now();
            const c = [];
            try { if (PW.Phaser && Array.isArray(PW.Phaser.GAMES)) PW.Phaser.GAMES.forEach((g) => c.push([g, 'Phaser.GAMES'])); } catch (e) { /* ignore */ }
            for (const k of ['game', 'phaserGame', '__game', '__PHASER_GAME__', 'Game', 'gameInstance']) { try { c.push([PW[k], 'window.' + k]); } catch (e) { /* ignore */ } }
            try {
                for (const k of Object.getOwnPropertyNames(PW)) {
                    if (/^(webkit|on[a-z]|chrome|__tm|GM_)/.test(k)) continue;
                    let v; try { v = PW[k]; } catch (e) { continue; }
                    if (!v || typeof v !== 'object' || v === PW || v instanceof Node) continue;
                    c.push([v, 'window.' + k]);
                    for (const k2 of ['game', 'phaser', 'app', 'engine']) { try { c.push([v[k2], `window.${k}.${k2}`]); } catch (e) { /* ignore */ } }
                }
            } catch (e) { /* ignore */ }
            const hit = c.find(([g]) => looksGame(g));
            if (hit) { D.game = hit[0]; D.how = hit[1]; }
            return D.game;
        }
        function pickScene(g) {
            const all = (g.scene.scenes || []).filter((s) => s && s.sys);
            const act = all.filter((s) => { try { return s.sys.isActive(); } catch (e) { return false; } });
            const n = (s) => { try { return (s.children && s.children.list ? s.children.list.length : 0); } catch (e) { return 0; } };
            return (act.length ? act : all).sort((a, b) => n(b) - n(a))[0] || null;
        }
        function tileInfo(sc, cam) {
            const num = (v) => typeof v === 'number' && isFinite(v);
            const cands = [sc.map, sc.tilemap, sc.tileMap, sc.level, sc.world, sc.mapData];
            for (const k of Object.keys(sc)) { try { const v = sc[k]; if (v && typeof v === 'object' && num(v.tileWidth) && num(v.width)) cands.push(v); } catch (e) { /* ignore */ } }
            for (const m of cands) { if (m && num(m.tileWidth) && num(m.width) && num(m.height)) return { tw: m.tileWidth, th: m.tileHeight || m.tileWidth, cols: m.width, rows: m.height, src: 'tilemap' }; }
            let tw = 0, src = '';
            for (const k of Object.keys(sc)) { try { if (/tile|cell|grid/i.test(k) && num(sc[k]) && sc[k] >= 8 && sc[k] <= 256) { tw = sc[k]; src = 'scene.' + k; break; } } catch (e) { /* ignore */ } }
            if (!tw && D.px) { tw = D.px; src = 'ตั้งเอง'; }
            if (!tw) return null;
            let cols = 0, rows = 0;
            try { const b = cam.getBounds ? cam.getBounds() : cam._bounds; if (b && b.width) { cols = Math.round(b.width / tw); rows = Math.round(b.height / tw); } } catch (e) { /* ignore */ }
            if (!cols) { try { const w = sc.physics && sc.physics.world && sc.physics.world.bounds; if (w && w.width) { cols = Math.round(w.width / tw); rows = Math.round(w.height / tw); } } catch (e) { /* ignore */ } }
            return { tw, th: tw, cols, rows, src };
        }
        const canvasEl = () => { const all = [...document.querySelectorAll('canvas')].filter((c) => !/^at-/.test(c.id || '') && !c.classList.contains('at-ov')); return all.sort((a, b) => b.width * b.height - a.width * a.height)[0] || null; };
        function toWorld(cam, cv, x, y) {
            const r = cv.getBoundingClientRect(); const wv = cam.worldView;
            if (!wv || !wv.width) return null;
            return { x: wv.x + (x - r.left) / r.width * wv.width, y: wv.y + (y - r.top) / r.height * wv.height };
        }
        function toScreen(cam, cv, wx, wy) {
            const r = cv.getBoundingClientRect(); const wv = cam.worldView;
            return { x: r.left + (wx - wv.x) / wv.width * r.width, y: r.top + (wy - wv.y) / wv.height * r.height };
        }
        const cellOf = (t, wx, wy) => ({ x: Math.floor(wx / t.tw), z: Math.floor(wy / t.th) });
        function minimapCell() {
            const root = (document.querySelector('.minimap-name') || {}).parentElement;
            for (let el = root, i = 0; el && i < 4; el = el.parentElement, i++) {
                for (const n of el.querySelectorAll('*')) {
                    if (n.children.length) continue;
                    const m = /^\s*(-?\d+)\s*,\s*(-?\d+)\s*$/.exec(n.textContent || '');
                    if (m) return { x: +m[1], z: +m[2] };
                }
            }
            return null;
        }
        const typeOf = (o, key) => {
            let d = ''; try { d = String((o.getData && (o.getData('type') || o.getData('kind'))) || ''); } catch (e) { /* ignore */ }
            const s = `${key} ${o.name || ''} ${d}`;
            if (/npc|shop|merchant|vendor|guide|kafra|quest/i.test(s)) return 'npc';
            if (/mon|enemy|mob|boss|slime|creature/i.test(s)) return 'monster';
            if (/player|hero|self|me\b|char/i.test(s)) return 'player';
            return 'other';
        };
        function collect(sc, cam, t) {
            const out = []; const seenObj = new Set();
            const visit = (o, depth) => {
                if (!o || seenObj.has(o) || out.length > 1500) return; seenObj.add(o);
                if (typeof o.x === 'number' && typeof o.y === 'number' && o.visible !== false && !(o.type === 'TilemapLayer')) {
                    const key = (o.texture && o.texture.key && o.texture.key !== '__DEFAULT' ? o.texture.key : '') || o.name || (o.constructor && o.constructor.name) || '?';
                    out.push({ o, key, kind: typeOf(o, key), x: o.x, y: o.y, c: cellOf(t, o.x, o.y) });
                }
                if (depth < 2 && o.list && Array.isArray(o.list)) o.list.forEach((ch) => visit(ch, depth + 1));
            };
            ((sc.children && sc.children.list) || []).forEach((ch) => visit(ch, 0));
            return out;
        }
        // 🗺️ อ่านแมพ Tiled ของเกม (/maps/<id>.json): ขนาดแมพ · NPC · จุดมอนเกิด · ประตูวาร์ป — ตรงจากไฟล์แมพ ไม่ต้องเดา
        const kindOfObj = (o) => {
            const t = `${o.layer} ${o.name} ${o.type} ${Object.values(o.props || {}).join(' ')}`;
            if (/portal|warp|exit|gate|teleport|travel/i.test(t)) return 'portal';
            if (/npc|shop|merchant|vendor|kafra|guide|quest|smith|healer|storage/i.test(t)) return 'npc';
            if (/spawn|monster|mob|enemy|boss/i.test(t)) return 'spawn';
            return 'other';
        };
        function parseTiled(id, j) {
            const props = {}; (j.properties || []).forEach((p) => { props[p.name] = p.value; });
            const tw = j.tilewidth || 32, th = j.tileheight || 32; const objs = []; const layers = []; let col = null;
            const walk = (ls, pre) => (ls || []).forEach((l) => {
                if (l.type === 'group') return walk(l.layers, pre + l.name + '/');
                layers.push({ name: pre + l.name, type: l.type, n: l.type === 'objectgroup' ? (l.objects || []).length : undefined });
                if (l.type === 'tilelayer' && /coll|block|wall|solid|obstacle/i.test(l.name) && Array.isArray(l.data) && !l.encoding) {
                    col = col || new Uint8Array(l.data.length); l.data.forEach((v, i) => { if (v) col[i] = 1; });
                }
                if (l.type !== 'objectgroup') return;
                (l.objects || []).forEach((o) => {
                    const p = {}; (o.properties || []).forEach((q) => { p[q.name] = q.value; });
                    const w = o.width || 0, h = o.height || 0, x0 = o.x || 0, y0 = o.gid ? (o.y || 0) - h : (o.y || 0);
                    const ob = { layer: pre + l.name, name: o.name || '', type: o.type || o.class || '', props: p, x: x0, y: y0, w, h, c0: Math.floor(x0 / tw), z0: Math.floor(y0 / th), c1: Math.floor(Math.max(x0, x0 + w - 1) / tw), z1: Math.floor(Math.max(y0, y0 + h - 1) / th) };
                    ob.kind = kindOfObj(ob); objs.push(ob);
                });
            });
            walk(j.layers, '');
            // ช่องชน "ตามที่เกมใช้จริง" (โค้ดเกม readBlocked): ไทล์ที่ tileset ตั้ง property collides=true ในเลเยอร์ไทล์ไหนก็ได้ (กำแพง ตึก ต้นไม้ น้ำ ฯลฯ)
            try {
                const gids = new Set();
                for (const ts of j.tilesets || []) for (const tl of ts.tiles || []) if ((tl.properties || []).some((p) => p.name === 'collides' && p.value === true)) gids.add((ts.firstgid || 0) + tl.id);
                if (gids.size) {
                    const all = []; const grab = (ls) => (ls || []).forEach((l) => { if (l.type === 'group') grab(l.layers); else if (l.type === 'tilelayer' && Array.isArray(l.data)) all.push(l.data); });
                    grab(j.layers);
                    col = col || new Uint8Array(j.width * j.height);
                    for (const d of all) d.forEach((v, i) => { if (gids.has(v & 536870911)) col[i] = 1; });
                }
            } catch (e) { /* ignore */ }
            return { id, w: j.width, h: j.height, tw, th, props, layers, objs, col, disp: String(props.displayName || '') };
        }
        async function loadTiled(name) {
            D.tmFor = name; D.tmState = 'loading'; D.tm = null;
            try {
                const get = async (u) => { const r = await PW.fetch(u, { credentials: 'same-origin' }); if (!r.ok) throw new Error(r.status); return r.json(); };
                const ids = new Set();
                try { const at = await get('/world/atlas'); (at.links || []).forEach((l) => l.forEach((x) => ids.add(x))); } catch (e) { /* ignore */ }
                ['aet_capital', 'capital'].forEach((x) => ids.add(x));
                const cand = [...new Set([...ids].flatMap((id) => [id, id.replace(/^aet_/, '')]))];
                for (const id of cand) {
                    if (D.tmFor !== name) return;
                    let m = D.mapFiles[id];
                    if (m === undefined) { try { m = parseTiled(id, await get(`/maps/${id}.json`)); } catch (e) { m = null; } D.mapFiles[id] = m; }
                    if (m && m.disp && (name.includes(m.disp) || m.disp.includes(name))) { D.tm = m; D.tmState = 'ok'; return; }
                }
                D.tmState = 'notfound';
            } catch (e) { D.tmState = 'error'; }
        }
        const rng = (o) => (o.c0 === o.c1 && o.z0 === o.z1 ? `${o.c0},${o.z0}` : `${o.c0}-${o.c1},${o.z0}-${o.z1}`);
        // 🔍 ซูมของเกม (แถบสไลเดอร์ข้างมินิแมพ เช่น "50%") → ขนาดช่องบนจอ = ขนาดช่อง × ซูม
        const GZ = { t: 0, v: 0 };
        function gameZoom() {
            if (Date.now() - GZ.t < 400) return GZ.v;
            GZ.v = gameZoom0(); GZ.t = Date.now(); return GZ.v;
        }
        function gameZoom0() {
            const root = (document.querySelector('.minimap-name') || {}).parentElement;
            for (let el = root, i = 0; el && i < 5; el = el.parentElement, i++) {
                for (const n of el.querySelectorAll('*')) {
                    if (n.children.length) continue;
                    const m = /^\s*(\d{2,3})\s*%\s*$/.exec(n.textContent || '');
                    if (m && +m[1] >= 10 && +m[1] <= 400) return +m[1];
                }
            }
            return 0;
        }
        // อัตราย่อ/ขยายของ canvas เทียบความละเอียดภายใน (จอเล็ก/ย่อหน้าต่าง) — เลือกค่าที่ใกล้ 1 ที่สุดระหว่างคิด/ไม่คิด devicePixelRatio
        function scaleRatio() {
            const cv = canvasEl(); if (!cv || !cv.width) return 1; const r = cv.getBoundingClientRect(); if (!r.width) return 1;
            const a = r.width / cv.width, b = r.width * (window.devicePixelRatio || 1) / cv.width;
            const q = Math.abs(Math.log(a)) < Math.abs(Math.log(b)) ? a : b; return q > 0.25 && q < 4 ? q : 1;
        }
        // สเกลจริงที่เรียนรู้จากการเดิน แยกตามความกว้างจอเกม (ตอนหน้าต่างใหญ่/เล็กเกมซูมภาพต่างกัน) — เก็บใน localStorage
        const calKey = () => { const cv = canvasEl(); return cv ? String(Math.round(cv.getBoundingClientRect().width / 40) * 40) : '0'; };
        try { if (localStorage.getItem('at_walk_v') !== '3') { lsDel('at_walk_blk'); lsDel('at_walk_nodiag'); lsSet('at_walk_v', '3'); } } catch (e) { /* ignore */ }
        try { if (localStorage.getItem('at_walk_cal_v') !== '2') { lsDel('at_walk_cal'); lsSet('at_walk_cal_v', '2'); } } catch (e) { /* ignore */ }
        const calLoad = () => { try { return JSON.parse(localStorage.getItem('at_walk_cal') || '{}') || {}; } catch (e) { return {}; } };
        const calFor = () => { const v = calLoad()[calKey()]; return v > 0.2 && v < 5 ? v : 1; };
        const calSet = (v) => { try { const o = calLoad(); o[calKey()] = Math.max(0.2, Math.min(5, v)); lsSet('at_walk_cal', JSON.stringify(o)); } catch (e) { /* ignore */ } };
        // ขนาดช่องบนจอ (CSS px) = 32 × ซูมกล้องของเกม — อ่านตรงจากการตั้งค่าเกม (webgame.camera.zoom) ไม่ขึ้นกับขนาดหน้าต่าง/ความละเอียดภาพ/ซูมเบราว์เซอร์
        // (โค้ดเกม: canvas = ขนาดหน้าต่าง × render, ย่อกลับ 1/render, กล้องซูม zoom × render → 1 หน่วยโลก = zoom px บนจอ)
        const camZoom = () => { try { const c = JSON.parse(localStorage.getItem('webgame.camera') || 'null'); const z = c && +c.zoom; return z >= 0.5 && z <= 1.5 ? z : 1; } catch (e) { return 1; } };
        const pxNow = () => { const z = camZoom(); D.gz = Math.round(z * 100); return D.px || 32 * z; };
        // 🔍 ปรับซูมเกมด้วยปุ่ม -/+ ข้างมินิแมพ (.minimap-zoom) จนอ่านได้ตามเป้า (ระบบเดินแม่นเฉพาะ 100%)
        async function setZoomTo(target) {
            const box = document.querySelector('.minimap-zoom'); if (!box) return false;
            const btns = [...box.querySelectorAll('button,[role="button"]')];
            const plus = btns.find((b) => /^\s*\+\s*$/.test(b.textContent || '')), minus = btns.find((b) => /^\s*[-−–]\s*$/.test(b.textContent || ''));
            if (!plus || !minus) return false;
            for (let i = 0; i < 24; i++) {
                GZ.t = 0; const z = gameZoom(); if (z === target) return true;
                if (!z) return false;
                wtap(z < target ? plus : minus); await sleep(350);
            }
            GZ.t = 0; await sleep(500); return gameZoom() === target;
        }
        const ensureZoom100 = async () => { const ok = await setZoomTo(100); if (ok) { await sleep(600); D.frac = { x: [0, 1], z: [0, 1] }; D.lastEnd = null; } return ok; };
        // 🎯 อ่านกล้องจากเอนจินเกมตรง ๆ: ได้ตำแหน่งตัวละคร (ทศนิยม) และสเกลจริงบนจอ ไม่ขึ้นกับขนาดหน้าต่าง/ซูม
        function engineView() {
            try {
                const g = findGame(), cv = canvasEl(); if (!g || !cv) return null;
                const sc = pickScene(g), cam = sc && sc.cameras && sc.cameras.main; if (!cam || !cam.worldView || !cam.worldView.width) return null;
                const t = tileInfo(sc, cam); if (!t || !t.tw) return null;
                let me = null; try { me = cam._follow || cam.followTarget || null; } catch (e) { /* ignore */ }
                if (!me || !isFinite(me.x) || !isFinite(me.y)) return null;
                return { t, cam, cv, me: { x: me.x / t.tw, z: me.y / t.th } };
            } catch (e) { return null; }
        }
        function projector(mm) {
            const cv = canvasEl(), r = cv.getBoundingClientRect(), ev = engineView();
            if (ev && mm && Math.abs(Math.floor(ev.me.x) - mm.x) <= 1 && Math.abs(Math.floor(ev.me.z) - mm.z) <= 1) {
                const wv = ev.cam.worldView, t = ev.t;
                return { exact: true, me: ev.me, r, px: r.width / wv.width * t.tw, pz: r.height / wv.height * t.th, scr: (cx, cz) => { const w = ev.cam.worldView; return [r.left + (cx * t.tw - w.x) / w.width * r.width, r.top + (cz * t.th - w.y) / w.height * r.height]; } };
            }
            // เกมปัดจุดคลิกเป็น "กลางช่อง" เสมอ (sendMoveTo: (floor(x/32)+.5)*32) → หลังเดินด้วยคลิก ตัวละครยืนกลางช่องพอดี ไม่ต้องเดาเศษในช่อง
            const px = pxNow(), tl = camTilt(), pz = px * tl, me = { x: mm.x + 0.5, z: mm.z + 0.5 };
            // กล้องตามตัวละคร แต่ไม่เลื่อนเกินขอบแมพ (เผื่อขอบ 128px = 4 ช่อง) → ใกล้ขอบแมพ ตัวละครไม่อยู่กลางจอ
            const cam = { x: me.x, z: me.z }, m = D.tm;
            if (m && m.w && m.h && D.tmFor === norm((queryGame(SELECTORS.mapName) || {}).textContent || '').replace(/\s*Lv\.?[\d\-–\s]+$/i, '').trim()) {      // ใช้เฉพาะไฟล์แมพของแมพที่อยู่ตอนนี้
                const hw = r.width / px / 2, hh = r.height / pz / 2, padX = 4, padZ = 4 / tl;
                const clampC = (v, lo, hi, mid) => (lo > hi ? mid : Math.max(lo, Math.min(hi, v)));
                cam.x = clampC(me.x, -padX + hw, m.w + padX - hw, m.w / 2);
                cam.z = clampC(me.z, -padZ + hh, m.h + padZ - hh, m.h / 2);
            }
            return { exact: false, me, cam, r, px, pz, scr: (cx, cz) => [r.left + r.width / 2 + D.off.x + (cx - cam.x) * px, r.top + r.height / 2 + D.off.z + (cz - cam.z) * pz] };
        }
        // โหมดกล้อง "มุมเอียง 2.5D" ของเกม: แกนตั้งบนจอถูกบีบ ×0.72 (เกมคิด worldY = จอY ÷ tilt) · มองจากด้านบน = 1
        const camTilt = () => { try { const c = JSON.parse(localStorage.getItem('webgame.camera') || 'null'); return c && c.mode === 'tilted' ? 0.72 : 1; } catch (e) { return 1; } };
        const zoomBad = () => 0;       // ตอนนี้คิดขนาดช่องจากซูมจริงของเกมได้แล้ว → ใช้ได้ทุกระดับซูม ไม่ต้องบังคับ 100%
        function mapRec() { const k = D.mapName || '(ไม่ทราบแมพ)'; return (D.maps[k] = D.maps[k] || { npc: {}, spawn: {}, grid: null }); }
        function update() {
            D.mapName = norm((queryGame(SELECTORS.mapName) || {}).textContent || '').replace(/\s*Lv\.?[\d\-–\s]+$/i, '').trim();
            if (D.mapName && D.tmFor !== D.mapName && D.tmState !== 'loading') loadTiled(D.mapName);
            const g = findGame(); D.scene = null; D.cam = null; D.tile = null; D.ents = []; D.hover = null; D.me = null;
            const cv = canvasEl();
            { const rr = cv && cv.getBoundingClientRect(); D.view = rr ? { w: Math.round(rr.width), h: Math.round(rr.height) } : null; }
            const mm = minimapCell();
            if (g && cv) {
                const sc = pickScene(g); D.scene = sc; const cam = sc && sc.cameras && sc.cameras.main; D.cam = cam || null;
                if (sc && cam) {
                    const t = tileInfo(sc, cam); D.tile = t;
                    if (t) {
                        D.ents = collect(sc, cam, t);
                        const w = toWorld(cam, cv, D.mx, D.my); if (w) D.hover = cellOf(t, w.x, w.y);
                        let me = null; try { me = cam._follow || cam.followTarget || null; } catch (e) { /* ignore */ }
                        const meE = me ? { x: me.x, y: me.y } : (D.ents.find((e) => e.kind === 'player') || null);
                        if (meE) D.me = cellOf(t, meE.x, meE.y);
                        const rec = mapRec(); rec.grid = { cols: t.cols, rows: t.rows, tile: t.tw, src: t.src };
                        for (const e of D.ents) {
                            if (e === meE || (me && e.o === me)) continue;
                            const id = `${e.c.x},${e.c.z}`;
                            if (e.kind === 'npc') { rec.npc[e.key] = rec.npc[e.key] || {}; rec.npc[e.key][id] = 1; }
                            else if (e.kind === 'monster' && !D.seen.has(e.o)) { D.seen.set(e.o, 1); rec.spawn[e.key] = rec.spawn[e.key] || {}; rec.spawn[e.key][id] = (rec.spawn[e.key][id] || 0) + 1; }
                        }
                    }
                }
            }
            if (!D.tile && mm) {       // ไม่มีเอนจิน: ใช้พิกัดมินิแมพ + ขนาดช่อง px (กล้องตามตัวละครอยู่กลางจอ → ประมาณการ)
                D.me = mm;
                if (cv) {
                    const r = cv.getBoundingClientRect(); const px = pxNow();
                    D.hover = { x: mm.x + Math.floor((D.mx - (r.left + r.width / 2 + D.off.x)) / px + 0.5), z: mm.z + Math.floor((D.my - (r.top + r.height / 2 + D.off.z)) / (px * camTilt()) + 0.5), approx: true };
                }
            } else if (mm && D.me && (mm.x !== D.me.x || mm.z !== D.me.z)) D.me.note = `มินิแมพ ${mm.x},${mm.z}`;
            D.hobj = (D.tm && D.hover) ? D.tm.objs.filter((o) => D.hover.x >= o.c0 && D.hover.x <= o.c1 && D.hover.z >= o.z0 && D.hover.z <= o.z1) : [];
            D.mm = mm;
            if (D.inPanel) { D.hover = null; D.hobj = []; }
        }
        function draw() {
            const ov = D.ov; if (!ov) return; const cv = canvasEl();
            if (!cv) return; const r = cv.getBoundingClientRect();
            if (ov.width !== Math.round(r.width) || ov.height !== Math.round(r.height)) { ov.width = Math.round(r.width); ov.height = Math.round(r.height); }
            ov.style.left = r.left + 'px'; ov.style.top = r.top + 'px';
            const c = ov.getContext('2d'); c.clearRect(0, 0, ov.width, ov.height);
            if (!D.cam || !D.tile) {
                if (!D.me || !D.mm) return;
                const px = pxNow(), pzv = px * camTilt(), cx = r.width / 2 + D.off.x, cz = r.height / 2 + D.off.z;
                const X = (k) => cx + (k - D.me.x - 0.5) * px, Z = (k) => cz + (k - D.me.z - 0.5) * pzv;
                if (D.grid) {
                    c.strokeStyle = 'rgba(255,255,255,.18)'; c.lineWidth = 1; c.beginPath();
                    for (let k = D.me.x - Math.ceil(cx / px) - 1; k <= D.me.x + Math.ceil((r.width - cx) / px) + 1; k++) { c.moveTo(X(k), 0); c.lineTo(X(k), r.height); }
                    for (let k = D.me.z - Math.ceil(cz / pzv) - 1; k <= D.me.z + Math.ceil((r.height - cz) / pzv) + 1; k++) { c.moveTo(0, Z(k)); c.lineTo(r.width, Z(k)); }
                    c.stroke();
                }
                const bx = (c0, z0, c1, z1, col, fill) => { c.strokeStyle = col; c.fillStyle = fill; c.lineWidth = 2; const x = X(c0), y = Z(z0), w = X(c1 + 1) - x, h = Z(z1 + 1) - y; if (x > r.width || y > r.height || x + w < 0 || y + h < 0) return; c.fillRect(x, y, w, h); c.strokeRect(x, y, w, h); };
                if (D.marks && D.tm) for (const o of D.tm.objs) { if (o.kind === 'npc') bx(o.c0, o.z0, o.c1, o.z1, '#38bdf8', 'rgba(56,189,248,.25)'); else if (o.kind === 'spawn') bx(o.c0, o.z0, o.c1, o.z1, '#f87171', 'rgba(248,113,113,.15)'); else if (o.kind === 'portal') bx(o.c0, o.z0, o.c1, o.z1, '#c084fc', 'rgba(192,132,252,.25)'); }
                bx(D.me.x, D.me.z, D.me.x, D.me.z, '#4ade80', 'rgba(74,222,128,.3)');
                if (D.hover) bx(D.hover.x, D.hover.z, D.hover.x, D.hover.z, '#facc15', 'rgba(250,204,21,.25)');
                return;
            }
            const t = D.tile, cam = D.cam, wv = cam.worldView; if (!wv || !wv.width) return;
            const sx = (wx) => (wx - wv.x) / wv.width * r.width, sy = (wy) => (wy - wv.y) / wv.height * r.height;
            if (D.grid) {
                c.strokeStyle = 'rgba(255,255,255,.18)'; c.lineWidth = 1; c.beginPath();
                for (let x = Math.floor(wv.x / t.tw) * t.tw; x < wv.x + wv.width; x += t.tw) { c.moveTo(sx(x), 0); c.lineTo(sx(x), r.height); }
                for (let y = Math.floor(wv.y / t.th) * t.th; y < wv.y + wv.height; y += t.th) { c.moveTo(0, sy(y)); c.lineTo(r.width, sy(y)); }
                c.stroke();
            }
            const box = (cx, cz, col, fill) => { c.strokeStyle = col; c.lineWidth = 2; c.fillStyle = fill || 'transparent'; const x = sx(cx * t.tw), y = sy(cz * t.th), w = sx((cx + 1) * t.tw) - x, h = sy((cz + 1) * t.th) - y; c.fillRect(x, y, w, h); c.strokeRect(x, y, w, h); };
            if (D.marks) for (const e of D.ents) { if (e.kind === 'npc') box(e.c.x, e.c.z, '#38bdf8', 'rgba(56,189,248,.25)'); else if (e.kind === 'monster') box(e.c.x, e.c.z, '#f87171', 'rgba(248,113,113,.2)'); }
            if (D.me) box(D.me.x, D.me.z, '#4ade80', 'rgba(74,222,128,.3)');
            if (D.hover) box(D.hover.x, D.hover.z, '#facc15', 'rgba(250,204,21,.25)');
        }
        const esc = (s) => String(s).replace(/[&<>]/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m]));
        function render() {
            const el = D.el; if (!el) return; const t = D.tile; const rec = D.maps[D.mapName || '(ไม่ทราบแมพ)'];
            const q = (s) => el.querySelector(s);
            q('#dv-eng').innerHTML = D.game ? `✅ พบเอนจินเกม <small>(${esc(D.how)})</small>` : `⚠️ ไม่พบเอนจินเกม — ใช้พิกัดมินิแมพ · จอเกม ${D.view ? D.view.w + '×' + D.view.h : '?'} · ซูม ${D.gz ? D.gz + '%' : 'อ่านไม่ได้ (สมมติ 100%)'}${camTilt() < 1 ? ' · มุมเอียง 2.5D' : ''} · ช่องละ ${pxNow()}px${D.view ? ` · เห็น ~${Math.round(D.view.w / pxNow())}×${Math.round(D.view.h / (pxNow() * camTilt()))} ช่อง` : ''}${D.px ? ' (ตั้งขนาดเอง)' : ' (ซิงค์อัตโนมัติ)'}`;
            const tm = D.tm;
            q('#dv-map').textContent = `${D.mapName || '—'}${tm ? ` · ${tm.w}×${tm.h} ช่อง · ช่องละ ${tm.tw}px (ไฟล์แมพ ${tm.id})` : t ? ` · ${t.cols || '?'}×${t.rows || '?'} ช่อง · ช่องละ ${t.tw}px (${t.src})` : D.tmState === 'loading' ? ' · กำลังโหลดไฟล์แมพ…' : ' · ไม่พบไฟล์แมพของแมพนี้'}`;
            const h = D.hover; q('#dv-hover').textContent = h ? `${h.x}, ${h.z}${h.approx ? ' ≈' : ''}` : '—';
            q('#dv-me').textContent = D.me ? `${D.me.x}, ${D.me.z}${D.me.note ? ' (' + D.me.note + ')' : ''}` : (D.mm ? `${D.mm.x}, ${D.mm.z} (มินิแมพ)` : '—');
            const cnt = { npc: 0, monster: 0 }; D.ents.forEach((e) => { if (cnt[e.kind] !== undefined) cnt[e.kind]++; });
            q('#dv-cnt').innerHTML = D.hobj.length ? `🎯 ช่องนี้มี: ${D.hobj.map((o) => esc(`${o.kind} ${o.name || o.type || o.layer}`)).join(' · ')}` : (D.game ? `ตอนนี้ในฉาก: NPC ${cnt.npc} · มอน ${cnt.monster} · วัตถุทั้งหมด ${D.ents.length}` : '');
            let html = '';
            if (D.tm) {
                const grp = { npc: [], spawn: [], portal: [], other: [] };
                D.tm.objs.forEach((o) => grp[o.kind].push(o));
                const line = (arr, col, lab) => arr.slice(0, 40).map((o) => `<div${o.kind === 'npc' ? ` class="dv-npc" data-i="${D.tm.objs.indexOf(o)}" style="cursor:pointer" title="คลิก: เดินไปคุยกับ NPC นี้"` : o.kind === 'portal' || o.kind === 'spawn' ? ` class="dv-go" data-i="${D.tm.objs.indexOf(o)}" style="cursor:pointer" title="คลิก: เดินไปที่จุดนี้"` : ''}><b style="color:${col}">${lab}</b> ${esc(o.name || o.type || o.layer)} → ${rng(o)}${o.kind === 'npc' ? ' 💬' : ' 🚶'}</div>`).join('') + (arr.length > 40 ? `<div style="opacity:.6">…อีก ${arr.length - 40}</div>` : '');
                html += `<div style="opacity:.7">จากไฟล์แมพ: NPC ${grp.npc.length} · จุดมอนเกิด ${grp.spawn.length} · ประตู ${grp.portal.length} · อื่น ๆ ${grp.other.length}</div>` + line(grp.npc, '#38bdf8', 'NPC') + line(grp.spawn, '#f87171', 'มอนเกิด') + line(grp.portal, '#c084fc', 'ประตู');
            }
            if (D.hobj.length) q('#dv-hover').title = D.hobj.map((o) => `${o.kind}:${o.name || o.type}`).join(', ');
            if (rec) {
                const rows = [];
                for (const [k, cells] of Object.entries(rec.npc)) rows.push(`<div><b style="color:#38bdf8">NPC ${esc(k)}</b> → ${Object.keys(cells).join(' · ')}</div>`);
                for (const [k, cells] of Object.entries(rec.spawn)) { const top = Object.entries(cells).sort((a, b) => b[1] - a[1]).slice(0, 12).map(([c, n]) => `${c}${n > 1 ? '×' + n : ''}`).join(' · '); rows.push(`<div><b style="color:#f87171">มอน ${esc(k)}</b> เจอครั้งแรกที่ ${top}</div>`); }
                html = rows.join('') || '<div style="opacity:.6">ยังไม่พบ NPC/มอนที่จัดประเภทได้ (กด "คัดลอกรายงานวินิจฉัย" ส่งให้ผมช่วยปรับ)</div>';
            }
            if (D.lastList !== html) { D.lastList = html; q('#dv-list').innerHTML = html; }
            if (D.msg && Date.now() - D.msgAt < 15000 && !D.mh) q('#dv-mh').textContent = D.msg;
            if (D.doc.activeElement !== q('#dv-px')) q('#dv-px').value = D.px || '';
            try { const hh = Math.min(D.doc.documentElement.scrollHeight + 2, innerHeight - 24); if (Math.abs(hh - D.fr.offsetHeight) > 3) D.fr.style.height = hh + 'px'; } catch (e) { /* ignore */ }
            if (D.doc.activeElement !== q('#dv-grid')) q('#dv-grid').checked = D.grid; if (D.doc.activeElement !== q('#dv-marks')) q('#dv-marks').checked = D.marks;
        }
        function diag() {
            const L = []; const g = D.game;
            L.push(`Aetherack ${VERSION} dev report · map=${D.mapName} · ${new Date().toISOString()}`);
            L.push(`engine: ${g ? D.how : 'NOT FOUND'} · Phaser global: ${!!PW.Phaser}${PW.Phaser ? ' v' + PW.Phaser.VERSION : ''}`);
            try { const f = document.createElement('iframe'); f.style.display = 'none'; document.body.appendChild(f); const base = new Set(Object.getOwnPropertyNames(f.contentWindow)); f.remove(); L.push('custom globals: ' + Object.getOwnPropertyNames(PW).filter((k) => !base.has(k) && !/^(webkit|__tm|GM_)/.test(k)).slice(0, 60).join(', ')); } catch (e) { L.push('custom globals: ?'); }
            const cv = canvasEl(); if (cv) { const r = cv.getBoundingClientRect(); L.push(`canvas: attr ${cv.width}x${cv.height} · css ${Math.round(r.width)}x${Math.round(r.height)} · id=${cv.id} class=${cv.className}`); }
            L.push(`minimap coord: ${D.mm ? D.mm.x + ',' + D.mm.z : 'not found'}`);
            try { L.push('engines: ' + ['THREE', 'BABYLON', 'PIXI', 'Phaser', 'pc', 'PlayCanvas'].filter((k) => PW[k]).join(', ')); } catch (e) { /* ignore */ }
            L.push(`websocket (เห็นหลังสคริปต์โหลด): ${Net.ws.join(' , ') || 'ไม่เห็น (เกมอาจเปิดก่อนสคริปต์ — ลองรีเฟรชหน้าแล้วเปิด 🧪 ทันที)'}`);
            try {
                const res = [...new Set(performance.getEntriesByType('resource').filter((r) => /fetch|xmlhttprequest|websocket|other/.test(r.initiatorType) && !/\.(png|webp|jpg|svg|woff2?|css|mp3|ogg)(\?|$)/i.test(r.name)).map((r) => r.name.replace(/^https?:\/\/[^/]+/, '').replace(/\?.*$/, '')))];
                L.push('resources: ' + res.slice(0, 50).join(' , '));
            } catch (e) { /* ignore */ }
            L.push('network samples (รูปแบบข้อความที่เห็น):');
            [...Net.sig.values()].sort((x, y) => y.n - x.n).slice(0, 30).forEach((e) => L.push(`  [${e.dir} ×${e.n}] ${e.url} :: ${e.sample.replace(/\s+/g, ' ').slice(0, 500)}`));
            if (g) {
                for (const s of g.scene.scenes) {
                    let act = false; try { act = s.sys.isActive(); } catch (e) { /* ignore */ }
                    const ch = (s.children && s.children.list) || []; const cls = {};
                    ch.forEach((o) => { const k = (o.texture && o.texture.key) || o.name || (o.constructor && o.constructor.name) || '?'; cls[k] = (cls[k] || 0) + 1; });
                    L.push(`scene "${s.sys.settings && s.sys.settings.key}" active=${act} children=${ch.length}`);
                    L.push('  top keys: ' + Object.entries(cls).sort((a, b) => b[1] - a[1]).slice(0, 25).map(([k, n]) => `${k}×${n}`).join(', '));
                    const nums = []; Object.keys(s).forEach((k) => { try { if (typeof s[k] === 'number' && /tile|cell|grid|map|width|height|size/i.test(k)) nums.push(`${k}=${s[k]}`); } catch (e) { /* ignore */ } });
                    if (nums.length) L.push('  numeric: ' + nums.join(', '));
                    L.push('  object keys: ' + Object.keys(s).filter((k) => { try { return s[k] && typeof s[k] === 'object' && !/^(sys|game|anims|cache|registry|sound|textures|events|cameras|add|make|scene|children|input|scale|data|physics|lights|load|plugins|renderer|cameras3d|displayList|updateList)$/.test(k); } catch (e) { return false; } }).slice(0, 40).join(', '));
                    const cam = s.cameras && s.cameras.main; if (cam) L.push(`  camera: zoom=${cam.zoom} scroll=${Math.round(cam.scrollX)},${Math.round(cam.scrollY)} view=${Math.round(cam.worldView.width)}x${Math.round(cam.worldView.height)} follow=${!!(cam._follow || cam.followTarget)}`);
                }
            }
            if (D.tm) {
                const m = D.tm; L.push(`tiled map: id=${m.id} ${m.w}x${m.h} tile=${m.tw} props=${JSON.stringify(m.props).slice(0, 400)}`);
                L.push('  layers: ' + m.layers.map((l) => `${l.name}(${l.type}${l.n !== undefined ? ' ' + l.n : ''})`).join(', '));
                const byL = {}; m.objs.forEach((o) => { (byL[o.layer] = byL[o.layer] || []).push(o); });
                Object.entries(byL).forEach(([ln, arr]) => { L.push(`  layer "${ln}" ${arr.length} objs · kinds: ${[...new Set(arr.map((o) => o.kind))].join('/')} · types: ${[...new Set(arr.map((o) => o.type))].slice(0, 8).join('/')}`); arr.slice(0, 3).forEach((o) => L.push(`    ${JSON.stringify({ name: o.name, type: o.type, props: o.props, x: o.x, y: o.y, w: o.w, h: o.h })}`.slice(0, 400))); });
            } else L.push(`tiled map: ${D.tmState}`);
            L.push(`tile: ${D.tile ? JSON.stringify(D.tile) : 'unknown'} · me=${JSON.stringify(D.me)} · hover=${JSON.stringify(D.hover)}`);
            L.push('sample entities: ' + D.ents.slice(0, 25).map((e) => `${e.kind}:${e.key}@${e.c.x},${e.c.z}`).join(' | '));
            return L.join('\n');
        }
        const copy = (txt, msg) => {
            try {
                const d = D.doc || document; const ta = d.createElement('textarea'); ta.value = txt; ta.style.cssText = 'position:fixed;left:0;top:0;opacity:0'; d.body.appendChild(ta); ta.focus(); ta.select();
                const ok = d.execCommand('copy'); ta.remove(); if (ok) { showToast(msg || 'คัดลอกแล้ว', 'ok'); return; }
            } catch (e) { /* ignore */ }
            try { navigator.clipboard.writeText(txt); showToast(msg || 'คัดลอกแล้ว', 'ok'); } catch (e) { prompt('คัดลอกข้อความนี้', txt); }
        };
        // 🗺️ แผนที่ย่อในแผง + คลิกเพื่อเดิน
        function drawMini() {
            const cv = D.mini; if (!cv || !D.fr || D.fr.style.display === 'none') return;
            const c = cv.getContext('2d'), W = cv.width, H = cv.height, m = D.tm;
            c.fillStyle = '#0b0b12'; c.fillRect(0, 0, W, H);
            if (!m) { c.fillStyle = '#9ca3af'; c.font = '12px sans-serif'; c.fillText(D.tmState === 'loading' ? 'กำลังโหลดไฟล์แมพ…' : 'ไม่พบไฟล์แมพ', 12, 24); D.mv = null; return; }
            const s = W / D.zoom; const me = D.me || { x: m.w / 2, z: m.h / 2 };
            const vx0 = me.x + 0.5 - W / s / 2, vz0 = me.z + 0.5 - H / s / 2; D.mv = { vx0, vz0, s };
            const X = (k) => (k - vx0) * s, Z = (k) => (k - vz0) * s;
            c.fillStyle = '#1e293b'; c.fillRect(X(0), Z(0), m.w * s, m.h * s);
            if (m.col) {
                c.fillStyle = '#475569';
                for (let z = Math.max(0, Math.floor(vz0)); z < Math.min(m.h, Math.ceil(vz0 + H / s)); z++) for (let x = Math.max(0, Math.floor(vx0)); x < Math.min(m.w, Math.ceil(vx0 + W / s)); x++) if (m.col[z * m.w + x]) c.fillRect(X(x), Z(z), s + 0.5, s + 0.5);
            }
            if (s >= 7) { c.strokeStyle = 'rgba(255,255,255,.07)'; c.lineWidth = 1; c.beginPath(); for (let x = Math.ceil(vx0); x < vx0 + W / s; x++) { c.moveTo(X(x), 0); c.lineTo(X(x), H); } for (let z = Math.ceil(vz0); z < vz0 + H / s; z++) { c.moveTo(0, Z(z)); c.lineTo(W, Z(z)); } c.stroke(); }
            const col = { npc: ['#38bdf8', 'rgba(56,189,248,.45)'], spawn: ['#f87171', 'rgba(248,113,113,.28)'], portal: ['#c084fc', 'rgba(192,132,252,.5)'] };
            for (const o of m.objs) { const k = col[o.kind]; if (!k) continue; const x = X(o.c0), y = Z(o.z0), w = (o.c1 - o.c0 + 1) * s, h = (o.z1 - o.z0 + 1) * s; if (x > W || y > H || x + w < 0 || y + h < 0) continue; c.fillStyle = k[1]; c.strokeStyle = k[0]; c.lineWidth = 1.5; c.fillRect(x, y, w, h); c.strokeRect(x, y, w, h); if (s >= 9 && o.kind !== 'spawn' && o.name) { c.fillStyle = '#e5e7eb'; c.font = '10px sans-serif'; c.fillText(o.name.slice(0, 14), x + 1, y - 2); } }
            const box = (cx, cz, st, fl) => { c.strokeStyle = st; c.fillStyle = fl; c.lineWidth = 2; c.fillRect(X(cx), Z(cz), s, s); c.strokeRect(X(cx), Z(cz), s, s); };
            if (D.me && D.view && !D.tile) {       // กรอบสีขาว = ส่วนของแมพที่มองเห็นอยู่บนจอเกมตอนนี้ (ซิงค์กับซูม/ขนาดจอ)
                const px = pxNow(), vw = D.view.w / px, vh = D.view.h / px;
                c.strokeStyle = 'rgba(255,255,255,.7)'; c.setLineDash([4, 3]); c.lineWidth = 1; c.strokeRect(X(D.me.x + 0.5 - vw / 2), Z(D.me.z + 0.5 - vh / 2), vw * s, vh * s); c.setLineDash([]);
            }
            { const bz = badNow().rects; c.lineWidth = 1.5; bz.forEach((z) => { c.fillStyle = 'rgba(239,68,68,.28)'; c.strokeStyle = '#ef4444'; c.fillRect(X(z[0]), Z(z[1]), (z[2] - z[0] + 1) * s, (z[3] - z[1] + 1) * s); c.strokeRect(X(z[0]), Z(z[1]), (z[2] - z[0] + 1) * s, (z[3] - z[1] + 1) * s); }); }
            { const zs = zonesFor(zKey()); c.lineWidth = 2;
              zs.forEach((z, i) => { c.fillStyle = 'rgba(250,204,21,.25)'; c.strokeStyle = '#facc15'; c.fillRect(X(z[0]), Z(z[1]), (z[2] - z[0] + 1) * s, (z[3] - z[1] + 1) * s); c.strokeRect(X(z[0]), Z(z[1]), (z[2] - z[0] + 1) * s, (z[3] - z[1] + 1) * s); c.fillStyle = '#fde68a'; c.font = '10px sans-serif'; c.fillText('โซน ' + (i + 1), X(z[0]) + 3, Z(z[1]) + 11); });
              if (D.zs && D.ze) { const a = Math.min(D.zs.x, D.ze.x), b = Math.min(D.zs.z, D.ze.z), w = Math.abs(D.zs.x - D.ze.x) + 1, h = Math.abs(D.zs.z - D.ze.z) + 1; c.setLineDash([5, 3]); c.strokeStyle = '#fff'; c.fillStyle = 'rgba(255,255,255,.18)'; c.fillRect(X(a), Z(b), w * s, h * s); c.strokeRect(X(a), Z(b), w * s, h * s); c.setLineDash([]); }
              const zi = D.mini.ownerDocument.getElementById('dv-zinfo'); if (zi) { const mm = D.me ? { x: D.me.x, z: D.me.z } : null; zi.textContent = `โซนของแมพนี้: ${zs.length} โซน${mm ? ' · ตัวเรา ' + (inZones(zs, mm) ? '✅ อยู่ในโซน' : 'นอกโซน') : ''}${D.zs ? '' : ' · ลากบนแผนที่เพื่อเพิ่ม · คลิกขวาในโซนเพื่อลบ'}`; } }
            { const P = ovPath(); if (P && P.length > 1) { c.strokeStyle = 'rgba(34,211,238,.9)'; c.lineWidth = Math.max(1.5, s / 4); c.setLineDash([4, 3]); c.beginPath(); P.forEach((p, i) => { const x = X(p.x + 0.5), y = Z(p.z + 0.5); if (i) c.lineTo(x, y); else c.moveTo(x, y); }); c.stroke(); c.setLineDash([]); } }
            if (D.target) box(D.target.x, D.target.z, '#f472b6', 'rgba(244,114,182,.35)');
            if (D.me) box(D.me.x, D.me.z, '#4ade80', 'rgba(74,222,128,.6)');
            if (D.mh) box(D.mh.x, D.mh.z, '#facc15', 'rgba(250,204,21,.3)');
        }
        const miniCell = (e) => { const r = D.mini.getBoundingClientRect(); const v = D.mv; if (!v) return null; return { x: Math.floor(v.vx0 + (e.clientX - r.left) / r.width * D.mini.width / v.s), z: Math.floor(v.vz0 + (e.clientY - r.top) / r.height * D.mini.height / v.s) }; };
        function say(t) { D.msg = t; D.msgAt = Date.now(); if (t !== D.lastSay) { D.lastSay = t; try { Log.info('WALK', t); } catch (x) { /* ignore */ } } try { if (W.run) { const e = document.getElementById('at-warp-st'); if (e) e.textContent = t; } } catch (x) { /* ignore */ } }
        function clickAt(cv, x, y) {
            const o = { bubbles: true, cancelable: true, clientX: x, clientY: y, screenX: x, screenY: y, button: 0, view: PW };
            const fire = (type, ptr) => { try { cv.dispatchEvent(ptr ? new PointerEvent(type, { ...o, buttons: type.endsWith('up') ? 0 : 1, pointerId: 1, pointerType: 'mouse', isPrimary: true }) : new MouseEvent(type, { ...o, buttons: type.endsWith('up') ? 0 : 1 })); } catch (e) { /* ignore */ } };
            fire('pointermove', true); fire('mousemove', false); fire('pointerdown', true); fire('mousedown', false); fire('pointerup', true); fire('mouseup', false); fire('click', false);
        }
        // เดินไปยืนช่องเป๊ะ ๆ: เล็งกลางช่องเป้าหมาย + เรียนรู้ตำแหน่งย่อยในช่อง (เศษทศนิยม) ของตัวเราจากผลการเดินแต่ละครั้ง แล้วแก้ซ้ำจนอยู่ช่องเดียวกับเป้า
        // 👥 ผู้เล่นคนอื่น: ป้ายชื่อ "ชื่อ Lv.99" เหนือหัว (DOM) → ใช้เลี่ยงช่องที่มีคนยืนอยู่ (คลิกทับคนจะเป็นการเลือกคนนั้นแทนการเดิน)
        function playerLabels() {
            const out = []; const myn = norm((queryGame(SELECTORS.charName) || {}).textContent || '').toLowerCase(); const cv = canvasEl(); const cr = cv ? cv.getBoundingClientRect() : null;
            for (const n of document.querySelectorAll('div,span,b,p')) {
                if (n.closest('#aetheria-dev,#aetheria-tracker,[id^="aetheria-"],[class*="at-"],[class*="target" i],[class*="party" i],[class*="chat" i]')) continue;
                const t = norm(n.textContent || ''); if (t.length < 4 || t.length > 40 || !/\sLv\.?\s*\d+\s*$/i.test(t)) continue;
                if ([...n.children].some((c) => /Lv\.?\s*\d+/i.test(c.textContent || '') && norm(c.textContent || '') === t)) continue;
                if (myn && t.toLowerCase().includes(myn)) continue;
                const r = n.getBoundingClientRect(); if (!r.width || r.height > 34) continue;
                if (cr && (r.right < cr.left || r.left > cr.right || r.bottom < cr.top || r.top > cr.bottom)) continue;
                out.push({ cx: r.left + r.width / 2, bottom: r.bottom, t });
            }
            return out;
        }
        function occupiedCell(cx, cz, labels) {
            const cv = canvasEl(), mm = minimapCell(); if (!cv || !mm) return false;
            const P = projector(mm), px = P.px, [X, Y] = P.scr(cx + 0.5, cz + 0.5);
            return (labels || playerLabels()).some((l) => Math.abs(l.cx - X) < 0.75 * px && l.bottom > Y - 2.2 * px && l.bottom < Y - 0.8 * px);
        }
        // กล่องเป้าหมายของเกม (ชื่อ + Lv + ✕) ที่เด้งตอนคลิกโดนผู้เล่น/มอน → กด ✕ ปิด (คืน true ถ้าปิดได้)
        function dismissTarget() {
            for (const n of document.querySelectorAll('div,span')) {
                if (n.children.length || n.closest('#aetheria-dev,#aetheria-tracker,[id^="aetheria-"]') || !/^Lv\.?\s*\d+$/i.test((n.textContent || '').trim())) continue;
                let box = n.parentElement;
                for (let i = 0; i < 3 && box; i++, box = box.parentElement) {
                    const close = [...box.querySelectorAll('button,[role="button"],span,div')].find((c) => !c.children.length && /^[✕×xX]$/.test((c.textContent || '').trim()));
                    if (close) { try { close.click(); } catch (e) { /* ignore */ } return true; }
                }
            }
            return false;
        }
        // กล่องเป้าหมายเป็น "ตัวเราเอง" (คลิกโดนสไปรต์ตัวเอง เกมจะเลือกตัวเองแทนการเดิน) → คืนปุ่ม ✕ ของกล่องนั้น
        function selfTargeted() {
            const me = String(readField(SELECTORS.charName, 'name') || '').trim().toLowerCase();
            if (!me) return null;
            for (const n of document.querySelectorAll('div,span')) {
                if (n.children.length || n.closest('#aetheria-dev,#aetheria-tracker,[id^="aetheria-"]') || !/^Lv\.?\s*\d+$/i.test((n.textContent || '').trim())) continue;
                let box = n.parentElement;
                for (let i = 0; i < 3 && box; i++, box = box.parentElement) {
                    const close = [...box.querySelectorAll('button,[role="button"],span,div')].find((c) => !c.children.length && /^[✕×xX]$/.test((c.textContent || '').trim()));
                    if (close) return norm(box.textContent).toLowerCase().includes(me) ? close : null;
                }
            }
            return null;
        }
        // ⌨️ เดินด้วยปุ่ม WASD: ไม่พึ่งขนาดจอ/ซูม — วางทางด้วย BFS บนแมพ (collision) แล้วกดปุ่มทีละช่อง ตรวจจากพิกัดมินิแมพทุกก้าว
        const KEYMAP = { up: ['w', 'KeyW', 87], down: ['s', 'KeyS', 83], left: ['a', 'KeyA', 65], right: ['d', 'KeyD', 68] };
        const KEYFLIP = { x: false, z: false };
        const DIRV = { up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0] };
        const D8 = [[0, -1], [0, 1], [-1, 0], [1, 0], [-1, -1], [1, -1], [-1, 1], [1, 1]];
        // ช่องที่เรียนรู้ว่า "เดินไม่ได้" (กดปุ่มแล้วไม่ขยับ) — แยกตามแมพ หมดอายุ 10 นาที (กันกรณีเป็นผู้เล่น/มอนยืนบัง)
        const LB = new Map(); let lbMap = '';
        // จำช่องที่ "คลิก/กดแล้วไม่ไป" ข้ามรอบข้ามการรีโหลด (localStorage แยกตามแมพ): ล้มเหลว ≥2 ครั้ง = ถือเป็นสิ่งกีดขวางถาวร
        const LBK = 'at_walk_blk', FAR = () => Date.now() + 1e12;
        const blkLoad = () => { try { return JSON.parse(localStorage.getItem(LBK) || '{}') || {}; } catch (e) { return {}; } };
        function blkAdd(x, z, w) {
            const k = x + ',' + z; let cnt = w || 1;
            try { const o = blkLoad(), m = (o[lbMap] = o[lbMap] || {}); m[k] = (m[k] || 0) + cnt; cnt = m[k]; const ks = Object.keys(m); if (ks.length > 500) delete m[ks[0]]; lsSet(LBK, JSON.stringify(o)); } catch (e) { /* ignore */ }
            LB.set(k, cnt >= 2 ? FAR() : Date.now()); D.df = null;
        }
        const lbSync = () => {
            const nmx = (document.querySelector('.minimap-name') || {}).textContent || '';
            if (nmx !== lbMap) { lbMap = nmx; LB.clear(); D.df = null; try { const m = blkLoad()[lbMap] || {}; for (const k in m) if (m[k] >= 2) LB.set(k, FAR()); } catch (e) { /* ignore */ } }
        };
        const lbHas = (x, z) => { const t = LB.get(x + ',' + z); if (!t) return false; if (Date.now() - t > 600000) { LB.delete(x + ',' + z); return false; } return true; };
        function walkBlocked(x, z) {
            const m = D.tm; if (!m) return lbHas(x, z);
            const bz = (D.badC && D.badC.rects) || []; if (bz.length && inZones(bz, { x, z })) return true;      // ⛔/👹 ไม่เดินผ่าน
            return lbHas(x, z) || x < 0 || z < 0 || x >= m.w || z >= m.h || !!(m.col && m.col[z * m.w + x]) || m.objs.some((p) => p.kind === 'npc' && p.c1 - p.c0 <= 3 && p.z1 - p.z0 <= 3 && x >= p.c0 && x <= p.c1 && z >= p.z0 && z <= p.z1);
        }
        function blkWhy(x, z) {
            const m = D.tm; if (!m) return lbHas(x, z) ? 'ช่องที่เคยเดินติด' : '';
            if (x < 0 || z < 0 || x >= m.w || z >= m.h) return 'นอกแมพ';
            if (m.col && m.col[z * m.w + x]) return 'กำแพง';
            const bz = (D.badC && D.badC.rects) || []; if (bz.length && inZones(bz, { x, z })) return 'โซนห้ามเข้า/มอนอันตราย';
            if (lbHas(x, z)) return 'ช่องที่เคยเดินติด';
            const o = m.objs.find((p) => p.kind === 'npc' && p.c1 - p.c0 <= 3 && p.z1 - p.z0 <= 3 && x >= p.c0 && x <= p.c1 && z >= p.z0 && z <= p.z1);
            return o ? 'NPC ' + (o.name || o.type || '') : '';
        }
        // เส้นทาง: Dijkstra (SPFA) บนกริด — ช่องที่ชิดกำแพง/ของกีดขวาง (รวมมุมเฉียง) แพงกว่า เพื่อเดินห่างกำแพง ไม่เฉียดมุม
        function costField(t, diag) {
            const m = D.tm; if (!m) return null; lbSync();
            badNow(); const key = `${t.x},${t.z},${LB.size},${lbMap},${diag ? 8 : 4},${D.badC ? D.badC.sig : ''}`; if (D.df && D.df.key === key) return D.df;
            const W_ = m.w, H_ = m.h, N = W_ * H_, cost = new Float32Array(N).fill(1e9);
            if (t.x < 0 || t.z < 0 || t.x >= W_ || t.z >= H_) return null;
            const near = new Int8Array(N).fill(-1);
            const nearOf = (x, z) => { const k = x + z * W_; if (near[k] >= 0) return near[k]; let c = 0; for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) { if ((dx || dz) && walkBlocked(x + dx, z + dz)) c++; } return (near[k] = c ? (c > 2 ? 3 : 2) : 0); };
            const q = [t.x + t.z * W_]; cost[q[0]] = 0; const inq = new Uint8Array(N); inq[q[0]] = 1;
            for (let h = 0; h < q.length && h < 400000; h++) {
                const k = q[h]; inq[k] = 0; const cx = k % W_, cz = (k / W_) | 0;
                for (const d of (diag ? D8 : Object.values(DIRV))) {
                    const nx = cx + d[0], nz = cz + d[1]; if (nx < 0 || nz < 0 || nx >= W_ || nz >= H_) continue;
                    if (walkBlocked(nx, nz)) continue;
                    if (d[0] && d[1] && (walkBlocked(cx + d[0], cz) || walkBlocked(cx, cz + d[1]))) continue;      // เฉียงต้องไม่ตัดมุม: ช่องข้างทั้งสองต้องว่าง
                    const nk = nx + nz * W_, nc = cost[k] + (d[0] && d[1] ? 1.42 : 1) + nearOf(nx, nz); if (nc < cost[nk]) { cost[nk] = nc; if (!inq[nk]) { inq[nk] = 1; q.push(nk); } }
                }
            }
            return (D.df = { key, cost, W_, H_ });
        }
        function nextDir(a, t) {
            const df = costField(t);
            if (df) {
                const { cost, W_, H_ } = df; let best = null, bd = 1e9;
                const ak = a.x >= 0 && a.z >= 0 && a.x < W_ && a.z < H_ ? a.x + a.z * W_ : -1;
                for (const [n, d] of Object.entries(DIRV)) { const nx = a.x + d[0], nz = a.z + d[1]; if (nx < 0 || nz < 0 || nx >= W_ || nz >= H_) continue; const v = cost[nx + nz * W_]; if (v < 1e8 && v < bd) { bd = v; best = n; } }
                if (best && ak >= 0 && (cost[ak] > 1e8 || bd < cost[ak] + 3)) return best;
            }
            const dx = t.x - a.x, dz = t.z - a.z;   // ไม่มีแผนที่/หาทางไม่ได้ → ลดแกนที่ไกลกว่าก่อน (เลี่ยงช่องที่เรียนรู้ว่าเดินไม่ได้)
            if (!dx && !dz) return null;
            const opts = Math.abs(dx) >= Math.abs(dz) ? [dx > 0 ? 'right' : 'left', dz > 0 ? 'down' : 'up'] : [dz > 0 ? 'down' : 'up', dx > 0 ? 'right' : 'left'];
            for (const o of opts) { const d = DIRV[o]; if (!(d[0] ? !dx : !dz) && !lbHas(a.x + d[0], a.z + d[1])) return o; }
            return opts[0];
        }
        // ⌨️ เดินด้วยปุ่มค้างต่อเนื่อง: วางเส้นทางทั้งทาง (เลี่ยงกำแพง/ช่องที่เรียนรู้ว่าตัน) → กดปุ่มค้างตลอดช่วงตรง เปลี่ยนปุ่มตรงมุมเลี้ยว ปล่อยเมื่อเข้าช่องเป้าหมาย
        const effKey = (dir) => { const eff = dir === 'up' || dir === 'down' ? (KEYFLIP.z ? (dir === 'up' ? 'down' : 'up') : dir) : (KEYFLIP.x ? (dir === 'left' ? 'right' : 'left') : dir); const [k, c, kc] = KEYMAP[eff]; return { key: k, code: c, keyCode: kc, which: kc, bubbles: true, cancelable: true }; };
        const diagOn = () => !D.noDiag && localStorage.getItem('at_walk_nodiag') !== '1';
        function planPath(mm, t) {          // รายการช่อง (เดินเฉียงได้ ไม่ตัดมุม) จากตัวเราไปเป้า ตามต้นทุนต่ำสุด · เสมอกันให้ไปทิศเดิม = เลี้ยวน้อย
            const diag = diagOn(), stair = !diag, df = costField(t, true); if (!df) return null;      // เดินเฉียงด้วย 2 ปุ่มไม่ได้ผล → วางทางแบบเฉียงแล้วแตกเป็นขั้นบันได (แกน X แล้วแกน Z สลับกัน) ให้ดูเนียนกว่าเดินเป็นเส้นตรงยาว
            const { cost, W_, H_ } = df; if (mm.x < 0 || mm.z < 0 || mm.x >= W_ || mm.z >= H_ || cost[mm.x + mm.z * W_] > 1e8) return null;
            const out = []; let cur = { x: mm.x, z: mm.z }, pv = null;
            for (let i = 0; i < 800; i++) {
                if (cur.x === t.x && cur.z === t.z) break;
                let best = null, bc = cost[cur.x + cur.z * W_];
                for (const d of D8) {
                    const nx = cur.x + d[0], nz = cur.z + d[1]; if (nx < 0 || nz < 0 || nx >= W_ || nz >= H_) continue;
                    if (d[0] && d[1] && (walkBlocked(cur.x + d[0], cur.z) || walkBlocked(cur.x, cur.z + d[1]))) continue;
                    const v = cost[nx + nz * W_]; const same = pv && pv[0] === d[0] && pv[1] === d[1];
                    if (v < bc - 1e-6 || (best && Math.abs(v - bc) < 1e-6 && same)) { bc = v; best = { x: nx, z: nz, vx: d[0], vz: d[1] }; }
                }
                if (!best) break;
                if (stair && best.vx && best.vz) { out.push({ x: cur.x + best.vx, z: cur.z, vx: best.vx, vz: 0 }, { x: best.x, z: best.z, vx: 0, vz: best.vz }); } else out.push(best);
                cur = best; pv = [best.vx, best.vz];
            }
            return out;
        }
        const vecDir = (vx, vz) => (vx && vz ? (vz < 0 ? (vx < 0 ? '↖' : '↗') : (vx < 0 ? '↙' : '↘')) : vx ? (vx < 0 ? '⬅' : '➡') : (vz < 0 ? '⬆' : '⬇'));
        // กดปุ่มค้าง (เฉียง = 2 ปุ่มพร้อมกัน) จนมินิแมพบอกว่าเข้าช่อง end · คืน {ok, cell, why}
        async function holdTo(vx, vz, end, cells, final) {
            const diag = !!(vx && vz), keys = [];
            if (vx) keys.push(effKey(vx < 0 ? 'left' : 'right')); if (vz) keys.push(effKey(vz < 0 ? 'up' : 'down'));
            const on = new Set(); for (const c of cells) for (let dx = -(diag ? 1 : 0); dx <= (diag ? 1 : 0); dx++) for (let dz = -(diag ? 1 : 0); dz <= (diag ? 1 : 0); dz++) on.add((c.x + dx) + ',' + (c.z + dz));
            for (const o of keys) document.dispatchEvent(new KeyboardEvent('keydown', o));
            const t0 = Date.now(); let last = minimapCell(), lastMove = Date.now(), res = { ok: false, cell: last, why: 'timeout' };
            try {
                while (!D.abort && Date.now() - t0 < 30000) {
                    await sleep(25); if (isTyping() && !(Date.now() - Pause.inputAt > 3000 && unfocusChat('ระหว่างเดิน'))) { res.why = 'typing'; break; }
                    const m = minimapCell(); if (!m) continue;
                    if (!last || m.x !== last.x || m.z !== last.z) {
                        if (!diag && last) { const dx = m.x - last.x, dz = m.z - last.z; if ((vx && dx && Math.sign(dx) !== vx) || (vz && dz && Math.sign(dz) !== vz)) { if (vx) KEYFLIP.x = !KEYFLIP.x; else KEYFLIP.z = !KEYFLIP.z; res = { ok: false, cell: m, why: 'flip' }; break; } }
                        last = m; lastMove = Date.now(); D.keyOk = true;
                        if (m.x === end.x && m.z === end.z) { res = { ok: true, cell: m, why: 'end' }; if (diag) D.diagOk = true; break; }
                        if (!on.has(m.x + ',' + m.z)) { res = { ok: false, cell: m, why: 'off' }; break; }
                    } else if (Date.now() - lastMove > (D.keyOk ? 650 : 1100)) { res = { ok: false, cell: m, why: 'stuck' }; break; }
                }
            } finally { for (const o of keys) document.dispatchEvent(new KeyboardEvent('keyup', o)); }
            if (final || !res.ok) await sleep(70);
            return res;
        }
        // ⌨️ เดินด้วยปุ่มแบบ "บังคับต่อเนื่อง": กดปุ่มค้างไว้แล้วเปลี่ยนทิศตอนเข้าช่องใหม่ (ไม่ปล่อยปุ่มทุกช่วง) · เฉียงได้ (กด 2 ปุ่ม)
        // ใกล้เป้า (≤1 ช่อง) ใช้แตะปุ่มสั้น ๆ แล้วรอให้นิ่ง กันไถเลยเป้า · ทิศเดิมยังดีพอ = คงทิศเดิม (ไม่ส่ายไปมา)
        function steerStep(mm, t, prev) {
            const df = costField(t, true);
            if (df) {
                const { cost, W_, H_ } = df; let best = null, bv = 1e9; const opts = [];
                for (const d of D8) {
                    if (d[0] && d[1] && !diagOn()) continue;
                    const nx = mm.x + d[0], nz = mm.z + d[1]; if (nx < 0 || nz < 0 || nx >= W_ || nz >= H_) continue;
                    if (d[0] && d[1] && (walkBlocked(mm.x + d[0], mm.z) || walkBlocked(mm.x, mm.z + d[1]))) continue;
                    const c = cost[nx + nz * W_]; if (c > 1e8) continue;
                    const v = c + (d[0] && d[1] ? 1.42 : 1); opts.push({ vx: d[0], vz: d[1], v });
                    if (v < bv) { bv = v; best = { vx: d[0], vz: d[1] }; }
                }
                if (best && prev) { const p = opts.find((o) => o.vx === prev.vx && o.vz === prev.vz); if (p && p.v <= bv + 0.35) return prev; }
                if (best) return best;
            }
            const dir = nextDir(mm, t); if (!dir) return null; const d = DIRV[dir]; return { vx: d[0], vz: d[1] };
        }
        async function goToKeys(t) {
            if (D.walking) { D.abort = true; await sleep(400); }
            D.walking = true; D.abort = false; D.target = t; KEYFLIP.x = false; KEYFLIP.z = false;
            const held = new Map();      // dir -> event options
            const dirsOf = (st) => { const w = []; if (st && st.vx) w.push(st.vx < 0 ? 'left' : 'right'); if (st && st.vz) w.push(st.vz < 0 ? 'up' : 'down'); return w; };
            const setKeys = (want) => {
                for (const [d, o] of [...held]) if (!want.includes(d)) { document.dispatchEvent(new KeyboardEvent('keyup', o)); held.delete(d); }
                for (const d of want) if (!held.has(d)) { const o = effKey(d); document.dispatchEvent(new KeyboardEvent('keydown', o)); held.set(d, o); }
            };
            const settle = async () => { let last = minimapCell(), at = Date.now(); const t0 = Date.now(); while (Date.now() - t0 < 900) { await sleep(60); const c = minimapCell(); if (c && last && (c.x !== last.x || c.z !== last.z)) { last = c; at = Date.now(); } else if (Date.now() - at > 260) break; } return minimapCell(); };
            try {
                lbSync();
                let prev = null, lastCell = null, lastMove = Date.now(), marks = 0, diagStuck = 0, taps = 0; const t0 = Date.now();
                while (!D.abort && Date.now() - t0 < 180000) {
                    await sleep(40);
                    if (isTyping() && !(Date.now() - Pause.inputAt > 3000 && unfocusChat('ระหว่างเดิน'))) { setKeys([]); say('กำลังพิมพ์แชท — หยุดเดินด้วยปุ่ม'); return; }
                    const mm = minimapCell(); if (!mm) continue;
                    if (!lastCell || mm.x !== lastCell.x || mm.z !== lastCell.z) {
                        if (lastCell && held.size === 2 && mm.x !== lastCell.x && mm.z !== lastCell.z) D.diagOk = true;
                        lastCell = mm; lastMove = Date.now();
                    }
                    if (mm.x === t.x && mm.z === t.z) {
                        setKeys([]); const m2 = await settle();
                        if (m2 && m2.x === t.x && m2.z === t.z) { say(`✅ ยืนที่ช่อง ${t.x}, ${t.z} แล้ว (WASD)`); return; }
                        prev = null; continue;      // ไถเลยไป → บังคับกลับ
                    }
                    if (t.chk && t.chk()) { setKeys([]); say(`ช่อง ${t.x}, ${t.z} มีผู้เล่นยืนอยู่ — เปลี่ยนช่อง`); return; }
                    lbSync();
                    const st = steerStep(mm, t, prev); if (!st) { setKeys([]); say('หาทางเดินไม่ได้'); return; }
                    const near = mm.x + st.vx === t.x && mm.z + st.vz === t.z;      // ก้าวถัดไปคือช่องเป้าพอดี
                    if (near) {      // ช่องสุดท้าย: แตะสั้น ๆ แล้วรอนิ่ง
                        setKeys([]); if (++taps > 14) { say(`เข้าช่อง ${t.x}, ${t.z} ไม่ได้ (ไถเลยซ้ำ ๆ)`); return; }
                        const w = dirsOf(st); setKeys(w); await sleep(110); setKeys([]); await settle();
                        prev = null; lastMove = Date.now(); continue;
                    }
                    if (!prev || prev.vx !== st.vx || prev.vz !== st.vz) say(`เดิน ${vecDir(st.vx, st.vz)} จาก ${mm.x}, ${mm.z} (เป้า ${t.x}, ${t.z})`);
                    prev = st; setKeys(dirsOf(st));
                    if (Date.now() - lastMove > 900) {      // กดค้างแล้วไม่ขยับ = ติด → จำช่องนั้นชั่วคราว (10 นาที ไม่บันทึกถาวร) แล้วหาทางใหม่
                        const nx = mm.x + st.vx, nz = mm.z + st.vz;
                        if (st.vx && st.vz && !D.diagOk && ++diagStuck >= 3) { D.noDiag = true; say('เดินเฉียงไม่ได้ผล — ใช้เดินแนวตรงแทน (รอบนี้)'); }
                        else { LB.set(nx + ',' + nz, Date.now()); D.df = null; say(`ติดที่ ${nx}, ${nz} — หาทางใหม่`); }
                        setKeys([]); prev = null; await sleep(150); lastMove = Date.now();
                        if (++marks > 16) { say('หาทางเดินไม่ได้ (ติดหลายจุด)'); return; }
                    }
                }
                const e = minimapCell(); if (e && !D.abort) say(e.x === t.x && e.z === t.z ? `✅ ยืนที่ช่อง ${t.x}, ${t.z} แล้ว (WASD)` : `หยุดที่ ${e.x}, ${e.z}`);
            } finally { setKeys([]); D.walking = false; if (!D.abort) setTimeout(() => { if (!D.walking) D.target = null; }, 4000); }
        }
        // โหมดเดิน: click = คลิกบนจอ · wasd = กดปุ่ม · auto = คลิกก่อน ถ้าไปไม่ถึงช่อง ใช้ WASD เก็บให้ตรง
        const walkMode = () => (State.opt && State.opt.walkMode) || 'auto';
        // 📍 จุดแวะบนเส้นทางจริง (เลี่ยงกำแพง): ไล่ตามเส้นทางถูกสุดจากตัวเราไปเป้า แล้วเลือกช่องที่ไกลที่สุดที่ยังอยู่ในจอเกม — เกมจะเดินไปให้เองถ้าช่องนั้นเดินถึง
        function pathWaypoint(mm, t, P) {
            const df = costField(t); if (!df) return null;
            const { cost, W_, H_ } = df, mx = P.r.width * 0.44, mz = P.r.height * 0.44;
            let cur = { x: mm.x, z: mm.z }, best = null;
            for (let i = 0; i < 80; i++) {
                let nb = null, bc = cost[cur.x + cur.z * W_] < 1e8 ? cost[cur.x + cur.z * W_] : 1e9;
                for (const d of Object.values(DIRV)) { const nx = cur.x + d[0], nz = cur.z + d[1]; if (nx < 0 || nz < 0 || nx >= W_ || nz >= H_) continue; const v = cost[nx + nz * W_]; if (v < bc) { bc = v; nb = { x: nx, z: nz }; } }
                if (!nb) break; cur = nb;
                if (Math.abs(cur.x + 0.5 - P.me.x) * P.px > mx || Math.abs(cur.z + 0.5 - P.me.z) * (P.pz || P.px) > mz) break;
                best = cur; if (cur.x === t.x && cur.z === t.z) break;
            }
            return best;
        }
        async function goTo(t) {
            const md = walkMode();
            if (md === 'wasd') return goToKeys(t);
            await goToClick(t);
            if ((md === 'auto' || D.selfBlock) && !D.abort) { const e = minimapCell(); if (e && (e.x !== t.x || e.z !== t.z)) { say(D.selfBlock ? 'ใกล้ตัวเกินไป (เสี่ยงคลิกโดนตัวเอง) — ใช้ WASD เก็บให้ตรง' : 'คลิกเดินไม่ตรงช่อง — ใช้ WASD เก็บให้ตรง'); await goToKeys(t); } }
        }
        async function goToClick(t) {
            D.selfBlock = false;
            if (zoomBad() && !(await ensureZoom100())) { say(`⚠️ ซูมเกมตอนนี้ ${gameZoom()}% และปรับเป็น 100% ให้เองไม่สำเร็จ — ปรับด้วยมือก่อนใช้ระบบเดิน`); return; }
            const gzNow = gameZoom(); if (gzNow !== D.gzLast) { D.gzLast = gzNow; D.frac = { x: [0, 1], z: [0, 1] }; }
            if (D.walking) { D.abort = true; await sleep(400); }
            D.walking = true; D.abort = false; D.target = t;
            try {
                const cv = canvasEl(); if (!cv) { say('ไม่พบหน้าจอเกม'); return; }
                let bad = 0, adjFail = 0, prevEarly = false, selfN = 0, awayN = 0, overN = 0, dFail = false;
                for (let i = 0; i < 90 && !D.abort; i++) {
                    const mm = minimapCell(); if (!mm) { say('อ่านตำแหน่งตัวละครจากมินิแมพไม่ได้'); return; }
                    if (mm.x === t.x && mm.z === t.z) { say(`✅ ยืนที่ช่อง ${t.x}, ${t.z} แล้ว`); return; }
                    if (t.chk && t.chk()) { say(`ช่อง ${t.x}, ${t.z} มีผู้เล่นยืนอยู่ — เปลี่ยนช่อง`); return; }
                    if (!D.lastEnd || D.lastEnd.x !== mm.x || D.lastEnd.z !== mm.z) D.frac = { x: [0, 1], z: [0, 1] };
                    const fr = D.frac, P = projector(mm);
                    lbSync();
                    const [tsx, tsy] = P.scr(t.x + 0.5, t.z + 0.5);
                    const direct = !dFail && tsx > P.r.left + P.r.width * 0.06 && tsx < P.r.right - P.r.width * 0.06 && tsy > P.r.top + P.r.height * 0.06 && tsy < P.r.bottom - P.r.height * 0.06;
                    const wp = direct ? { x: t.x, z: t.z } : pathWaypoint(mm, t, P), wx = wp ? wp.x : t.x, wz = wp ? wp.z : t.z;
                    let ox = wx + 0.5 - P.me.x, oz = wz + 0.5 - P.me.z;          // หน่วย "ช่อง" จากตัวเราถึงกลางช่องจุดแวะ/เป้าหมาย
                    const px = P.px, pz = P.pz || P.px, r = P.r;
                    const k = Math.max(Math.abs(ox * px) / (r.width * 0.4), Math.abs(oz * pz) / (r.height * 0.4), 1); ox /= k; oz /= k;
                    say(`กำลังเดินไป ${t.x}, ${t.z} (เหลือ ${Math.abs(t.x - mm.x) + Math.abs(t.z - mm.z)} ช่อง)`);
                    let [cxp, cyp] = P.scr(P.me.x + ox, P.me.z + oz);
                    // เกมไม่เดินถ้าคลิกโดนตัวละคร/มอน/NPC (เลือกเป้าแทน) → ห้ามคลิกบนสไปรต์ตัวเรา (สูง ~2 ช่องเหนือเท้า)
                    const [sx0, sy0] = P.scr(P.me.x, P.me.z);
                    const onSelf = (x, y) => Math.abs(x - sx0) < 0.9 * px && y > sy0 - 2.6 * px && y < sy0 + 0.9 * px;
                    if (onSelf(cxp, cyp)) {
                        const left = Math.abs(t.x - mm.x) + Math.abs(t.z - mm.z);
                        let pushed = false;
                        if (left > 3) for (const f of [1.6, 2.2, 3]) {
                            const [x2, y2] = P.scr(P.me.x + ox * f, P.me.z + oz * f);
                            if (!onSelf(x2, y2) && x2 > r.left + 4 && x2 < r.right - 4 && y2 > r.top + 4 && y2 < r.bottom - 4) { cxp = x2; cyp = y2; pushed = true; break; }
                        }
                        if (!pushed) { D.selfBlock = true; say(`จุดคลิกทับตัวเอง (เหลือ ${left} ช่อง) — สลับไปใช้ WASD`); return; }
                    }
                    { const sc = selfTargeted(); if (sc) { try { sc.click(); } catch (e) { /* ignore */ } await sleep(250); } }
                    clickAt(cv, cxp, cyp);
                    const wl = (m) => { try { Log.info('WALK', m); } catch (e) { /* ignore */ } };
                    wl(`คลิกเดิน #${i + 1}: จาก ${mm.x},${mm.z} → เป้า ${t.x},${t.z} · โหมด ${P.exact ? 'อ่านกล้องเกม(แม่น)' : 'ประมาณจากมินิแมพ'} · ตัวเรา(ทศนิยม) ${P.me.x.toFixed(2)},${P.me.z.toFixed(2)} · ช่อง=${P.px.toFixed(1)}px · จอเกม ${Math.round(r.width)}x${Math.round(r.height)} (canvas ${cv.width}x${cv.height}) · ซูมเกม ${gameZoom() || '?'}% · อัตราย่อ ${scaleRatio().toFixed(2)} · คลิกที่ ${Math.round(cxp)},${Math.round(cyp)} (กลางจอ ${Math.round(r.left + r.width / 2)},${Math.round(r.top + r.height / 2)}) · k=${k.toFixed(2)} · แผนที่ชน ${D.tm ? 'มี' : 'ไม่มี'} · จุดแวะ ${wp ? wp.x + ',' + wp.z : 'ไม่มี(คลิกตรงไปเป้า)'}`);
                    let last = `${mm.x},${mm.z}`, still = 0, moved = false, early = false; const t0 = Date.now();
                    while (Date.now() - t0 < 9000 && !D.abort) {
                        await sleep(150); const c = minimapCell(); const cur = c ? `${c.x},${c.z}` : last;
                        if (cur !== last) { moved = true; still = 0; last = cur; } else still++;
                        // ใกล้ถึงจุดแวะแล้ว (ยังเดินอยู่) → คลิกจุดถัดไปต่อทันที ไม่รอให้ตัวละครหยุด = เดินต่อเนื่อง ไม่สะดุด
                        if (moved && c && wp && !(wp.x === t.x && wp.z === t.z) && Math.max(Math.abs(c.x - wp.x), Math.abs(c.z - wp.z)) <= 1) { early = true; break; }
                        if (c && c.x === t.x && c.z === t.z && still >= 2) break;
                        if ((moved && still >= 8) || (!moved && still >= 6)) break;
                    }
                    const m1 = minimapCell() || mm;
                    try { Log.info('WALK', `ผลคลิก #${i + 1}: ${moved ? `ขยับ ${mm.x},${mm.z} → ${m1.x},${m1.z} (คาดว่า ${t.x},${t.z}; ต่าง ${m1.x - t.x},${m1.z - t.z})` : 'ตัวละครไม่ขยับ'} · ใช้เวลา ${((Date.now() - t0) / 1000).toFixed(1)} วิ`); } catch (e) { /* ignore */ }
                    { const sc = selfTargeted(); if (sc) {
                        try { sc.click(); } catch (e) { /* ignore */ }
                        wl(`คลิก #${i + 1} โดนตัวเอง — ปิดกล่องเป้าหมาย ไม่นำผลไปปรับสเกล`);
                        D.frac = { x: [0, 1], z: [0, 1] }; D.lastEnd = null; prevEarly = false; await sleep(300);
                        if (Math.abs(t.x - m1.x) + Math.abs(t.z - m1.z) <= 4 || ++selfN >= 2) { D.selfBlock = true; say('คลิกโดนตัวเอง — สลับไปใช้ WASD'); return; }
                        continue;
                    } }
                    if (!moved) {
                        if (dismissTarget()) { say('คลิกโดนผู้เล่น/เป้าหมายอื่น — ปิดกล่องเป้าหมายแล้วลองใหม่'); await sleep(300); }
                        if (direct) dFail = true; else if (wp) blkAdd(wx, wz, 1);     // จำช่องที่คลิกแล้วไม่ไป (ครั้งที่ 2 = ถาวร) → รอบหน้าเลือกทางอื่น
                        if (Math.abs(t.x - mm.x) + Math.abs(t.z - mm.z) <= 2 && ++adjFail >= 2) { say('เหลือ ≤2 ช่องแต่คลิกไม่ไป — ปล่อยให้ WASD เก็บก้าวสุดท้าย'); return; }
                        if (++bad >= 6) { say('ตัวละครไม่ขยับ (ช่องนั้นอาจเดินไม่ได้ หรือเกมไม่รับคลิกจากสคริปต์)'); return; }
                        D.frac = { x: [0, 1], z: [0, 1] }; continue;
                    }
                    if (early) { D.frac = { x: [0, 1], z: [0, 1] }; D.lastEnd = null; bad = 0; prevEarly = true; continue; }
                    const wasEarly = prevEarly; prevEarly = false;
                    { const mvx = m1.x - mm.x, mvz = m1.z - mm.z, mvd = Math.hypot(mvx, mvz), od = Math.hypot(ox, oz);
                      if (mvd >= 3 && od > 0 && (mvx * ox + mvz * oz) / (mvd * od) < 0.3) {      // เดินผิดทิศไปไกล → ไม่เรียนรู้จากรอบนี้
                          wl(`เดินผิดทิศ (ไป ${mvx},${mvz} แต่คลิกทิศ ${ox.toFixed(1)},${oz.toFixed(1)}) — ไม่นำไปปรับสเกล`);
                          D.frac = { x: [0, 1], z: [0, 1] }; D.lastEnd = null;
                          if (++awayN >= 2) { D.selfBlock = true; say('เดินผิดทิศ 2 ครั้ง — สลับไปใช้ WASD'); return; }
                          continue;
                      } }
                    if (!P.exact && !wasEarly) {     // เดินไกลกว่าที่คาดมาก = สเกลภาพบนจอเล็กกว่าที่ใช้คำนวณ (เช่นขยายหน้าต่าง) → ปรับสเกลแล้วคิดใหม่
                        const exC = Math.hypot(ox, oz), gotC = Math.hypot(m1.x - mm.x, m1.z - mm.z);
                        const over = exC >= 3 && gotC >= exC * 1.6;
                        overN = over ? overN + 1 : 0;      // ต้องเกินคาด 2 ครั้งติดถึงจะปรับ · ปรับได้ไม่เกิน 40% ต่อครั้ง (กันเรียนผิดจากคลิกพลาดครั้งเดียว)
                        if (over && overN >= 2) { overN = 0; try { Log.info('WALK', `เดินไกลเกินคาด 2 ครั้งติด (${gotC.toFixed(1)} ช่อง แทน ${exC.toFixed(1)}) · ซูมเกม ${D.gz}% · ช่อง ${pxNow()}px · จอ ${Math.round(P.r.width)}x${Math.round(P.r.height)}`); } catch (e) { /* ignore */ } }
                    }
                    // อัปเดตช่วงเศษของตำแหน่งย่อย (สมมติว่าตัวละครไปหยุดตรงจุดที่คลิก)
                    const upd = (a, c0, c1, o) => { const L = Math.max(fr[a][0], c1 - c0 - o), H = Math.min(fr[a][1], c1 + 1 - c0 - o); if (L >= H) return [0, 1]; return [Math.max(0, c0 + L + o - c1), Math.min(1, c0 + H + o - c1)]; };
                    if (!P.exact) D.frac = { x: upd('x', mm.x, m1.x, ox), z: upd('z', mm.z, m1.z, oz) };
                    D.lastEnd = { x: m1.x, z: m1.z };
                    if (direct && (m1.x !== t.x || m1.z !== t.z)) dFail = true;      // คลิกเป้าตรง ๆ แล้วไปไม่ถึง (ติดกำแพง/เกมหาทางไม่ได้) → ใช้จุดแวะตามเส้นทางแทน
                    if (k <= 1 && (m1.x !== t.x || m1.z !== t.z)) bad++; else bad = 0;
                    if (bad >= 6) { say(`ไปถึงใกล้ ๆ ที่ ${m1.x}, ${m1.z} แต่เข้าช่อง ${t.x}, ${t.z} เป๊ะไม่ได้ (เกมอาจหยุดก่อนถึงจุด)`); return; }
                }
                const e = minimapCell(); if (e && !D.abort) say(e.x === t.x && e.z === t.z ? `✅ ยืนที่ช่อง ${t.x}, ${t.z} แล้ว` : `หยุดที่ ${e.x}, ${e.z}`);
            } finally { D.walking = false; if (!D.abort) setTimeout(() => { if (!D.walking) D.target = null; }, 4000); }
        }
        // 🗣️ เดินไปหา NPC แล้วคลิกที่ตัว NPC เพื่อเปิดหน้าต่างคุย
        // 📡 เปลี่ยน CH (เซิร์ฟ) ไปห้องที่คนน้อยที่สุด: กดปุ่ม CH ข้างมินิแมพ → เมนู .ch-menu → แถวที่ "x/y" น้อยสุด (ไม่ใช่ห้องที่อยู่ ไม่เต็ม ไม่ซ้ำห้องที่เพิ่งลอง)
        const CH = { tried: {} };
        async function switchChannel(why, avoid) {
            const btn = document.querySelector('button.minimap-ch') || document.querySelector('.ch-picker .minimap-ch');
            if (!btn) { say('ไม่พบปุ่มเปลี่ยน CH'); return false; }
            const curTxt = () => norm(btn.textContent || '');
            const cur0 = (/CH\s*(\d+)/i.exec(curTxt()) || [])[1] || '';
            const menu = () => { const m = document.querySelector('.ch-menu'); return m && wvis(m) ? m : null; };
            if (!menu()) { wtap(btn); if (!(await wget(menu, 3000))) { say('เมนู CH ไม่เปิด'); return false; } await sleep(300); }
            const rows = []; const mn = menu();
            if (!mn) { say('เมนู CH ปิดไปก่อนอ่านรายการ'); return false; }
            const leaves = (n) => [...n.querySelectorAll('*')].filter((c) => !c.children.length);
            for (const n of mn.querySelectorAll('button,[role="button"],li,div')) {
                const lv = leaves(n); if (!lv.length) continue;
                const chL = lv.filter((c) => /^\s*CH\s*\d+\s*$/i.test(c.textContent || ''));
                if (chL.length !== 1) continue;
                const cL = lv.find((c) => /(\d+)\s*\/\s*(\d+)\s*$/.test(c.textContent || '')); if (!cL) continue;
                if (n.parentElement && n.parentElement !== mn && n.parentElement.closest('.ch-menu') && leaves(n.parentElement).filter((c) => /^\s*CH\s*\d+\s*$/i.test(c.textContent || '')).length === 1 && n.parentElement !== mn && ['LI', 'BUTTON'].includes(n.parentElement.tagName)) continue;
                const q = /(\d+)\s*\/\s*(\d+)\s*$/.exec(cL.textContent), num = (/CH\s*(\d+)/i.exec(chL[0].textContent) || [])[1];
                if (rows.some((r) => r.num === num)) continue;
                rows.push({ el: n, num, cnt: +q[1], max: +q[2], here: /อยู่ที่นี่/.test(n.textContent || '') || num === cur0 });
            }
            const now = Date.now();
            const base = rows.filter((r) => !r.here && r.cnt < r.max);
            let okA = avoid && avoid.size ? base.filter((r) => !avoid.has(r.num)) : base; if (!okA.length) okA = base;      // เลี่ยง CH ที่ตัวเราตัวอื่นอยู่ (ถ้ามีให้เลือก)
            const ok = okA.sort((a, b) => ((CH.tried[a.num] > now - 90000) - (CH.tried[b.num] > now - 90000)) || a.cnt - b.cnt);
            if (!ok.length) { wtap(btn); say('ไม่มี CH ว่างให้ย้าย'); return false; }
            const r = ok[0]; CH.tried[r.num] = now;
            say(`${why || 'ย้าย CH'}: CH ${cur0} → CH ${r.num} (${r.cnt}/${r.max} คน น้อยสุด)`);
            wtap(wclk(r.el));
            await wget(() => (/CH\s*(\d+)/i.exec(curTxt()) || [])[1] === r.num, 12000, 300);
            await sleep(3000);
            D.frac = { x: [0, 1], z: [0, 1] }; D.lastEnd = null;
            return true;
        }
        // ⚡ คลิกที่ตัว NPC ตรง ๆ (ถ้าเห็นบนจอ): เกมส่งคำขอคุยทันทีไม่ว่าอยู่ไกลแค่ไหน (โค้ดเกม: คลิก NPC = npc_talk) — เปิดคุยได้ = จบ ไม่ต้องเดินไปยืนข้าง ๆ
        async function quickTalk(o) {
            const isOpen = () => wvis(document.querySelector('.npc-dialog')) || !!wfind(/เลือกจากแผนที่โลก/)[0];
            if (isOpen()) return true;
            const cv = canvasEl(), mm = minimapCell(); if (!cv || !mm) return false;
            const dist = Math.max(Math.abs(mm.x - (o.c0 + o.c1) / 2), Math.abs(mm.z - (o.z0 + o.z1) / 2));
            const cx = (o.c0 + o.c1 + 1) / 2, cz = (o.z0 + o.z1 + 1) / 2;
            for (const up of [0.9, 0.5, 1.4]) {
                if (D.abort) return false;
                const P = projector(minimapCell() || mm), r = P.r, [X0, Y0] = P.scr(cx, cz), X = X0, Y = Y0 - up * P.px;
                if (X < r.left + 8 || X > r.right - 8 || Y < r.top + 8 || Y > r.bottom - 8) return false;      // NPC ไม่อยู่บนจอ
                dismissTarget();
                clickAt(cv, X, Y);
                let last = minimapCell() || mm, lastMove = Date.now(), moved = false; const t0 = Date.now();
                while (Date.now() - t0 < 15000 && !D.abort) {
                    await sleep(200);
                    if (isOpen()) return true;
                    const c = minimapCell(); if (c && (c.x !== last.x || c.z !== last.z)) { last = c; lastMove = Date.now(); moved = true; }
                    if (Date.now() - lastMove > (moved ? 1500 : 1200)) break;      // ไม่ขยับ = เกมไม่ได้พาเดิน
                }
                if (isOpen()) return true;
                dismissTarget();      // อาจคลิกโดนผู้เล่นที่ยืนทับ NPC → ปิดกล่องเป้าหมาย
                if (dist > 3 && !moved) return false;      // อยู่ไกลและเกมไม่พาเดิน → ต้องเดินไปเอง
            }
            return false;
        }
        async function talkTo(o, topt) {
            const avoidFront = !!(topt && topt.avoidFront);
            D.abort = false;
            const m = D.tm; if (!m) return;
            if (walkMode() !== 'wasd' && zoomBad() && !(await ensureZoom100()) && walkMode() === 'click') { say(`⚠️ ซูมเกมตอนนี้ ${gameZoom()}% และปรับเป็น 100% ให้เองไม่สำเร็จ — ปรับด้วยมือ หรือเปลี่ยนโหมดเดินเป็น WASD/อัตโนมัติ`); return; }
            const blocked = (x, z) => x < 0 || z < 0 || x >= m.w || z >= m.h || !!(m.col && m.col[z * m.w + x]) || m.objs.some((p) => p.kind === 'npc' && p.c1 - p.c0 <= 3 && p.z1 - p.z0 <= 3 && x >= p.c0 && x <= p.c1 && z >= p.z0 && z <= p.z1);
            // ช่องรอบ NPC (สูงสุด 8 ช่อง ตัดช่องที่เดินไม่ได้/ทับ NPC ออก) → เลือกช่องที่ไม่มีผู้เล่นยืน · ถ้าเต็มทุกช่อง รอจนมีช่องว่าง (สูงสุด 3 นาที)
            const ring = () => { const out = []; for (let z = o.z0 - 1; z <= o.z1 + 1; z++) for (let x = o.c0 - 1; x <= o.c1 + 1; x++) { if (x >= o.c0 && x <= o.c1 && z >= o.z0 && z <= o.z1) continue; if (!blocked(x, z)) out.push({ x, z }); } return out; };
            if (!ring().length) { say(`หาช่องยืนข้าง ${o.name || 'NPC'} ไม่ได้`); return; }
            if (await quickTalk(o)) { D.talkOk = true; say(`💬 เปิดหน้าต่างคุยกับ ${o.name || 'NPC'} แล้ว (คลิกตรง)`); return; }
            if (D.abort) return;
            const badStand = {}; let selfTry = 0;
            const npcOpen = () => wvis(document.querySelector('.npc-dialog')) || !!wfind(/เลือกจากแผนที่โลก/)[0];      // หน้าต่างคุยของเกม (เปิดช้าได้ถ้าเน็ตหน่วง)
            for (;;) {   // วนเลือกช่องยืนใหม่ ถ้าคลิกแล้วโดนตัวเองบัง
            if (npcOpen()) { D.talkOk = true; say(`💬 เปิดหน้าต่างคุยกับ ${o.name || 'NPC'} แล้ว`); return; }
            const failedAt = {}; const t0 = Date.now(); let e = null, waited = false, fullSince = 0, lastSw = 0;
            while (!e && !D.abort && Date.now() - t0 < 3600000) {
                const me = minimapCell() || D.me || { x: o.c0, z: o.z0 + 2 }; const lbs = playerLabels();
                const all = ring().map((c) => Object.assign(c, { d: Math.abs(c.x - me.x) + Math.abs(c.z - me.z) + (c.z > o.z1 && (avoidFront || (c.x >= o.c0 && c.x <= o.c1)) ? (avoidFront ? 8 : 3) : 0) + (badStand[c.x + ',' + c.z] ? 100 : 0), occ: occupiedCell(c.x, c.z, lbs) }));
                const free = all.filter((c) => !c.occ && !badStand[c.x + ',' + c.z] && !(failedAt[c.x + ',' + c.z] > Date.now() - 8000)).sort((a, b) => a.d - b.d);
                if (!free.length && all.length && all.every((c) => badStand[c.x + ',' + c.z])) { for (const k in badStand) delete badStand[k]; continue; }
                if (!free.length) {
                    const nocc = all.filter((c) => c.occ).length; waited = true;
                    if (nocc === all.length) { if (!fullSince) fullSince = Date.now(); } else fullSince = 0;
                    if (fullSince && Date.now() - fullSince > 6000 && Date.now() - lastSw > 12000) {      // เต็มจริง ๆ (ติดต่อกัน >6 วิ) → ย้าย CH ไปห้องที่คนน้อยสุด แล้ววนลูปต่อ
                        lastSw = Date.now(); fullSince = 0;
                        try { await switchChannel(`รอบ ${o.name || 'NPC'} เต็มทุกช่อง`); } catch (er) { say('ย้าย CH ไม่สำเร็จ: ' + (er && er.message)); }
                        continue;
                    }
                    say(`รอบ ${o.name || 'NPC'} ว่าง 0/${all.length} ช่อง (มีผู้เล่นยืน ${nocc}) — รอ/ย้าย CH… (${Math.round((Date.now() - t0) / 1000)} วิ)`);
                    dismissTarget(); await sleep(1500); continue;
                } else fullSince = 0;
                const c = free[0]; c.chk = () => occupiedCell(c.x, c.z);
                say(`${o.name || 'NPC'}: ช่องว่าง ${free.length}/${all.length} → เดินไปยืนที่ ${c.x}, ${c.z}…`);
                dismissTarget(); await goTo(c); if (D.abort) return;
                const e1 = minimapCell();
                if (e1 && Math.abs(e1.x - c.x) <= 1 && Math.abs(e1.z - c.z) <= 1) { e = e1; break; }
                failedAt[c.x + ',' + c.z] = Date.now(); say(`ช่อง ${c.x}, ${c.z} ไปไม่ถึง (อาจมีผู้เล่นยืน) — ลองช่องอื่น…`); dismissTarget(); await sleep(300);
            }
            if (!e) { const e2 = minimapCell(); say(`ยังไปไม่ถึงข้าง ${o.name || 'NPC'} ${waited ? '(หยุดหรือหมดเวลา 1 ชม.)' : ''} (อยู่ ${e2 ? e2.x + ',' + e2.z : '?'})`); return; }
            const cv = canvasEl(); if (!cv) return;
            const P = projector(e), px = P.px;
            const cx = (o.c0 + o.c1 + 1) / 2, cz = (o.z0 + o.z1 + 1) / 2;
            const dlgSel = '[class*="dialog" i],[class*="npc" i],[class*="shop" i],[class*="modal" i]';
            const mine = (n) => !!(n.closest && n.closest('#aetheria-dev,#aetheria-tracker,[id^="aetheria-"],[class*="at-"]'));
            const before = new Set([...document.querySelectorAll(dlgSel)].filter((n) => n.offsetParent));
            const dlgOpen = () => npcOpen() || [...document.querySelectorAll(dlgSel)].some((n) => n.offsetParent && !before.has(n) && !mine(n));
            const nm = String(o.name || '').trim().toLowerCase();
            // ป้ายชื่อ NPC บนหัว (ถ้าเป็น DOM): ใช้เป็นตำแหน่งจริง แม่นกว่าคำนวณ และไม่ชนผู้เล่นที่ยืนทับตัว NPC
            const findLabel = () => { if (!nm) return null; for (const n of document.querySelectorAll('div,span,b,p')) { if (n.children.length || mine(n)) continue; if ((n.textContent || '').trim().toLowerCase() !== nm) continue; const r = n.getBoundingClientRect(); if (r.width > 0 && r.height > 0 && r.bottom > 0 && r.top < innerHeight) return { n, r }; } return null; };
            // กล่องเป้าหมายของเกม (ชื่อ + Lv + ปุ่ม ✕): ถ้าไปติดผู้เล่น/มอนที่ไม่ใช่ NPC ให้กดปิดแล้วลองจุดอื่น
            const wrongTarget = () => {
                for (const n of document.querySelectorAll('div,span')) {
                    if (n.children.length || mine(n) || !/^Lv\.?\s*\d+$/i.test((n.textContent || '').trim())) continue;
                    let box = n.parentElement;
                    for (let i = 0; i < 3 && box; i++, box = box.parentElement) {
                        const close = [...box.querySelectorAll('button,[role="button"],span,div')].find((c) => !c.children.length && /^[✕×xX]$/.test((c.textContent || '').trim()));
                        if (close) return { text: norm(box.textContent), close };
                    }
                }
                return null;
            };
            const r0 = cv.getBoundingClientRect();
            const proj = (up) => { const [X0, Y0] = P.scr(cx, cz); return [X0, Y0 - up * px]; };
            const lab = findLabel();
            const pts = [];
            if (lab) { const lx = lab.r.left + lab.r.width / 2; pts.push(['label', lx, lab.r.top + lab.r.height / 2, lab.n], ['หัว', lx, lab.r.bottom + 0.3 * px], ['ตัวบน', lx, lab.r.bottom + 0.9 * px], ['ตัวล่าง', lx, lab.r.bottom + 1.5 * px]); }
            else for (const up of [1.3, 0.9, 0.5, 0.15]) pts.push(['คำนวณ', ...proj(up)]);
            // หามุมที่กดได้: ไล่จุดรอบตัว NPC เพิ่ม (สูง/ต่ำ × ซ้าย/กลาง/ขวา) — ใช้เมื่อจุดมาตรฐานไม่ติด
            for (const up of [1.0, 0.7, 1.5, 0.3]) for (const sx of [0, -0.3, 0.3]) { const [px0, py0] = proj(up); pts.push(['มุม', px0 + sx * px, py0]); }
            if (selfTry > 0) pts.length = Math.min(pts.length, 6);      // ลองยืนมุมใหม่: ใช้แค่จุดหลัก ๆ ให้เร็ว
            let ok = false, wrong = '', selfHit = false;
            const myName = String(readField(SELECTORS.charName, 'name') || '').trim().toLowerCase();
            for (const [kind, x, y, el] of pts) {
                if (kind === 'label' && el) { try { ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach((t) => el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0, view: PW }))); } catch (er) { /* ignore */ } }
                else clickAt(cv, x, y);
                await sleep(900);
                if (dlgOpen()) { ok = true; break; }
                const w = wrongTarget();
                if (w && myName && w.text.toLowerCase().includes(myName) && !(nm && w.text.toLowerCase().includes(nm))) { selfHit = true; try { w.close.click(); } catch (er) { /* ignore */ } await sleep(300); break; }
                if (w && !(nm && w.text.toLowerCase().includes(nm))) { wrong = w.text.slice(0, 40); try { w.close.click(); } catch (er) { /* ignore */ } await sleep(400); }
            }
            if (!ok) { for (let i = 0; i < 8 && !D.abort; i++) { await sleep(250); if (dlgOpen()) { ok = true; break; } } }      // เผื่อหน้าต่างขึ้นช้า (ping สูง)
            if (!ok && selfHit && selfTry < 4) {
                selfTry++; badStand[e.x + ',' + e.z] = 1;
                say(`ตัวเองบังที่ช่อง ${e.x}, ${e.z} (คลิกโดนตัวเอง) — ขยับไปช่องอื่น (${selfTry}/4)`); dismissTarget(); await sleep(300); continue;
            }
            if (!ok && !selfHit && selfTry < 3) {      // กดไม่ติดจากช่องนี้ (โดนคนอื่น/ไม่เจอหน้าต่าง) → ลองยืนอีกมุมรอบ NPC ก่อนจะย้าย CH
                selfTry++; badStand[e.x + ',' + e.z] = 1;
                say(`คลิกไม่ติดที่ช่อง ${e.x}, ${e.z}${wrong ? ` (โดน "${wrong}")` : ''} — ลองยืนอีกมุม (${selfTry}/3)`); dismissTarget(); await sleep(300); continue;
            }
            if (!ok && wrong) { say(`คลิกไปโดน "${wrong}" (ผู้เล่น/มอน) แทน NPC — ปิดเป้าหมายให้แล้ว · ลองเดินไปยืนอีกฝั่งของ NPC หรือรอให้คนหลบ`); return; }
            D.talkOk = ok;
            say(ok ? `💬 เปิดหน้าต่างคุยกับ ${o.name || 'NPC'} แล้ว` : `คลิกที่ ${o.name || 'NPC'} แล้ว (ยังตรวจไม่เจอหน้าต่างคุย — ดูในเกม)`);
            break;
            }
        }
        // 🌀 วาร์ปอัตโนมัติ: เดินไปคุย Alice Service → ข้อ "วาร์ป (เลือกจากแผนที่โลก)" → เลือกแมพ → กดวาร์ป/เดินไป
        const W = { run: false, abort: false };
        const wsay = (t, lv) => { const e = document.getElementById('at-warp-st'); if (e) e.textContent = t; try { Log[lv || 'info']('WARP', t); } catch (x) { /* ignore */ } };
        const wvis = (n) => !!(n && (n.offsetParent || (n.getClientRects && n.getClientRects().length)));
        const wmine = (n) => !!(n.closest && n.closest('#aetheria-dev,#aetheria-tracker,#aetheria-config,#aetheria-profit,[id^="aetheria-"]'));
        const wesc = (t) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        function wfind(re, sel) {
            const out = [];
            for (const n of document.querySelectorAll(sel || 'button,[role="button"],a,li,div,span,p,b,label,h1,h2,h3,h4')) {
                if (n.childElementCount > 8 || wmine(n) || !wvis(n)) continue;
                const t = norm(n.textContent || ''); if (!t || t.length > 160 || !re.test(t)) continue;
                if ([...n.children].some((c) => re.test(norm(c.textContent || '')))) continue;
                out.push(n);
            }
            return out;
        }
        const wclk = (n) => n.closest('button,[role="button"],a,li,[class*="option" i],[class*="btn" i]') || n;
        const wbtn = (re) => [...document.querySelectorAll('button,[role="button"],a,[class*="btn" i],[class*="button" i]')].find((b) => !wmine(b) && wvis(b) && re.test(norm(b.textContent || '')) && norm(b.textContent).length < 60);
        // คลิกแบบมีพิกัดกึ่งกลางของ element (เผื่อแผนที่อ่านตำแหน่งเมาส์) — ยิงชุดอีเวนต์ครั้งเดียว ไม่ซ้ำด้วย .click()
        function wtap(el) {
            const r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
            const o = { bubbles: true, cancelable: true, view: VIEW, clientX: x, clientY: y, button: 0, buttons: 1 };
            for (const t of ['pointerover', 'mouseover', 'pointermove', 'mousemove', 'pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
                try { el.dispatchEvent(/^pointer/.test(t) ? new PointerEvent(t, Object.assign({ pointerType: 'mouse', isPrimary: true }, o)) : new MouseEvent(t, o)); } catch (e) { /* ignore */ }
            }
        }
        const wcur = () => norm((queryGame(SELECTORS.mapName) || {}).textContent || '');
        const wautoBtn = () => queryGame(SELECTORS.autoToggle);
        const wautoOn = () => { const b = wautoBtn(); return !!b && (b.classList.contains('on') || b.getAttribute('aria-pressed') === 'true'); };
        async function wget(cond, ms, step) { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (W.abort) return null; const v = cond(); if (v) return v; await sleep(step || 150); } return null; }
        async function wAutoOff() {
            if (!wautoOn()) return true;
            pressKey('z', 'KeyZ', 90); await sleep(700);
            if (wautoOn()) { triggerClick(wautoBtn()); await sleep(700); }
            return !wautoOn();
        }
        const wCloseMap = () => { const c = wbtn(/^\s*(ปิด|✕|×|x)\s*$/i) || [...document.querySelectorAll('[aria-label*="close" i],[class*="close" i]')].find((n) => !wmine(n) && wvis(n)); if (c) triggerClick(c); };
        async function warpTo(destRaw, opt0) {
            const scan = !!(opt0 && opt0.scan), auto = !!(opt0 && opt0.auto);
            if (W.run) { wsay('กำลังทำงานอยู่ — กด ⏹ หยุด ก่อนถ้าจะเริ่มใหม่'); return; }
            const dest = norm(destRaw || ''); if (!dest && !scan) { wsay('ใส่ชื่อแมพปลายทางก่อน หรือเลือกจากรายการ', 'warn'); return; }
            if (Frame.captcha) { wsay('มีแคปช่าขึ้นอยู่ — ไม่ทำวาร์ปต่อ (ต้องกรอกเอง)', 'warn'); return; }
            if (InvLock.owner) {
                wsay(`รอระบบ "${InvLock.owner}" ทำงานเสร็จก่อน แล้วค่อยวาร์ป…`);
                const t0 = Date.now(); while (InvLock.owner && Date.now() - t0 < 45000 && !W.abort) await sleep(300);
                if (InvLock.owner) { wsay(`ระบบ "${InvLock.owner}" ใช้กระเป๋านานเกินไป — ยกเลิกการวาร์ป`, 'warn'); return; }
                await sleep(500);
            }
            if (dest && wcur().includes(dest)) { wsay(`อยู่ที่ ${dest} แล้ว`); return true; }
            W.run = true; W.abort = false; W.auto = auto; W.dest = dest; InvLock.owner = 'warp'; State.warpHold = true;
            const wasAuto = wautoOn(); let arrived = false, zoomWas = 0, zoneAuto = false;
            try {
                if (wasAuto) { wsay('ปิด Auto (Z) ชั่วคราว…'); await wAutoOff(); }
                // 1) เปิดหน้าต่างคุยกับ Alice (ถ้ายังไม่เปิด)
                let opt = wfind(/เลือกจากแผนที่โลก/)[0];
                if (walkMode() !== 'wasd' && zoomBad()) {
                    zoomWas = gameZoom(); wsay(`ซูมเกม ${zoomWas}% — ปรับเป็น 100% ชั่วคราว (เพื่อให้เดินตรง) แล้วจะคืนค่าให้หลังเสร็จ`);
                    if (!(await ensureZoom100())) { if (walkMode() === 'click') throw new Error(`ปรับซูมเกมเป็น 100% เองไม่สำเร็จ (ตอนนี้ ${gameZoom()}%) — ปรับด้วยมือ หรือเปลี่ยนโหมดเดินเป็น WASD/อัตโนมัติ`); wsay('ปรับซูมไม่สำเร็จ — ใช้ WASD เดินแทน'); zoomWas = 0; }
                }
                // คลิก Alice ไม่ติด (มักมีผู้เล่นยืนรุม/ทับ) → ย้าย CH ไปห้องที่คนน้อยสุดแล้วลองใหม่ วนไปจนสำเร็จหรือกดหยุด (เพดาน 1 ชม.)
                const tLoop = Date.now(); let talkFail = 0;
                while (!opt && !W.abort && Date.now() - tLoop < 3600000) {
                    update();
                    await wget(() => D.tm && D.tmFor === wcur().replace(/\s*Lv\.?[\d\-–\s]+$/i, '').trim() ? 1 : 0, 6000);
                    const npc = D.tm && D.tm.objs.find((o) => o.kind === 'npc' && /alice/i.test(o.name || ''));
                    if (!npc) throw new Error(`ไม่พบ NPC Alice ในแมพนี้ (${D.mapName || '?'}) — ไปที่เมืองหลวงก่อน`);
                    wsay(`เดินไปหา ${npc.name}…${talkFail ? ` (ครั้งที่ ${talkFail + 1})` : ''}`);
                    await talkTo(npc);
                    if (W.abort) break;
                    opt = await wget(() => wfind(/เลือกจากแผนที่โลก/)[0], 5000);
                    if (opt || W.abort) break;
                    talkFail++;
                    const why = D.msg ? ` (${D.msg})` : '';
                    wsay(`เปิดคุยกับ Alice ไม่สำเร็จ${why} — ย้าย CH แล้วลองใหม่ (ครั้งที่ ${talkFail})`, 'warn');
                    dismissTarget(); wEsc(); await sleep(400);
                    let moved = false;
                    try { moved = await switchChannel('คลิก Alice ไม่ติด'); } catch (er) { /* ignore */ }
                    if (!moved && !W.abort) await sleep(4000);
                }
                if (W.abort) throw new Error('ยกเลิกแล้ว');
                if (!opt) throw new Error('เปิดหน้าต่างคุยกับ Alice ไม่สำเร็จ (หมดเวลา 1 ชม.)');
                if (State.opt.warpHeal && !scan) {
                    const healRe = /^\s*(\d+\s*)?ขอรักษา/;
                    const h = wfind(healRe)[0];
                    if (!h) wsay('🩹 ไม่เจอตัวเลือก "ขอรักษาหน่อย" — ข้ามการรักษา', 'warn');
                    else {
                        wsay('🩹 เลือก "ขอรักษาหน่อย (ฟรี)"'); await sleep(500); wtap(wclk(h));
                        await sleep(1500);
                        opt = wfind(/เลือกจากแผนที่โลก/)[0];
                        if (!opt) {      // รักษาแล้วหน้าต่างปิด → คุยกับ Alice ใหม่เพื่อเลือกวาร์ป
                            wsay('🩹 รักษาแล้ว — คุยกับ Alice ใหม่เพื่อวาร์ป');
                            for (let t = 0; t < 3 && !opt && !W.abort; t++) {
                                update(); await wget(() => D.tm && D.tmFor === wcur().replace(/\s*Lv\.?[\d\-–\s]+$/i, '').trim() ? 1 : 0, 6000);
                                const npc2 = D.tm && D.tm.objs.find((o) => o.kind === 'npc' && /alice/i.test(o.name || ''));
                                if (!npc2) break;
                                await sleep(800); await talkTo(npc2);
                                opt = await wget(() => wfind(/เลือกจากแผนที่โลก/)[0], 5000);
                                if (!opt) { dismissTarget(); wEsc(); await sleep(500); }
                            }
                            if (W.abort) throw new Error('ยกเลิกแล้ว');
                            if (!opt) throw new Error('รักษาแล้วแต่เปิดคุยกับ Alice ใหม่ไม่สำเร็จ');
                        }
                    }
                }
                wsay('เลือก "วาร์ป (เลือกจากแผนที่โลก)"');
                await sleep(500); wtap(wclk(opt));
                if (scan) {
                    if (!(await wget(() => document.querySelectorAll('[class*="atlas-pin"]').length > 3, 10000))) throw new Error('แผนที่โลกไม่โหลดหมุด');
                    await sleep(600); const l = warpHarvest(); wCloseMap(); await sleep(500); wEsc();
                    wsay(`📋 โหลดรายชื่อแมพแล้ว ${l.length} แมพ (เลือกได้จากรายการด้านบน)`); arrived = true; return true;
                }
                // 2) เลือกแมพบนแผนที่โลก
                const re = new RegExp(wesc(dest), 'i');
                // เลือกเฉพาะหมุดบนแผนที่โลก (button.atlas-pin) หรือ element ในกล่อง worldmap — ห้ามไปจับข้อความชื่อแมพที่โผล่ในแชท
                const pins = () => [...document.querySelectorAll('[class*="pin" i]')].filter((pn) => !wmine(pn) && wvis(pn) && !pn.closest('[class*="chat" i]') && re.test(norm(pn.textContent || '')) && norm(pn.textContent).length < dest.length + 30);
                const pick = () => pins()[0] || wfind(re).filter((n) => n.closest('[class*="worldmap" i]') && !n.closest('[class*="inspect" i]') && !/วาร์ปไปที่นี่|เดินไปที่นี่/.test(n.textContent || '')).sort((a, b) => Math.abs(norm(a.textContent).length - dest.length) - Math.abs(norm(b.textContent).length - dest.length))[0];
                const node = await wget(pick, 10000);
                try { await sleep(300); warpHarvest(); } catch (e) { /* ignore */ }
                if (!node) {
                    const seen = [...new Set(wfind(/\S/, 'button,[role="button"],li,span').map((n) => norm(n.textContent)).filter((t) => t.length > 1 && t.length < 30))].slice(0, 25).join(' | ');
                    throw new Error(`ไม่พบ "${dest}" บนแผนที่โลก (ข้อความที่เห็น: ${seen || 'ไม่มี'})`);
                }
                wsay(`เลือกแมพ ${dest}`); await sleep(400);
                // ปุ่มวาร์ปขึ้นหลังกดจุด/ชื่อแมพ — ถ้ายังไม่ขึ้น ลองกด element อื่นของหมุดเดียวกัน (ตัวชื่อ → ปุ่มหมุด → ตัวห่อ)
                const findGo = () => wbtn(/วาร์ปไปที่นี่/) || wbtn(/เดินไปที่นี่/);
                const tries = [];
                pins().forEach((pn) => tries.push(pn));
                { let e = node; for (let i = 0; i < 3 && e && e !== document.body && !/worldmap/i.test(String(e.className)); i++, e = e.parentElement) if (!tries.includes(e)) tries.push(e); }
                const desc = (e) => e.tagName.toLowerCase() + (e.className && typeof e.className === 'string' ? '.' + e.className.trim().split(/\s+/).slice(0, 2).join('.') : '');
                let btn = null;
                for (const t of tries) {
                    if (W.abort) break; btn = findGo(); if (btn) break;
                    wsay(`กดหมุด ${desc(t)}`);
                    try { t.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) { /* ignore */ }
                    wtap(t); btn = await wget(findGo, 1500); if (btn) break;
                    try { t.focus(); t.click(); } catch (e) { /* ignore */ } btn = await wget(findGo, 1500); if (btn) break;
                }
                if (!btn) {
                    const bt = [...new Set([...document.querySelectorAll('button,[role="button"]')].filter((b) => !wmine(b) && wvis(b)).map((b) => norm(b.textContent)).filter((t) => t && t.length < 40))].slice(-14).join(' | ');
                    const ins = document.querySelector('[class*="inspect" i]'); const it = ins ? norm(ins.textContent).slice(0, 160) : '(ไม่พบกล่องรายละเอียดแมพ)';
                    wCloseMap(); throw new Error(`กดเลือก "${dest}" แล้วไม่เจอปุ่ม "วาร์ปไปที่นี่" / "เดินไปที่นี่" · กล่องรายละเอียด: ${it} · ปุ่ม: ${bt || 'ไม่มี'}`);
                }
                const isWarp = /วาร์ปไปที่นี่/.test(btn.textContent || '');
                wsay(isWarp ? `กด "วาร์ปไปที่นี่" → ${dest}` : `ยังไม่เคยไป ${dest} — กด "เดินไปที่นี่" (ปิด Z ระหว่างเดิน)`);
                await sleep(400); wtap(btn);
                // เกมอาจถามยืนยัน
                await sleep(900);
                if (wvis(document.querySelector('.npc-dialog'))) { wEsc(); await sleep(300); }
                { const cd = document.querySelector('.confirm-dialog'); if (cd && /วาร์ป|เดิน/.test(cd.textContent || '')) { const y = [...cd.querySelectorAll('button')].find((b) => /ตกลง|ยืนยัน|ใช่|OK/i.test(b.textContent || '')); if (y) triggerClick(y); } }
                // 3) รอจนถึงแมพปลายทาง (ระหว่างนี้คุม Z ให้ปิด)
                const lim = Date.now() + (isWarp ? 60000 : 20 * 60000);
                while (Date.now() < lim && !W.abort) {
                    if (wcur().includes(dest)) { arrived = true; break; }
                    if (Frame.captcha) throw new Error('มีแคปช่าขึ้นระหว่างทาง — หยุดวาร์ป (ต้องกรอกเอง)');
                    if (wautoOn()) await wAutoOff();
                    await sleep(500);
                }
                if (W.abort) throw new Error('ยกเลิกแล้ว');
                if (!arrived) throw new Error(isWarp ? 'วาร์ปแล้วแต่แมพไม่เปลี่ยนภายใน 1 นาที' : 'เดินไม่ถึงแมพปลายทางภายใน 20 นาที');
                wsay(`✅ ถึง ${dest} แล้ว`); wRecent(dest);
                try { showToast(`🌀 ถึง ${dest} แล้ว`, 'ok'); } catch (e) { /* ignore */ }
                if (State.opt.warpZone) zoneAuto = await flyToZone(dest); else if (State.opt.warpFly) await warpFly(dest);
            } catch (e) {
                wsay('❌ ' + (e && e.message ? e.message : e), 'warn');
            } finally {
                InvLock.owner = ''; W.run = false;
                if (zoomWas && zoomWas !== 100) { try { await setZoomTo(zoomWas); } catch (er) { /* ignore */ } }
                await sleep(arrived ? 250 : 200);
                const m = wcur();
                if (!RS.pending && (wasAuto || zoneAuto) && !Frame.captcha && !CONFIG.SAFE_MAPS.some((x) => m.includes(x)) && !wautoOn()) { pressKey('z', 'KeyZ', 90); Log.info('WARP', 'เปิด Auto (Z) คืนแล้ว'); await sleep(600); if (!wautoOn() && wautoBtn()) triggerClick(wautoBtn()); }
                State.warpHold = false;      // ปล่อยหลังเปิด Z แล้ว → อัพสเตตัส/ระบบอื่นเริ่มได้ขณะตัวละครฟาร์มอยู่
            }
            if (RS.pending) { const p = RS.pending; RS.pending = null; if (!W.abort) setTimeout(() => { flyRestock(p.field, p.why); }, 300); }
            return arrived;
        }
        const wEsc = () => { pressKey('Escape', 'Escape', 27); };
        const wclean = (t) => norm(t).replace(/\s*Lv\.?[\d\-–\s]+$/i, '').replace(/\s*ปลอดภัย$/, '').trim();
        // อ่านรายชื่อแมพจากหมุดบนแผนที่โลก (🌀 warpable = เคยไป)
        function warpHarvest() {
            const out = [];
            for (const pn of document.querySelectorAll('button[class*="atlas-pin"]')) {
                const lb = pn.querySelector('.atlas-label'); if (!lb) continue;
                const sm = lb.querySelector('small'); const n = norm((lb.firstChild && lb.firstChild.textContent) || '');
                if (!n) continue;
                out.push({ n, w: pn.classList.contains('warpable'), lv: sm ? norm(sm.textContent) : '', here: pn.classList.contains('here') });
            }
            if (out.length > 3) { try { lsSet('at_warp_maps', JSON.stringify(out)); } catch (e) { /* ignore */ } warpSel(); }
            return out;
        }
        function wRecent(n) {
            let r = []; try { r = JSON.parse(localStorage.getItem('at_warp_recent') || '[]'); } catch (e) { /* ignore */ }
            r = [n, ...r.filter((x) => x !== n)].slice(0, 5);
            try { lsSet('at_warp_recent', JSON.stringify(r)); } catch (e) { /* ignore */ } warpSel();
        }
        function warpSel() {
            const sel = document.getElementById('at-warp-sel'); if (!sel) return;
            let maps = []; try { maps = JSON.parse(localStorage.getItem('at_warp_maps') || '[]'); } catch (e) { /* ignore */ }
            if (!maps.length) { try { maps = JSON.parse(localStorage.getItem('at_warp_names') || '[]').map((n) => ({ n, w: null, lv: '' })); } catch (e) { /* ignore */ } }
            const cur = sel.value; sel.innerHTML = '<option value="">— เลือกแมพจากรายการ' + (maps.length ? '' : ' (กด 📋 โหลดรายชื่อก่อน)') + ' —</option>';
            for (const m of maps) { if (m.here) continue; const o = document.createElement('option'); o.value = m.n; o.textContent = `${m.w === null ? '' : m.w ? '🌀 ' : '🚶 '}${m.n}${m.lv ? ' · ' + m.lv : ''}`; sel.appendChild(o); }
            sel.value = cur;
            const rc = document.getElementById('at-warp-recent'); if (!rc) return; rc.innerHTML = '';
            let r = []; try { r = JSON.parse(localStorage.getItem('at_warp_recent') || '[]'); } catch (e) { /* ignore */ }
            for (const n of r) { const b = document.createElement('button'); b.className = 'at-btn-ghost'; b.style.cssText = 'width:auto;padding:2px 8px;font-size:10.5px'; b.textContent = '⟲ ' + n; b.title = 'กดเพื่อวาร์ปไปแมพนี้ทันที'; b.addEventListener('click', () => { warpPick(n); }); rc.appendChild(b); }
        }
        // 🪽 Fly Wing ในแถบด่วน (.hot-slot.item): หาช่องจากรูปไอคอน ↔ id ไอเทมใน wiki (ถ้าไอคอนซ้ำกับ Butterfly Wing จะไม่ใช้)
        // ช่องในแถบด่วนของไอเทมชื่อ name (ถ้าไอคอนซ้ำกับไอเทม other จะไม่นับ กันกดผิดชิ้น)
        function hotSlotOf(name, other) {
            try {
                const items = (Profit.db && Profit.db.items) || {}; const id = items[name] ? items[name][0] : 0; const bid = other && items[other] ? items[other][0] : -1;
                if (!id) return null;
                for (const sl of document.querySelectorAll('.hot-slot.item')) {
                    const im = sl.querySelector('img'); if (!im) continue;
                    const c = iconCands(im.getAttribute('src') || '');
                    if (c.includes(id) && !c.includes(bid)) return sl;
                }
            } catch (e) { /* ignore */ }
            return null;
        }
        const flySlot = () => hotSlotOf('Fly Wing', 'Butterfly Wing');
        const hotCnt = (sl) => { const q = sl && /x\s*([\d,]+)/i.exec((sl.querySelector('.hot-sub') || {}).textContent || ''); return q ? parseInt(q[1].replace(/,/g, ''), 10) : -1; };
        // 🦋 Fly Wing ใกล้หมด → Butterfly Wing กลับเมือง → ซื้อของ → วาร์ปกลับแมพเดิม (flyToZone ทำงานต่อเองใน warpTo)
        const RS = { busy: false, pending: null, fails: 0, at: 0 };
        const flyBuyMin = () => { const b = (State.opt.buy || []).find((x) => x && String(x.n || '').trim().toLowerCase() === 'fly wing' && +x.q > 0); return b ? Math.max(0, +b.min || 0) : -1; };
        function flyRestockCheck() {      // คืนข้อความปัญหา (ว่าง = พร้อม)
            if (flyBuyMin() < 0) return 'ยังไม่มี "Fly Wing" ในรายการ 🛒 ซื้อของอัตโนมัติ (ใส่ชื่อ เหลือ ≤ และจำนวนซื้อ) — ระบบกลับไปซื้อจะยังไม่ทำงาน';
            if (!hotSlotOf('Butterfly Wing', 'Fly Wing')) return 'ยังไม่มี Butterfly Wing ในแถบด่วน — ลากจากกระเป๋าไปใส่แถบด่วนก่อน';
            if (!State.opt.warpZone) return 'ต้องเปิด "🎯 ใช้ Fly Wing จนเข้าโซนฟาร์ม" ด้วย';
            return '';
        }
        const buyMinOf = (name) => { const b = (State.opt.buy || []).find((x) => x && String(x.n || '').trim().toLowerCase() === String(name).toLowerCase() && +x.q > 0); return b ? Math.max(0, +b.min || 0) : -1; };
        async function flyRestock(field, why, names) {
            names = names && names.length ? names : ['Fly Wing'];
            if (RS.busy || W.run) return false;
            RS.busy = true; RS.at = Date.now(); W.abort = false;
            try {
                const min = buyMinOf(names[0]);
                if (min < 0) { wsay(`🦋 ไม่มี ${names[0]} ในรายการซื้อของ — ไม่กลับไปซื้อ`, 'warn'); return false; }
                const bw = hotSlotOf('Butterfly Wing', 'Fly Wing');
                if (!bw) { wsay('⚠️ ไม่พบ Butterfly Wing ในแถบด่วน — กลับเมืองไปซื้อ Fly Wing ไม่ได้', 'warn'); try { showToast('🦋 ไม่พบ Butterfly Wing ในแถบด่วน', 'warn'); } catch (e) { /* ignore */ } RS.fails++; return false; }
                if (hotCnt(bw) === 0) { wsay('⚠️ Butterfly Wing หมด — กลับเมืองไปซื้อไม่ได้', 'warn'); RS.fails++; return false; }
                wsay(`🦋 ${why} (≤ ${min}) — ใช้ Butterfly Wing กลับเมืองไปซื้อ ${names.join(', ')}`);
                try { Log.info('WARP', `${why} → ใช้ Butterfly Wing กลับเมืองไปซื้อ`); showToast(`🦋 ${why} — กลับเมืองไปซื้อ`, 'warn'); } catch (e) { /* ignore */ }
                State.warpHold = true;
                await wAutoOff();
                const inTown = () => (/เมืองหลวง/.test(wcur()) ? 1 : 0);
                for (let t = 0; t < 2 && !inTown(); t++) { wtap(hotSlotOf('Butterfly Wing', 'Fly Wing') || bw); if (await wget(inTown, 12000, 300)) break; }
                if (!inTown()) { wsay('❌ ใช้ Butterfly Wing แล้วไม่กลับเมือง — ยกเลิก', 'warn'); RS.fails++; return false; }
                await sleep(2500);
                await buyRun();
                await sleep(800);
                const got = [];
                for (const nm of names) {
                    const n = await itemCount(nm), mn = buyMinOf(nm);
                    if (n >= 0 && mn >= 0 && n <= mn) { RS.fails++; wsay(`❌ ซื้อ ${nm} ไม่สำเร็จ (ยังเหลือ ${n}) — อยู่ในเมือง ไม่วาร์ปกลับ`, 'warn'); try { showToast(`🦋 ซื้อ ${nm} ไม่สำเร็จ — หยุดอยู่ในเมือง`, 'warn'); } catch (e) { /* ignore */ } return false; }
                    got.push(`${nm} ${n < 0 ? '?' : n}`);
                }
                RS.fails = 0;
                State.warpHold = false;
                if (W.abort || !field) return false;
                wsay(`🦋 ซื้อแล้ว (${got.join(', ')}) — วาร์ปกลับ ${field}`);
                return await warpTo(field, { auto: true });
            } catch (e) { wsay('❌ กลับไปซื้อ Fly Wing ไม่สำเร็จ: ' + (e && e.message ? e.message : e), 'warn'); return false; }
            finally { RS.busy = false; if (!W.run) State.warpHold = false; }
        }
        // ระหว่างฟาร์ม: Fly Wing ในแถบด่วนเหลือ ≤ ที่ตั้ง → กลับไปซื้อทันที
        setInterval(() => {
            try {
                if (RS.busy || RS.fails >= 3 || Date.now() - RS.at < 60000 || autoPaused()) return;
                if (!State.isGameReady || Frame.captcha || Frame.dead || isTyping() || autoBusy('restock')) return;
                const m = wclean(wcur()); if (!m || CONFIG.SAFE_MAPS.some((x) => m.includes(x)) || /คุก/.test(m)) return;
                if (State.opt.flyRestock && State.opt.warpZone && zonesFor(m).length) {
                    const min = flyBuyMin(), n = hotCnt(flySlot());
                    if (min >= 0 && n >= 0 && n <= min) { flyRestock(m, `Fly Wing เหลือ ${n}`); return; }
                }
                if (State.opt.supplyRestock) {      // 🧴 ของใช้อื่นในรายการซื้อของ
                    const low = (State.opt.buy || []).filter((b) => b && String(b.n || '').trim() && +b.q > 0 && !/^(butterfly|fly) wing$/i.test(String(b.n).trim()))
                        .map((b) => ({ n: String(b.n).trim(), min: Math.max(0, +b.min || 0), c: hotCnt(hotSlotOf(String(b.n).trim())) }))
                        .filter((x) => x.c >= 0 && x.c <= x.min);
                    if (!low.length) return;
                    const why = low.map((x) => `${x.n} เหลือ ${x.c}`).join(', ');
                    if (State.opt.newDry) { RS.at = Date.now() + 240000; Log.info('BUY', `[ทดลอง] ${why} — จะใช้ Butterfly Wing กลับเมืองไปซื้อ แล้ววาร์ปกลับ ${m} (ปิด 🧪 โหมดทดลองเพื่อให้ทำจริง)`); return; }
                    flyRestock(m, why, low.map((x) => x.n));
                }
            } catch (e) { /* ignore */ }
        }, 5000);
        // 👹 ตัวละครอยู่ในโซนห้ามเข้า / ใกล้จุดเกิดมอนอันตราย (Auto ไล่มอนเข้าไป หรือถูกไล่) → หลบกลับเข้าโซนฟาร์ม
        const DGW = { at: 0, dryAt: 0, busy: false };
        setInterval(async () => {
            try {
                if (!State.opt.dangerFlee || DGW.busy || autoPaused() || !State.isGameReady || Frame.captcha || Frame.dead || isTyping() || autoBusy('danger')) return;
                const m = zKey(); if (!m || CONFIG.SAFE_MAPS.some((x) => m.includes(x)) || /คุก/.test(m) || !zonesFor(m).length) return;
                const c = minimapCell(), bz = badNow().rects; if (!c || !bz.length || !inZones(bz, c)) return;
                if (Date.now() - DGW.at < 15000) return;
                DGW.at = Date.now();
                if (State.opt.newDry) { if (Date.now() - DGW.dryAt > 60000) { DGW.dryAt = Date.now(); Log.info('DANGER', `[ทดลอง] ตัวละครอยู่ในโซนห้ามเข้า/จุดเกิดมอนอันตรายที่ (${c.x}, ${c.z}) — จะหลบกลับเข้าโซนฟาร์ม (ปิด 🧪 โหมดทดลองเพื่อให้ทำจริง)`); } return; }
                DGW.busy = true; W.run = true; W.abort = false; W.auto = true; W.dest = m; State.warpHold = true;
                try {
                    Log.warn('DANGER', `👹 อยู่ในโซนห้ามเข้า/จุดเกิดมอนอันตรายที่ (${c.x}, ${c.z}) — หลบกลับเข้าโซนฟาร์ม`);
                    try { showToast('👹 เข้าโซนอันตราย — กำลังหลบ', 'warn'); } catch (e) { /* ignore */ }
                    await wAutoOff();
                    const ok = await flyToZone(m);
                    Log[ok ? 'ok' : 'warn']('DANGER', ok ? 'หลบกลับเข้าโซนฟาร์มแล้ว' : 'หลบไม่สำเร็จ (ดู Logs ของ WARP)');
                } finally { W.run = false; State.warpHold = false; DGW.busy = false; }
            } catch (e) { DGW.busy = false; }
        }, 2000);
        // 📡 ไม่มีความเคลื่อนไหวในแมพฟาร์ม (ไม่ได้ฆ่ามอน/ไม่มีดรอป) → ย้ายไป CH ที่คนน้อยสุด
        const CHW = { since: 0, map: '', at: 0, hist: [], busy: false };
        setInterval(async () => {
            try {
                if (!State.opt.chSwitch || CHW.busy || autoPaused() || !State.isGameReady || Frame.captcha || Frame.dead || isTyping() || autoBusy('ch')) { if (!CHW.busy) CHW.since = 0; return; }
                const m = wclean(wcur());
                if (!m || CONFIG.SAFE_MAPS.some((x) => m.includes(x)) || /คุก/.test(m) || !wautoOn()) { CHW.since = 0; return; }
                if (!CHW.since || CHW.map !== m) { CHW.since = Date.now(); CHW.map = m; }
                const lg = curLedger() || {}, act = Math.max(CHW.since, lg.lastGainAt || 0, Profit.lastKillAt || 0), idle = Date.now() - act;
                if (idle < Math.max(1, +State.opt.chMin || 5) * 60000 || Date.now() - CHW.at < 600000) return;
                CHW.hist = CHW.hist.filter((t) => Date.now() - t < 3600000); if (CHW.hist.length >= 3) return;
                CHW.at = Date.now(); CHW.hist.push(CHW.at);
                const mins = Math.round(idle / 60000);
                if (State.opt.newDry) { Log.info('CH', `[ทดลอง] ไม่ได้ฆ่ามอน/ไม่มีดรอปมา ${mins} นาทีที่ ${m} — จะย้ายไป CH ที่คนน้อยสุด (ปิด 🧪 โหมดทดลองเพื่อให้ทำจริง)`); return; }
                CHW.busy = true; W.run = true; W.abort = false; W.auto = true; W.dest = ''; State.warpHold = true;
                try {
                    await wAutoOff();
                    const ok = await switchChannel(`ไม่มีความเคลื่อนไหว ${mins} นาที`);
                    if (ok) {
                        Log.info('CH', `ย้าย CH แล้ว (ไม่มีความเคลื่อนไหว ${mins} นาทีที่ ${m})`);
                        sendDiscord('stall', { title: '📡 ย้าย CH อัตโนมัติ', description: `**${charLabel()}** ไม่ได้ฆ่ามอน/ไม่มีดรอปมา ${mins} นาทีที่ **${m}** → ย้ายไป ${readField(SELECTORS.channel, 'channel') || 'CH ใหม่'}`, color: 0x60a5fa, fields: [] }, { ping: false });
                        const zs = zonesFor(zKey());
                        if (State.opt.warpZone && zs.length && !inZones(zs, minimapCell())) await flyToZone(m);
                    }
                } finally { W.run = false; State.warpHold = false; CHW.busy = false; CHW.since = Date.now(); }
            } catch (e) { CHW.busy = false; }
        }, 10000);
        // 🖥️ ปิดภาพ 3D อยู่ แต่มีงานที่ต้องเดิน/คลิกในเกม (วาร์ป · ซื้อของ · เดินกลับโซน · ย้าย CH · หนีโซนอันตราย) → เปิดภาพชั่วคราว จบงาน 3 วิ แล้วปิดกลับ
        setInterval(() => {
            try {
                const need = !!(W.run || D.walking || RS.busy || ZG.busy || CHW.busy || DGW.busy);
                if (need) {
                    R3T.idleAt = 0;
                    if (State.opt.renderOff && !R3T.force) { R3T.force = true; applyRender(); Log.info('SYS', '🖥️ เปิดภาพ 3D ชั่วคราวระหว่างเดิน/วาร์ป/ซื้อของ (ตอนปิดภาพเกมเดินช้า คลิกพลาดง่าย)'); }
                    return;
                }
                if (R3T.force) {
                    if (!R3T.idleAt) R3T.idleAt = Date.now();
                    else if (Date.now() - R3T.idleAt > 3000) { R3T.force = false; R3T.idleAt = 0; applyRender(); if (State.opt.renderOff) Log.info('SYS', '🌙 งานเสร็จ — ปิดภาพ 3D กลับ'); }
                }
            } catch (e) { /* ignore */ }
        }, 400);
        // 👥 กระจาย CH: ตัวละครของเราหลายตัวฟาร์มแมพเดียวกัน CH เดียวกัน (แย่งมอนกันเอง) → ทยอยย้ายให้อยู่คนละ CH
        //    ตัวที่ชื่อเรียงก่อนอยู่ CH เดิม ตัวอื่นย้ายทีละตัวห่างกัน 20 วิ · เลี่ยง CH ที่ตัวเราตัวอื่นอยู่แล้ว · แต่ละจอย้ายได้ไม่ถี่กว่า 3 นาที
        const SPR = { at: 0, map: '', since: 0 };
        const chNum = (t) => { const x = String(t || ''); return (/CH\s*(\d+)/i.exec(x) || /(\d+)/.exec(x) || [])[1] || ''; };
        setInterval(async () => {
            try {
                if (!State.opt.chSpread || CHW.busy || autoPaused() || !State.isGameReady || Frame.captcha || Frame.dead || isTyping()) return;
                const m = wclean(wcur());
                if (!m || CONFIG.SAFE_MAPS.some((x) => m.includes(x)) || /คุก/.test(m) || !wautoOn()) { SPR.map = ''; return; }
                if (SPR.map !== m) { SPR.map = m; SPR.since = Date.now(); return; }
                if (Date.now() - SPR.since < 45000 || Date.now() - SPR.at < 180000) return;
                const btn = document.querySelector('button.minimap-ch'); const my = chNum(btn && btn.textContent); if (!my) return;
                const me = charLabel(), now = Date.now();
                const sameMap = Object.values(Live.peers).filter((p) => p && p.tab !== TAB_ID && p.name && p.name !== me && now - p.ts < 30000 && wclean(p.map || '') === m);
                const clash = sameMap.filter((p) => chNum(p.ch) === my);
                if (!clash.length) return;
                const group = clash.map((p) => p.name).concat(me).sort();
                const idx = group.indexOf(me); if (idx <= 0) return;      // ตัวแรกอยู่ที่เดิม
                if (Date.now() - SPR.since < 45000 + (idx - 1) * 20000) return;      // ทยอยย้าย ไม่ย้ายพร้อมกัน
                if (autoBusy('ch')) return;
                const avoid = new Set(sameMap.map((p) => chNum(p.ch)).filter(Boolean)); avoid.add(my);
                SPR.at = Date.now(); CHW.busy = true; W.run = true; W.abort = false; W.auto = true; W.dest = ''; State.warpHold = true;
                try {
                    await wAutoOff();
                    const ok = await switchChannel(`กระจาย CH (CH ${my} มี ${clash.map((p) => p.name).join(', ')} อยู่แล้ว)`, avoid);
                    if (ok) {
                        Log.info('CH', `👥 กระจาย CH: ย้ายออกจาก CH ${my} (ตัวเราอยู่ซ้ำ: ${clash.map((p) => p.name).join(', ')})`);
                        const zs = zonesFor(zKey());
                        if (State.opt.warpZone && zs.length && !inZones(zs, minimapCell())) await flyToZone(m);
                    }
                } finally { W.run = false; State.warpHold = false; CHW.busy = false; SPR.since = Date.now(); }
            } catch (e) { CHW.busy = false; }
        }, 10000);
        // ▶️ กลับไปฟาร์มต่อ: วาร์ปไปแมพฟาร์มล่าสุด → Fly Wing หาโซน → เปิด Auto
        async function resumeFarm() {
            if (W.run || RS.busy) { wsay('กำลังทำงานอื่นอยู่ — รอสักครู่ หรือกด ⏹ หยุด ก่อน', 'warn'); return; }
            bkSync(); const field = BK.field;
            if (!field) { wsay('ยังไม่มีแมพฟาร์มที่จำไว้ — ไปฟาร์มสักแมพก่อน แล้วค่อยใช้ปุ่มนี้', 'warn'); showToast('ยังไม่มีแมพฟาร์มที่จำไว้', 'warn'); return; }
            if (Frame.captcha) { wsay('มีแคปช่าอยู่ — ตอบก่อนแล้วค่อยกดใหม่', 'warn'); return; }
            State.isAutoEnabled = true; State.autoAttempts = 0; savePrefs();
            { const sw = document.getElementById('at-sw-auto'); if (sw) sw.classList.add('on'); updateAutoSum(); }
            const m = wclean(wcur());
            wsay(`▶️ กลับไปฟาร์มต่อที่ ${field}`); Log.info('WARP', `▶️ กลับไปฟาร์มต่อที่ ${field}`);
            if (m.includes(field)) {      // อยู่แมพฟาร์มแล้ว: หาโซน (ถ้าตั้งไว้) แล้วให้ระบบเปิด Auto เอง
                const zs = zonesFor(zKey());
                if (State.opt.warpZone && zs.length && !inZones(zs, minimapCell())) {
                    W.run = true; W.abort = false; W.auto = false; W.dest = field; State.warpHold = true;
                    try { await wAutoOff(); await flyToZone(field); } finally { W.run = false; State.warpHold = false; }
                }
                return;
            }
            if (!/เมืองหลวง/.test(m)) {      // อยู่แมพอื่น: ใช้ Butterfly Wing กลับเมืองก่อน
                const bw = hotSlotOf('Butterfly Wing', 'Fly Wing');
                if (!bw) { BK.pickGo = true; BK.pickAt = 0; wsay(`อยู่นอกเมือง และไม่มี Butterfly Wing ในแถบด่วน — กลับเมืองหลวงเอง แล้วระบบจะวาร์ปไป ${field} ให้`, 'warn'); return; }
                State.warpHold = true; await wAutoOff(); wtap(bw);
                const ok = await wget(() => (/เมืองหลวง/.test(wcur()) ? 1 : 0), 15000, 300);
                State.warpHold = false;
                if (!ok) { wsay('ใช้ Butterfly Wing แล้วไม่กลับเมือง — ยกเลิก', 'warn'); return; }
                await sleep(2500);
            }
            if (State.opt.buyOn) { try { await buyRun(); } catch (e) { /* ignore */ } }
            await warpTo(field, { auto: true });
        }
        // 🎯 โซนฟาร์ม: ผู้ใช้ลากกรอบช่อง (x,z) บนแผนที่ Dev ไว้ต่อแมพ · Fly Wing สุ่มวาร์ปจนตัวเรา (พิกัดมินิแมพ) เข้าโซนใดโซนหนึ่ง
        const ZK = 'at_fly_zones';
        const zKey = () => wclean(wcur());
        const zonesAll = () => { try { return JSON.parse(localStorage.getItem(ZK) || '{}') || {}; } catch (e) { return {}; } };
        const zonesFor = (map) => zonesAll()[map] || [];
        const zInfoUpdate = () => { const e = document.getElementById('at-zone-info'); if (e) { const k = zKey(), n = zonesFor(k).length; e.textContent = k ? `โซนของแมพ "${k}": ${n} โซน` : ''; } };
        // ⛔ โซนห้ามเข้า (วาดเอง) + 👹 มอนอันตราย (เลือกจาก wiki → ใช้จุดเกิดในไฟล์แมพ) — เก็บต่อแมพ
        const BZK = 'at_fly_nozones', DMK = 'at_danger_mons', SPK = 'at_fly_spots';
        // 📍 จุดยืนตี (เลือกเองบนแผนที่) — เก็บต่อแมพ [[x,z], ...]
        const spotsFor = (map) => { try { return (JSON.parse(localStorage.getItem(SPK) || '{}') || {})[map] || []; } catch (e) { return []; } };
        const spotsSave = (map, list) => { let a = {}; try { a = JSON.parse(localStorage.getItem(SPK) || '{}') || {}; } catch (e) { /* ignore */ } if (list.length) a[map] = list; else delete a[map]; try { lsSet(SPK, JSON.stringify(a)); } catch (e) { /* ignore */ } };
        const jget = (k) => { try { return JSON.parse(localStorage.getItem(k) || '{}') || {}; } catch (e) { return {}; } };
        const banFor = (map) => jget(BZK)[map] || [];
        const banSave = (map, list) => { const a = jget(BZK); if (list.length) a[map] = list; else delete a[map]; try { lsSet(BZK, JSON.stringify(a)); } catch (e) { /* ignore */ } D.badC = null; D.df = null; };
        const dangerFor = (map) => jget(DMK)[map] || [];
        const dangerSave = (map, ids) => { const a = jget(DMK); if (ids.length) a[map] = ids; else delete a[map]; try { lsSet(DMK, JSON.stringify(a)); } catch (e) { /* ignore */ } D.badC = null; D.df = null; };
        // ชนิดมอนของจุดเกิดในไฟล์แมพ (fixedMonster.monsterId หรือ property ที่ชื่อเกี่ยวกับมอน)
        function spawnMonIds(o) {
            const out = new Set();
            for (const [k, v] of Object.entries(o.props || {})) {
                if (!/mon|mob|enemy|spawn|kind/i.test(k)) continue;
                const t = typeof v === 'object' ? JSON.stringify(v) : String(v);
                for (const n of t.match(/\d+/g) || []) out.add(+n);
            }
            return [...out];
        }
        const isSpawnObj = (o) => o.kind === 'spawn' || /fixedMonster|spawn/i.test(o.type || '');
        function dangerRectsOf(m, map) {
            const ids = new Set(dangerFor(map)); if (!m || !ids.size) return [];
            const pad = Math.max(0, Math.min(15, +State.opt.dangerPad || 0)), out = [];
            for (const o of m.objs) { if (!isSpawnObj(o)) continue; if (spawnMonIds(o).some((id) => ids.has(id))) out.push([o.c0 - pad, o.z0 - pad, o.c1 + pad, o.z1 + pad]); }
            return out;
        }
        const tmFor = (map) => (D.tm && (D.tmFor === map || (D.tm.disp && (map.includes(D.tm.disp) || D.tm.disp.includes(map)))) ? D.tm : null);
        function badZones(map) { return banFor(map).concat(dangerRectsOf(tmFor(map), map)); }
        function badNow() {
            const now = Date.now(), map = zKey();
            if (!D.badC || D.badC.map !== map || now - D.badC.at > 2000 || D.badC.tm !== D.tm) { const rects = map ? badZones(map) : []; D.badC = { at: now, map, tm: D.tm, rects, sig: JSON.stringify(rects).length + ':' + rects.length }; }
            return D.badC;
        }
        const zonesSave = (map, list) => { const a = zonesAll(); if (list.length) a[map] = list; else delete a[map]; try { lsSet(ZK, JSON.stringify(a)); } catch (e) { /* ignore */ } zInfoUpdate(); };
        const inZones = (zs, c) => !!c && zs.some((z) => c.x >= z[0] && c.x <= z[2] && c.z >= z[1] && c.z <= z[3]);
        // 🗺️ หน้าต่างเลือกโซนฟาร์ม (แยกจาก Dev) — เลื่อน/ซูมแผนที่เองได้ ไม่ตามตัวละคร · ลากกรอบเลือกโซน · เก็บใน at_fly_zones (ซิงค์กับ Dev/ระบบวาร์ป)
        async function fetchMap(name) {
            const get = async (u) => { const r = await PW.fetch(u, { credentials: 'same-origin' }); if (!r.ok) throw new Error(r.status); return r.json(); };
            const ids = new Set();
            try { const at = await get('/world/atlas'); (at.links || []).forEach((l) => l.forEach((x) => ids.add(x))); } catch (e) { /* ignore */ }
            ['aet_capital', 'capital'].forEach((x) => ids.add(x));
            for (const id of [...new Set([...ids].flatMap((i) => [i, i.replace(/^aet_/, '')]))]) {
                let m = D.mapFiles[id];
                if (m === undefined) { try { m = parseTiled(id, await get(`/maps/${id}.json`)); } catch (e) { m = null; } D.mapFiles[id] = m; }
                if (m && m.disp && (name.includes(m.disp) || m.disp.includes(name))) return m;
            }
            return null;
        }
        const ZP = { el: null };
        function zoneEdit() {
            if (ZP.el) { ZP.el.style.display = 'flex'; ZP.refresh && ZP.refresh(); return; }
            if (!document.getElementById('aetheria-zone-css')) {
                const st = document.createElement('style'); st.id = 'aetheria-zone-css';
                st.textContent = `#aetheria-zone{position:fixed;z-index:1000000;display:flex;flex-direction:column;width:min(640px,96vw);max-height:92vh;left:max(8px,calc(50vw - 320px));top:60px;font-family:'Inter','Noto Sans Thai',system-ui,sans-serif;font-size:12px;color:var(--at-text);background:rgba(var(--at-bg-rgb),calc(.97*var(--at-op)));backdrop-filter:blur(16px);border-radius:16px;border:1px solid rgba(var(--at-acc-rgb),.3);box-shadow:0 20px 45px -15px rgba(var(--at-bg0-rgb),calc(.85*var(--at-op)));overflow:hidden;user-select:none}
#aetheria-zone .az-h{display:flex;align-items:center;gap:8px;padding:10px 12px;cursor:move;font-weight:700;font-size:13.5px;background:linear-gradient(180deg,rgba(var(--at-bg2-rgb),.95),rgba(var(--at-bg-rgb),.95));border-bottom:1px solid rgba(255,255,255,.08)}
#aetheria-zone .az-h .az-t{flex:1}#aetheria-zone .az-x{cursor:pointer;opacity:.7;padding:2px 6px;border-radius:6px}#aetheria-zone .az-x:hover{background:rgba(255,255,255,.12);opacity:1}
#aetheria-zone .az-bar{display:flex;gap:6px;flex-wrap:wrap;align-items:center;padding:8px 12px}
#aetheria-zone select,#aetheria-zone .az-bar button{background:rgba(255,255,255,.06);color:#e4e4e7;border:1px solid rgba(255,255,255,.12);padding:5px 9px;border-radius:7px;font-size:11px;font-weight:600;cursor:pointer;font-family:inherit}
#aetheria-zone .az-bar button:hover{background:rgba(255,255,255,.14)}
#aetheria-zone .az-bar button.az-on{background:rgba(var(--at-acc-rgb),.2);border-color:var(--at-acc);color:var(--at-acc)}
#aetheria-zone select{flex:1;min-width:140px;max-width:100%}
#aetheria-zone .az-cv{margin:0 12px;border-radius:10px;border:1px solid rgba(var(--at-acc-rgb),.25);overflow:hidden;background:#0b0b12;height:min(46vh,380px);position:relative;touch-action:none}
#aetheria-zone canvas{width:100%;height:100%;display:block;cursor:crosshair}
#aetheria-zone .az-info{padding:6px 12px 0;opacity:.85;min-height:18px;font-size:11px}
#aetheria-zone .az-list{display:flex;gap:6px;flex-wrap:wrap;padding:6px 12px 12px}
#aetheria-zone .az-chip{display:flex;align-items:center;gap:6px;padding:3px 8px;border-radius:999px;background:rgba(250,204,21,.14);border:1px solid rgba(250,204,21,.5);color:#fde68a;font-size:11px}
#aetheria-zone .az-chip.ban{background:rgba(248,113,113,.14);border-color:rgba(248,113,113,.55);color:#fecaca}
#aetheria-zone .az-danger{padding:0 12px 8px;font-size:11px}
#aetheria-zone .az-danger .az-dt{font-weight:700;margin:2px 0 4px;color:#fdba74}
#aetheria-zone .az-danger label{display:inline-flex;align-items:center;gap:4px;margin:0 10px 4px 0;cursor:pointer}
#aetheria-zone .az-chip i{cursor:pointer;font-style:normal;opacity:.7}#aetheria-zone .az-chip i:hover{opacity:1;color:#fca5a5}
#aetheria-zone .az-hint{padding:0 12px 4px;opacity:.6;font-size:10.5px}`;
                document.head.appendChild(st);
            }
            const el = document.createElement('div'); el.id = 'aetheria-zone'; ZP.el = el;
            el.innerHTML = `<div class="az-h"><span>🎯</span><span class="az-t">โซนฟาร์ม (Fly Wing)</span><span class="az-x" id="az-close" title="ปิด">✕</span></div>
<div class="az-bar"><select id="az-map" title="เลือกแมพที่จะกำหนดโซน"></select><button id="az-draw" class="az-on" title="ลากเป็นกรอบเพื่อเพิ่มโซนฟาร์ม">▭ โซนฟาร์ม</button><button id="az-ban" title="ลากเป็นกรอบเพื่อเพิ่มโซนห้ามเข้า (เลี่ยงมอนตีแรง)">⛔ ห้ามเข้า</button><button id="az-spot" title="คลิกบนแผนที่เพื่อวางจุดยืนตี (วางได้หลายจุด)">📍 จุดยืนตี</button><button id="az-pan" title="ลากเพื่อเลื่อนแผนที่">✋ เลื่อน</button><button id="az-zo" title="ซูมออก">−</button><button id="az-zi" title="ซูมเข้า">＋</button><button id="az-fit" title="ดูทั้งแมพ">⤢ ทั้งแมพ</button><button id="az-me" title="เลื่อนไปที่ตัวเรา">📍 ตัวเรา</button></div>
<div class="az-cv" id="az-cv"><canvas id="az-c"></canvas></div>
<div class="az-info" id="az-info"></div>
<div class="az-danger" id="az-danger"></div>
<div class="az-hint">🟨 โซนฟาร์ม · 🟥 ห้ามเข้า · 🟧 จุดเกิดมอนอันตราย (จากไฟล์แมพ) · 📍 จุดยืนตี (โหมด 📍 คลิกเพื่อวาง) · ลากซ้ายบนแผนที่ = วาดโซน · ลากขวา/ล้อกลางหรือโหมด ✋ = เลื่อน · ล้อเมาส์ = ซูม · คลิกขวาที่โซน = ลบ · บันทึกอัตโนมัติ · ใช้ได้ทุกขนาดจอ</div>
<div class="az-list" id="az-list"></div>`;
            document.body.appendChild(el);
            const $ = (id) => el.querySelector('#' + id), cv = $('az-c'), box = $('az-cv');
            ['pointerdown', 'mousedown', 'click', 'keydown', 'keyup', 'wheel', 'contextmenu'].forEach((t) => el.addEventListener(t, (e) => { e.stopPropagation(); }));
            const P = { name: '', m: null, vx0: 0, vz0: 0, s: 10, mode: 'draw', zs: null, ze: null, pan: null, hover: null, msg: '' };
            const css = (n) => (getComputedStyle(document.documentElement).getPropertyValue(n) || '').trim();
            const size = () => { const r = box.getBoundingClientRect(), d = window.devicePixelRatio || 1; const w = Math.max(50, Math.round(r.width)), h = Math.max(50, Math.round(r.height)); if (cv.width !== Math.round(w * d) || cv.height !== Math.round(h * d)) { cv.width = Math.round(w * d); cv.height = Math.round(h * d); } return { w, h, d }; };
            const fit = () => { const { w, h } = size(); if (!P.m) return; P.s = Math.max(1.5, Math.min(w / P.m.w, h / P.m.h)); P.vx0 = (P.m.w - w / P.s) / 2; P.vz0 = (P.m.h - h / P.s) / 2; };
            const meNow = () => (P.name && P.name === zKey() ? minimapCell() : null);
            const clampC = (c) => ({ x: Math.max(0, Math.min(P.m.w - 1, c.x)), z: Math.max(0, Math.min(P.m.h - 1, c.z)) });
            const cellAt = (e) => { const r = cv.getBoundingClientRect(); return { x: Math.floor(P.vx0 + (e.clientX - r.left) / P.s), z: Math.floor(P.vz0 + (e.clientY - r.top) / P.s) }; };
            const zl = () => zonesFor(P.name);
            const renderList = () => {
                const l = $('az-list'), zs = zl(); l.innerHTML = '';
                zs.forEach((z, i) => { const c = document.createElement('div'); c.className = 'az-chip'; c.innerHTML = `<span>โซน ${i + 1} · ${z[0]},${z[1]} → ${z[2]},${z[3]} (${(z[2] - z[0] + 1) * (z[3] - z[1] + 1)} ช่อง)</span><i title="ลบโซนนี้">✕</i>`; c.querySelector('i').onclick = () => { const a = zl().slice(); a.splice(i, 1); zonesSave(P.name, a); renderList(); }; l.appendChild(c); });
                if (zs.length) { const c = document.createElement('div'); c.className = 'az-chip'; c.style.cssText += ';background:rgba(248,113,113,.12);border-color:rgba(248,113,113,.5);color:#fecaca;cursor:pointer'; c.textContent = '🗑️ ล้างโซนฟาร์มทั้งหมด'; c.onclick = () => { zonesSave(P.name, []); renderList(); }; l.appendChild(c); }
                banFor(P.name).forEach((z, i) => { const c = document.createElement('div'); c.className = 'az-chip ban'; c.innerHTML = `<span>⛔ ห้ามเข้า ${i + 1} · ${z[0]},${z[1]} → ${z[2]},${z[3]}</span><i title="ลบ">✕</i>`; c.querySelector('i').onclick = () => { const a = banFor(P.name).slice(); a.splice(i, 1); banSave(P.name, a); renderList(); draw(); }; l.appendChild(c); });
                spotsFor(P.name).forEach((p, i) => { const c = document.createElement('div'); c.className = 'az-chip'; c.style.cssText += ';background:rgba(74,222,128,.14);border-color:rgba(74,222,128,.55);color:#bbf7d0'; c.innerHTML = `<span>📍 จุดยืนตี ${i + 1} · ${p[0]}, ${p[1]}${zl().length && !inZones(zl(), { x: p[0], z: p[1] }) ? ' (นอกโซน)' : ''}</span><i title="ลบ">✕</i>`; c.querySelector('i').onclick = () => { const a = spotsFor(P.name).slice(); a.splice(i, 1); spotsSave(P.name, a); renderList(); draw(); }; l.appendChild(c); });
                renderDanger();
            };
            // 👹 รายชื่อมอนในแมพ (จาก wiki) ให้ติ๊กว่าตัวไหนอันตราย → ใช้จุดเกิดของมันในไฟล์แมพเป็นพื้นที่ห้ามเข้า
            const renderDanger = () => {
                const box = $('az-danger'); if (!box) return; box.innerHTML = '';
                const t = document.createElement('div'); t.className = 'az-dt'; t.textContent = '👹 มอนอันตรายในแมพนี้ (ติ๊ก = เลี่ยงจุดเกิดของมัน)'; box.appendChild(t);
                if (!Info.data) { const n = document.createElement('div'); n.textContent = '⏳ กำลังโหลดข้อมูลมอนจาก wiki…'; box.appendChild(n); infoLoad().then(renderDanger, () => {}); return; }
                const e = mapIndex().get(P.name);
                if (!e) { const n = document.createElement('div'); n.style.opacity = '.7'; n.textContent = 'ไม่พบข้อมูลมอนของแมพนี้ใน wiki'; box.appendChild(n); return; }
                const sel = new Set(dangerFor(P.name));
                for (const x of [...e.mons.values()].sort((a, b) => (b.m.level || 0) - (a.m.level || 0))) {
                    const lb = document.createElement('label'); const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = sel.has(x.m.id);
                    cb.onchange = () => { const s2 = new Set(dangerFor(P.name)); if (cb.checked) s2.add(x.m.id); else s2.delete(x.m.id); dangerSave(P.name, [...s2]); renderDanger(); draw(); };
                    lb.append(cb, document.createTextNode(`${x.m.name} Lv.${x.m.level}`)); box.appendChild(lb);
                }
                if (P.m && sel.size) {
                    const n = dangerRectsOf(P.m, P.name).length, anyIds = P.m.objs.some((o) => isSpawnObj(o) && spawnMonIds(o).length);
                    const d = document.createElement('div'); d.style.cssText = 'margin-top:2px;opacity:.85';
                    d.textContent = n ? `🟧 พบจุดเกิดของมอนที่เลือก ${n} จุด ในไฟล์แมพ (ขยายออก ${State.opt.dangerPad} ช่อง)` : anyIds ? '⚠️ ไม่พบจุดเกิดของมอนที่เลือกในไฟล์แมพ (อาจเกิดแบบสุ่มทั้งแมพ) — วาด ⛔ ห้ามเข้า เองบริเวณที่มันอยู่' : '⚠️ ไฟล์แมพนี้ไม่บอกชนิดมอนของจุดเกิด — วาด ⛔ ห้ามเข้า เองบริเวณที่มันอยู่แทน';
                    box.appendChild(d);
                }
            };
            const draw = () => {
                const { w, h, d } = size(), c = cv.getContext('2d'); c.setTransform(d, 0, 0, d, 0, 0);
                c.fillStyle = '#0b0b12'; c.fillRect(0, 0, w, h);
                const m = P.m; if (!m) { c.fillStyle = '#9ca3af'; c.font = '13px sans-serif'; c.fillText(P.msg || 'เลือกแมพ…', 16, 28); return; }
                const s = P.s, X = (k) => (k - P.vx0) * s, Z = (k) => (k - P.vz0) * s, acc = css('--at-acc') || '#a78bfa';
                c.fillStyle = '#1e293b'; c.fillRect(X(0), Z(0), m.w * s, m.h * s);
                if (m.col) { c.fillStyle = '#475569'; for (let z = Math.max(0, Math.floor(P.vz0)); z < Math.min(m.h, Math.ceil(P.vz0 + h / s)); z++) for (let x = Math.max(0, Math.floor(P.vx0)); x < Math.min(m.w, Math.ceil(P.vx0 + w / s)); x++) if (m.col[z * m.w + x]) c.fillRect(X(x), Z(z), s + .5, s + .5); }
                if (s >= 8) { c.strokeStyle = 'rgba(255,255,255,.07)'; c.lineWidth = 1; c.beginPath(); for (let x = Math.max(0, Math.ceil(P.vx0)); x <= Math.min(m.w, P.vx0 + w / s); x++) { c.moveTo(X(x), 0); c.lineTo(X(x), h); } for (let z = Math.max(0, Math.ceil(P.vz0)); z <= Math.min(m.h, P.vz0 + h / s); z++) { c.moveTo(0, Z(z)); c.lineTo(w, Z(z)); } c.stroke(); }
                const col = { npc: ['#38bdf8', 'rgba(56,189,248,.35)'], spawn: ['#f87171', 'rgba(248,113,113,.22)'], portal: ['#c084fc', 'rgba(192,132,252,.45)'] };
                for (const o of m.objs) { const k = col[o.kind]; if (!k) continue; const x = X(o.c0), y = Z(o.z0), ww = (o.c1 - o.c0 + 1) * s, hh = (o.z1 - o.z0 + 1) * s; if (x > w || y > h || x + ww < 0 || y + hh < 0) continue; c.fillStyle = k[1]; c.strokeStyle = k[0]; c.lineWidth = 1; c.fillRect(x, y, ww, hh); c.strokeRect(x, y, ww, hh); if (s >= 9 && o.kind !== 'spawn' && o.name) { c.fillStyle = '#e5e7eb'; c.font = '10px sans-serif'; c.fillText(String(o.name).slice(0, 14), x + 2, y + 10); } }
                const zs = zl(); c.lineWidth = 2;
                zs.forEach((z, i) => { const x = X(z[0]), y = Z(z[1]), ww = (z[2] - z[0] + 1) * s, hh = (z[3] - z[1] + 1) * s; c.fillStyle = 'rgba(250,204,21,.24)'; c.strokeStyle = '#facc15'; c.fillRect(x, y, ww, hh); c.strokeRect(x, y, ww, hh); c.fillStyle = '#fde68a'; c.font = 'bold 11px sans-serif'; c.fillText('โซน ' + (i + 1), x + 4, y + 13); });
                const rect = (z, fill, stroke, label) => { const x = X(z[0]), y = Z(z[1]), ww = (z[2] - z[0] + 1) * s, hh = (z[3] - z[1] + 1) * s; c.fillStyle = fill; c.strokeStyle = stroke; c.fillRect(x, y, ww, hh); c.strokeRect(x, y, ww, hh); if (label) { c.fillStyle = '#fff'; c.font = 'bold 11px sans-serif'; c.fillText(label, x + 4, y + 13); } };
                dangerRectsOf(m, P.name).forEach((z) => rect(z, 'rgba(251,146,60,.28)', '#fb923c', ''));
                banFor(P.name).forEach((z, i) => rect(z, 'rgba(239,68,68,.32)', '#ef4444', '⛔ ' + (i + 1)));
                spotsFor(P.name).forEach((p, i) => {      // 📍 จุดยืนตี + วงล่าโดยประมาณ (ถ้าเปิดปรับระยะล่า)
                    const cx = X(p[0] + 0.5), cy = Z(p[1] + 0.5), rr = State.opt.zoneFit && zs.length ? fitRadius(zs, { x: p[0], z: p[1] }) : 0;
                    if (rr > 0) { c.beginPath(); c.arc(cx, cy, rr * s, 0, Math.PI * 2); c.fillStyle = 'rgba(74,222,128,.10)'; c.strokeStyle = 'rgba(74,222,128,.7)'; c.setLineDash([4, 3]); c.fill(); c.stroke(); c.setLineDash([]); }
                    c.beginPath(); c.arc(cx, cy, Math.max(4, s * 0.6), 0, Math.PI * 2); c.fillStyle = '#22c55e'; c.strokeStyle = '#fff'; c.lineWidth = 1.5; c.fill(); c.stroke();
                    c.fillStyle = '#fff'; c.font = 'bold 11px sans-serif'; c.fillText(`📍${i + 1}${rr ? ' · ' + rr : ''}`, cx + Math.max(6, s * 0.7), cy - 4);
                });
                if (P.zs && P.ze) { const a = Math.min(P.zs.x, P.ze.x), b = Math.min(P.zs.z, P.ze.z), ww = Math.abs(P.zs.x - P.ze.x) + 1, hh = Math.abs(P.zs.z - P.ze.z) + 1; c.setLineDash([5, 3]); c.strokeStyle = '#fff'; c.fillStyle = 'rgba(255,255,255,.2)'; c.fillRect(X(a), Z(b), ww * s, hh * s); c.strokeRect(X(a), Z(b), ww * s, hh * s); c.setLineDash([]); c.fillStyle = '#fff'; c.font = '11px sans-serif'; c.fillText(`${ww}×${hh}`, X(a) + 4, Z(b) - 4 < 12 ? Z(b) + hh * s + 12 : Z(b) - 4); }
                const me = meNow(); if (me) { c.strokeStyle = '#4ade80'; c.fillStyle = 'rgba(74,222,128,.7)'; c.lineWidth = 2; c.fillRect(X(me.x), Z(me.z), Math.max(s, 4), Math.max(s, 4)); c.strokeRect(X(me.x), Z(me.z), Math.max(s, 4), Math.max(s, 4)); }
                if (P.hover && !P.pan) { c.strokeStyle = acc; c.lineWidth = 1.5; c.strokeRect(X(P.hover.x), Z(P.hover.z), s, s); }
                const inf = $('az-info'); const me2 = meNow();
                inf.textContent = `${P.name || ''} · ${m.w}×${m.h} ช่อง · ${zs.length} โซน${P.hover ? ` · เมาส์ ${P.hover.x}, ${P.hover.z}` : ''}${me2 ? ` · ตัวเรา ${me2.x}, ${me2.z} ${inZones(zs, me2) ? '✅ อยู่ในโซน' : '(นอกโซน)'}` : ''}`;
            };
            const loadMap = async (name) => {
                P.name = name; P.m = null; P.msg = 'กำลังโหลดแผนที่…'; P.zs = P.ze = null; renderList(); draw();
                let m = null; try { m = await fetchMap(name); } catch (e) { /* ignore */ }
                if (P.name !== name) return;
                if (!m) { P.msg = `ไม่พบไฟล์แมพ "${name}"`; draw(); return; }
                P.m = m; fit(); const me = meNow(); if (me) { const { w, h } = size(); P.s = Math.max(P.s, Math.min(14, 40)); P.vx0 = me.x + .5 - w / P.s / 2; P.vz0 = me.z + .5 - h / P.s / 2; } renderList(); draw();
            };
            const fillMaps = () => {
                const sel = $('az-map'), cur = zKey(); const set = new Map();
                if (cur) set.set(cur, `📍 แมพปัจจุบัน: ${cur}`);
                try { for (const x of JSON.parse(localStorage.getItem('at_warp_maps') || '[]')) if (x && x.n && !set.has(x.n)) set.set(x.n, x.n); } catch (e) { /* ignore */ }
                for (const k of Object.keys(zonesAll())) if (!set.has(k)) set.set(k, k);
                sel.innerHTML = ''; for (const [v, t] of set) { const o = document.createElement('option'); o.value = v; o.textContent = (zonesFor(v).length ? '🎯 ' : '') + t; sel.appendChild(o); }
                return cur || (set.size ? [...set.keys()][0] : '');
            };
            ZP.refresh = () => { const first = fillMaps(); const sel = $('az-map'); if (!P.name || !set0(sel, P.name)) { sel.value = first; if (first) loadMap(first); } zInfoUpdate(); };
            const set0 = (sel, v) => { const o = [...sel.options].find((x) => x.value === v); if (o) { sel.value = v; return true; } return false; };
            $('az-map').onchange = (e) => loadMap(e.target.value);
            $('az-close').onclick = () => { el.style.display = 'none'; };
            const setMode = (m) => { P.mode = m === 'ban' || m === 'spot' ? 'draw' : m; P.kind = m === 'ban' ? 'ban' : m === 'spot' ? 'spot' : 'farm'; $('az-draw').classList.toggle('az-on', m === 'draw'); $('az-ban').classList.toggle('az-on', m === 'ban'); $('az-spot').classList.toggle('az-on', m === 'spot'); $('az-pan').classList.toggle('az-on', m === 'pan'); cv.style.cursor = m === 'pan' ? 'grab' : 'crosshair'; };
            $('az-draw').onclick = () => setMode('draw'); $('az-ban').onclick = () => setMode('ban'); $('az-spot').onclick = () => setMode('spot'); $('az-pan').onclick = () => setMode('pan');
            const zoomAt = (f, px, py) => { if (!P.m) return; const { w, h } = size(); px = px == null ? w / 2 : px; py = py == null ? h / 2 : py; const wx = P.vx0 + px / P.s, wz = P.vz0 + py / P.s; P.s = Math.max(1.5, Math.min(60, P.s * f)); P.vx0 = wx - px / P.s; P.vz0 = wz - py / P.s; draw(); };
            $('az-zi').onclick = () => zoomAt(1.4); $('az-zo').onclick = () => zoomAt(1 / 1.4);
            $('az-fit').onclick = () => { fit(); draw(); };
            $('az-me').onclick = () => { const me = meNow(); if (!me) { P.msg = ''; $('az-info').textContent = 'ตัวเราไม่ได้อยู่ในแมพที่เลือก (หรืออ่านพิกัดไม่ได้)'; return; } const { w, h } = size(); P.vx0 = me.x + .5 - w / P.s / 2; P.vz0 = me.z + .5 - h / P.s / 2; draw(); };
            cv.addEventListener('wheel', (e) => { e.preventDefault(); const r = cv.getBoundingClientRect(); zoomAt(e.deltaY < 0 ? 1.18 : 1 / 1.18, e.clientX - r.left, e.clientY - r.top); }, { passive: false });
            cv.addEventListener('contextmenu', (e) => e.preventDefault());
            let rcStart = null;
            cv.addEventListener('pointerdown', (e) => {
                if (!P.m) return; try { cv.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ }
                if (e.button === 1 || e.button === 2 || P.mode === 'pan') { P.pan = { sx: e.clientX, sy: e.clientY, vx0: P.vx0, vz0: P.vz0, btn: e.button, moved: false }; cv.style.cursor = 'grabbing'; e.preventDefault(); return; }
                if (e.button === 0 && P.kind === 'spot') { P.spotDown = clampC(cellAt(e)); return; }
                if (e.button === 0) { P.zs = P.ze = clampC(cellAt(e)); }
            });
            cv.addEventListener('pointermove', (e) => {
                if (!P.m) return; const c = cellAt(e); P.hover = (c.x >= 0 && c.z >= 0 && c.x < P.m.w && c.z < P.m.h) ? c : null;
                if (P.pan) { const dx = e.clientX - P.pan.sx, dy = e.clientY - P.pan.sy; if (Math.abs(dx) + Math.abs(dy) > 4) P.pan.moved = true; P.vx0 = P.pan.vx0 - dx / P.s; P.vz0 = P.pan.vz0 - dy / P.s; }
                else if (P.zs) P.ze = clampC(c);
                draw();
            });
            const up = (e) => {
                if (P.pan) { const pn = P.pan; P.pan = null; cv.style.cursor = P.mode === 'pan' ? 'grab' : 'crosshair'; if (pn.btn === 2 && !pn.moved && P.m) { const c = cellAt(e), sp = spotsFor(P.name).slice(), si = sp.findIndex((p) => Math.max(Math.abs(p[0] - c.x), Math.abs(p[1] - c.z)) <= 1); if (si >= 0) { sp.splice(si, 1); spotsSave(P.name, sp); renderList(); draw(); return; } const b = banFor(P.name).slice(), bi = b.findIndex((z) => inZones([z], c)); if (bi >= 0) { b.splice(bi, 1); banSave(P.name, b); renderList(); } else { const a = zl().slice(), i = a.findIndex((z) => inZones([z], c)); if (i >= 0) { a.splice(i, 1); zonesSave(P.name, a); renderList(); } } } draw(); return; }
                if (P.spotDown) { const p = clampC(cellAt(e)); P.spotDown = null; const sp = spotsFor(P.name).slice(); if (!sp.some((q) => q[0] === p.x && q[1] === p.z)) { sp.push([p.x, p.z]); spotsSave(P.name, sp); } renderList(); draw(); return; }
                if (P.zs && P.ze) { const a = [Math.min(P.zs.x, P.ze.x), Math.min(P.zs.z, P.ze.z), Math.max(P.zs.x, P.ze.x), Math.max(P.zs.z, P.ze.z)]; if (P.kind === 'ban') { const b = banFor(P.name).slice(); b.push(a); banSave(P.name, b); } else { const l = zl().slice(); l.push(a); zonesSave(P.name, l); } renderList(); }
                P.zs = P.ze = null; draw();
            };
            cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', () => { P.pan = null; P.zs = P.ze = null; draw(); });
            cv.addEventListener('pointerleave', () => { P.hover = null; draw(); });
            // ลากหน้าต่าง
            const hd = el.querySelector('.az-h'); let dg = null;
            hd.addEventListener('pointerdown', (e) => { if (e.target.id === 'az-close') return; const r = el.getBoundingClientRect(); dg = { sx: e.clientX, sy: e.clientY, l: r.left, t: r.top }; try { hd.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ } });
            hd.addEventListener('pointermove', (e) => { if (!dg) return; el.style.left = Math.max(0, Math.min(innerWidth - 80, dg.l + e.clientX - dg.sx)) + 'px'; el.style.top = Math.max(0, Math.min(innerHeight - 40, dg.t + e.clientY - dg.sy)) + 'px'; });
            hd.addEventListener('pointerup', () => { dg = null; });
            try { new ResizeObserver(() => { if (el.style.display !== 'none') draw(); }).observe(box); } catch (e) { /* ignore */ }
            setInterval(() => { if (el.style.display !== 'none' && !P.pan && !P.zs) draw(); }, 400);
            ZP.refresh();
        }
        // ⭕ วงล่าที่ใหญ่ที่สุด (ช่อง) รอบจุด c ที่ไม่ล้นออกนอกโซน — ช่องชน (กำแพง) / นอกแมพ ไม่นับว่าล้น เพราะมอนอยู่ตรงนั้นไม่ได้
        function fitRadius(zs, c) {
            if (!c || !inZones(zs, c)) return 0;
            const m = D.tm && D.tmFor === norm((queryGame(SELECTORS.mapName) || {}).textContent || '').replace(/\s*Lv\.?[\d\-–\s]+$/i, '').trim() ? D.tm : null;
            const bad = badNow().rects;
            const okCell = (x, z) => { const wall = m && (x < 0 || z < 0 || x >= m.w || z >= m.h || (m.col && m.col[z * m.w + x])); if (wall) return true; const p = { x, z }; return inZones(zs, p) && !(bad.length && inZones(bad, p)); };
            for (let r = 1; r <= 30; r++) {
                for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
                    const d2 = dx * dx + dz * dz; if (d2 > r * r || d2 <= (r - 1) * (r - 1)) continue;
                    if (!okCell(c.x + dx, c.z + dz)) return r - 1;
                }
            }
            return 30;
        }
        // ตั้ง "ระยะล่า" ในหน้าต่างต่อสู้อัตโนมัติของเกม (ปุ่มฟันเฟือง ▸ แท็บมอน ▸ แถบเลื่อน) แล้วปิดหน้าต่างคืน
        async function setHuntRadius(r) {
            r = Math.max(3, Math.min(30, Math.floor(r)));
            const rangeEl = () => { const i = document.querySelector('.auto-range input[type=range]'); return i && wvis(i) ? i : null; };
            let inp = rangeEl(), opened = false;
            try {
                if (!inp) {
                    const g = document.querySelector('.auto-gear'); if (!g) { wsay('⭕ ไม่พบปุ่มตั้งค่าต่อสู้อัตโนมัติ — ตั้งระยะล่าเองไม่ได้', 'warn'); return false; }
                    g.click(); opened = true;
                    await wget(() => document.querySelector('.auto-tabs button'), 2500);
                    if (!rangeEl()) { const tab = [...document.querySelectorAll('.auto-tabs button')].find((b) => /มอน/.test(b.textContent || '')); if (tab) { tab.click(); await sleep(350); } }
                    inp = await wget(rangeEl, 2500);
                    if (!inp) { wsay('⭕ เปิดหน้าต่างต่อสู้อัตโนมัติแล้วแต่ไม่พบแถบ "ระยะล่า"', 'warn'); return false; }
                }
                const all = document.querySelector('.auto-range .auto-range-all');
                if (all && all.classList.contains('on')) { all.click(); await sleep(400); inp = rangeEl() || inp; }      // ปิดโหมด "ทั้งแมพ" ก่อน
                if (+inp.value !== r) {
                    setVal(inp, r);
                    for (const t of ['pointerup', 'keyup']) { try { inp.dispatchEvent(t === 'keyup' ? new KeyboardEvent('keyup', { bubbles: true, key: 'ArrowRight' }) : new PointerEvent('pointerup', { bubbles: true })); } catch (e) { /* ignore */ } }
                    await sleep(400);
                }
                const shown = norm((document.querySelector('.auto-range b') || {}).textContent || '');
                const ok = new RegExp('^' + r + '\\s').test(shown);
                wsay(ok ? `⭕ ตั้งระยะล่าเป็น ${r} ช่อง (วงล่าอยู่ในโซนพอดี)` : `⭕ ตั้งระยะล่าเป็น ${r} ช่องแล้ว แต่ตรวจยืนยันไม่ได้ (เห็น "${shown}")`, ok ? 'info' : 'warn');
                return ok;
            } catch (e) { wsay('⭕ ตั้งระยะล่าไม่สำเร็จ: ' + (e && e.message), 'warn'); return false; }
            finally {
                if (opened) { await sleep(250); const pnl = document.querySelector('.auto-panel'); const x = pnl && ([...pnl.querySelectorAll('button[class*="close"]')].find(wvis) || [...pnl.querySelectorAll('button')].find((b) => wvis(b) && /^\s*✕\s*$/.test(b.textContent || ''))); if (x) x.click(); else { const g = document.querySelector('.auto-gear'); if (g) g.click(); } await sleep(250); }
            }
        }
        async function flyToZone(dest, fo) {
            const noFly = !!(fo && fo.noFly);
            const map = zKey(), zs = zonesFor(map);
            const minR = Math.max(3, Math.min(30, +State.opt.zoneMinR || 6));
            try { update(); } catch (e) { /* ignore */ } await wget(() => D.tmState !== 'loading', 6000);      // โหลดไฟล์แมพ (ช่องชน) ของแมพนี้ก่อน — ใช้ทั้งวงล่าและหาทางไปจุดยืนตี
            if (!tmFor(map)) wsay(`⚠️ ยังโหลดไฟล์แมพของ "${map}" ไม่ได้ (${D.tmState || '-'}) — คำนวณทางเดินอาจคลาดเคลื่อน`, 'warn');
            lbSync(); let spotDiag = false;
            const zoneOk = (c) => { if (!inZones(zs, c)) return { ok: false, r: 0 }; { const bz = badNow().rects; if (bz.length && inZones(bz, c)) return { ok: false, r: 0, bad: true }; } if (!State.opt.zoneFit) return { ok: true, r: 0 }; const r = fitRadius(zs, c); return { ok: r >= minR, r }; };
            const done = async (c, r, msg) => { wsay(msg); if (State.opt.zoneFit && r >= 3) await setHuntRadius(r); return true; };
            if (!zs.length) { wsay(`🎯 ยังไม่ได้กำหนดโซนฟาร์มของแมพ "${map}" — ข้ามการใช้ Fly Wing หาโซน`, 'warn'); if (State.opt.warpFly) await warpFly(dest); return false; }
            const here = () => minimapCell();
            await wget(here, 4000);
            // 📍 มีจุดยืนตีที่เลือกไว้ → เดินไปยืนตรงจุดนั้นแล้วค่อยเปิด Auto (วงล่ามีศูนย์กลางที่จุดนั้น) · ไกลเกินกว่าที่ตั้ง = ใช้ Fly Wing สุ่มให้ใกล้ขึ้น
            const spots = State.opt.spotOn ? spotsFor(map).filter((p) => Array.isArray(p) && !walkBlocked(p[0], p[1])) : [];
            const trySpot = async (tag) => {
                if (!spots.length || W.abort) return false;
                const c = here(); if (!c) return false;
                badNow();
                const keys = new Set(spots.map((p) => p[0] + ',' + p[1]));
                const L = Math.max(2, Math.min(80, +State.opt.spotMax || 25));
                let tgt = keys.has(c.x + ',' + c.z) ? { x: c.x, z: c.z } : null, d = 0;
                const seen = new Set([c.x + ',' + c.z]); let q = [c]; const why = {};
                while (!tgt && q.length && d < L) {
                    d++; const nq = [];
                    for (const p of q) for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
                        const n = { x: p.x + dx, z: p.z + dz }, k = n.x + ',' + n.z; if (seen.has(k)) continue; seen.add(k);
                        if (keys.has(k)) { tgt = n; break; }
                        if (walkBlocked(n.x, n.z)) { const w = blkWhy(n.x, n.z) || '?'; why[w] = (why[w] || 0) + 1; continue; }
                        nq.push(n);
                    }
                    if (tgt) break; q = nq;
                }
                if (!tgt) {
                    // ใกล้จุดยืนตี (เส้นตรง) แต่หาทางเดินไม่เจอ → เขียนสาเหตุลง Log (ครั้งเดียวต่อรอบ) ไว้ตรวจว่าอะไรกันทาง
                    let nb = null; spots.forEach((sp, i) => { const dd = Math.max(Math.abs(sp[0] - c.x), Math.abs(sp[1] - c.z)); if (!nb || dd < nb.d) nb = { d: dd, i }; });
                    if (nb && nb.d <= L && !spotDiag) {
                        spotDiag = true;
                        const ws = Object.entries(why).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${v}`).join(' · ') || 'ไม่มี (ทางตันภายใน ' + L + ' ก้าว)';
                        Log.warn('WARP', `📍 [วินิจฉัย] ลงที่ (${c.x}, ${c.z}) ห่างจุดยืนตี #${nb.i + 1} (${spots[nb.i][0]}, ${spots[nb.i][1]}) แค่ ${nb.d} ช่อง แต่หาทางเดินไม่เจอใน ${L} ก้าว · ช่องที่ถูกกัน: ${ws} · ไฟล์แมพ ${D.tm ? D.tm.id + ' ' + D.tm.w + '×' + D.tm.h : 'ไม่มี'} · โซนห้ามเข้า ${(badNow().rects || []).length} กรอบ`);
                    }
                    return false;
                }
                const no = spots.findIndex((p) => p[0] === tgt.x && p[1] === tgt.z) + 1;
                if (d) { wsay(`📍 ${tag}เดินไปจุดยืนตี #${no} (${tgt.x}, ${tgt.z}) · ${d} ช่อง`); await goTo(tgt); }
                const c2 = here();
                if (!c2 || Math.max(Math.abs(c2.x - tgt.x), Math.abs(c2.z - tgt.z)) > 1) { wsay(`📍 ไปถึงจุดยืนตี #${no} ไม่สำเร็จ (อยู่ ${c2 ? c2.x + ', ' + c2.z : '?'})`, 'warn'); return false; }
                const r = State.opt.zoneFit ? fitRadius(zs, c2) : 0;
                await done(c2, r, `✅ ถึงจุดยืนตี #${no} (${c2.x}, ${c2.z})${r ? ` · วงล่าได้ ${r} ช่อง` : ''}`);
                return true;
            };
            if (spots.length && await trySpot('')) return true;
            if (!spots.length) { const c0 = here(), z0 = zoneOk(c0); if (z0.ok) return done(c0, z0.r, `🎯 ตัวเราอยู่ในโซนฟาร์มแล้ว${z0.r ? ` (วงล่าได้ ${z0.r} ช่อง)` : ''} — ไม่ต้องใช้ Fly Wing`); }
            // 🚶 ใกล้โซนอยู่แล้ว → เดินเข้าโซน (ไม่เปลือง Fly Wing) · หาช่องที่เข้าเกณฑ์ใกล้สุดตามทางเดินจริง (BFS เลี่ยงกำแพง/โซนห้ามเข้า)
            const walkIn = async (tag) => {
                if (!State.opt.zoneWalk || W.abort) return false;
                const c = here(); if (!c) return false;
                badNow();
                const maxD = Math.max(1, Math.min(40, +State.opt.zoneWalkMax || 10));
                const seen = new Set([c.x + ',' + c.z]); let q = [c], d = 0, tgt = null;
                while (q.length && d < maxD && !tgt) {
                    d++; const nq = [];
                    for (const p of q) for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
                        const n = { x: p.x + dx, z: p.z + dz }, k = n.x + ',' + n.z; if (seen.has(k)) continue; seen.add(k);
                        if (walkBlocked(n.x, n.z)) continue;
                        if (inZones(zs, n) && zoneOk(n).ok) { tgt = n; break; }
                        nq.push(n);
                    }
                    q = nq;
                }
                if (!tgt) return false;
                wsay(`🚶 ${tag}ห่างโซน ${d} ช่อง — เดินเข้าโซนที่ (${tgt.x}, ${tgt.z}) แทนการใช้ Fly Wing`);
                await goTo(tgt);
                const c2 = here(), z2 = zoneOk(c2);
                if (z2.ok) { await done(c2, z2.r, `✅ เดินเข้าโซนแล้ว (${c2.x}, ${c2.z})${z2.r ? ` · วงล่าได้ ${z2.r} ช่อง` : ''}`); return true; }
                wsay(`🚶 เดินเข้าโซนไม่สำเร็จ (อยู่ ${c2 ? c2.x + ', ' + c2.z : '?'}) — ใช้ Fly Wing แทน`);
                return false;
            };
            if ((!spots.length || noFly) && await walkIn('')) return true;
            if (noFly) { wsay('🧲 เดินกลับจุดยืนตี/เข้าโซนไม่ได้ (ไกลหรือทางถูกกัน) — ปล่อยให้ Auto ฟาร์มต่อ'); return false; }
            const cnt = (sl) => { const q = /x\s*([\d,]+)/i.exec((sl.querySelector('.hot-sub') || {}).textContent || ''); return q ? parseInt(q[1].replace(/,/g, ''), 10) : -1; };
            let unread = 0;
            const maxTry = State.opt.warpZoneMax == null ? 80 : (+State.opt.warpZoneMax > 0 ? +State.opt.warpZoneMax : Infinity);
            let i = 0;
            for (; i < maxTry && !W.abort; i++) {
                const m = wclean(wcur());
                if (!m.includes(dest || map) || /เมืองหลวง|คุก/.test(m)) { wsay('🎯 หยุดใช้ Fly Wing — ไม่ได้อยู่ในแมพฟาร์มแล้ว', 'warn'); return false; }
                if (Frame.captcha) { wsay('🎯 มีแคปช่า — หยุด', 'warn'); return false; }
                if (Frame.dead) { wsay('💀 ตัวละครตาย — หยุดใช้ Fly Wing', 'warn'); return false; }
                if (State.opt.flyRestock && flyBuyMin() >= 0) {
                    const s0 = flySlot(), c0 = s0 ? hotCnt(s0) : 0;
                    if (c0 >= 0 && c0 <= flyBuyMin()) { RS.pending = { field: dest || map, why: `Fly Wing เหลือ ${c0}` }; wsay(`🦋 Fly Wing เหลือ ${c0} (≤ ${flyBuyMin()}) — หยุดสุ่ม จะกลับเมืองไปซื้อ`); return false; }
                }
                const sl = flySlot(); if (!sl) { wsay('⚠️ ไม่พบ Fly Wing ในแถบด่วน (หมด?) — หยุดสุ่ม', 'warn'); try { showToast('🪽 Fly Wing หมด/ไม่พบในแถบด่วน', 'warn'); } catch (e) { /* ignore */ } return false; }
                if (cnt(sl) === 0) { wsay('⚠️ Fly Wing หมดแล้ว — หยุดสุ่ม', 'warn'); return false; }
                const p0 = here(); if (!p0 && ++unread >= 3) { wsay('⚠️ อ่านพิกัดตัวเราจากมินิแมพไม่ได้ — หยุดสุ่ม', 'warn'); return false; }
                { const fm = getMapName(); if (isCountMap(fm)) { const lg = ledgerFor(fm); lg.fly = (lg.fly || 0) + 1; Profit.dirty = true; } }
                wtap(sl); wsay(`🪽 ใช้ Fly Wing ครั้งที่ ${i + 1} (เหลือ ${cnt(sl) < 0 ? '?' : cnt(sl)}) …`);
                const moved = await wget(() => { const c = here(); return c && p0 && (c.x !== p0.x || c.z !== p0.z) ? c : null; }, 6000);
                await sleep(700);
                if (Frame.dead || /เมืองหลวง|คุก/.test(wclean(wcur()))) continue;      // ตาย/กลับเมืองระหว่างรอ → รอบถัดไปจะหยุดเอง
                const c = here();
                if (spots.length) {
                    if (moved && await trySpot(`ลงที่ ${c ? c.x + ', ' + c.z : '?'} · `)) return true;
                    wsay(!moved ? '🪽 ตำแหน่งไม่เปลี่ยน — รอแล้วลองใหม่' : `🪽 ลงที่ (${c ? c.x + ', ' + c.z : '?'}) ไกลจากจุดยืนตีเกิน ${State.opt.spotMax} ช่อง — สุ่มใหม่`);
                    await sleep(moved ? 1200 : 3000);
                    continue;
                }
                const zc = zoneOk(c);
                if (!zc.ok && moved && await walkIn('ลงที่ ' + (c ? c.x + ', ' + c.z : '?') + ' · ')) return true;
                if (zc.ok) { try { showToast(`🎯 ถึงโซนฟาร์ม (${c.x}, ${c.z})`, 'ok'); } catch (e) { /* ignore */ } return done(c, zc.r, `✅ ถึงโซนฟาร์มแล้ว (${c.x}, ${c.z})${zc.r ? ` · วงล่าได้ ${zc.r} ช่อง` : ''} หลังใช้ Fly Wing ${i + 1} ครั้ง`); }
                wsay(!moved ? '🪽 ตำแหน่งไม่เปลี่ยน — รอแล้วลองใหม่' : zc.bad ? `🪽 ลงที่ (${c.x}, ${c.z}) ในโซนห้ามเข้า/จุดเกิดมอนอันตราย — สุ่มใหม่` : inZones(zs, c) ? `🪽 ลงที่ (${c.x}, ${c.z}) ในโซนแต่ใกล้ขอบ (วงล่าได้แค่ ${zc.r} ช่อง < ${minR}) — สุ่มใหม่` : `🪽 ลงที่ (${c ? c.x + ', ' + c.z : '?'}) นอกโซน — สุ่มใหม่`);
                await sleep(moved ? 1200 : 3000);
            }
            if (!W.abort) wsay(`🎯 ใช้ Fly Wing ครบ ${i} ครั้งแล้วยังไม่เข้าโซน — หยุด`, 'warn');
            return false;
        }
        async function warpFly(dest) {
            // ห้ามใช้ Fly Wing ในเมือง: เช็คซ้ำหลายรอบ (ผู้เล่นอาจกดกลับเมืองระหว่างรอ) และเช็คอีกทีก่อนกดจริง
            const inField = () => { const m = wcur(); if (!m) return false; if (CONFIG.SAFE_MAPS.some((x) => m.includes(x)) || CONFIG.SAFE_MAP_KEYWORDS.some((k) => m.includes(k)) || /เมืองหลวง|คุก|ตลาดคาราวาน/.test(m)) return false; return !dest || m.includes(dest); };
            if (!inField()) { wsay('ข้ามการใช้ Fly Wing (ไม่ได้อยู่ในแมพปลายทาง/อยู่ในเมือง)'); return; }
            const sl = flySlot(); if (!sl) { wsay('⚠️ ไม่พบ Fly Wing ในแถบด่วน — ลากจากกระเป๋าใส่ก่อน', 'warn'); try { showToast('🪽 ไม่พบ Fly Wing ในแถบด่วน', 'warn'); } catch (e) { /* ignore */ } return; }
            for (let i = 0; i < 2; i++) { await sleep(250); if (W.abort) return; if (!inField()) { wsay('ยกเลิกใช้ Fly Wing — ตอนนี้ไม่ได้อยู่ในแมพปลายทางแล้ว (กลับเมือง?)', 'warn'); return; } }
            const cnt = () => { const t = (sl.querySelector('.hot-sub') || {}).textContent || ''; const q = /x\s*([\d,]+)/i.exec(t); return q ? parseInt(q[1].replace(/,/g, ''), 10) : -1; };
            if (!inField()) { wsay('ยกเลิกใช้ Fly Wing — กลับเมืองแล้ว', 'warn'); return; }
            const before = cnt(); wtap(sl); await sleep(600);
            const after = cnt();
            wsay(after >= 0 && before >= 0 && after < before ? `🪽 ใช้ Fly Wing แล้ว (เหลือ ${after})` : '🪽 กดใช้ Fly Wing แล้ว (ยืนยันจำนวนที่ลดไม่ได้)');
        }
        // ↩️ กลับแมพเดิมเอง: จำแมพฟาร์มล่าสุด · เมื่อเข้าเมืองหลวงจากแมพฟาร์ม (ตาย/กลับเมือง ฯลฯ) และบอท Z เปิดอยู่ → วาร์ปกลับ
        // อยู่เมืองแล้ว → ตรวจของ/ซื้อก่อนวาร์ปกลับ ถ้าเปิดระบบที่เกี่ยวกับการซื้อไว้อย่างใดอย่างหนึ่ง (ซื้อของอัตโนมัติ / Fly Wing ใกล้หมด / ของใช้ใกล้หมด)
        const buyCheckOn = () => !!(State.opt.buyOn || State.opt.flyRestock || State.opt.supplyRestock) && (State.opt.buy || []).some((b) => b && String(b.n || '').trim() && +b.q > 0);
        // แถบด่วน: ชื่อ + จำนวน (ใช้ตอนเขียน Log วินิจฉัย)
        function hotSummary() {
            const items = (Profit.db && Profit.db.items) || {}, byId = {};
            for (const [n, a] of Object.entries(items)) if (a && a[0] && !byId[a[0]]) byId[a[0]] = n;
            return [...document.querySelectorAll('.hot-slot.item')].map((sl) => { const im = sl.querySelector('img'); const c = im ? iconCands(im.getAttribute('src') || '') : []; const n = (c.map((id) => byId[id]).find(Boolean)) || (im && (im.getAttribute('alt') || im.getAttribute('title'))) || '?'; const k = hotCnt(sl); return `${n} x${k < 0 ? '?' : k}`; }).join(' · ') || '(ไม่พบแถบด่วน)';
        }
        const BK = { field: '', wasSafe: null, townAt: 0, lastTry: 0, fails: 0, pickGo: false, pickAt: 0, deadAt: 0, townPend: false, townSince: 0, selfTown: [], loopStop: 0, jit: Math.floor(Math.random() * 4000) };      // jit: หน่วงสุ่ม 0–4 วิ ต่อแท็บ กันทุกจอวิ่งไปหา Alice พร้อมกัน (หลังเซิร์ฟรีสตาร์ท)
        // ↩️ แจ้ง Discord: วาร์ปกลับแมพเดิมสำเร็จ (หลังตาย/กลับเมือง) หรือไม่สำเร็จครบ 3 ครั้ง
        function bkNotify(ok, dest, t0, deathAgo) {
            try {
                const why = deathAgo < 180000 ? '💀 ตายแล้วฟื้นที่เมือง' : '🏙️ กลับเมือง';
                const secs = Math.max(1, Math.round((Date.now() - t0) / 1000)), map = wclean(wcur());
                const fields = [{ name: 'สาเหตุ', value: why, inline: true }, { name: 'ใช้เวลา', value: `${secs} วิ`, inline: true }];
                try { const ch = readField(SELECTORS.channel, 'channel'); if (ch) fields.push({ name: 'CH', value: String(ch), inline: true }); } catch (e) { /* ignore */ }
                if (ok) sendDiscord('warpback', { title: '↩️ กลับแมพเดิมสำเร็จ', description: `**${charLabel()}** กลับมาฟาร์มที่ **${map || dest}** แล้ว`, color: 0x22c55e, fields }, { ping: false });
                else sendDiscord('warpback', { title: '⚠️ กลับแมพเดิมไม่สำเร็จ 3 ครั้ง', description: `**${charLabel()}** ยังอยู่ที่ **${map || 'เมือง'}** — ไป **${dest}** ไม่ได้ หยุดลองแล้ว (กด "ไปเลย" เอง)`, color: 0xf87171, fields }, { ping: true });
            } catch (e) { /* ignore */ }
        }
        const wlKey = () => 'at_warp_last@' + (Store.char || '-');      // แมพฟาร์มล่าสุด แยกต่อตัวละคร
        const bkSync = () => { if (BK.char === Store.char) return; BK.char = Store.char; try { BK.field = Store.char ? localStorage.getItem(wlKey()) || '' : ''; } catch (e) { BK.field = ''; } BK.townAt = 0; BK.pickGo = false; };
        setInterval(() => {
            try {
                const m = wclean(wcur()); if (!m || !State.isGameReady || !Store.char) return;
                bkSync();
                const safe = CONFIG.SAFE_MAPS.some((x) => m.includes(x)) || /คุก/.test(m);
                if (Frame.dead) BK.deadAt = Date.now();
                BK.townSince = /เมืองหลวง/.test(m) ? (BK.townSince || Date.now()) : 0;
                if (W.run || RS.busy) {
                    if (safe && BK.wasSafe === false && /เมืองหลวง/.test(m) && Date.now() - Math.max(BK.deadAt, State.lastDeathAt || 0) < 30000) { BK.townPend = true; Log.info('WARP', 'ตายระหว่างระบบวาร์ป/Fly Wing ทำงาน — จะวาร์ปกลับแมพเดิมเมื่อระบบนั้นหยุด'); }
                    BK.wasSafe = safe; BK.townAt = 0; return;
                }
                if (BK.townPend) { BK.townPend = false; if (safe && /เมืองหลวง/.test(m)) BK.townAt = Date.now(); }
                if (!safe) { if (BK.field !== m && !BK.pickGo) { BK.field = m; try { lsSet(wlKey(), m); } catch (e) { /* ignore */ } } BK.fails = 0; BK.townAt = 0; }
                else if (BK.wasSafe === false && /เมืองหลวง/.test(m)) {
                    BK.townAt = Date.now();
                    if (Date.now() - Math.max(BK.deadAt, State.lastDeathAt || 0) > 30000) {      // กลับเมืองเองโดยไม่ได้ตาย และสคริปต์ไม่ได้พากลับ (มักเป็น Auto ของเกมใช้ Butterfly Wing เพราะยา/ของที่ตั้งไว้หมด)
                        BK.selfTown = BK.selfTown.filter((t) => Date.now() - t < 600000).concat(Date.now());
                        const n = BK.selfTown.length, hs = hotSummary();
                        Log.warn('WARP', `↩️ กลับเมืองเองโดยไม่ได้ตาย (${n} ครั้งใน 10 นาที) · แถบด่วน: ${hs}`);
                        if (n >= 4) {
                            BK.townAt = 0; BK.loopStop = Date.now(); BK.selfTown = [];
                            raiseAlert('supply', { title: '🔁 ตัวละครถูกส่งกลับเมืองซ้ำ ๆ', desc: `**${charLabel()}** กลับเมืองเอง ${n} ครั้งใน 10 นาทีโดยไม่ได้ตาย — มักเป็นเพราะ **Auto ของเกม** ตั้งให้กลับเมืองเมื่อยา/ของบางอย่างหมด แต่ของชิ้นนั้นไม่อยู่ในรายการซื้อของสคริปต์\nแถบด่วน: ${hs}\n⏸️ หยุดวาร์ปกลับอัตโนมัติ 15 นาที (กันเปลือง Butterfly Wing) — เพิ่มของที่หมดในรายการซื้อ หรือปิดตัวเลือกกลับเมืองใน Auto ของเกม`, color: 0xf59e0b, ping: true });
                        }
                    }
                }
                BK.wasSafe = safe;
                // เลือกแมพใหม่ตอนอยู่นอกเมือง → พอเข้าเมืองหลวงไปแมพที่เลือกทันที (ไม่ขึ้นกับสวิตช์กลับแมพเดิม/Z)
                if (BK.pickGo && /เมืองหลวง/.test(m) && BK.field && !Frame.captcha && !isTyping() && !autoPaused() && !autoBusy('warpback')) {
                    if (!BK.pickAt) BK.pickAt = Date.now();
                    if (Date.now() - BK.pickAt > 1200) { BK.pickGo = false; BK.pickAt = 0; Log.info('WARP', `เข้าเมืองหลวงแล้ว → ไปแมพที่เลือก: ${BK.field}`); warpTo(BK.field); }
                    return;
                }
                // 🐕 กันค้างในเมือง: อยู่เมืองหลวงเกิน 90 วิ ทั้งที่เปิดกลับแมพเดิม + บอท Z และไม่มีระบบไหนทำงาน → วาร์ปกลับเอง (ไม่ต้องรอจังหวะ "เพิ่งกลับเข้าเมือง")
                if (!BK.townAt && BK.townSince && Date.now() - BK.townSince > 45000 && State.opt.warpBack && State.isAutoEnabled && BK.field && !autoPaused() && Date.now() - BK.lastTry > 60000 && !Frame.captcha && !Frame.dead && !isTyping() && !autoBusy('warpback')) {
                    if (BK.fails >= 3 && Date.now() - BK.lastTry > 300000) BK.fails = 0;      // เคยล้มเหลวครบ 3 ครั้ง: พักไว้ 5 นาทีแล้วลองใหม่
                    if (BK.fails < 3) { Log.warn('WARP', `อยู่เมืองหลวงมา ${fmtTown(Date.now() - BK.townSince)} โดยไม่มีระบบไหนทำงาน — วาร์ปกลับแมพเดิมให้`); BK.townAt = Date.now() - 2000; }
                }
                if (BK.townAt && !autoPaused() && /เมืองหลวง/.test(m) && State.opt.warpBack && State.isAutoEnabled && BK.field && Date.now() - BK.townAt > 1500 + BK.jit && Date.now() - BK.loopStop > 900000 && Date.now() - BK.lastTry > 15000 && BK.fails < 3 && !Frame.captcha && !isTyping() && !autoBusy('warpback')) {
                    BK.townAt = 0; BK.lastTry = Date.now();
                    const bkT0 = Date.now(), bkDeathAgo = Date.now() - Math.max(BK.deadAt, State.lastDeathAt || 0), bkDest = BK.field;
                    Log.info('WARP', `กลับมาเมืองหลวง → วาร์ปกลับแมพเดิม: ${BK.field}`);
                    try { showToast(`↩️ กลับไป ${BK.field}`, 'ok'); } catch (e) { /* ignore */ }
                    (async () => { if (buyCheckOn()) { try { await buyRun(); } catch (e) { /* ignore */ } } else wsay('🛒 ไม่ได้ตรวจของก่อนวาร์ป — ปิด "ซื้อของอัตโนมัติ" และ "กลับไปซื้อ" อยู่'); if (!State.opt.warpBack || W.abort) return false; return warpTo(BK.field, { auto: true }); })().then((ok) => { if (!ok) { BK.fails++; if (BK.fails >= 3) { Log.warn('WARP', 'กลับแมพเดิมอัตโนมัติไม่สำเร็จ 3 ครั้ง — หยุดลอง (กด "ไปเลย" เอง)'); try { showToast('↩️ กลับแมพเดิมไม่สำเร็จ 3 ครั้ง — หยุดลองแล้ว', 'warn'); } catch (e) { /* ignore */ } bkNotify(false, bkDest, bkT0, bkDeathAgo); } } else { BK.fails = 0; bkNotify(true, bkDest, bkT0, bkDeathAgo); } });
                }
            } catch (e) { /* ignore */ }
        }, 1000);
        // 🛒 ซื้อของอัตโนมัติ: จำนวนไอเทม ≤ ที่ตั้ง → เดินไปหา Shopkeeper → เปิดร้าน → ค้นหา → ใส่ตะกร้า → ตั้งจำนวน → ตรวจสอบและซื้อ → ปิดร้าน (เว้นจังหวะคงที่ระหว่างขั้นเพื่อให้หน้าจอทัน)
        const BUY_STEP = 550;
        const bagCountById = (id) => { let n = 0; for (const el of invSlots()) { let ids = []; try { ids = iconCands(slotIcon(el)); } catch (e) { /* ignore */ } if (itemIdFromIcon(slotIcon(el)) === id || ids.includes(id)) n += parseInt((((el.querySelector('.inv-qty') || {}).textContent) || '1').replace(/,/g, ''), 10) || 1; } return n; };
        async function itemCount(name) {
            const items = (Profit.db && Profit.db.items) || {}; const key = Object.keys(items).find((k) => k.toLowerCase() === String(name).toLowerCase()); const id = key ? items[key][0] : 0;
            if (!id) return -1;
            let best = -1;
            for (const sl of document.querySelectorAll('.hot-slot.item')) {
                const im = sl.querySelector('img'); if (!im) continue; const src = im.getAttribute('src') || '';
                let ids = []; try { ids = iconCands(src); } catch (e) { /* ignore */ }
                if (itemIdFromIcon(src) !== id && !ids.includes(id)) continue;
                const q = /x\s*([\d,]+)/i.exec((sl.querySelector('.hot-sub') || {}).textContent || ''); if (q) best = Math.max(best, parseInt(q[1].replace(/,/g, ''), 10));
            }
            if (best >= 0) return best;
            const wasOpen = isVisible(SELECTORS.weight);
            if (!wasOpen) { pressKey('i', 'KeyI', 73); if (!(await waitFor(() => isVisible(SELECTORS.weight), 2000))) return -1; await sleep(350); }
            const n = bagCountById(id);
            if (!wasOpen) { pressKey('i', 'KeyI', 73); await sleep(400); }
            return n;
        }
        const setVal = (inp, v) => { try { Object.getOwnPropertyDescriptor(PW.HTMLInputElement.prototype, 'value').set.call(inp, String(v)); } catch (e) { inp.value = String(v); } for (const t of ['input', 'change']) { try { inp.dispatchEvent(new Event(t, { bubbles: true })); } catch (e) { /* ignore */ } } };
        const shopRoot = () => { const f = document.querySelector('.shop-window'); if (f && wvis(f)) return f; const c = wfind(/ตรวจสอบและซื้อ/)[0]; for (let n = c, i = 0; n && i < 10; n = n.parentElement, i++) { if (n.querySelector('input') && /ตะกร้า/.test(n.textContent || '') && n.querySelectorAll('button').length > 5) return n; } return null; };
        const enterKey = (inp) => { enterKey0(inp); setTimeout(() => { try { if (document.activeElement !== inp && Date.now() - Pause.inputAt > 3000) unfocusChat(); } catch (e) { /* ignore */ } }, 150); };
        const enterKey0 = (inp) => { try { inp.focus(); } catch (e) { /* ignore */ } for (const t of ['keydown', 'keypress', 'keyup']) { try { inp.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true })); } catch (e) { /* ignore */ } } try { inp.dispatchEvent(new Event('change', { bubbles: true })); inp.blur(); } catch (e) { /* ignore */ } };
        const cartTotal = (root) => { for (const n of root.querySelectorAll('div,span,b')) { if (n.children.length) continue; if (/ต้องจ่าย/.test(n.textContent || '')) { let p = n.parentElement; for (let i = 0; i < 3 && p; i++, p = p.parentElement) { const m = [...p.querySelectorAll('div,span,b')].filter((x) => !x.children.length && /^[\d,]+\s*z$/i.test((x.textContent || '').trim())).pop(); if (m) return parseInt(m.textContent.replace(/[^\d]/g, ''), 10); } } } return -1; };
        const findShopRow = (root, name) => {
            const ex = new RegExp('^\\s*' + wesc(name) + '\\s*$', 'i');
            for (const r of root.querySelectorAll('.shop-list .shop-row, .shop-row')) {
                if (r.querySelector('input')) continue;
                const nm = r.querySelector('.shop-name > span, .shop-name'); if (!nm || !ex.test(nm.firstElementChild ? nm.firstElementChild.textContent : nm.textContent)) continue;
                const plus = r.querySelector('button.cart-add') || [...r.querySelectorAll('button')].find((b) => /^\s*\+\s*$/.test(b.textContent || '')); if (plus) return { row: r, plus };
            }
            const nameRe = new RegExp('^\\s*' + wesc(name) + '\\s*$', 'i'); const list = [];
            for (const n of root.querySelectorAll('div,span,b,p')) { if (n.children.length || !nameRe.test(n.textContent || '')) continue; let row = n; for (let i = 0; i < 6 && row; i++, row = row.parentElement) { const bt = [...row.querySelectorAll('button')].filter((b) => /^\s*\+\s*$/.test(b.textContent || '')); if (bt.length === 1) { list.push({ row, plus: bt[0] }); break; } if (bt.length > 1) break; } }
            return list.find((x) => !x.row.closest('[class*="cart" i]') && !/ตะกร้า/.test((x.row.parentElement || {}).textContent || '') && !x.row.querySelector('input')) || list[0] || null;
        };
        const nameRx = (name) => new RegExp('(?<![A-Za-z])' + wesc(name) + '(?![A-Za-z])', 'i');
        const qtyInput = (root, name) => { const re = nameRx(name); return [...root.querySelectorAll('input')].filter((i) => !/ค้นหา/.test(i.placeholder || '') && !/search/i.test(i.className || '') && wvis(i)).find((i) => { let n = i.parentElement; for (let k = 0; n && n !== root && k < 6; n = n.parentElement, k++) { if (n.querySelectorAll('input').length > 1) return false; if (re.test(n.textContent || '')) return true; } return false; }) || null; };
        // ใส่สินค้าลงตะกร้า + ตั้งจำนวน + กด Enter ยืนยันจำนวน (ยังไม่กดซื้อ) · คืน {n, q, price}
        async function shopAdd(name, qty) {
            const root = shopRoot(); if (!root) throw new Error('ไม่พบหน้าต่างร้านค้า');
            const search = [...root.querySelectorAll('input')].find((i) => /ค้นหา/.test(i.placeholder || '')) || null;
            // 1) หาแถวสินค้าจากรายการทั้งหมดก่อน (ไม่พึ่งช่องค้นหา) 2) ไม่เจอค่อยพิมพ์ค้นหาแล้วหาใหม่ หลายรอบ
            if (search && search.value) { setVal(search, ''); await sleep(400); }      // ล้างคำค้นเก่าก่อน (ไม่งั้นรายการถูกกรองเหลือแต่ของเดิม)
            let hit = findShopRow(root, name);
            for (let k = 0; !hit && k < 3 && search; k++) { setVal(search, name); await sleep(BUY_STEP + 350); hit = findShopRow(root, name); if (!hit) { setVal(search, ''); await sleep(300); hit = findShopRow(root, name); } }
            if (!hit) { const seen = [...root.querySelectorAll('.shop-name > span,.shop-name')].filter((n) => !n.children.length && wvis(n) && /^[A-Za-z][A-Za-z '\-]{2,30}$/.test((n.textContent || '').trim())).map((n) => n.textContent.trim()).slice(0, 12); throw new Error(`ไม่พบ "${name}" ในร้าน (ที่เห็น: ${seen.join(', ') || '—'})`); }
            try { hit.row.scrollIntoView({ block: 'center' }); } catch (e) { /* ignore */ }
            const price = (() => { const m = /([\d,]+)\s*z\b/i.exec(hit.row.textContent || ''); return m ? parseInt(m[1].replace(/,/g, ''), 10) : 0; })();
            const zeny = (() => { for (const n of root.querySelectorAll('div,span,b')) { if (n.children.length) continue; const t = (n.textContent || '').trim(); if (/^\d{1,3}(,\d{3})+$|^\d{4,}$/.test(t)) return parseInt(t.replace(/,/g, ''), 10); } return 0; })();
            let q = qty; if (price && zeny && price * q > zeny) { q = Math.floor(zeny / price); wsay(`🛒 Zeny ไม่พอซื้อ ${qty} ชิ้น → ซื้อ ${q} ชิ้นแทน`, 'warn'); }
            if (q <= 0) throw new Error('Zeny ไม่พอ');
            wtap(hit.plus); await sleep(BUY_STEP);
            const qiOf = () => qtyInput(root, name);
            const qi = qiOf(); if (!qi) throw new Error('ไม่พบช่องจำนวนในตะกร้า');
            if (q !== 1) {
                setVal(qi, q); await sleep(250); enterKey(qi); await sleep(BUY_STEP);      // เปลี่ยนจำนวนแล้วกด Enter เพื่อยืนยัน
                const qj = qiOf() || qi;
                if (String(qj.value).replace(/,/g, '') !== String(q)) {      // ตั้งตรง ๆ ไม่ติด → กด + ทีละครั้ง
                    const cp = [...qj.parentElement.querySelectorAll('button')].find((b) => /^\s*\+\s*$/.test(b.textContent || ''));
                    for (let i = parseInt(qj.value, 10) || 1; cp && i < q && !W.abort; i++) { wtap(cp); await sleep(130); }
                    enterKey(qiOf() || qj); await sleep(300);
                }
            }
            const got = parseInt((qiOf() || qi).value, 10) || q;
            wsay(`🛒 ใส่ตะกร้า ${name} × ${got}${price ? ` (~${(price * got).toLocaleString()} z)` : ''} (กด Enter ยืนยันจำนวนแล้ว)`);
            return { n: name, q: got, price };
        }
        async function shopCheckout(items) {
            const root = shopRoot(); const expectTotal = items.reduce((t, x) => t + x.price * x.q, 0);
            let tot = root ? cartTotal(root) : -1;
            if (root && expectTotal > 0 && tot >= 0 && tot !== expectTotal) {      // จำนวนยังไม่ติด → กด Enter ย้ำทุกช่องแล้วเช็กใหม่
                for (const it of items) { const qi = qtyInput(root, it.n); if (qi && String(qi.value) !== String(it.q)) setVal(qi, it.q); if (qi) { enterKey(qi); await sleep(350); } }
                tot = cartTotal(root);
                if (tot !== expectTotal) throw new Error(`ยอดในตะกร้า ${tot.toLocaleString()} z ไม่ตรงที่คำนวณ ${expectTotal.toLocaleString()} z — ไม่กดซื้อ (กันซื้อผิดจำนวน)`);
            }
            const btn = wbtn(/ตรวจสอบและซื้อ/); if (!btn || btn.disabled) throw new Error('ปุ่ม "ตรวจสอบและซื้อ" ใช้ไม่ได้ (ตะกร้าว่าง?)');
            wtap(btn); await sleep(BUY_STEP + 400);
            // หน้า "ยืนยันการซื้อ" (ป๊อปอัป: ยกเลิก / ยืนยันซื้อ) — รอให้ขึ้นก่อน แล้วกดเฉพาะปุ่มในป๊อปอัปนั้น (ห้ามไปโดนแท็บ "ซื้อ" ของร้าน)
            const confirmBtn = () => {
                const t = wfind(/^\s*ยืนยันการซื้อ\s*$/)[0]; if (!t) return null;
                for (let n = t, i = 0; n && i < 7; n = n.parentElement, i++) { const y = [...n.querySelectorAll('button')].find((b) => wvis(b) && /ยืนยัน/.test(b.textContent || '') && !/ยกเลิก/.test(b.textContent || '')); if (y) return y; }
                return null;
            };
            const y = await wget(confirmBtn, 4000);
            if (y) { wsay(`🛒 กดยืนยัน "${norm(y.textContent)}"`); await sleep(BUY_STEP); wtap(y); await sleep(BUY_STEP + 300); }
            else { try { Log.warn('BUY', 'ไม่เห็นหน้า "ยืนยันการซื้อ" · ปุ่มที่เห็น: ' + [...document.querySelectorAll('button')].filter((b) => !wmine(b) && wvis(b)).map((b) => norm(b.textContent || '')).filter(Boolean).slice(-14).join(' | ')); } catch (e) { /* ignore */ } throw new Error('ไม่เห็นหน้าต่าง "ยืนยันการซื้อ" หลังกดตรวจสอบและซื้อ'); }
            // รอผล: ตะกร้าว่าง/ร้านปิด
            const cleared = await wget(() => { const r = shopRoot(); if (!r) return 1; return cartTotal(r) === 0 || [...r.querySelectorAll('div,span,b')].some((n) => !n.children.length && /^\s*0\s*รายการ/.test(n.textContent || '')) ? 1 : 0; }, 3500);
            return !!cleared;
        }
        // opts.force = ซื้อทุกรายการที่ตั้งไว้ (ปุ่มทดสอบ) · ไม่ใส่ = ซื้อเฉพาะที่จำนวน ≤ ค่าที่ตั้ง · คืน true ถ้าซื้ออะไรสักอย่างสำเร็จ
        async function buyRun(opts) {
            const force = !!(opts && opts.force), cfg = (State.opt.buy || []).filter((b) => b && String(b.n || '').trim() && +b.q > 0);
            if (!cfg.length) { if (force) wsay('ยังไม่ได้ตั้งรายการซื้อ (ใส่ชื่อไอเทมและจำนวน)', 'warn'); return false; }
            if (Frame.captcha || InvLock.owner) return false;
            const wasRun = W.run; if (!wasRun) { W.run = true; W.abort = false; W.auto = !force; W.dest = ''; } InvLock.owner = 'buy'; State.warpHold = true; let did = false;
            try {
                const need = []; try { if (document.activeElement && document.activeElement !== document.body) document.activeElement.blur(); } catch (e) { /* ignore */ }
                for (const b of cfg) {
                    const n = await itemCount(String(b.n).trim()); const lim = +b.min || 0;
                    wsay(`🛒 ตรวจ ${b.n}: มี ${n < 0 ? 'อ่านไม่ได้' : n} (ซื้อเมื่อ ≤ ${lim})`);
                    if (n < 0 && !force) wsay(`⚠️ อ่านจำนวน ${b.n} ไม่ได้ — ข้ามรายการนี้ (กดปุ่มทดสอบถ้าจะซื้อเลย)`, 'warn');
                    if (force || (n >= 0 && n <= lim)) need.push({ n: String(b.n).trim(), q: Math.max(1, Math.floor(+b.q)), have: n });
                }
                if (!need.length) { wsay('🛒 ของยังพอ ไม่ต้องซื้อ'); return false; }
                // เดินไปหา Shopkeeper แล้วเปิดคุย — คลิกไม่ติด/มีคนยืนบัง → ย้าย CH ไปห้องที่คนน้อยสุดแล้วลองใหม่ (เหมือน Alice) วนจนสำเร็จหรือกดหยุด (สูงสุด 1 ชม.)
                const nm = norm(State.opt.buyNpc || 'Shopkeeper') || 'Shopkeeper', re = new RegExp(wesc(nm), 'i');
                wsay(`🛒 ต้องซื้อ: ${need.map((x) => x.n + '×' + x.q).join(', ')} — เดินไปหา ${nm}…`);
                const tLoop = Date.now(); let tFail = 0; D.talkOk = false;
                while (!D.talkOk && !W.abort && Date.now() - tLoop < 3600000) {
                    update(); await wget(() => (D.tm && D.tmFor === wclean(wcur()) ? 1 : 0), 6000);
                    const npcs = (D.tm ? D.tm.objs : []).filter((o) => o.kind === 'npc' && re.test(o.name || ''));
                    if (!npcs.length) throw new Error(`ไม่พบ NPC "${nm}" ในแมพนี้ (ต้องอยู่ในเมืองหลวง)`);
                    const me = minimapCell() || { x: 0, z: 0 }; const dd = (o) => Math.abs((o.c0 + o.c1) / 2 - me.x) + Math.abs((o.z0 + o.z1) / 2 - me.z); npcs.sort((a, b) => dd(a) - dd(b));
                    D.talkOk = false; await talkTo(npcs[0], { avoidFront: true }); if (W.abort) throw new Error('ยกเลิกแล้ว');
                    if (D.talkOk) break;
                    tFail++; wsay(`🛒 เปิดคุยกับ ${nm} ไม่สำเร็จ — ย้าย CH แล้วลองใหม่ (ครั้งที่ ${tFail})`, 'warn');
                    try { dismissTarget(); wEsc(); await sleep(300); await switchChannel(`คลิก ${nm} ไม่ติด`); } catch (er) { wsay('ย้าย CH ไม่สำเร็จ: ' + (er && er.message), 'warn'); await sleep(1500); }
                }
                if (W.abort) throw new Error('ยกเลิกแล้ว');
                if (!D.talkOk) throw new Error(`เปิดหน้าต่างคุยกับ ${nm} ไม่สำเร็จ`);
                await sleep(BUY_STEP);
                // ต้องเป็นแถวตัวเลือกจริง ๆ ("ซื้อของหน่อย") ไม่ใช่ประโยคทักทายที่มีคำว่า "ซื้อของ" อยู่ด้วย
                const optRe = /^\s*(\d+\s*)?ซื้อของ(หน่อย)?\s*$/;
                const opt = await wget(() => wfind(optRe)[0], 4000); if (!opt) throw new Error('ไม่พบตัวเลือก "ซื้อของหน่อย" ในหน้าต่างคุย');
                wtap(wclk(opt)); wsay('🛒 เปิดร้านค้า…');
                if (!(await wget(() => shopRoot(), 3000))) {
                    wsay('🛒 ร้านยังไม่เปิด — ลองกดแถวตัวเลือกอีกครั้ง');
                    const o2 = wfind(optRe)[0]; if (o2) { wtap(o2); await sleep(400); wtap(wclk(o2)); }
                    if (!(await wget(() => shopRoot(), 3000))) { pressKey('1', 'Digit1', 49); wsay('🛒 ลองกดปุ่มเลข 1'); }
                }
                if (!(await wget(() => shopRoot(), 5000))) throw new Error('ร้านค้าไม่เปิด (กดตัวเลือก "ซื้อของหน่อย" แล้วหน้าร้านไม่ขึ้น)');
                await sleep(BUY_STEP);
                // เพิ่มทุกรายการลงตะกร้าให้ครบก่อน (ตั้งจำนวน + Enter) แล้วกดซื้อครั้งเดียว
                const added = [];
                for (const it of need) { if (W.abort) break; try { added.push(Object.assign(await shopAdd(it.n, it.q), { have: it.have })); } catch (e) { wsay(`🛒 ข้าม ${it.n}: ${e.message}`, 'warn'); } await sleep(BUY_STEP); }
                let cleared = false;
                if (added.length && !W.abort) {
                    cleared = await shopCheckout(added); wsay("🛒 ตะกร้าว่างหลังซื้อ: " + (cleared ? "ใช่" : "ไม่ใช่"));
                    await sleep(BUY_STEP);
                }
                // ปิดร้าน
                const x = [...document.querySelectorAll('button')].find((b) => !wmine(b) && wvis(b) && /^\s*[✕×xX]\s*$/.test(norm(b.textContent || '')) && b.closest('[class*="shop" i],[class*="modal" i],[class*="dialog" i],div'));
                if (x && shopRoot()) wtap(x); await sleep(BUY_STEP); if (shopRoot()) wEsc(); await sleep(300);
                if (added.length) {
                    const ok = [], bad = [];
                    for (const it of added) { const after = await itemCount(it.n); if (after >= 0) wsay(`🛒 ${it.n} ตอนนี้ ${after} ชิ้น (ก่อนซื้อ ${it.have < 0 ? '?' : it.have})`); (it.have >= 0 && after >= 0 ? after - it.have >= it.q : cleared) ? ok.push(`${it.n}×${it.q}`) : bad.push(it.n + `(ก่อน ${it.have} หลัง ${after})`); }
                    if (ok.length) { did = true; wsay(`✅ ซื้อแล้ว (ยืนยันจากจำนวนในตัว): ${ok.join(', ')}`); try { Log.info('BUY', `ซื้อแล้ว: ${ok.join(', ')}`); showToast(`🛒 ซื้อแล้ว ${ok.join(', ')}`, 'ok'); } catch (e) { /* ignore */ } }
                    if (bad.length) wsay(`⚠️ กดซื้อแล้วแต่ยังไม่เห็นของเข้าตัว: ${bad.join(', ')} — ตรวจดูหน้าร้าน/Log "ปุ่มที่เห็น"`, 'warn');
                }
            } catch (e) { wsay('❌ ซื้อของไม่สำเร็จ: ' + (e && e.message ? e.message : e), 'warn'); try { if (shopRoot()) wEsc(); } catch (er) { /* ignore */ } }
            finally { InvLock.owner = ''; if (!wasRun) { W.run = false; State.warpHold = false; } if (Date.now() - Pause.inputAt > 3000) unfocusChat(did ? 'หลังซื้อของ' : ''); }
            return did;
        }
        // 📈 อัพสเตตัสอัตโนมัติ: กด C เปิดหน้าตัวละคร → กด + ตามลำดับที่ตั้ง (ค่าฐานถึงเป้าแล้วไปตัวถัดไป) · แต้มไม่พอ/กดไม่ได้ = หยุดเฉยๆ
        const STAT_KEYS = ['STR', 'AGI', 'VIT', 'INT', 'DEX', 'LUK'], STAT_STEP = 450, ST = { busy: false, lastPts: -2, lastAt: 0, method: (() => { try { return localStorage.getItem('at_stat_m') || ''; } catch (e) { return ''; } })(), dbl: {} };
        const stTap = (el, k) => {
            if (k === 'click') { el.click(); return; } if (k === 'full') { wtap(el); return; }
            const r = el.getBoundingClientRect(), o = { bubbles: true, cancelable: true, view: VIEW, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0, buttons: 1 };
            const ts = k === 'pointer' ? ['pointerover', 'pointerdown', 'pointerup'] : ['mouseover', 'mousedown', 'mouseup'];
            for (const t of ts) { try { el.dispatchEvent(/^pointer/.test(t) ? new PointerEvent(t, Object.assign({ pointerType: 'mouse', isPrimary: true }, o)) : new MouseEvent(t, o)); } catch (e) { /* ignore */ } }
        };
        const cxy = (e) => { const r = e.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2, l: r.left, r: r.right }; };
        // แต้มสถานะ: (1) ในหน้าตัวละครที่เปิดอยู่ (.stat-points) (2) ปุ่ม HUD "แต้มสถานะ N" — ตอนย่อจอปุ่มนี้ยังอยู่ในหน้าแต่ถูกซ่อน จึงอ่านแม้มองไม่เห็น
        // (3) มีกรอบ HUD แต่ไม่มีปุ่ม = เกมไม่แสดงปุ่มเมื่อแต้ม = 0
        function statPoints() {
            const sp = document.querySelector('.stat-points strong');
            if (sp && wvis(sp)) { const v = parseInt(norm(sp.textContent || '').replace(/,/g, ''), 10); if (isFinite(v)) return v; }
            const b = hudStatBtn(); if (b) { const m = /แต้มสถานะ\s*([\d,]+)/.exec(norm(b.textContent || '')); if (m) return parseInt(m[1].replace(/,/g, ''), 10); }
            const e = wfind(/แต้มสถานะ\s*[\d,]+/)[0];
            if (e) { const m = /แต้มสถานะ\s*([\d,]+)/.exec(norm(e.textContent || '')); if (m) return parseInt(m[1].replace(/,/g, ''), 10); }
            return document.querySelector('.hud-status') ? 0 : -1;
        }
        function statPanel() {
            const labs = wfind(/^(STR|AGI|VIT|INT|DEX|LUK)$/, 'span,div,b,label,strong,p');
            const by = {}; labs.forEach((e) => { const k = norm(e.textContent); if (!by[k]) by[k] = e; });
            if (STAT_KEYS.some((k) => !by[k])) return null;
            let root = by.STR; for (let i = 0; i < 8 && root && !STAT_KEYS.every((k) => root.contains(by[k])); i++) root = root.parentElement; if (!root) return null;
            const leaves = [...root.querySelectorAll('*')].filter((e) => !e.children.length && wvis(e));
            const plusAll = [...root.querySelectorAll('button,[role="button"]')].filter((b) => wvis(b) && /^[+＋]$/.test(norm(b.textContent || '')));
            const row = (k, list, test) => { const c = cxy(by[k]); let best = null, bd = 1e9; for (const e of list) { if (!test(e)) continue; const p = cxy(e); if (Math.abs(p.y - c.y) > 14 || p.x < c.x - 2) continue; const d = p.x - c.x; if (d < bd) { bd = d; best = e; } } return best; };
            const val = (k) => { const e = row(k, leaves, (n) => /^\d+(\s*\(\+?\d+\))?$/.test(norm(n.textContent || ''))); return e ? parseInt(norm(e.textContent), 10) : -1; };
            const plus = (k) => row(k, plusAll, () => true);
            const cost = (k) => { const b = plus(k); if (!b) return ''; const bc = cxy(b), c = cxy(by[k]); let best = null, bd = 1e9; for (const e of leaves) { if (!/^(\d+|[-–—])$/.test(norm(e.textContent || ''))) continue; const p = cxy(e); if (Math.abs(p.y - c.y) > 14 || p.x <= bc.x) continue; if (p.x - bc.x < bd) { bd = p.x - bc.x; best = e; } } return best ? norm(best.textContent) : ''; };
            return { val, plus, cost };
        }
        // เปิดหน้าตัวละครด้วยปุ่ม HUD "แต้มสถานะ N" (ไม่ต้องกด C) · ไม่เจอ/ไม่เปิด → ใช้ปุ่ม C แทน
        const hudStatBtn = () => [...document.querySelectorAll('.hud-alerts button')].find((b) => /^\s*แต้มสถานะ\s*[\d,]*\s*$/.test(norm(b.textContent || '')))      // ซ่อนอยู่ (ย่อจอ) ก็ใช้ได้ — กดด้วย .click() ได้เหมือนกัน
            || [...document.querySelectorAll('button')].find((b) => !wmine(b) && wvis(b) && !b.closest('.character-window') && /^\s*แต้มสถานะ\s*[\d,]*\s*$/.test(norm(b.textContent || '')));
        async function openChar() {
            const h = hudStatBtn();
            if (h) { h.click(); let p = await wget(statPanel, 1800); if (p) return p; if (wvis(h)) { wtap(h); p = await wget(statPanel, 2500); if (p) return p; } }
            pressKey('c', 'KeyC', 67); return await wget(statPanel, 3500);
        }
        async function closeChar() {
            const w = document.querySelector('.character-window');
            const x = w && [...w.querySelectorAll('button')].find((b) => wvis(b) && (/^\s*[✕×xX]\s*$/.test(norm(b.textContent || '')) || /close|ปิด/i.test(b.getAttribute('aria-label') || '')));
            if (x) { x.click(); await sleep(500); if (!statPanel()) return; }
            pressKey('c', 'KeyC', 67); await sleep(500);
        }
        const btnOff = (b) => !b || b.disabled || b.getAttribute('aria-disabled') === 'true' || /disabled/i.test(b.className || '');
        const waitVal = async (key, from, ms) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { await sleep(80); const q = statPanel(); const v = q ? q.val(key) : -1; if (v > from) { await sleep(250); const q2 = statPanel(); const v2 = q2 ? q2.val(key) : v; return v2 > v ? v2 : v; } } return from; };      // เจอค่าเปลี่ยนแล้วรออีกนิดอ่านซ้ำ กันนับเลื่อน
        // รอค่าเพิ่มจาก from แล้วรอให้ "นิ่ง" (ไม่เปลี่ยนต่อ 600ms) ก่อนคืนค่า — กันอ่านค่าระหว่างที่เกมยังส่งค่าไม่ครบ
        const settleVal = async (key, from, ms) => {
            const rd = () => { const q = statPanel(); return q ? q.val(key) : -1; };
            const t0 = Date.now(); let v = rd();
            while (v <= from && Date.now() - t0 < ms) { await sleep(80); v = rd(); }
            if (v <= from) return v;
            let last = v, at = Date.now(); const t1 = Date.now();
            while (Date.now() - at < 600 && Date.now() - t1 < 2500) { await sleep(100); const w = rd(); if (w !== last && w >= 0) { last = w; at = Date.now(); } }
            return last;
        };
        // ⚔️ อยู่แมพฟาร์มและเปิดบอท Z ไว้ แต่ Auto ยังไม่ทำงาน → เปิด Z ก่อน ให้ตีมอนไปด้วยระหว่างอัพสเตตัส (ไม่ยืนให้มอนตีเปล่า ๆ)
        const wSafeMap = (m) => CONFIG.SAFE_MAPS.some((x) => m.includes(x)) || CONFIG.SAFE_MAP_KEYWORDS.some((k) => m.includes(k));
        async function autoFirst(why) {
            const m = wcur();
            if (!State.isAutoEnabled || autoPaused() || !m || wSafeMap(m) || Frame.dead || Frame.captcha || wautoOn() || !wautoBtn()) return;
            wsay(`⚔️ เปิด Auto (Z) ก่อน แล้วค่อย${why}`);
            pressKey('z', 'KeyZ', 90);
            if (!(await wget(() => wautoOn(), 1500))) { const b = wautoBtn(); if (b) triggerClick(b); await wget(() => wautoOn(), 1500); }
            State.autoAttempts = 0; State.lastAutoAttempt = Date.now();
            await sleep(300);
        }
        async function statRun(force) {
            if (ST.busy) return false;
            if (!force && (W.run || InvLock.owner || Frame.captcha)) return false;
            const plan = (State.opt.stat || []).filter((x) => x && STAT_KEYS.includes(x.s) && +x.t > 0);
            ST.planSig = JSON.stringify(State.opt.stat || []);
            if (!plan.length) { if (force) wsay('📈 ยังไม่ได้ตั้งลำดับสเตตัส', 'warn'); return false; }
            ST.busy = true; const prevOwner = InvLock.owner; InvLock.owner = 'stat'; let opened = false, did = 0; const touched = new Set();
            try {
                try { if (document.activeElement && document.activeElement !== document.body) document.activeElement.blur(); } catch (e) { /* ignore */ }
                if (!statPanel()) await autoFirst('อัพสเตตัส');
                let p = statPanel();
                if (!p) { opened = true; p = await openChar(); }
                if (!p) throw new Error('เปิดหน้าตัวละครไม่สำเร็จ (ลองทั้งปุ่ม "แต้มสถานะ" และ C)');
                await sleep(400);
                const pts0 = statPoints();
                if (pts0 === 0) { wsay('📈 แต้มสถานะเหลือ 0 — ไม่มีอะไรให้อัพ'); return false; }
                wsay(`📈 เริ่มอัพ (แต้มเหลือ ${pts0 < 0 ? '?' : pts0}) ตามลำดับ: ${plan.map((x) => x.s + '→' + x.t).join(', ')}`);
                // ยืนยันทีละสเตตัส: (1) เกินเป้าแล้วกด "ยกเลิก" จะคืนเฉพาะแต้มของสเตตัสนั้น ไม่ล้างตัวอื่น (2) กันเกมล็อกปุ่ม + ของสเตตัสอื่นระหว่างมีแต้มค้าง
                const confirmNow = async () => {
                    await sleep(500);
                    const cf = await wget(() => wbtn(/^\s*ยืนยัน\s*$/), 2500); if (!cf) return false;
                    await sleep(BUY_STEP); cf.click(); await sleep(700);
                    await wget(() => !wbtn(/^\s*ยืนยัน\s*$/), 3000); await sleep(400);
                    return true;
                };
                const cancelNow = async () => { const cc = wbtn(/^\s*ยกเลิก\s*$/); if (!cc) return false; cc.click(); await sleep(900); return true; };
                outer: for (const it of plan) {
                    let pend = 0, overN = 0;
                    for (let g = 0; g < 200 && !W.abort; g++) {
                        p = statPanel(); if (!p) throw new Error('หน้าตัวละครหายระหว่างอัพ');
                        const cur = p.val(it.s); if (cur < 0) { wsay(`📈 อ่านค่า ${it.s} ไม่ได้ — ข้าม`, 'warn'); break; }
                        if (cur >= it.t) break;
                        const b = p.plus(it.s);
                        if (btnOff(b)) {
                            if (/^[-–—]$/.test(p.cost(it.s))) { wsay(`📈 ${it.s} อัพต่อไม่ได้ (เต็ม) — ไปตัวถัดไป`); break; }
                            if (pend) break;      // ปุ่มถูกล็อกระหว่างมีแต้มค้าง → ยืนยันก่อนแล้วไปต่อ
                            wsay(`📈 แต้มไม่พอสำหรับ ${it.s} (ต้องใช้ ${p.cost(it.s) || '?'} · เหลือ ${statPoints()}) — หยุดรอแต้มเพิ่ม`); break outer;
                        }
                        // เกมนี้ไม่รับ .click() เฉยๆ และการยิงอีเวนต์ครบชุดนับ +2 → ลองวิธีกดทีละแบบ จำแบบที่เพิ่มทีละ 1
                        let moved = false, nv = cur;
                        const kinds = ST.method ? [ST.method] : ['pointer', 'mouse', 'click', 'full'].filter((k) => !ST.dbl[k]);
                        if (!kinds.length) kinds.push(...Object.keys(ST.dbl));
                        for (const k of kinds) {
                            if (ST.dbl[k] && it.t - cur < ST.dbl[k]) continue;
                            stTap(b, k); nv = await settleVal(it.s, cur, 3500);      // รอค่าขึ้นแล้ว "นิ่ง" ก่อนตัดสินใจ (เน็ตหน่วง = ค่าขึ้นช้า ไม่ใช่กดไม่ติด)
                            if (nv <= cur) nv = await settleVal(it.s, cur, 2500);      // เผื่อค่าขึ้นช้ามาก — ห้ามกดซ้ำ/เปลี่ยนวิธีก่อนแน่ใจ (กดซ้ำตอนหน่วง = เกินเป้า)
                            if (nv > cur) {
                                const d = nv - cur;
                                if (d === 1) { if (!ST.method) { ST.method = k; try { lsSet('at_stat_m', k); } catch (e) { /* ignore */ } wsay(`📈 วิธีกด + ที่ใช้ได้: ${k}`); } }
                                else if (!ST.method) { ST.dbl[k] = d; wsay(`⚠️ กดแบบ ${k} เพิ่มทีละ ${d} — ลองแบบอื่นต่อ`, 'warn'); }
                                moved = true; did += d; pend += d; touched.add(it.s); break;
                            }
                        }
                        if (!moved) {
                            const q = statPanel();
                            if (q && /^[-–—]$/.test(q.cost(it.s))) break;
                            if (ST.method) { stTap(b, ST.method); nv = await settleVal(it.s, cur, 4500); if (nv > cur) { did += nv - cur; pend += nv - cur; touched.add(it.s); moved = true; } }      // ลองกดซ้ำอีกครั้งก่อนยอมแพ้
                            if (!moved) { wsay(`📈 กด + ที่ ${it.s} แล้วค่าไม่เพิ่ม (ค่า ${cur}, แต้ม ${statPoints()}) — หยุด`, 'warn'); break outer; }
                        }
                        if (nv > it.t) {      // เกินเป้า → ยกเลิกเฉพาะแต้มค้างของสเตตัสนี้ แล้วกดใหม่
                            wsay(`⚠️ ${it.s} เกินเป้า (${nv} > ${it.t}) — กด "ยกเลิก" คืนแต้มของ ${it.s} แล้วกดใหม่ทีละแต้ม`, 'warn');
                            if (!(await cancelNow())) { wsay('⚠️ ไม่เจอปุ่ม "ยกเลิก" — หยุด (ตรวจหน้าตัวละครเอง)', 'warn'); break outer; }
                            did -= pend; pend = 0;
                            if (++overN >= 2) { wsay(`⚠️ ${it.s} กดแล้วเกินเป้าซ้ำ 2 รอบ — ข้าม ${it.s}`, 'warn'); break; }
                        }
                    }
                    if (pend && !W.abort) {
                        if (await confirmNow()) wsay(`📈 ยืนยัน ${it.s} แล้ว (+${pend} → ${(statPanel() || p).val(it.s)})`);
                        else { wsay('⚠️ ไม่เจอปุ่ม "ยืนยัน" — ไม่ปิดหน้าตัวละคร (ปิดตอนนี้แต้มจะถูกคืน) กดยืนยันเอง', 'warn'); opened = false; break outer; }
                    }
                    if (W.abort) break;
                }
                if (wbtn(/^\s*ยืนยัน\s*$/) && did > 0) await confirmNow();      // กันแต้มค้างไม่ได้ยืนยัน
                // ยังมีสเตตัสที่ไม่ถึงเป้าและแต้มพอ → ลองใหม่อีกรอบภายหลัง (ไม่ต้องรอแต้มเพิ่ม)
                { const q = statPanel(), left = statPoints(); ST.retryAt = 0;
                  if (q && left > 0 && plan.some((x) => { const v = q.val(x.s), c = parseInt(q.cost(x.s), 10); return v >= 0 && v < x.t && isFinite(c) && c <= left; })) { ST.retryAt = Date.now() + 45000; ST.retries = (ST.retries || 0) + 1; } else ST.retries = 0; }
                const pts1 = statPoints(); ST.lastPts = pts1; ST.lastAt = Date.now();
                if (did) { wsay(`✅ อัพสเตตัส ${did} ครั้ง (แต้มเหลือ ${pts1 < 0 ? '?' : pts1})`); try { Log.info('STAT', `อัพสเตตัส ${did} ครั้ง · แต้มเหลือ ${pts1}`); } catch (e) { /* ignore */ } }
                else wsay(`📈 ไม่มีอะไรให้อัพ (แต้มเหลือ ${pts0 < 0 ? '?' : pts0} — ครบตามเป้า/แต้มไม่พอ)`);
            } catch (e) { wsay('❌ อัพสเตตัสไม่สำเร็จ: ' + (e && e.message ? e.message : e), 'warn'); ST.lastAt = Date.now(); }
            finally {
                try { if (opened && statPanel()) await closeChar(); } catch (e) { /* ignore */ }
                InvLock.owner = prevOwner === 'stat' ? '' : prevOwner; ST.busy = false;
            }
            return did > 0;
        }
        let stDiagAt = 0;
        const stDiag = (why) => { if (Date.now() - stDiagAt < 60000) return; stDiagAt = Date.now(); try { Log.info('STAT', 'เช็คอัพสเตตัส: ' + why); } catch (e) { /* ignore */ } };
        setInterval(() => {
            try {
                if (!State.opt.statOn || autoPaused() || State.warpHold) return;
                if (ST.busy) return;
                { const b = autoBusy('stat'); if (b) return stDiag('รอ — ' + b); }
                if (Frame.captcha) return stDiag('รอ — มีแคปช่า');
                const dlg = [...document.querySelectorAll('.npc-dialog')].some((d) => wvis(d)); if (dlg) return stDiag('รอ — หน้าต่างคุย NPC เปิดอยู่');
                if (shopRoot()) return stDiag('รอ — ร้านค้าเปิดอยู่');
                // เปลี่ยนค่าเป้า / ลำดับ / เพิ่ม-ลบสเตตัสระหว่างเปิดอยู่ → เริ่มอัพตามแผนใหม่ทันที (เดิมรอจนแต้มเพิ่มเท่านั้น จึงดูเหมือนไม่อัพต่อ)
                { const sig = JSON.stringify(State.opt.stat || []);
                  if (ST.planSig === undefined) ST.planSig = sig;
                  else if (sig !== ST.planSig) {      // รอให้พิมพ์/จัดลำดับเสร็จ (ค่าไม่เปลี่ยนต่อ ~5 วิ) ก่อน กันอัพตามตัวเลขที่พิมพ์ค้างครึ่งทาง
                      if (ST.sigWait !== sig) { ST.sigWait = sig; ST.sigAt = Date.now(); return; }
                      if (Date.now() - ST.sigAt < 5000) return;
                      ST.planSig = sig; ST.sigWait = ''; ST.lastPts = -2; ST.retryAt = 0; ST.retries = 0; ST.lastAt = 0; Log.info('STAT', 'เปลี่ยนลำดับ/ค่าเป้าสเตตัส — อัพตามแผนใหม่');
                  } }
                const pts = statPoints();
                if (pts < 0) return stDiag('อ่านแต้มสถานะไม่ได้ (ไม่เห็นข้อความ "แต้มสถานะ N" บนจอ) — กด "อัพตอนนี้" เพื่อลองเอง');
                if (pts === 0) return;
                if (pts > ST.lastPts) { stDiag(`แต้มเพิ่มเป็น ${pts} — เริ่มอัพ`); statRun(false); }
                else if (ST.retryAt && Date.now() > ST.retryAt && (ST.retries || 0) <= 5) { ST.retryAt = 0; stDiag(`ยังอัพไม่ครบตามลำดับ (แต้มเหลือ ${pts}) — อัพต่อ`); statRun(false); }      // แต้มเหลือน้อย/อัพไม่ได้ = ไม่ทำอะไร รอจนแต้มเพิ่มขึ้นกว่าเดิมค่อยเปิดหน้าตัวละคร
            } catch (e) { /* ignore */ }
        }, 8000);
        // 🧪 ทดสอบเดินไกล: เดินไปหา NPC (เช่น Shopkeeper) ในแมพนี้ แล้วเปิดหน้าต่างคุย · จับเวลาและบอกระยะ
        async function walkTalk(nameRaw) {
            if (W.run) { wsay('กำลังทำงานอยู่ — กด ⏹ หยุด ก่อน'); return; }
            if (Frame.captcha) { wsay('มีแคปช่าขึ้นอยู่ — ไม่เดิน', 'warn'); return; }
            if (InvLock.owner) { wsay(`กำลังใช้กระเป๋าอยู่ (${InvLock.owner}) — รอสักครู่`, 'warn'); return; }
            const name = norm(nameRaw || '') || 'Shopkeeper';
            W.run = true; W.abort = false; W.auto = false; W.dest = ''; InvLock.owner = 'walktest'; State.warpHold = true;
            try {
                update(); await wget(() => (D.tm && D.tmFor === wclean(wcur()) ? 1 : 0), 6000);
                const npcs = (D.tm ? D.tm.objs : []).filter((o) => o.kind === 'npc');
                const re = new RegExp(wesc(name), 'i'); const hit = npcs.filter((o) => re.test(o.name || ''));
                if (!hit.length) { wsay(`❌ ไม่พบ NPC "${name}" ในแมพนี้ ${npcs.length ? '(มี: ' + [...new Set(npcs.map((o) => o.name).filter(Boolean))].slice(0, 8).join(', ') + ')' : '(ยังโหลดแผนที่ไม่ได้)'}`, 'warn'); return; }
                const me = minimapCell() || { x: 0, z: 0 }; const dd = (o) => Math.abs((o.c0 + o.c1) / 2 - me.x) + Math.abs((o.z0 + o.z1) / 2 - me.z);
                hit.sort((a, b) => dd(a) - dd(b)); const npc = hit[0], dist = Math.round(dd(npc)), t0 = Date.now();
                wsay(`🧪 เดินไปหา ${npc.name} (ห่าง ~${dist} ช่อง)…`); D.talkOk = false;
                await talkTo(npc);
                const sec = ((Date.now() - t0) / 1000).toFixed(1);
                wsay(D.talkOk ? `✅ ถึงและเปิดคุยกับ ${npc.name} แล้ว · ~${dist} ช่อง ใช้ ${sec} วิ` : `⚠️ เดินไปหา ${npc.name} แล้วแต่ยังไม่เห็นหน้าต่างคุย (${sec} วิ)`, D.talkOk ? 'info' : 'warn');
            } catch (e) { wsay('❌ ' + (e && e.message ? e.message : e), 'warn'); }
            finally { InvLock.owner = ''; W.run = false; State.warpHold = false; }
        }
        function npcNames() {
            try { update(); } catch (e) { /* ignore */ }
            const m = new Map(); for (const o of (D.tm ? D.tm.objs : [])) if (o.kind === 'npc' && o.name) m.set(o.name, (m.get(o.name) || 0) + 1);
            return [...m.keys()].sort((a, b) => a.localeCompare(b));
        }
        function warpStop() { if (W.run) { W.abort = true; D.abort = true; wsay('กำลังหยุด…'); } }
        // ↩️ สวิตช์กลับแมพเดิม: ปิด = หยุดงานอัตโนมัติที่กำลังทำทันที + ยกเลิกคิว รอจนเปิดใหม่ · เปิด = ถ้าอยู่ในเมืองและมีแมพที่จำไว้ จะไปต่อทันที
        function warpBackOff() { BK.townAt = 0; if (W.run && W.auto) { warpStop(); wsay('ปิดสวิตช์กลับแมพเดิม — หยุดแล้ว รอเปิดใหม่'); } else wsay('ปิดสวิตช์กลับแมพเดิมแล้ว'); }
        function warpBackOn() { try { const m = wclean(wcur()); if (/เมืองหลวง/.test(m) && BK.field && !W.run) { BK.townAt = Date.now() - 1500; BK.lastTry = 0; BK.fails = 0; } wsay('เปิดสวิตช์กลับแมพเดิมแล้ว'); } catch (e) { /* ignore */ } }
        // 🎯 เลือกแมพใหม่ → ไปแมพที่เลือกเลย (เปิดหรือปิดสวิตช์ก็ได้): หยุดงานเดิมก่อนถ้ามี · ถ้าอยู่นอกเมือง จะไปทันทีที่เข้าเมือง · และใช้แมพนี้เป็นแมพที่จะกลับมาให้ด้วย
        async function warpPick(nameRaw) {
            const name = norm(nameRaw || ''); if (!name) return;
            bkSync();
            try { Store.set('at_warp_dest', name); lsSet(wlKey(), name); } catch (e) { /* ignore */ }
            const wi = document.getElementById('at-warp-dest'); if (wi) wi.value = name;
            BK.field = name; BK.fails = 0; BK.townAt = 0;
            const m = wclean(wcur());
            if (m && m.includes(name)) { BK.pickGo = false; wsay(`อยู่ที่ ${name} แล้ว`); return; }
            if (W.run && W.dest === name) return;     // กำลังไปแมพนี้อยู่แล้ว
            if (W.run) { warpStop(); const t0 = Date.now(); while (W.run && Date.now() - t0 < 20000) await sleep(200); }
            if (!/เมืองหลวง/.test(m)) {
                // 🦋 เปลี่ยนแมพกะทันหันระหว่างฟาร์ม → ใช้ Butterfly Wing กลับเมืองทันที แล้ววาร์ปไปแมพที่เลือก
                const bw = State.opt.pickBw && !Frame.captcha ? hotSlotOf('Butterfly Wing', 'Fly Wing') : null;
                if (bw && hotCnt(bw) !== 0) {
                    wsay(`🦋 เปลี่ยนไป ${name} — ใช้ Butterfly Wing กลับเมืองก่อน`);
                    let ok = false;
                    W.run = true; W.abort = false; W.auto = false; W.dest = name; State.warpHold = true;
                    try { await wAutoOff(); wtap(bw); ok = !!(await wget(() => (/เมืองหลวง/.test(wcur()) ? 1 : 0), 15000, 300)); } finally { W.run = false; }
                    if (ok) {
                        BK.pickGo = false; await sleep(2000);      // State.warpHold ยังค้างไว้ กันระบบอื่น (อัพสเตตัส ฯลฯ) แทรกก่อนวาร์ป
                        if (State.opt.buyOn) { try { await buyRun(); } catch (e) { /* ignore */ } }
                        const r = await warpTo(name);
                        State.warpHold = false;
                        return r;
                    }
                    State.warpHold = false;
                    wsay('🦋 ใช้ Butterfly Wing แล้วไม่กลับเมือง — จะวาร์ปให้เมื่อกลับเมืองหลวง', 'warn');
                } else if (State.opt.pickBw) wsay('🦋 ไม่พบ Butterfly Wing ในแถบด่วน', 'warn');
                BK.pickGo = true; BK.pickAt = 0; wsay(`ตั้งปลายทางเป็น ${name} แล้ว — ตอนนี้อยู่นอกเมือง จะวาร์ปทันทีที่เข้าเมืองหลวง`); return;
            }
            BK.pickGo = false; return warpTo(name);
        }
        async function warpNames() {
            try {
                const dl = document.getElementById('at-warp-list'); if (!dl || dl.childElementCount) return;
                let names = []; try { names = JSON.parse(localStorage.getItem('at_warp_names') || '[]'); } catch (e) { /* ignore */ }
                if (!names.length) {
                    const get = async (u) => { const r = await PW.fetch(u, { credentials: 'same-origin' }); if (!r.ok) throw new Error(r.status); return r.json(); };
                    const ids = new Set(); const at = await get('/world/atlas'); (at.links || []).forEach((l) => l.forEach((x) => ids.add(String(x).replace(/^aet_/, ''))));
                    for (const id of ids) { try { const j = await get(`/maps/${id}.json`); const pr = j.properties; const d = Array.isArray(pr) ? (pr.find((q) => q.name === 'displayName') || {}).value : pr && pr.displayName; if (d) names.push(String(d)); } catch (e) { /* ignore */ } }
                    try { lsSet('at_warp_names', JSON.stringify(names)); } catch (e) { /* ignore */ }
                }
                names.forEach((n) => { const o = document.createElement('option'); o.value = n; dl.appendChild(o); });
            } catch (e) { /* ignore */ }
        }
        function placeDefault() {
            const el = D.fr; if (!el) return; const mp = document.getElementById('aetheria-tracker'); const r = mp ? mp.getBoundingClientRect() : null;
            const left = r ? r.right + 28 : 16; el.style.left = (left + 380 > innerWidth ? Math.max(8, r ? r.left - 380 : 16) : left) + 'px'; el.style.top = '60px';
        }
        function build() {
            if (D.el) return;
            // แผง Dev อยู่ใน iframe: เหตุการณ์เมาส์/คลิกข้างในจะไม่ไหลออกมาถึงหน้าเกม (ตัวละครไม่เดินเองตอนกดแผง)
            const fr = document.createElement('iframe'); fr.id = 'aetheria-dev'; fr.title = 'Aetherack Dev';
            fr.style.cssText = 'position:fixed;left:16px;top:130px;width:362px;height:560px;z-index:2147483000;border:1px solid #a78bfa;border-radius:12px;background:#0e0e14;color-scheme:dark;box-shadow:0 8px 30px rgba(0,0,0,.5)';
            document.body.appendChild(fr);
            const doc = fr.contentDocument; doc.open(); doc.write('<!doctype html><meta charset="utf-8"><body style="margin:0;background:#0e0e14;overflow-x:hidden"></body>'); doc.close();
            const el = doc.createElement('div'); el.id = 'aetheria-dev-body';
            el.style.cssText = 'width:100%;box-sizing:border-box;color:#e5e7eb;font:12px/1.5 system-ui,sans-serif';
            el.innerHTML = `<div id="dv-h" style="cursor:move;padding:8px 10px;display:flex;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,.1)"><b>🧪 Dev Mode · ตรวจช่อง x,z</b><span id="dv-x" style="cursor:pointer">✕</span></div>
<div style="padding:8px 10px;display:grid;gap:5px">
<div id="dv-eng"></div><div id="dv-map" style="opacity:.8"></div>
<div style="display:flex;gap:10px"><div style="flex:1;background:rgba(250,204,21,.12);border-radius:8px;padding:6px"><div style="opacity:.7">🖱️ เมาส์ชี้ช่อง (x, z)</div><div id="dv-hover" style="font-size:20px;font-weight:700;color:#facc15">—</div></div>
<div style="flex:1;background:rgba(74,222,128,.12);border-radius:8px;padding:6px"><div style="opacity:.7">📍 ตัวเรา (x, z)</div><div id="dv-me" style="font-size:16px;font-weight:700;color:#4ade80">—</div></div></div>
<div id="dv-cnt" style="opacity:.8"></div>
<div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap"><b>🗺️ แผนที่</b><button id="dv-zo">−</button><button id="dv-zi">+</button><label><input type="checkbox" id="dv-walk" checked> คลิกที่แผนที่เพื่อเดิน</label><button id="dv-stop">⏹ หยุด</button></div>
<div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap"><label><input type="checkbox" id="dv-zone"> ✏️ ลากกำหนดโซนฟาร์ม</label><button id="dv-zundo">↩️ ลบโซนล่าสุด</button><button id="dv-zclr">🗑️ ล้างโซนแมพนี้</button></div><div id="dv-zinfo" style="opacity:.85"></div>
<canvas id="dv-map2" width="338" height="260" style="width:338px;height:260px;cursor:crosshair;border-radius:6px;background:#0b0b12;border:1px solid rgba(255,255,255,.15)"></canvas>
<div id="dv-mh" style="opacity:.9;min-height:18px"></div>
<label><input type="checkbox" id="dv-grid"> เส้นตารางบนหน้าจอเกม</label> <label><input type="checkbox" id="dv-marks"> ไฮไลต์ NPC/มอนบนจอเกม</label>
<label>ขนาดช่อง (px) ถ้าอ่านเองไม่ได้ <input id="dv-px" type="number" min="0" style="width:60px;background:#222;color:#fff;border:1px solid #444;border-radius:4px"></label>
<div style="opacity:.75">ปรับให้เส้นตารางตรงกับช่องในเกม: px ต่อช่อง (32×ซูม) และเลื่อนเส้น <input id="dv-ox" type="number" style="width:50px;background:#222;color:#fff;border:1px solid #444;border-radius:4px" title="เลื่อนแนวนอน px"> <input id="dv-oz" type="number" style="width:50px;background:#222;color:#fff;border:1px solid #444;border-radius:4px" title="เลื่อนแนวตั้ง px"></div>
<div style="display:flex;gap:6px;flex-wrap:wrap"><button id="dv-diag">📋 คัดลอกรายงานวินิจฉัย</button><button id="dv-json">💾 คัดลอก JSON แมพ</button><button id="dv-clr">🧹 ล้างข้อมูลแมพนี้</button></div>
<div id="dv-list" style="max-height:200px;overflow:auto;border-top:1px solid rgba(255,255,255,.1);padding-top:6px;word-break:break-all"></div></div>`;
            el.querySelectorAll('button').forEach((b) => { b.style.cssText = 'background:rgba(255,255,255,.1);color:#fff;border:1px solid rgba(255,255,255,.2);border-radius:6px;padding:3px 7px;cursor:pointer;font-size:11px'; });
            doc.body.appendChild(el); D.el = el; D.fr = fr; D.doc = doc;
            fr.addEventListener('mouseenter', () => { D.inPanel = true; }); fr.addEventListener('mouseleave', () => { D.inPanel = false; });
            // วางห่างจากแผง Aetherack หลัก (ไม่ชิดกัน) · จำตำแหน่งที่ลากไว้
            try {
                const sv = JSON.parse(LS('at_dev_pos', 'null'));
                if (sv && typeof sv.x === 'number') { fr.style.left = Math.max(0, Math.min(innerWidth - 120, sv.x)) + 'px'; fr.style.top = Math.max(0, Math.min(innerHeight - 60, sv.y)) + 'px'; }
                else placeDefault();
            } catch (e) { /* ignore */ }
            const ov = document.createElement('canvas'); ov.id = 'at-dev-ov'; ov.style.cssText = 'position:fixed;pointer-events:none;z-index:2147482000'; document.body.appendChild(ov); D.ov = ov;
            el.querySelector('#dv-x').onclick = () => setOn(false);
            el.querySelector('#dv-grid').onchange = (e) => { D.grid = e.target.checked; try { lsSet('at_dev_grid2', D.grid ? '1' : '0'); } catch (x) { /* ignore */ } };
            el.querySelector('#dv-marks').onchange = (e) => { D.marks = e.target.checked; try { lsSet('at_dev_marks2', D.marks ? '1' : '0'); } catch (x) { /* ignore */ } };
            el.querySelector('#dv-px').onchange = (e) => { D.px = Math.max(0, Number(e.target.value) || 0); try { lsSet('at_dev_px', String(D.px)); } catch (x) { /* ignore */ } };
            const offSet = (k, id) => { el.querySelector(id).onchange = (e) => { D.off[k] = Number(e.target.value) || 0; try { lsSet('at_dev_o' + k, String(D.off[k])); } catch (x) { /* ignore */ } }; el.querySelector(id).value = D.off[k] || ''; };
            offSet('x', '#dv-ox'); offSet('z', '#dv-oz');
            el.querySelector('#dv-diag').onclick = () => copy(diag(), 'คัดลอกรายงานวินิจฉัยแล้ว — วางส่งให้ Claude ได้เลย');
            el.querySelector('#dv-json').onclick = () => copy(JSON.stringify({ map: D.mapName, ...(D.maps[D.mapName] || {}), me: D.me }, null, 1), 'คัดลอก JSON แมพแล้ว');
            el.querySelector('#dv-clr').onclick = () => { delete D.maps[D.mapName || '(ไม่ทราบแมพ)']; save(); render(); };
            D.mini = el.querySelector('#dv-map2');
            D.mini.addEventListener('mousemove', (e) => { D.mh = miniCell(e); const m = D.tm; const ob = (m && D.mh) ? m.objs.filter((o) => D.mh.x >= o.c0 && D.mh.x <= o.c1 && D.mh.z >= o.z0 && D.mh.z <= o.z1) : []; el.querySelector('#dv-mh').textContent = D.mh ? `ช่อง ${D.mh.x}, ${D.mh.z}${m && m.col && D.mh.x >= 0 && D.mh.z >= 0 && D.mh.x < m.w && D.mh.z < m.h && m.col[D.mh.z * m.w + D.mh.x] ? ' · ⛔ ชน' : ''}${ob.length ? ' · ' + ob.map((o) => `${o.kind}:${o.name || o.type}`).join(', ') : ''}` : ''; });
            const zmode = () => !!(el.querySelector('#dv-zone') || {}).checked;
            const zclamp = (c) => { const m = D.tm; if (!c || !m) return c; return { x: Math.max(0, Math.min(m.w - 1, c.x)), z: Math.max(0, Math.min(m.h - 1, c.z)) }; };
            const zcommit = () => { if (!D.zs || !D.ze) { D.zs = D.ze = null; return; } const k = zKey(); if (k) { const a = [Math.min(D.zs.x, D.ze.x), Math.min(D.zs.z, D.ze.z), Math.max(D.zs.x, D.ze.x), Math.max(D.zs.z, D.ze.z)]; const l = zonesFor(k).slice(); l.push(a); zonesSave(k, l); say(`เพิ่มโซนฟาร์ม ${a[0]},${a[1]} → ${a[2]},${a[3]} (รวม ${l.length} โซน)`); } D.zs = D.ze = null; };
            D.mini.addEventListener('mousedown', (e) => { if (!zmode() || e.button !== 0) return; D.zs = D.ze = zclamp(miniCell(e)); e.preventDefault(); });
            D.mini.addEventListener('mousemove', (e) => { if (D.zs) D.ze = zclamp(miniCell(e)); });
            D.mini.addEventListener('mouseup', () => { if (D.zs) zcommit(); });
            D.mini.addEventListener('mouseleave', () => { D.mh = null; if (D.zs) zcommit(); });
            D.mini.addEventListener('contextmenu', (e) => { if (!zmode()) return; e.preventDefault(); const c = miniCell(e), k = zKey(); if (!c || !k) return; const l = zonesFor(k).slice(); const i = l.findIndex((z) => inZones([z], c)); if (i >= 0) { l.splice(i, 1); zonesSave(k, l); say('ลบโซนแล้ว'); } });
            el.querySelector('#dv-zundo').onclick = () => { const k = zKey(), l = zonesFor(k).slice(); l.pop(); zonesSave(k, l); };
            el.querySelector('#dv-zclr').onclick = () => { zonesSave(zKey(), []); };
            D.mini.addEventListener('click', (e) => { const c = miniCell(e); if (!c || zmode() || !el.querySelector('#dv-walk').checked) return; if (D.tm && (c.x < 0 || c.z < 0 || c.x >= D.tm.w || c.z >= D.tm.h)) return; const npc = D.tm && D.tm.objs.find((o) => o.kind === 'npc' && c.x >= o.c0 && c.x <= o.c1 && c.z >= o.z0 && c.z <= o.z1); if (npc) talkTo(npc); else goTo(c); });
            el.querySelector('#dv-list').addEventListener('click', (e) => {
                const row = e.target.closest && e.target.closest('.dv-npc,.dv-go'); if (!row || !D.tm) return;
                const o = D.tm.objs[Number(row.dataset.i)]; if (!o) return;
                if (row.classList.contains('dv-npc')) talkTo(o); else goTo({ x: Math.floor((o.c0 + o.c1) / 2), z: Math.floor((o.z0 + o.z1) / 2) });
            });
            el.querySelector('#dv-stop').onclick = () => { D.abort = true; D.target = null; say('หยุดเดินแล้ว'); };
            const zs = (f) => { D.zoom = Math.max(12, Math.min(160, Math.round(D.zoom * f))); try { lsSet('at_dev_zoom', String(D.zoom)); } catch (x) { /* ignore */ } };
            el.querySelector('#dv-zi').onclick = () => zs(0.7); el.querySelector('#dv-zo').onclick = () => zs(1.4);
            const hd = el.querySelector('#dv-h'); let drag = null;
            hd.addEventListener('pointerdown', (e) => { if (e.target && e.target.id === 'dv-x') return; drag = { sx: e.screenX, sy: e.screenY, l: fr.offsetLeft, t: fr.offsetTop }; try { hd.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ } e.preventDefault(); });
            hd.addEventListener('pointermove', (e) => { if (drag) { fr.style.left = (drag.l + e.screenX - drag.sx) + 'px'; fr.style.top = (drag.t + e.screenY - drag.sy) + 'px'; } });
            hd.addEventListener('pointerup', () => { if (drag) { try { lsSet('at_dev_pos', JSON.stringify({ x: fr.offsetLeft, y: fr.offsetTop })); } catch (x) { /* ignore */ } } drag = null; });
        }
        function setOn(v) {
            D.on = !!v; try { lsSet('at_dev_on', D.on ? '1' : '0'); } catch (e) { /* ignore */ }
            const b = document.getElementById('at-btn-dev'); if (b) b.classList.toggle('active', D.on);
            clearInterval(D.timer); clearInterval(D.rt); D.timer = 0;
            try {
                if (D.on) {
                    build(); D.fr.style.display = ''; D.ov.style.display = ''; D.ov.width = 0;
                    const r = D.fr.getBoundingClientRect();
                    if (r.right < 80 || r.left > innerWidth - 80 || r.top < 0 || r.top > innerHeight - 60) { placeDefault(); try { lsDel('at_dev_pos'); } catch (e) { /* ignore */ } }
                    try { update(); draw(); drawMini(); render(); } catch (e) { /* ignore */ }
                    D.timer = setInterval(() => { if (document.hidden) return; try { update(); draw(); drawMini(); } catch (e) { /* ignore */ } }, 150);
                    let n = 0; D.rt = setInterval(() => { if (document.hidden) return; try { render(); if (++n % 8 === 0) save(); } catch (e) { /* ignore */ } }, 500);
                    Log.info('DEV', 'เปิด Dev Mode');
                } else {
                    save();
                    if (D.fr) D.fr.style.display = 'none'; if (D.ov) D.ov.style.display = 'none'; D.inPanel = false;
                }
            } catch (e) { Log.err('DEV', 'เปิด Dev Mode ไม่สำเร็จ: ' + (e && e.message)); try { showToast('Dev Mode ผิดพลาด: ' + (e && e.message), 'err'); } catch (x) { /* ignore */ } }
        }

        // 🎯 เข้าแมพฟาร์มโดยไม่ผ่านระบบวาร์ปของสคริปต์ (วาร์ปเอง / เดินผ่านประตู) แต่ตัวละครไม่อยู่ในโซน → เข้าโซนให้ (เมื่อเปิด "ใช้ Fly Wing จนเข้าโซนฟาร์ม")
        const ZG = { map: '', pend: null, busy: false, outSince: 0, lastGuard: 0, gFails: 0 };
        // 🧲 หลุดโซนระหว่างฟาร์ม (Auto ไล่มอนออกนอกโซน) ติดต่อกันนานเกินที่ตั้ง → ปิด Auto เดินกลับจุดยืนตี/เข้าโซน แล้วเปิด Auto ใหม่ (เดินอย่างเดียว ไม่ใช้ Fly Wing)
        async function zoneGuard(map) {
            const zs = zonesFor(map), me = minimapCell();
            const ok = !State.opt.zoneGuard || !zs.length || !me || !isFarmMap() || !State.isAutoEnabled || !wautoOn() || Frame.dead || Frame.captcha;
            const out = !ok && (!inZones(zs, me) || inZones(badNow().rects, me));
            if (!out) { ZG.outSince = 0; return; }
            if (!ZG.outSince) { ZG.outSince = Date.now(); return; }
            const lim = Math.max(10, +State.opt.zoneGuardSec || 30) * 1000;
            if (Date.now() - ZG.outSince < lim || Date.now() - ZG.lastGuard < Math.max(60000, lim) * (1 + Math.min(4, ZG.gFails))) return;
            ZG.lastGuard = Date.now(); ZG.outSince = 0; ZG.busy = true;
            Log.info('WARP', `🧲 หลุดโซนฟาร์มนานเกิน ${Math.round(lim / 1000)} วิ (อยู่ ${me.x}, ${me.z}) — ปิด Auto แล้วเดินกลับ`);
            W.run = true; W.abort = false; W.auto = true; W.dest = map; State.warpHold = true; let r = false;
            try { await wAutoOff(); r = await flyToZone(map, { noFly: true }); }
            finally {
                W.run = false; State.warpHold = false; ZG.busy = false; ZG.gFails = r ? 0 : ZG.gFails + 1;
                if (!W.abort && State.isAutoEnabled && !autoPaused() && !Frame.captcha && isFarmMap() && !wautoOn()) { pressKey('z', 'KeyZ', 90); await sleep(600); if (!wautoOn() && wautoBtn()) triggerClick(wautoBtn()); Log.info('WARP', '🧲 เปิด Auto (Z) คืนแล้ว'); }
            }
        }
        setInterval(async () => {
            try {
                const map = State.isGameReady ? zKey() : '';
                if (map && map !== ZG.map) { ZG.map = map; ZG.outSince = 0; ZG.gFails = 0; ZG.pend = !W.run && isFarmMap() && zonesFor(map).length ? { map, at: Date.now() } : null; }
                if (!ZG.pend && !ZG.busy && map) { if (autoPaused() || isTyping() || autoBusy('zone')) ZG.outSince = 0; else await zoneGuard(map); return; }
                const p = ZG.pend; if (!p || ZG.busy) return;
                if (map !== p.map || Date.now() - p.at > 600000 || !State.opt.warpZone) { ZG.pend = null; return; }
                if (autoPaused() || Frame.dead || Frame.captcha || isTyping() || autoBusy('zone')) return;
                const me = minimapCell(); if (!me) return;
                if (inZones(zonesFor(map), me)) { ZG.pend = null; return; }
                ZG.pend = null; ZG.busy = true;
                wsay(`🎯 เข้า ${map} แล้วแต่ตัวละครอยู่นอกโซนฟาร์ม (${me.x}, ${me.z}) — พาเข้าโซนให้`); Log.info('WARP', `🎯 อยู่นอกโซนหลังเข้า ${map} — พาเข้าโซน`);
                W.run = true; W.abort = false; W.auto = false; W.dest = map; State.warpHold = true;
                try { await wAutoOff(); await flyToZone(map); } finally { W.run = false; State.warpHold = false; ZG.busy = false; }
            } catch (e) { ZG.busy = false; }
        }, 3000);
        // 🗺️ ภาพซ้อนบนจอ — วาดให้ดูอย่างเดียว ไม่ส่งคำสั่งเข้าเกม (canvas pointer-events:none)
        //   โซน/จุดยืนตี/โซนห้ามเข้าบนมินิแมพของเกม · เส้นทางที่ระบบเดินวางไว้ · ลูกศรชี้กลับโซน · ช่องกำแพงที่ใช้คำนวณทาง
        // มินิแมพของเกม: canvas กว้าง 200px = ทั้งแมพ (สเกล = กว้าง canvas ÷ จำนวนช่อง) วาดใหม่ทุก 100ms → วาง canvas ของเราทับไว้ใน .minimap-stage
        const OV = { mm: null, scr: null, path: null, pathAt: 0, pathKey: '' };
        const ovAny = () => !!(State.opt.ovMini || State.opt.ovPath || State.opt.ovArrow || State.opt.ovWall);
        function ovPath() {        // เส้นทางของการเดินที่กำลังทำ (คำนวณใหม่เมื่อย้ายช่อง หรือทุก 1.5 วิ)
            if (!State.opt.ovPath || !D.walking || !D.target || !D.tm) { OV.path = null; OV.pathKey = ''; return null; }
            const mm = minimapCell(); if (!mm) return OV.path;
            const k = `${mm.x},${mm.z}>${D.target.x},${D.target.z}`;
            if (k !== OV.pathKey || Date.now() - OV.pathAt > 1500) {
                OV.pathKey = k; OV.pathAt = Date.now();
                try { const p = planPath(mm, D.target); OV.path = p ? [{ x: mm.x, z: mm.z }].concat(p) : null; } catch (e) { OV.path = null; }
            }
            return OV.path;
        }
        function ovTm(mapK) {
            const n = norm((queryGame(SELECTORS.mapName) || {}).textContent || '').replace(/\s*Lv\.?[\d\-–\s]+$/i, '').trim();
            if (n && D.tmFor !== n && D.tmState !== 'loading') loadTiled(n);
            return (mapK && tmFor(mapK)) || (n && D.tmFor === n ? D.tm : null);
        }
        const ovHide = (o) => { if (o && o.style.display !== 'none') o.style.display = 'none'; };
        function ovMini(m, mapK) {
            const cv = document.querySelector('.minimap-stage canvas:not(.at-ov)');
            if (!cv || !m || !m.w || !(State.opt.ovMini || State.opt.ovPath)) { ovHide(OV.mm); return; }
            const st = cv.parentElement; let ov = OV.mm;
            if (!ov || ov.parentElement !== st) {
                if (ov) ov.remove();
                ov = OV.mm = document.createElement('canvas'); ov.id = 'at-mm-ov'; ov.className = 'at-ov'; ov.style.cssText = 'position:absolute;pointer-events:none;margin:0;padding:0';
                if (getComputedStyle(st).position === 'static') st.style.position = 'relative';
                st.appendChild(ov);
            }
            ov.style.display = '';
            if (ov.width !== cv.width || ov.height !== cv.height) { ov.width = cv.width; ov.height = cv.height; }
            ov.style.left = cv.offsetLeft + 'px'; ov.style.top = cv.offsetTop + 'px'; ov.style.width = cv.offsetWidth + 'px'; ov.style.height = cv.offsetHeight + 'px';
            const c = ov.getContext('2d'); c.clearRect(0, 0, ov.width, ov.height);
            const sx = ov.width / m.w, sz = ov.height / m.h;
            const rect = (z, sc, fl, lw) => { const x = z[0] * sx, y = z[1] * sz, w = (z[2] - z[0] + 1) * sx, h = (z[3] - z[1] + 1) * sz; c.fillStyle = fl; c.fillRect(x, y, w, h); c.strokeStyle = sc; c.lineWidth = lw || 1; c.strokeRect(x + 0.5, y + 0.5, Math.max(1, w - 1), Math.max(1, h - 1)); };
            if (State.opt.ovMini && mapK) {
                badNow().rects.forEach((z) => rect(z, 'rgba(239,68,68,.95)', 'rgba(239,68,68,.22)'));
                zonesFor(mapK).forEach((z, i) => { rect(z, 'rgba(250,204,21,.95)', 'rgba(250,204,21,.14)', 1.3); c.fillStyle = '#fde68a'; c.font = 'bold 9px sans-serif'; c.fillText(String(i + 1), z[0] * sx + 2, z[1] * sz + 9); });
                spotsFor(mapK).forEach((p) => { c.fillStyle = '#4ade80'; c.strokeStyle = '#052e16'; c.lineWidth = 1; c.beginPath(); c.arc((p[0] + 0.5) * sx, (p[1] + 0.5) * sz, 2.4, 0, Math.PI * 2); c.fill(); c.stroke(); });
            }
            const P = ovPath();
            if (P && P.length > 1) {
                c.strokeStyle = 'rgba(34,211,238,.95)'; c.lineWidth = 1.6; c.setLineDash([3, 2]); c.beginPath();
                P.forEach((p, i) => { const x = (p.x + 0.5) * sx, y = (p.z + 0.5) * sz; if (i) c.lineTo(x, y); else c.moveTo(x, y); }); c.stroke(); c.setLineDash([]);
            }
            if (State.opt.ovPath && D.walking && D.target) { c.strokeStyle = '#22d3ee'; c.lineWidth = 1.5; c.beginPath(); c.arc((D.target.x + 0.5) * sx, (D.target.z + 0.5) * sz, 4, 0, Math.PI * 2); c.stroke(); }
        }
        function ovLabel(c, x, y, txt, col) {
            c.font = 'bold 12px sans-serif'; const w = c.measureText(txt).width + 12;
            c.fillStyle = 'rgba(15,23,42,.78)'; c.strokeStyle = col; c.lineWidth = 1.2;
            if (c.roundRect) { c.beginPath(); c.roundRect(x - w / 2, y - 10, w, 20, 6); c.fill(); c.stroke(); } else { c.fillRect(x - w / 2, y - 10, w, 20); c.strokeRect(x - w / 2, y - 10, w, 20); }
            c.fillStyle = col; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(txt, x, y + 0.5); c.textAlign = 'start'; c.textBaseline = 'alphabetic';
        }
        function ovScreen(m, mapK) {
            const cv = m && (State.opt.ovArrow || State.opt.ovWall || State.opt.ovPath) && !r3Off() ? canvasEl() : null;
            if (!cv) { ovHide(OV.scr); return; }
            let ov = OV.scr;
            if (!ov || ov.previousElementSibling !== cv) {
                if (ov) ov.remove();
                ov = OV.scr = document.createElement('canvas'); ov.id = 'at-scr-ov'; ov.className = 'at-ov'; ov.style.cssText = 'position:absolute;pointer-events:none;margin:0;padding:0';
                cv.insertAdjacentElement('afterend', ov);
            }
            const r = cv.getBoundingClientRect(); if (!r.width || !r.height) { ovHide(ov); return; }
            ov.style.display = '';
            const W_ = Math.round(r.width), H_ = Math.round(r.height);
            if (ov.width !== W_ || ov.height !== H_) { ov.width = W_; ov.height = H_; }
            ov.style.left = cv.offsetLeft + 'px'; ov.style.top = cv.offsetTop + 'px'; ov.style.width = cv.offsetWidth + 'px'; ov.style.height = cv.offsetHeight + 'px';
            const c = ov.getContext('2d'); c.clearRect(0, 0, W_, H_);
            const mm = minimapCell(); if (!mm) return;
            let P; try { P = projector(mm); } catch (e) { return; }
            const k = W_ / r.width, S = (cx, cz) => { const p = P.scr(cx, cz); return [(p[0] - r.left) * k, (p[1] - r.top) * k]; };
            const bad = mapK ? badNow().rects : [];
            if (State.opt.ovWall) {
                lbSync();
                const sp = Math.max(4, P.px), spz = Math.max(3, P.pz || P.px), nx = Math.ceil(r.width / sp) + 2, nz = Math.ceil(r.height / spz) + 2;
                const x0 = Math.max(0, mm.x - nx), x1 = Math.min(m.w - 1, mm.x + nx), z0 = Math.max(0, mm.z - nz), z1 = Math.min(m.h - 1, mm.z + nz);
                const npcAt = (x, z) => m.objs.some((p) => p.kind === 'npc' && p.c1 - p.c0 <= 3 && p.z1 - p.z0 <= 3 && x >= p.c0 && x <= p.c1 && z >= p.z0 && z <= p.z1);
                for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) {
                    const wall = !!(m.col && m.col[z * m.w + x]), tmp = !wall && lbHas(x, z), npc = !wall && !tmp && npcAt(x, z);
                    if (!wall && !tmp && !npc) continue;
                    const a = S(x, z), b = S(x + 1, z + 1); if (b[0] < 0 || b[1] < 0 || a[0] > W_ || a[1] > H_) continue;
                    c.fillStyle = wall ? 'rgba(239,68,68,.28)' : tmp ? 'rgba(251,146,60,.45)' : 'rgba(56,189,248,.35)';
                    c.fillRect(a[0], a[1], b[0] - a[0], b[1] - a[1]);
                    c.strokeStyle = wall ? 'rgba(239,68,68,.55)' : tmp ? 'rgba(251,146,60,.9)' : 'rgba(56,189,248,.8)'; c.lineWidth = 1; c.strokeRect(a[0] + 0.5, a[1] + 0.5, b[0] - a[0] - 1, b[1] - a[1] - 1);
                }
                c.setLineDash([6, 4]); c.strokeStyle = 'rgba(239,68,68,.95)'; c.lineWidth = 2;
                bad.forEach((z) => { const a = S(z[0], z[1]), b = S(z[2] + 1, z[3] + 1); if (b[0] < 0 || b[1] < 0 || a[0] > W_ || a[1] > H_) return; c.strokeRect(a[0], a[1], b[0] - a[0], b[1] - a[1]); });
                c.setLineDash([]);
                ovLabel(c, 150, 18, '🧱 กำแพง · 🟧 เคยเดินติด · 🟦 NPC · ⛔ ห้ามเข้า', '#fca5a5');
            }
            const PP = ovPath();
            if (PP && PP.length > 1) {
                c.strokeStyle = 'rgba(34,211,238,.85)'; c.lineWidth = 3; c.setLineDash([8, 6]); c.beginPath();
                PP.forEach((p, i) => { const q = S(p.x + 0.5, p.z + 0.5); if (i) c.lineTo(q[0], q[1]); else c.moveTo(q[0], q[1]); }); c.stroke(); c.setLineDash([]);
                const t = S(D.target.x + 0.5, D.target.z + 0.5); c.strokeStyle = '#22d3ee'; c.lineWidth = 2.5; c.beginPath(); c.arc(t[0], t[1], Math.max(6, P.px * 0.35), 0, Math.PI * 2); c.stroke();
            }
            if (State.opt.ovArrow && mapK && isFarmMap()) {
                const me = { x: mm.x, z: mm.z }, zs = zonesFor(mapK), inBad = inZones(bad, me);
                const [ax, az] = S(me.x + 0.5, me.z + 0.5), head = Math.max(46, P.px * 1.6);
                let best = null;
                if (zs.length && !inZones(zs, me)) zs.forEach((z, i) => { const tx = Math.max(z[0], Math.min(z[2], me.x)), tz = Math.max(z[1], Math.min(z[3], me.z)), d = Math.max(Math.abs(tx - me.x), Math.abs(tz - me.z)); if (!best || d < best.d) best = { d, x: tx, z: tz, i }; });
                if (best && best.d < Math.max(1, +State.opt.ovArrowMin || 1)) best = null;      // หลุดขอบนิดเดียว: ไม่ต้องแสดง
                if (best) {
                    const [bx, bz] = S(best.x + 0.5, best.z + 0.5), ang = Math.atan2(bz - az, bx - ax), R = Math.max(40, P.px * 1.3);
                    const px_ = ax + Math.cos(ang) * R, pz_ = az + Math.sin(ang) * R;
                    c.save(); c.translate(px_, pz_); c.rotate(ang);
                    c.beginPath(); c.moveTo(16, 0); c.lineTo(-8, -11); c.lineTo(-3, 0); c.lineTo(-8, 11); c.closePath();
                    c.fillStyle = 'rgba(250,204,21,.95)'; c.strokeStyle = '#422006'; c.lineWidth = 2; c.fill(); c.stroke(); c.restore();
                    ovLabel(c, ax, az - head, `🎯 โซน ${best.i + 1} · ${best.d} ช่อง`, '#fde68a');
                }
                if (inBad) ovLabel(c, ax, az - head - (best ? 24 : 0), '⛔ อยู่ในโซนห้ามเข้า / มอนอันตราย', '#fca5a5');
            }
        }
        setInterval(() => {
            try {
                if (!ovAny() || document.hidden || !State.isGameReady) { ovHide(OV.mm); ovHide(OV.scr); return; }
                const mapK = zKey(), m = ovTm(mapK);
                ovMini(m, mapK); ovScreen(m, mapK);
            } catch (e) { /* ignore */ }
        }, 150);

        // 📅 แถบเวลารอบฟาร์ม: บันทึกสถานะทุก 10 วิ (เก็บเฉพาะจุดที่สถานะ/แมพเปลี่ยน) · 48 ชม. ต่อตัวละคร
        const TL_INFO = { farm: ['#22c55e', '🟩 ฟาร์ม'], warp: ['#3b82f6', '🟦 วาร์ป/เดิน/ซื้อของ'], idle: ['#eab308', '🟨 พัก/อยู่เมือง'], bad: ['#ef4444', '🟥 ตาย/ตรวจผู้เล่น/คุก/หลุด'], none: ['#334155', '⬛ ไม่ได้เปิดเกม'] };
        const TL = { save: 0, d: null, ch: '' };
        const tlKey = () => 'at_tl:' + (Store.char || '');
        function tlState() {
            if (!State.isGameReady || Watch.lost) return ['bad', 'หลุดการเชื่อมต่อ'];
            if (Frame.captcha) return ['bad', 'ตรวจผู้เล่น'];
            if (Frame.dead) return ['bad', 'ตาย'];
            const map = getMapName() || '';
            if (isJailMap(map)) return ['bad', 'ติดคุก'];
            if (W.run || RS.busy || DGW.busy || CHW.busy || D.walking) return ['warp', map];
            if (Profit.farming && !autoPaused()) return ['farm', map];
            return ['idle', map];
        }
        function tlLoad() {
            if (TL.d && TL.ch === Store.char) return TL.d;
            let d = null; try { d = JSON.parse(localStorage.getItem(tlKey()) || 'null'); } catch (e) { d = null; }
            if (!d || !Array.isArray(d.s)) d = { s: [], last: 0 };
            TL.d = d; TL.ch = Store.char; return d;
        }
        function tlTick() {
            if (!Store.char) return;
            const now = Date.now(), d = tlLoad(), [k, map] = tlState(); let ch = false;
            if (d.last && now - d.last > 120000) { d.s.push([d.last + 15000, 'none', '']); ch = true; }     // แท็บปิด / เครื่องหลับ
            const lt = d.s[d.s.length - 1];
            if (!lt || lt[1] !== k || (lt[2] || '') !== map) { d.s.push([now, k, map]); ch = true; }
            d.last = now;
            const cut = now - 48 * 3600000; while (d.s.length > 1 && d.s[1][0] < cut) { d.s.shift(); ch = true; }
            if (d.s.length > 4000) d.s.splice(0, d.s.length - 4000);
            if (ch || now - TL.save > 50000) { TL.save = now; try { lsSet(tlKey(), JSON.stringify(d)); } catch (e) { /* ignore */ } }
        }
        const hhmm = (t) => { const x = new Date(t); return String(x.getHours()).padStart(2, '0') + ':' + String(x.getMinutes()).padStart(2, '0'); };
        function tlRender() {
            const el = document.getElementById('at-tl'); if (!el) return;
            const sel = document.getElementById('at-tl-rng'); let hrs = 24;
            try { hrs = +localStorage.getItem('at_tl_rng') || 24; } catch (e) { /* ignore */ }
            if (sel && document.activeElement !== sel) sel.value = String(hrs);
            const now = Date.now(), t0 = now - hrs * 3600000, d = tlLoad(), s = d.s, segs = [], tot = {};
            for (let i = 0; i < s.length; i++) {
                const a = Math.max(t0, s[i][0]), b = Math.min(now, i + 1 < s.length ? s[i + 1][0] : (now - d.last < 120000 ? now : d.last + 15000));
                if (b <= a) continue;
                segs.push({ a, b, k: s[i][1], map: s[i][2] || '' }); tot[s[i][1]] = (tot[s[i][1]] || 0) + (b - a);
            }
            const pct = (t) => ((t - t0) / (now - t0) * 100).toFixed(3);
            const bar = segs.map((g) => { const ci = TL_INFO[g.k] || TL_INFO.none; return `<i style="position:absolute;top:0;bottom:0;left:${pct(g.a)}%;width:${Math.max(0.15, (g.b - g.a) / (now - t0) * 100).toFixed(3)}%;background:${ci[0]}" title="${hhmm(g.a)}–${hhmm(g.b)} · ${ci[1]}${g.map ? ' · ' + esc(g.map).replace(/"/g, '&quot;') : ''} · ${fmtTown(g.b - g.a)}"></i>`; }).join('');
            const step = hrs <= 3 ? 0.5 : hrs <= 6 ? 1 : hrs <= 12 ? 2 : hrs <= 24 ? 4 : 8, ticks = [];
            { const st = step * 3600000; for (let t = Math.ceil(t0 / st) * st; t < now; t += st) ticks.push(`<span style="position:absolute;left:${pct(t)}%;transform:translateX(-50%);font-size:10px;opacity:.65">${hhmm(t)}</span>`); }
            const known = Object.entries(tot).filter(([k]) => k !== 'none').reduce((a, [, v]) => a + v, 0) || 1;
            const leg = Object.keys(TL_INFO).filter((k) => tot[k]).map((k) => `<div style="display:flex;justify-content:space-between;gap:8px"><span><b style="display:inline-block;width:9px;height:9px;border-radius:2px;background:${TL_INFO[k][0]};margin-right:5px"></b>${TL_INFO[k][1].replace(/^\S+\s/, '')}</span><span>${fmtTown(tot[k])}${k !== 'none' ? ` · ${Math.round(tot[k] / known * 100)}%` : ''}</span></div>`).join('');
            const top = {}; segs.forEach((g) => { if (g.k === 'farm' && g.map) top[g.map] = (top[g.map] || 0) + (g.b - g.a); });
            const maps = Object.entries(top).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([n, v]) => `${esc(n)} ${fmtTown(v)}`).join(' · ');
            const html = segs.length
                ? `<div style="position:relative;height:22px;border-radius:5px;overflow:hidden;background:#1e293b;margin:4px 0 2px">${bar}</div><div style="position:relative;height:13px;margin-bottom:6px">${ticks.join('')}</div><div style="display:flex;flex-direction:column;gap:2px;font-size:12px">${leg}</div>${maps ? `<div style="font-size:11px;opacity:.75;margin-top:4px">🗺️ ฟาร์มนานสุด: ${maps}</div>` : ''}`
                : '<div class="ac-l">ยังไม่มีข้อมูล (เริ่มบันทึกหลังเข้าเกม)</div>';
            if (el.dataset.h !== html) { el.dataset.h = html; el.innerHTML = html; }
        }
        setInterval(() => { try { tlTick(); } catch (e) { /* ignore */ } }, 10000);
        setInterval(() => { try { const el = document.getElementById('at-tl'); if (el && el.offsetParent) tlRender(); } catch (e) { /* ignore */ } }, 2000);
        document.addEventListener('change', (e) => { if (e.target && e.target.id === 'at-tl-rng') { try { lsSet('at_tl_rng', e.target.value); } catch (x) { /* ignore */ } tlRender(); } }, true);
        document.addEventListener('click', (e) => {
            const b = e.target && e.target.closest && e.target.closest('#at-tl-clear'); if (!b) return;
            e.stopPropagation(); if (!confirm('ล้างประวัติแถบเวลาของตัวละครนี้?')) return;
            TL.d = { s: [], last: 0 }; TL.ch = Store.char; try { lsDel(tlKey()); } catch (x) { /* ignore */ } tlTick(); tlRender();
        }, true);
        window.addEventListener('mousemove', (e) => { D.mx = e.clientX; D.my = e.clientY; }, true);
        // ผูกปุ่ม 🧪 แบบ delegation (ยังใช้ได้แม้แผงหลักถูกสร้างใหม่) + คืนสถานะเปิดตอนโหลด
        document.addEventListener('click', (e) => { const b = e.target && e.target.closest && e.target.closest('#at-btn-dev'); if (!b) return; e.stopPropagation(); setOn(!D.on); }, true);
        const bind = setInterval(() => { if (!document.getElementById('at-btn-dev')) return; clearInterval(bind); if (D.on) setOn(true); }, 600);
        // สถานะงานภายในระบบเดิน/วาร์ป (ให้ตัวคุมคิวกลางใช้)
        function busyIn(self) {
            if (W.run) return 'เดิน/วาร์ป' + (W.dest ? ' → ' + W.dest : '');
            if (RS.busy && self !== 'restock') return 'กลับไปซื้อของ';
            if (DGW.busy && self !== 'danger') return 'หนีโซนอันตราย';
            if (CHW.busy && self !== 'ch') return 'ย้าย CH';
            if (ZG.busy && self !== 'zone') return 'เดินกลับโซน';
            if (ST.busy && self !== 'stat') return 'อัพสเตตัส';
            if (D.walking && self !== 'walk') return 'เดิน';
            if (BK.townAt && self !== 'warpback' && State.opt.warpBack && State.isAutoEnabled && BK.field && Date.now() - BK.townAt < 30000) return 'รอวาร์ปกลับแมพเดิม';
            if (BK.pickGo && BK.pickAt && self !== 'warpback') return 'รอวาร์ปไปแมพที่เลือก';
            return '';
        }
        return { D, setOn, diag, update, render, busy: busyIn, warp: warpTo, warpStop, warpPick, walkTalk, npcNames, statRun, zoneEdit, zonesFor, flyToZone, buyRun, warpBackOn, warpBackOff, warpNames, warpScan: () => warpTo('', { scan: true }), warpSel, flySlot, flyRestockCheck, resumeFarm, minimapCell, hotSlotOf, statPts: () => statPoints(), switchCh: (why) => switchChannel(why || 'สั่งจาก Aetherack Manager') };
    })();

    // 💬 ช่องไหนตัวเลข/ข้อความถูกตัด (...) ให้ชี้เมาส์แล้วขึ้นข้อความเต็ม (การ์ดสถิติใส่ "ชื่อ: ค่า" ให้ด้วย)
    document.addEventListener('mouseover', (e) => {
        try {
            const t = e.target; if (!t || !t.closest || !t.closest('#aetheria-profit,#aetheria-stats,#aetheria-tracker,#aetheria-config,#aetheria-logs,#aetheria-dps,#aetheria-wiki,[id^="aetheria-"]')) return;
            let el = t;
            for (let i = 0; i < 4 && el && el.nodeType === 1; i++, el = el.parentElement) {
                if (el.id && /^aetheria-/.test(el.id)) break;
                if (el.scrollWidth <= el.clientWidth + 1 || !el.clientWidth) continue;
                const ov = getComputedStyle(el).textOverflow; if (ov !== 'ellipsis') continue;
                const card = el.closest('.ap-card'); const sp = card && card.querySelector('span');
                const full = card && sp && sp !== el ? `${norm(sp.textContent)}: ${norm(el.textContent)}` : norm(el.textContent);
                if (!el.title || el.dataset.atAuto) { el.title = full; el.dataset.atAuto = '1'; }
                break;
            }
        } catch (er) { /* ignore */ }
    }, true);

    if (document.readyState === 'complete') init();
    else window.addEventListener('load', init);
})();

@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Aetherack Manager
where node >nul 2>nul
if errorlevel 1 (
  echo ยังไม่ได้ติดตั้ง Node.js - ดาวน์โหลดรุ่น LTS ได้ที่ https://nodejs.org แล้วเปิดไฟล์นี้ใหม่
  start https://nodejs.org/
  pause
  exit /b
)
rem สร้าง/อัปเดตทางลัด "Aetherack Manager" พร้อมไอคอน บน Desktop และ Start Menu (หน้าต่างดำเปิดแบบย่อไว้)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; foreach($d in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))){ $s=$w.CreateShortcut((Join-Path $d 'Aetherack Manager.lnk')); $s.TargetPath='%~dp0start.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0public\icon.ico'; $s.WindowStyle=7; $s.Description='Aetherack Manager'; $s.Save() }" >nul 2>nul
node server.js
if errorlevel 1 pause

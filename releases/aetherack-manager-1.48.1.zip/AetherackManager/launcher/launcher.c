// Aetherack Manager.exe — ตัวเปิดโปรแกรม: หา Node.js → รัน server.js แบบไม่มีหน้าต่างดำ (บันทึกลง manager.log) → สร้างทางลัดบน Desktop/Start Menu
#define _UNICODE
#include <windows.h>
#include <shellapi.h>
#include <wchar.h>

static wchar_t dir[MAX_PATH], exe[MAX_PATH];

static int findNode(wchar_t *out) {
    if (SearchPathW(NULL, L"node.exe", NULL, MAX_PATH, out, NULL)) return 1;
    const wchar_t *envs[] = { L"ProgramFiles", L"ProgramFiles(x86)", L"LOCALAPPDATA" };
    const wchar_t *subs[] = { L"\\nodejs\\node.exe", L"\\nodejs\\node.exe", L"\\Programs\\nodejs\\node.exe" };
    for (int i = 0; i < 3; i++) {
        wchar_t base[MAX_PATH];
        if (GetEnvironmentVariableW(envs[i], base, MAX_PATH)) {
            swprintf(out, MAX_PATH, L"%ls%ls", base, subs[i]);
            if (GetFileAttributesW(out) != INVALID_FILE_ATTRIBUTES) return 1;
        }
    }
    return 0;
}

static void runHidden(wchar_t *cmd, HANDLE out) {
    STARTUPINFOW si; PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof si); si.cb = sizeof si;
    if (out) { si.dwFlags = STARTF_USESTDHANDLES; si.hStdOutput = out; si.hStdError = out; si.hStdInput = NULL; }
    if (CreateProcessW(NULL, cmd, NULL, NULL, out ? TRUE : FALSE, CREATE_NO_WINDOW, NULL, dir, &si, &pi)) {
        CloseHandle(pi.hThread); CloseHandle(pi.hProcess);
    }
}

int WINAPI wWinMain(HINSTANCE h, HINSTANCE p, PWSTR args, int show) {
    GetModuleFileNameW(NULL, exe, MAX_PATH);
    wcscpy(dir, exe); wchar_t *s = wcsrchr(dir, L'\\'); if (s) *s = 0;
    SetCurrentDirectoryW(dir);

    wchar_t server[MAX_PATH]; swprintf(server, MAX_PATH, L"%ls\\server.js", dir);
    if (GetFileAttributesW(server) == INVALID_FILE_ATTRIBUTES) {
        MessageBoxW(NULL, L"ไม่พบ server.js — วาง Aetherack Manager.exe ไว้ในโฟลเดอร์เดียวกับไฟล์ของโปรแกรม", L"Aetherack Manager", MB_ICONERROR);
        return 1;
    }
    wchar_t node[MAX_PATH];
    if (!findNode(node)) {
        if (MessageBoxW(NULL, L"ยังไม่ได้ติดตั้ง Node.js (รุ่น LTS)\n\nกด OK เพื่อเปิดหน้าดาวน์โหลด แล้วเปิดโปรแกรมนี้ใหม่หลังติดตั้งเสร็จ", L"Aetherack Manager", MB_OKCANCEL | MB_ICONINFORMATION) == IDOK)
            ShellExecuteW(NULL, L"open", L"https://nodejs.org/", NULL, NULL, SW_SHOWNORMAL);
        return 1;
    }

    // ทางลัด Desktop + Start Menu ชี้มาที่ .exe นี้ (สร้าง/อัปเดตทุกครั้ง · ทำเงียบ ๆ)
    wchar_t ps[4096];
    swprintf(ps, 4096,
        L"powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command \"$w=New-Object -ComObject WScript.Shell; "
        L"foreach($d in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))){ "
        L"$s=$w.CreateShortcut((Join-Path $d 'Aetherack Manager.lnk')); $s.TargetPath='%ls'; $s.WorkingDirectory='%ls'; $s.IconLocation='%ls,0'; $s.Description='Aetherack Manager'; $s.Save() }\"",
        exe, dir, exe);
    runHidden(ps, NULL);

    // รันโปรแกรมหลักแบบไม่มีหน้าต่าง · ข้อความทั้งหมดลง manager.log
    SECURITY_ATTRIBUTES sa = { sizeof sa, NULL, TRUE };
    wchar_t logp[MAX_PATH]; swprintf(logp, MAX_PATH, L"%ls\\manager.log", dir);
    HANDLE log = CreateFileW(logp, GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, &sa, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    wchar_t cmd[2048]; swprintf(cmd, 2048, L"\"%ls\" \"%ls\"", node, server);
    runHidden(cmd, log != INVALID_HANDLE_VALUE ? log : NULL);
    if (log != INVALID_HANDLE_VALUE) CloseHandle(log);
    return 0;
}

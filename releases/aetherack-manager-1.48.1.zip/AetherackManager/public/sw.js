// Aetherack Manager — รับแจ้งเตือนเข้ามือถือ (Web Push) · ไม่เก็บแคช ไม่ดักหน้าเว็บ
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('push', (e) => {
  let d = {}; try { d = e.data ? e.data.json() : {}; } catch (er) { d = { title: 'Aetherack Manager', body: e.data ? e.data.text() : '' }; }
  e.waitUntil(self.registration.showNotification(d.title || 'Aetherack Manager', {
    body: d.body || '', icon: '/icon.png', badge: '/icon.png', tag: d.tag || 'aeth', renotify: true,
    requireInteraction: d.kind === 'captcha', silent: false, vibrate: d.kind === 'captcha' ? [400, 150, 400, 150, 800] : [300, 120, 300],
    data: { url: d.url || '/' },
  }));
});
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const u = (e.notification.data && e.notification.data.url) || '/';
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((ws) => {
    for (const w of ws) if (new URL(w.url).origin === new URL(u, self.location.href).origin && 'focus' in w) return w.focus();
    return self.clients.openWindow(u);
  }));
});

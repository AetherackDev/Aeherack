'use strict';
// Aetherack Manager — โปรแกรมคุม Chrome หลายตัว (1 Chrome = 1 IP = ไม่เกิน 3 จอ) + หน้ารวมสถานะตัวละครจากสคริปต์ Aetherack
// ไม่ต้องติดตั้งแพ็กเกจเพิ่ม: ใช้ Node.js 22 ขึ้นไป (มี WebSocket/fetch ในตัว) · เปิดเฉพาะในเครื่อง (127.0.0.1)
const http = require('node:http');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { spawn, execFile } = require('node:child_process');
const net = require('node:net');

const ROOT = __dirname;
const CONFIG_FILE = path.join(ROOT, 'config.json');
const PUBLIC = path.join(ROOT, 'public');
const VERSION = '1.32.2';
const UPDATE_URL = 'https://raw.githubusercontent.com/AetherackDev/Aeherack/main/manifest.json';      // ที่ตรวจอัปเดตค่าเริ่มต้น (ช่อง ลิงก์ตรวจอัปเดต ว่าง = ใช้อันนี้)

// ---------------------------------------------------------------
// การตั้งค่า
// ---------------------------------------------------------------
// ค่าเริ่มต้นกลาง (ไม่มีข้อมูลส่วนตัว) · ค่าเฉพาะของเครื่อง/ผู้ใช้ (IP พร็อกซี, รหัส) ใส่ใน config.default.json ได้ — ใช้เมื่อยังไม่มี config.json
const DEFAULTS_FILE = path.join(ROOT, 'config.default.json');
function defaultConfig() {
    let own = {}; try { own = JSON.parse(fs.readFileSync(DEFAULTS_FILE, 'utf8')) || {}; } catch (e) { /* ไม่มีไฟล์ = ค่ากลาง */ }
    return Object.assign(baseConfig(), own);
}
function baseConfig() {
    return {
        port: 17321,
        chromePath: '',
        gameUrl: 'https://aetheria-online.in.th/play',
        maxPerIp: 3,
        startGapSec: 5,
        bypass: '*.google.com;*.googleapis.com;*.gvt1.com;*.googleusercontent.com;*.gstatic.com',
        perfFlags: '--disable-background-timer-throttling --disable-renderer-backgrounding --disable-backgrounding-occluded-windows',
        screen: { width: 1920, height: 1040, cols: 4 },
        proxyUser: '', proxyPass: '',      // รหัสพร็อกซี — ตั้งในหน้า ตั้งค่า
        updateUrl: '',      // ลิงก์ manifest.json ของเวอร์ชันใหม่ ({ version, url, sha256, notes }) — ว่าง = ใช้ UPDATE_URL (GitHub)
        autoPurge: true, purgeMin: 20,      // 🧹 คืน RAM ทุกจออัตโนมัติ
        ramGuard: true, ramLimitGB: 2.5, ramCooldownMin: 60,      // 🧠 แรมต่อจอเกินกำหนด → รีโหลดตอนว่าง
        groups: [{ id: 'Home', name: 'บ้าน (เน็ตบ้าน)', proxy: '', dir: 'C:\\ChromeHome', debugPort: 9300 }],      // เพิ่มโปรไฟล์/IP ได้จากหน้าหลัก
    };
}
function loadConfig() {
    try { return Object.assign(defaultConfig(), JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'))); } catch (e) {
        const c = defaultConfig(); saveConfig(c); return c;
    }
}
function saveConfig(c) { fs.writeFileSync(CONFIG_FILE + '.tmp', JSON.stringify(c, null, 2)); fs.renameSync(CONFIG_FILE + '.tmp', CONFIG_FILE); }
let CFG = loadConfig();

function findChrome() {
    const cands = [CFG.chromePath,
        path.join(process.env['ProgramFiles'] || 'C:\\Program Files', 'Google\\Chrome\\Application\\chrome.exe'),
        path.join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Google\\Chrome\\Application\\chrome.exe'),
        path.join(process.env.LOCALAPPDATA || '', 'Google\\Chrome\\Application\\chrome.exe')];
    return cands.find((p) => p && fs.existsSync(p)) || '';
}

// ---------------------------------------------------------------
// สถานะ
// ---------------------------------------------------------------
const S = {
    groups: {},     // id -> { running, debug, outside, targets:[], ram, procs, err }
    peers: {},      // tab -> snapshot จากสคริปต์ + ts + group + targetId
    cmds: {},       // tab -> [{ id, cmd, at }]
    inv: {},        // tab -> ของในกระเป๋าล่าสุด (สคริปต์ส่งมาเมื่อกด 🎒 ดูกระเป๋า)
    log: [],        // ข้อความล่าสุด
    cpu: { pct: 0, prev: null },
    seq: 0,
};
function say(msg) { const line = `[${new Date().toLocaleTimeString('th-TH', { hour12: false })}] ${msg}`; S.log.push(line); if (S.log.length > 200) S.log.shift(); console.log(line); }
const groupOf = (id) => CFG.groups.find((g) => g.id === id);
const isGame = (t) => t.type === 'page' && /aetheria-online\.in\.th\/play/i.test(t.url || '');

// ---------------------------------------------------------------
// Chrome DevTools Protocol (ช่องควบคุมของ Chrome · เปิดเฉพาะ 127.0.0.1)
// ---------------------------------------------------------------
async function jget(port, p, ms = 1200) {
    const r = await fetch(`http://127.0.0.1:${port}${p}`, { signal: AbortSignal.timeout(ms) });
    if (!r.ok) throw Error('HTTP ' + r.status);
    return r.json();
}
// เปิด WebSocket แล้วส่งหลายคำสั่งต่อกัน: fn(send) → ผลลัพธ์
function cdp(wsUrl, fn, ms = 10000) {
    return new Promise((resolve, reject) => {
        const ws = new WebSocket(wsUrl); let id = 0; const wait = new Map();
        const t = setTimeout(() => { try { ws.close(); } catch (e) { /* ignore */ } reject(Error('CDP หมดเวลา')); }, ms);
        const send = (method, params = {}) => new Promise((res, rej) => { const i = ++id; wait.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params })); });
        ws.onmessage = (ev) => { let m; try { m = JSON.parse(ev.data); } catch (e) { return; } const w = m.id && wait.get(m.id); if (!w) return; wait.delete(m.id); if (m.error) w.rej(Error(m.error.message)); else w.res(m.result); };
        ws.onerror = () => { clearTimeout(t); reject(Error('ต่อช่องควบคุมของ Chrome ไม่ได้')); };
        ws.onopen = async () => { try { const r = await fn(send); clearTimeout(t); ws.close(); resolve(r); } catch (e) { clearTimeout(t); try { ws.close(); } catch (er) { /* ignore */ } reject(e); } };
    });
}
async function browserWs(g) { const v = await jget(g.debugPort, '/json/version'); return v.webSocketDebuggerUrl; }

async function startGroup(g) {
    const info = S.groups[g.id] || {};
    if (info.debug) throw Error(`${g.id} เปิดอยู่แล้ว`);
    if (info.outside) throw Error(`${g.id} เปิดอยู่จากทางลัดเดิม (ไม่มีช่องควบคุม) — ปิด Chrome ตัวนั้นก่อน แล้วเปิดจากโปรแกรมนี้`);
    const exe = findChrome(); if (!exe) throw Error('ไม่พบ chrome.exe — ใส่ที่อยู่ในหน้า ตั้งค่า');
    const args = [`--user-data-dir=${g.dir}`, `--remote-debugging-port=${g.debugPort}`, '--no-first-run', '--no-default-browser-check']
        .concat(String(CFG.perfFlags || '').split(/\s+/).filter(Boolean));
    if (g.proxy) { const rl = relayFor(g); args.push(`--proxy-server=${rl ? 'http://127.0.0.1:' + rl.port : proxyPlain(g.proxy)}`, `--proxy-bypass-list=${CFG.bypass}`); }
    args.push(CFG.prepOnStart !== false ? `http://127.0.0.1:${CFG.port}/prep.html?g=${encodeURIComponent(g.id)}` : gameUrlFor(g));      // หน้าเตรียมความพร้อม → เข้าเกมเองเมื่อพร้อม
    spawn(exe, args, { detached: true, stdio: 'ignore', windowsHide: false }).unref();
    if (CFG.prepOnStart !== false) setTimeout(() => { prepGroup(g, true).catch(() => {}); }, 1500);
    else if (CFG.autoAllow) setTimeout(() => { if ((S.groups[g.id] || {}).tm) allowUserScripts(g).catch((e) => say('⚠️ ' + e.message)); }, 10000);
    say(`🚀 เปิด Chrome ${g.id}${g.proxy ? ' ผ่าน ' + proxyPlain(g.proxy).replace(/^https?:\/\//, '') + (relayFor(g) ? ' (ใส่รหัสพร็อกซีให้อัตโนมัติ)' : '') : ' (เน็ตบ้าน)'}`);
}
// ---------------------------------------------------------------
// 🔑 ใส่รหัสพร็อกซีให้อัตโนมัติ: Chrome ใส่ user/pass ใน --proxy-server ไม่ได้ (จะเด้งหน้าต่าง Sign in ทุกครั้ง)
//    → โปรแกรมเปิดตัวกลางในเครื่อง (127.0.0.1:18xxx) ต่อกลุ่ม: Chrome ต่อตัวกลางแบบไม่ต้องใส่รหัส → ตัวกลางส่งต่อไปพร็อกซีจริงพร้อมรหัส
// ---------------------------------------------------------------
const RELAYS = new Map();      // group id -> { port, key, server }
function proxyPlain(u) { try { const x = new URL(u); return `${x.protocol}//${x.host}`; } catch (e) { return u; } }
function proxyCreds(g) {
    try { const x = new URL(g.proxy); if (x.username) return { user: decodeURIComponent(x.username), pass: decodeURIComponent(x.password) }; } catch (e) { /* ignore */ }
    return CFG.proxyUser ? { user: CFG.proxyUser, pass: CFG.proxyPass || '' } : null;
}
function relayFor(g) {
    const cr = g.proxy && /^http:\/\//i.test(g.proxy) ? proxyCreds(g) : null;
    const old = RELAYS.get(g.id);
    if (!cr) { if (old) { old.server.close(); RELAYS.delete(g.id); } return null; }
    const up = new URL(g.proxy), key = `${up.hostname}:${up.port}:${cr.user}:${cr.pass}`;
    if (old && old.key === key) return old;
    if (old) { old.server.close(); RELAYS.delete(g.id); }
    const port = 18000 + (g.debugPort % 1000);
    const auth = 'Basic ' + Buffer.from(`${cr.user}:${cr.pass}`).toString('base64');
    const upPort = +up.port || 80, upHost = up.hostname;
    const st = { warned: false };
    const server = http.createServer((req, res) => {      // เว็บ http ธรรมดา (url เต็ม)
        const h = Object.assign({}, req.headers, { 'proxy-authorization': auth });
        const r = http.request({ host: upHost, port: upPort, method: req.method, path: req.url, headers: h }, (ur) => { res.writeHead(ur.statusCode || 502, ur.headers); ur.pipe(res); });
        r.on('error', () => { try { res.writeHead(502); res.end(); } catch (e) { /* ignore */ } });
        req.pipe(r);
    });
    server.on('connect', (req, sock, head) => {      // https / wss → อุโมงค์ผ่านพร็อกซีจริง
        const u = net.connect(upPort, upHost, () => { u.write(`CONNECT ${req.url} HTTP/1.1\r\nHost: ${req.url}\r\nProxy-Authorization: ${auth}\r\n\r\n`); });
        let buf = Buffer.alloc(0);
        const onData = (d) => {
            buf = Buffer.concat([buf, d]); const i = buf.indexOf('\r\n\r\n');
            if (i < 0) { if (buf.length > 16384) { sock.destroy(); u.destroy(); } return; }
            u.removeListener('data', onData);
            const code = +((/^HTTP\/\d(?:\.\d)?\s+(\d+)/.exec(buf.slice(0, i).toString()) || [])[1]);
            if (code !== 200) {
                if (code === 407 && !st.warned) { st.warned = true; say(`❌ ${g.id}: พร็อกซีไม่รับรหัส (407) — ตรวจชื่อผู้ใช้/รหัสผ่านในหน้า ตั้งค่า`); }
                sock.end(`HTTP/1.1 ${code || 502} Proxy Error\r\n\r\n`); u.destroy(); return;
            }
            sock.write('HTTP/1.1 200 Connection Established\r\n\r\n');
            const rest = buf.slice(i + 4); if (rest.length) sock.write(rest);
            if (head && head.length) u.write(head);
            u.pipe(sock); sock.pipe(u);
        };
        u.on('data', onData);
        u.on('error', () => sock.destroy()); sock.on('error', () => u.destroy());
        u.setTimeout(30000, () => { if (buf.length === 0) { sock.destroy(); u.destroy(); } });
    });
    server.on('error', (e) => say(`❌ ${g.id}: เปิดตัวกลางพร็อกซีที่พอร์ต ${port} ไม่ได้ (${e.code || e.message})`));
    server.listen(port, '127.0.0.1');
    const rl = { port, key, server }; RELAYS.set(g.id, rl);
    return rl;
}
function relaysSync() { for (const id of [...RELAYS.keys()]) if (!groupOf(id)) { RELAYS.get(id).server.close(); RELAYS.delete(id); } for (const g of CFG.groups) relayFor(g); }

async function stopGroup(g) {
    const ws = await browserWs(g);
    await cdp(ws, (send) => send('Browser.close')).catch(() => {});
    say(`⏹️ ปิด Chrome ${g.id}`);
}
const maxOf = (g) => Math.max(1, +g.maxScreens || +CFG.maxPerIp || 3);      // จอสูงสุดของโปรไฟล์ (ว่าง = ค่ากลางในหน้าตั้งค่า)
async function newGameWindow(g) {
    const info = S.groups[g.id] || {};
    if (!info.debug) throw Error(`${g.id} ยังไม่ได้เปิด`);
    const n = (info.targets || []).filter(isGame).length, max = maxOf(g);
    if (n >= max) throw Error(`${g.id} เปิดเกมครบ ${max} จอแล้ว (1 IP ได้ ${max} จอ)`);
    const ws = await browserWs(g);
    await cdp(ws, (send) => send('Target.createTarget', { url: gameUrlFor(g), newWindow: true }));
    say(`➕ เปิดจอเกมใหม่ใน ${g.id} (${n + 1}/${max})`);
}
// ดึงหน้าต่างขึ้นมาด้านหน้า: Windows ไม่ยอมให้โปรแกรมดึงหน้าต่างทับแอปอื่นตรง ๆ → ย่อแล้วคืนหน้าต่าง (Windows ยอมให้ขึ้นมาบนสุด) + Page.bringToFront ของแท็บนั้น
async function focusTarget(g, targetId) {
    const ws = await browserWs(g);
    await cdp(ws, async (send) => {
        await send('Target.activateTarget', { targetId }).catch(() => {});
        try {
            const w = await send('Browser.getWindowForTarget', { targetId });
            const st = (w.bounds && w.bounds.windowState) || 'normal';
            if (st !== 'minimized') { await send('Browser.setWindowBounds', { windowId: w.windowId, bounds: { windowState: 'minimized' } }); await sleep(150); }
            await send('Browser.setWindowBounds', { windowId: w.windowId, bounds: { windowState: st === 'maximized' ? 'maximized' : 'normal' } });
        } catch (e) { /* ignore */ }
    });
    const t = ((S.groups[g.id] || {}).targets || []).find((x) => x.id === targetId);
    if (t && t.webSocketDebuggerUrl) await cdp(t.webSocketDebuggerUrl, (send) => send('Page.bringToFront')).catch(() => {});
}
async function minimizeTarget(g, targetId) {
    const ws = await browserWs(g);
    await cdp(ws, async (send) => { const w = await send('Browser.getWindowForTarget', { targetId }); await send('Browser.setWindowBounds', { windowId: w.windowId, bounds: { windowState: 'minimized' } }); });
}
async function purgeTarget(g, targetId) {
    const t = (S.groups[g.id].targets || []).find((x) => x.id === targetId); if (!t || !t.webSocketDebuggerUrl) throw Error('ไม่พบแท็บ');
    await cdp(t.webSocketDebuggerUrl, async (send) => { await send('HeapProfiler.collectGarbage').catch(() => {}); await send('Memory.simulatePressureNotification', { level: 'critical' }).catch(() => {}); });
}
async function closeTarget(g, targetId) { await jget(g.debugPort, `/json/close/${targetId}`).catch(() => {}); }
// จัดเรียงหน้าต่างเกมทุก Chrome เป็นตาราง
async function arrangeAll(scr) {      // scr = ขนาดจอจริงจากหน้ารวม (ไม่ส่ง = ใช้ค่าในหน้า ตั้งค่า)
    const sc = CFG.screen || {}; const W = (scr && +scr.w) || +sc.width || 1920, H = (scr && +scr.h) || +sc.height || 1040, X0 = (scr && +scr.x) || 0, Y0 = (scr && +scr.y) || 0;
    const wins = [];
    for (const g of CFG.groups) {
        const info = S.groups[g.id]; if (!info || !info.debug) continue;
        const games = (info.targets || []).filter(isGame); if (!games.length) continue;
        try {
            const ws = await browserWs(g);
            await cdp(ws, async (send) => {
                const seen = new Set();
                for (const t of games) { try { const w = await send('Browser.getWindowForTarget', { targetId: t.id }); if (!seen.has(w.windowId)) { seen.add(w.windowId); wins.push({ g, windowId: w.windowId }); } } catch (e) { /* ignore */ } }
            });
        } catch (e) { /* ignore */ }
    }
    if (!wins.length) throw Error('ไม่มีหน้าต่างเกมให้จัด');
    const cols = Math.max(1, +sc.cols || Math.ceil(Math.sqrt(wins.length))), rows = Math.ceil(wins.length / cols);
    const w = Math.floor(W / cols), h = Math.floor(H / rows);
    const byG = new Map(); wins.forEach((x, i) => { (byG.get(x.g) || byG.set(x.g, []).get(x.g)).push({ windowId: x.windowId, i }); });
    for (const [g, list] of byG) {
        const ws = await browserWs(g);
        await cdp(ws, async (send) => {
            for (const { windowId, i } of list) {      // ย่อแล้วคืน = Windows ยอมให้หน้าต่างขึ้นมาบนสุด (เห็นครบทุกจอ ไม่จมอยู่หลังโปรแกรมอื่น)
                await send('Browser.setWindowBounds', { windowId, bounds: { windowState: 'minimized' } }).catch(() => {}); await sleep(80);
                await send('Browser.setWindowBounds', { windowId, bounds: { windowState: 'normal' } }).catch(() => {});
                await send('Browser.setWindowBounds', { windowId, bounds: { left: X0 + (i % cols) * w, top: Y0 + Math.floor(i / cols) * h, width: w, height: h } }).catch(() => {});
            }
        });
    }
    for (const g of byG.keys()) for (const t of ((S.groups[g.id] || {}).targets || []).filter(isGame)) if (t.webSocketDebuggerUrl) await cdp(t.webSocketDebuggerUrl, (send) => send('Page.bringToFront')).catch(() => {});
    say(`🪟 จัดหน้าต่างเกม ${wins.length} หน้าต่าง (${cols} คอลัมน์ × ${rows} แถว) และดึงขึ้นมาด้านหน้า`);
}

// ---------------------------------------------------------------
// ตรวจสถานะเป็นระยะ
// ---------------------------------------------------------------
async function scanGroups() {
    await Promise.all(CFG.groups.map(async (g) => {
        const info = S.groups[g.id] || (S.groups[g.id] = {});
        try { const list = await jget(g.debugPort, '/json/list'); info.debug = true; info.targets = list.filter((t) => t.type === 'page'); info.tm = list.some((t) => String(t.url || '').startsWith('chrome-extension://' + TM_ID + '/'));
            // หน้าต้อนรับ/แจ้งอัปเดตที่ Tampermonkey เปิดเอง (tampermonkey.net/index.php?…updated=true, /installed) → ปิดให้ทุกครั้งที่เจอ
            for (const t of list) if (t.type === 'page' && TM_WELCOME.test(t.url || '')) { jget(g.debugPort, `/json/close/${t.id}`).catch(() => {}); say(`🧹 ${g.id}: ปิดหน้าแจ้งติดตั้ง/อัปเดตของ Tampermonkey`); }
        }
        catch (e) { info.debug = false; info.targets = []; info.tm = null; }
        info.running = info.debug || (info.procs || 0) > 0;
        info.outside = !info.debug && (info.procs || 0) > 0;
    }));
    // จับคู่ตัวละคร ↔ แท็บ: ชื่อแท็บที่สคริปต์ตั้ง ("ชื่อตัวละคร · แมพ · 3D …")
    const now = Date.now();
    for (const p of Object.values(S.peers)) {
        if (now - p.ts > 7 * 86400000) { delete S.peers[p.tab]; delete S.cmds[p.tab]; continue; }      // จำตัวละครที่เคยเล่นไว้ 7 วัน (ดูข้อมูลล่าสุดได้แม้ Chrome ปิด)
        if (now - p.ts > 60000) { delete S.cmds[p.tab]; continue; }      // ออฟไลน์: คงกลุ่มเดิมไว้ ไม่จับคู่แท็บใหม่
        p.group = p.grp && groupOf(p.grp) ? p.grp : ''; p.targetId = '';      // หน้าต่างที่เปิดจากโปรแกรม สคริปต์บอกกลุ่มมาเอง (#aeth=G01)
        for (const g of CFG.groups) {
            if (p.group && p.group !== g.id) continue;
            const t = ((S.groups[g.id] || {}).targets || []).find((x) => isGame(x) && ((p.ttl && x.title === p.ttl) || (x.title || '').split(' · ').some((part) => part.replace(/^\S+\s/, '') === p.name || part === p.name)));
            if (t) { p.group = g.id; p.targetId = t.id; break; }
        }
    }
}
// RAM ของ Chrome แต่ละตัว (รวมทุกโปรเซสที่มี --user-data-dir ของตัวนั้น) · Windows เท่านั้น
function scanProcs() {
    if (process.platform !== 'win32') return;
    const ps = "Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\" | Select-Object WorkingSetSize,CommandLine | ConvertTo-Json -Compress";
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], { windowsHide: true, maxBuffer: 32 * 1024 * 1024, timeout: 20000 }, (err, out) => {
        if (err) return;
        let list = []; try { list = JSON.parse(out || '[]'); if (!Array.isArray(list)) list = [list]; } catch (e) { return; }
        const agg = {};
        for (const p of list) {
            const m = /--user-data-dir="?([^"]+?)"?(?:\s--|$)/i.exec(p.CommandLine || ''); if (!m) continue;
            const g = CFG.groups.find((x) => x.dir.toLowerCase().replace(/\\+$/, '') === m[1].toLowerCase().replace(/\\+$/, '')); if (!g) continue;
            const a = agg[g.id] || (agg[g.id] = { ram: 0, procs: 0 }); a.ram += +p.WorkingSetSize || 0; a.procs++;
        }
        for (const g of CFG.groups) { const info = S.groups[g.id] || (S.groups[g.id] = {}); const a = agg[g.id] || { ram: 0, procs: 0 }; info.ram = a.ram; info.procs = a.procs; }
    });
}
function scanCpu() {
    const t = os.cpus().reduce((a, c) => { const s = Object.values(c.times).reduce((x, y) => x + y, 0); a.total += s; a.idle += c.times.idle; return a; }, { total: 0, idle: 0 });
    if (S.cpu.prev) { const dt = t.total - S.cpu.prev.total, di = t.idle - S.cpu.prev.idle; if (dt > 0) S.cpu.pct = Math.round(100 * (1 - di / dt)); }
    S.cpu.prev = t;
}
setInterval(() => { scanGroups().catch(() => {}); }, 3000);
// เก็บตัวละครที่เคยเล่น (ข้อมูลล่าสุด + กระเป๋าล่าสุด) ลงไฟล์ → ปิด/เปิดโปรแกรมใหม่ก็ยังดูได้
const PEERS_FILE = path.join(ROOT, 'peers.json');
try {
    const saved = JSON.parse(fs.readFileSync(PEERS_FILE, 'utf8'));
    for (const p of saved.peers || []) if (p && p.tab && p.name) { p.targetId = ''; S.peers[p.tab] = p; }
    Object.assign(S.inv, saved.inv || {});
} catch (e) { /* ยังไม่มีไฟล์ */ }
setInterval(() => {
    try {
        const peers = Object.values(S.peers), tabs = new Set(peers.map((p) => p.tab));
        const inv = {}; for (const [t, v] of Object.entries(S.inv)) if (tabs.has(t)) inv[t] = v;
        fs.writeFileSync(PEERS_FILE + '.tmp', JSON.stringify({ peers, inv })); fs.renameSync(PEERS_FILE + '.tmp', PEERS_FILE);
    } catch (e) { /* ignore */ }
}, 30000);
// 🎓 ข้อมูลอาชีพ/สกิลทั้งเกม (สคริปต์อ่านจากเซิร์ฟเวอร์เกมส่งมา) → classdata.json
const CD_FILE = path.join(ROOT, 'classdata.json');
S.cd = null; try { S.cd = JSON.parse(fs.readFileSync(CD_FILE, 'utf8')); } catch (e) { /* ยังไม่มี */ }
// 🏪 ตลาดกลาง (อ่านอย่างเดียว): ราคาล่าสุด + ประวัติราคาต่อไอเทม + รายการจับตา (แจ้งเตือนเมื่อราคาต่ำกว่าที่ตั้ง) · เก็บลง market.json
const MK_FILE = path.join(ROOT, 'market.json');
S.mk = { items: {}, watch: [], alerts: [], last: {}, every: 15, nextAt: 0 };
try { Object.assign(S.mk, JSON.parse(fs.readFileSync(MK_FILE, 'utf8')) || {}, { last: {} }); } catch (e) { /* ยังไม่มีไฟล์ */ }
let mkDirty = false;
setInterval(() => { if (!mkDirty) return; mkDirty = false; try { const { last, ...keep } = S.mk; fs.writeFileSync(MK_FILE + '.tmp', JSON.stringify(keep)); fs.renameSync(MK_FILE + '.tmp', MK_FILE); } catch (e) { /* ignore */ } }, 30000);
const mkKey = (n) => String(n || '').trim().toLowerCase();
function mkIngest(b) {
    const now = Date.now(), by = {};
    for (const r of (Array.isArray(b.rows) ? b.rows : []).slice(0, 200)) { if (!r || !r.n) continue; (by[mkKey(r.n)] || (by[mkKey(r.n)] = [])).push(r); }
    for (const [k, rows] of Object.entries(by)) {
        const it = S.mk.items[k] || (S.mk.items[k] = { n: rows[0].n, ic: '', hist: [], last: [], at: 0 });
        const buy = rows.filter((r) => !r.auc && r.unit > 0), auc = rows.filter((r) => r.auc && r.unit > 0);
        const minB = buy.length ? Math.min(...buy.map((r) => r.unit)) : 0, minA = auc.length ? Math.min(...auc.map((r) => r.unit)) : 0;
        it.ic = rows.find((r) => r.ic) ? rows.find((r) => r.ic).ic : it.ic; it.at = now; it.n = rows[0].n;
        it.last = rows.slice().sort((a, c) => a.unit - c.unit).slice(0, 40);
        const h = it.hist[it.hist.length - 1];
        if (!h || now - h[0] > 300000 || h[1] !== minB) { it.hist.push([now, minB, minA, rows.length, rows.reduce((a, r) => a + (+r.q || 0), 0)]); if (it.hist.length > 600) it.hist.splice(0, it.hist.length - 600); }
        for (const w of S.mk.watch) {      // 🔔 จับตา: ราคาต่อชิ้น (ซื้อทันที) ≤ ที่ตั้ง
            if (!w.on || mkKey(w.n) !== k || !minB || minB > +w.max) continue;
            const best = buy.find((r) => r.unit === minB);
            if (w.lastAlert && now - w.lastAlert < 1800000 && w.lastPrice === minB) continue;
            w.lastAlert = now; w.lastPrice = minB;
            S.mk.alerts.push({ at: now, n: it.n, unit: minB, q: best.q, seller: best.seller, max: +w.max, ic: it.ic });
            if (S.mk.alerts.length > 100) S.mk.alerts.splice(0, S.mk.alerts.length - 100);
            say(`🔔 ตลาด: ${it.n} ราคา ${minB.toLocaleString()} z/ชิ้น (≤ ${(+w.max).toLocaleString()}) · ${best.q} ชิ้น · ${best.seller}`);
        }
    }
    mkDirty = true;
}
function mkPickPeer(prefer) {      // ตัวที่ใช้ค้นตลาด: ที่เลือก > ตัวออนไลน์ที่ว่างและสคริปต์รองรับ
    const now = Date.now(), ok = (p) => p && now - p.ts < 30000 && verNum(p.v || '0') >= verNum('5.72.0');
    if (prefer && ok(S.peers[prefer])) return S.peers[prefer];
    const list = Object.values(S.peers).filter(ok).sort((a, c) => (a.busy ? 1 : 0) - (c.busy ? 1 : 0) || (S.mk.lastUse && S.mk.lastUse[a.tab] || 0) - (S.mk.lastUse && S.mk.lastUse[c.tab] || 0));
    return list[0] || null;
}
setInterval(() => {      // ⏱️ ค้นรายการจับตาตามรอบ (ทีละไอเทม ห่างกัน 45 วิ)
    try {
        const on = S.mk.watch.filter((w) => w.on); if (!on.length || Date.now() < (S.mk.nextAt || 0)) return;
        S.mk.nextAt = Date.now() + Math.max(5, +S.mk.every || 15) * 60000;
        on.forEach((w, i) => setTimeout(() => { const pe = mkPickPeer(); if (!pe) return; S.mk.lastUse = S.mk.lastUse || {}; S.mk.lastUse[pe.tab] = Date.now(); queue(pe.tab, 'mkscan', { q: w.n, pages: 1 }); }, i * 45000));
    } catch (e) { /* ignore */ }
}, 30000);
// 📊 Profit + สถิติของแต่ละตัวละคร (สคริปต์ส่งมาทุก 2 นาที) → หน้า สถิติ รวมรายตัว / รายโปรไฟล์ / ทั้งหมด · เก็บลงไฟล์
const STATS_FILE = path.join(ROOT, 'stats.json');
S.zone = {}; S.skill = {}; S.askill = {}; S.acfg = {}; S.junk = {}; S.stats = {};
const SKILL_FILE = path.join(ROOT, 'skills.json'); let skillDirty = false;
try { const j = JSON.parse(fs.readFileSync(SKILL_FILE, 'utf8')); Object.assign(S.skill, j.skill || {}); Object.assign(S.askill, j.askill || {}); } catch (e) { /* ยังไม่มีไฟล์ */ }
setInterval(() => { if (!skillDirty) return; skillDirty = false; try { fs.writeFileSync(SKILL_FILE + '.tmp', JSON.stringify({ skill: S.skill, askill: S.askill })); fs.renameSync(SKILL_FILE + '.tmp', SKILL_FILE); } catch (e) { /* ignore */ } }, 60000); try { S.stats = JSON.parse(fs.readFileSync(STATS_FILE, 'utf8')) || {}; } catch (e) { /* ยังไม่มีไฟล์ */ }
let statsDirty = false;
setInterval(() => {
    if (!statsDirty) return; statsDirty = false;
    try { fs.writeFileSync(STATS_FILE + '.tmp', JSON.stringify(S.stats)); fs.renameSync(STATS_FILE + '.tmp', STATS_FILE); } catch (e) { /* ignore */ }
}, 60000);
setInterval(scanProcs, 10000);
// 📈 ประวัติแรมของแต่ละ Chrome (ทุก 1 นาที · เก็บ 6 ชม.) + 🧹 คืน RAM อัตโนมัติ + 🧠 แรมเกิน → รีโหลดตอนว่าง
S.ramHist = {}; S.purgeAt = {}; S.guardAt = {};
setInterval(async () => {
    const now = Date.now();
    for (const g of CFG.groups) {
        const i = S.groups[g.id] || {}; const h = S.ramHist[g.id] || (S.ramHist[g.id] = []);
        if (i.running && i.ram) { h.push([now, Math.round(i.ram / 1048576)]); if (h.length > 360) h.splice(0, h.length - 360); }
        if (!i.debug) continue;
        const games = (i.targets || []).filter(isGame);
        if (CFG.autoPurge !== false && games.length && now - (S.purgeAt[g.id] || 0) > Math.max(5, +CFG.purgeMin || 20) * 60000) {
            S.purgeAt[g.id] = now; let n = 0;
            for (const t of games) {
                const pe = Object.values(S.peers).find((x) => x.targetId === t.id);
                if (pe && pe.busy) continue;      // กำลังวาร์ป/ซื้อของ/ทิ้งขยะ → ข้ามรอบนี้
                try { await purgeTarget(g, t.id); n++; } catch (e) { /* ignore */ }
                await sleep(1500);
            }
            if (n) say(`🧹 ${g.id}: คืน RAM อัตโนมัติ ${n} จอ`);
        }
        const lim = Math.max(0.5, +CFG.ramLimitGB || 2.5) * 1073741824;
        if (CFG.ramGuard !== false && games.length && i.ram > lim * games.length && now - (S.guardAt[g.id] || 0) > Math.max(10, +CFG.ramCooldownMin || 60) * 60000) {
            S.guardAt[g.id] = now;
            const ps = Object.values(S.peers).filter((x) => x.group === g.id && now - x.ts < 60000);
            ps.forEach((x, k) => setTimeout(() => queue(x.tab, 'reloadsafe', { why: `แรม ${g.id} สูง (${(i.ram / 1073741824).toFixed(1)} GB / ${games.length} จอ)` }), k * 20000));
            say(`🧠 ${g.id}: แรม ${(i.ram / 1073741824).toFixed(1)} GB เกิน ${CFG.ramLimitGB} GB/จอ — สั่งรีโหลด ${ps.length} จอตอนว่าง`);
        }
    }
}, 60000);
setInterval(scanCpu, 3000);
scanProcs(); scanCpu(); scanGroups().catch(() => {});

// ---------------------------------------------------------------
// คำสั่งให้ตัวละคร (สคริปต์มารับทุก ~3 วิ)
// ---------------------------------------------------------------
const SCRIPT_CMDS = new Set(['r3off', 'r3on', 'pause', 'resume', 'farm', 'reload', 'send', 'ch', 'inv', 'maps', 'reloadsafe', 'lowgfx', 'lowgfxoff', 'equip', 'statset', 'statrun', 'zone', 'zoneset', 'drop', 'skills', 'skillset', 'skillrun', 'askills', 'askillset', 'wbset', 'junkget', 'junkset', 'mkscan', 'mkbuy', 'mkclaim', 'sell', 'sellset', 'jobgo', 'jobset', 'autocfg', 'autocfgset']);
// 🔄 โปรแกรมรีเฟรชหน้าเกมที่ยังใช้สคริปต์รุ่นเก่าให้เอง (เปิด "อัปเดตสคริปต์ทุกจอเอง" อยู่) — ไม่รอสคริปต์ในเกม
//    เห็นว่าเก่ามาแล้ว 60 วิ + ตัวละครไม่ได้ทำงานค้าง (วาร์ป/ซื้อ/ทิ้งของ) + ไม่ติด Captcha/ตาย → ทยอยรีโหลดทีละจอ (ห่าง 15 วิ) · จอเดิมไม่ซ้ำภายใน 5 นาที
const AUR = { old: {}, last: {}, tries: {}, any: 0 };
setInterval(() => {
    try {
        if (CFG.autoUpdate === false) { for (const p of Object.values(S.peers)) p.aurWhy = 'ปิด "อัปเดตสคริปต์ทุกจอเอง" อยู่ (ตั้งค่า → อัตโนมัติ)'; return; }
        const si = scriptInfo(); if (!si) return; const now = Date.now();
        for (const p of Object.values(S.peers)) {
            const old = now - p.ts < 30000 && p.v && verNum(p.v) < verNum(si.version);
            if (!old) { delete AUR.old[p.tab]; delete AUR.tries[p.tab]; delete p.aurWhy; continue; }
            if (!AUR.old[p.tab]) AUR.old[p.tab] = now;
            const k = p.kd && p.kd.k, tries = AUR.tries[p.tab] || 0, oldFor = now - AUR.old[p.tab];
            const why = oldFor < 60000 ? 'รอครบ 1 นาที' : k === 'captcha' ? 'รอตอบ Captcha' : k === 'dead' ? 'ตัวละครตายอยู่' : p.busy && oldFor < 600000 ? `รอ ${p.busy} เสร็จ (สูงสุด 10 นาที)` : now - (AUR.last[p.tab] || 0) < 300000 ? (tries ? `รีโหลดแล้ว ${tries} ครั้งแต่ยังได้ v${p.v} — ตัวโหลดใน Tampermonkey อาจโหลดสคริปต์ใหม่ไม่ทัน แล้วใช้ชุดที่จำไว้ · ลองใหม่ใน ${Math.ceil((300000 - (now - AUR.last[p.tab])) / 60000)} นาที` : 'เพิ่งสั่งรีโหลด') : now - AUR.any < 15000 ? 'รอคิวจอก่อนหน้า' : '';
            p.aurWhy = why || 'กำลังสั่งรีโหลด';
            if (why) continue;
            AUR.last[p.tab] = now; AUR.any = now; AUR.tries[p.tab] = tries + 1; queue(p.tab, 'reload');
            say(`🔄 รีเฟรช ${p.name} เพื่ออัปเดตสคริปต์ v${p.v} → v${si.version}${tries ? ` (ครั้งที่ ${tries + 1})` : ''}`);
        }
    } catch (e) { /* ignore */ }
}, 5000);
function queue(tab, cmd, extra) { (S.cmds[tab] || (S.cmds[tab] = [])).push(Object.assign({ id: ++S.seq, cmd, at: Date.now() }, extra || {})); }
async function peerCmd(p, cmd, extra) {
    if (SCRIPT_CMDS.has(cmd)) { queue(p.tab, cmd, extra); return; }
    const g = groupOf(p.group); if (!g || !p.targetId) throw Error(`ยังไม่รู้ว่า ${p.name} อยู่หน้าต่างไหน (เปิดชื่อแท็บในสคริปต์ไว้ และ Chrome ต้องเปิดจากโปรแกรมนี้)`);
    if (cmd === 'focus') return focusTarget(g, p.targetId);
    if (cmd === 'min') return minimizeTarget(g, p.targetId);
    if (cmd === 'purge') return purgeTarget(g, p.targetId);
    if (cmd === 'close') return closeTarget(g, p.targetId);
    throw Error('ไม่รู้จักคำสั่ง ' + cmd);
}

// ---------------------------------------------------------------
// 🧩 ติดตั้ง/อัปเดตสคริปต์จากโฟลเดอร์โปรแกรม (ผู้ใช้กดยืนยันเองในหน้าของ Tampermonkey)
// ---------------------------------------------------------------
const TM_ID = 'dhdgffkkebhmkfjojejmpbldmpobfkfo';
const TM_STORE = 'https://chromewebstore.google.com/detail/tampermonkey/' + TM_ID;
const verNum = (v) => String(v || '0').split('.').map((x) => parseInt(x, 10) || 0).reduce((a, x) => a * 1000 + x, 0);
// สคริปต์ล่าสุดในโฟลเดอร์โปรแกรม (ไฟล์ *.user.js ที่ @version สูงสุด) — วางไฟล์ใหม่เพิ่ม/ทับได้เลย
let CORE_GZ = null; const SI_CACHE = {};
function scriptInfo() {      // อ่านไฟล์เฉพาะตอนเปลี่ยน (เทียบเวลาแก้ไข) — ถูกเรียกถี่ทุกจอ
    let best = null;
    for (const f of fs.readdirSync(ROOT)) {
        if (!/\.user\.js$/i.test(f)) continue;
        let src = ''; try { const st = fs.statSync(path.join(ROOT, f)), c = SI_CACHE[f]; if (c && c.m === st.mtimeMs && c.z === st.size) src = c.src; else { src = fs.readFileSync(path.join(ROOT, f), 'utf8'); SI_CACHE[f] = { m: st.mtimeMs, z: st.size, src }; } } catch (e) { continue; }
        const head = /\/\/ ==UserScript==[\s\S]*?\/\/ ==\/UserScript==/.exec(src); if (!head) continue;
        const v = (/@version\s+(\S+)/.exec(head[0]) || [])[1] || '0';
        if (!best || verNum(v) > verNum(best.version)) best = { file: f, version: v, src, head: head[0] };
    }
    return best;
}
// ใส่ @updateURL/@downloadURL ชี้มาที่โปรแกรมนี้ → Tampermonkey ทุก Chrome เช็คอัปเดตจากในเครื่องเองตามรอบ
// 🔁 ตัวโหลด: ติดตั้งใน Tampermonkey ครั้งเดียว (ชื่อเดียวกับสคริปต์เดิม → แทนที่ของเดิม) · ทุกครั้งที่เปิด/รีโหลดหน้าเกมจะดึงสคริปต์ล่าสุดจากโปรแกรมนี้มารัน
//    โปรแกรมไม่ได้เปิด → ใช้โค้ดชุดล่าสุดที่จำไว้ใน Tampermonkey · วางไฟล์ .user.js ใหม่ + รีโหลดหน้าเกม = อัปเดตทันที ไม่ต้องกดอะไรใน Tampermonkey
const LOADER_VERSION = '6.0.0';      // เปลี่ยนเลขนี้เฉพาะตอนแก้ตัวโหลดเอง (สคริปต์ตัวจริงไม่เกี่ยว)
function loaderHead(si) {
    const base = `http://127.0.0.1:${CFG.port}`;
    return si.head.replace(/^\/\/ @(version|updateURL|downloadURL|run-at)\s.*\r?\n/gm, '')
        .replace(/^(\/\/ @namespace\s.*)$/m, `$1\n// @version      ${LOADER_VERSION}\n// @updateURL    ${base}/aetherack.meta.js\n// @downloadURL  ${base}/aetherack.user.js`);
}
function loaderSource(si) {
    const base = `http://127.0.0.1:${CFG.port}`;
    return `${loaderHead(si)}

// Aetherack — ตัวโหลด: ดึงสคริปต์ล่าสุดจาก Aetherack Manager (${base}) ทุกครั้งที่เปิดหน้าเกม · ติดต่อไม่ได้ = ใช้ชุดที่จำไว้
(function () {
    'use strict';
    const AETH_LOADER = '${LOADER_VERSION}';      // สคริปต์ตัวจริงอ่านค่านี้ → บอกโปรแกรมว่าอัปเดตเองได้
    const KEY = 'aeth_core';
    let done = false;
    const run = (code, from) => {
        if (done) return; done = true;
        try { eval(code); } catch (e) { console.error('[Aetherack ตัวโหลด] รันสคริปต์ไม่สำเร็จ (' + from + ')', e); }
    };
    const fallback = () => { const c = GM_getValue(KEY, null); if (c && c.code) run(c.code, 'ชุดที่จำไว้ v' + c.v); else console.warn('[Aetherack ตัวโหลด] ติดต่อโปรแกรมไม่ได้ และยังไม่มีชุดที่จำไว้ — เปิด Aetherack Manager แล้วรีโหลดหน้านี้'); };
    const timer = setTimeout(fallback, 3000);
    GM_xmlhttpRequest({
        method: 'GET', url: '${base}/aetherack.core.js?t=' + Date.now(), timeout: 3000,
        onload: (r) => {
            const code = r.responseText || '';
            if (r.status !== 200 || !/==UserScript==/.test(code)) { clearTimeout(timer); fallback(); return; }
            clearTimeout(timer);
            const v = (/@version\\s+(\\S+)/.exec(code) || [])[1] || '?';
            const c = GM_getValue(KEY, null); if (!c || c.v !== v || c.code.length !== code.length) GM_setValue(KEY, { v, code, at: Date.now() });
            run(code, 'v' + v);
        },
        onerror: () => { clearTimeout(timer); fallback(); }, ontimeout: () => { clearTimeout(timer); fallback(); },
    });
})();
`;
}
function withUpdateUrls(text) {
    const base = `http://127.0.0.1:${CFG.port}`;
    return text.replace(/^\/\/ @(updateURL|downloadURL)\s.*\r?\n/gm, '')
        .replace(/^(\/\/ @version\s.*)$/m, `$1\n// @updateURL    ${base}/aetherack.meta.js\n// @downloadURL  ${base}/aetherack.user.js`);
}
async function openTab(g, url) { const ws = await browserWs(g); const r = await cdp(ws, (send) => send('Target.createTarget', { url })); return r && r.targetId; }

// ---------------------------------------------------------------
// ⚙️ ตัวเลือกอัตโนมัติ (เปิดเองในหน้า ตั้งค่า): ติดตั้ง Tampermonkey ด้วยนโยบายของ Chrome · เปิด Allow User Scripts · กดยืนยันติดตั้งสคริปต์ให้เอง
// ---------------------------------------------------------------
const TM_FORCE = TM_ID + ';https://clients2.google.com/service/update2/crx';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// ข้อความผิดพลาดของ PowerShell ตอนรันแบบ -EncodedCommand ออกมาเป็น CLIXML (มีข้อความ "Preparing modules…" ปน) → ดึงเฉพาะบรรทัด Error
function psErr(raw) {
    const t = String(raw || '');
    if (!/#< CLIXML/.test(t)) return t.trim();
    const errs = [...t.matchAll(/<S S="Error">([\s\S]*?)<\/S>/g)].map((m) => m[1].replace(/_x000D_/g, '').replace(/_x000A_/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').trim()).filter(Boolean);
    return errs.join(' ').trim();
}
function ps(script, elevated) {
    return new Promise((resolve, reject) => {
        if (process.platform !== 'win32') { reject(Error('ใช้ได้เฉพาะ Windows')); return; }
        const enc = Buffer.from(`$ProgressPreference='SilentlyContinue'; $ErrorActionPreference='Stop'; ${script}`, 'utf16le').toString('base64');
        const args = elevated      // ทั้งเครื่อง (HKLM) ต้องใช้สิทธิ์ Admin → Windows ถาม UAC
            ? ['-NoProfile', '-NonInteractive', '-Command', `$ProgressPreference='SilentlyContinue'; try { $p = Start-Process powershell -Verb RunAs -Wait -PassThru -WindowStyle Hidden -ArgumentList '-NoProfile','-NonInteractive','-EncodedCommand','${enc}'; exit $p.ExitCode } catch { Write-Error 'ไม่ได้รับสิทธิ์ Admin (กดยกเลิกหน้าต่าง UAC)'; exit 1 }`]
            : ['-NoProfile', '-NonInteractive', '-EncodedCommand', enc];
        execFile('powershell.exe', args, { windowsHide: true, timeout: 120000 }, (err, out, errOut) => {
            if (err) { const msg = psErr(errOut) || (err.killed ? 'PowerShell ทำงานนานเกิน' : `PowerShell ล้มเหลว (รหัส ${err.code})`); reject(Error(msg.slice(0, 300))); }
            else resolve(String(out || '').trim());
        });
    });
}
const POLICY_KEYS = { user: 'HKCU:\\Software\\Policies\\Google\\Chrome\\ExtensionInstallForcelist', machine: 'HKLM:\\Software\\Policies\\Google\\Chrome\\ExtensionInstallForcelist' };
S.policy = { user: false, machine: false };
async function policyScan() {
    if (process.platform !== 'win32') return;
    for (const scope of ['user', 'machine']) {
        try { const out = await ps(`$k='${POLICY_KEYS[scope]}'; if (Test-Path $k) { @((Get-ItemProperty $k).PSObject.Properties | Where-Object { $_.Name -match '^\\d+$' -and "$($_.Value)" -like '${TM_ID}*' }).Count } else { 0 }`); S.policy[scope] = +out > 0; } catch (e) { /* ignore */ }
    }
}
async function policySet(scope, on) {
    const k = POLICY_KEYS[scope]; if (!k) throw Error('scope ไม่ถูกต้อง');
    const script = on
        ? `$k='${k}'; if (!(Test-Path $k)) { New-Item -Path $k -Force | Out-Null }; $p=@((Get-ItemProperty $k).PSObject.Properties | Where-Object { $_.Name -match '^\\d+$' }); if (-not ($p | Where-Object { "$($_.Value)" -like '${TM_ID}*' })) { $i=1; while ($p.Name -contains "$i") { $i++ }; New-ItemProperty -Path $k -Name "$i" -Value '${TM_FORCE}' -PropertyType String -Force | Out-Null }`
        : `$k='${k}'; if (Test-Path $k) { (Get-ItemProperty $k).PSObject.Properties | Where-Object { $_.Name -match '^\\d+$' -and "$($_.Value)" -like '${TM_ID}*' } | ForEach-Object { Remove-ItemProperty -Path $k -Name $_.Name } }`;
    await ps(script, scope === 'machine');
    await policyScan();
    const where = scope === 'machine' ? 'ทั้งเครื่อง' : 'ผู้ใช้ Windows นี้';
    say(on ? `🧩 ตั้งนโยบายให้ Chrome ติดตั้ง Tampermonkey เอง (${where}) — ปิด/เปิด Chrome ใหม่ 1 ครั้ง` : `🧩 ยกเลิกนโยบายติดตั้ง Tampermonkey (${where})`);
}
// รันโค้ดในแท็บใหม่ของ Chrome กลุ่มนั้น แล้วปิดแท็บ
async function evalInNewTab(g, url, expression, waitMs = 1500) {
    const targetId = await openTab(g, url);
    try {
        await sleep(waitMs);
        const t = (await jget(g.debugPort, '/json/list')).find((x) => x.id === targetId); if (!t) throw Error('ไม่พบแท็บที่เปิด');
        const r = await cdp(t.webSocketDebuggerUrl, (send) => send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true }));
        if (r.exceptionDetails) throw Error((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || 'สคริปต์ผิดพลาด');
        return r.result && r.result.value;
    } finally { await jget(g.debugPort, `/json/close/${targetId}`).catch(() => {}); }
}
// เปิดสวิตช์ "Allow User Scripts" ของ Tampermonkey (Chrome 138+) · Chrome รุ่นเก่ากว่าใช้โหมดนักพัฒนาแทน — สั่งผ่านหน้า chrome://extensions ของ Chrome เอง
async function allowUserScripts(g) {
    const expr = `(async () => {
        const d = chrome.developerPrivate, out = {};
        const call = (fn, ...a) => new Promise((res, rej) => { try { const r = fn.call(d, ...a, (v) => { const e = chrome.runtime && chrome.runtime.lastError; if (e) rej(Error(e.message)); else res(v); }); if (r && r.then) r.then(res, rej); } catch (e) { rej(e); } });
        let info = null; try { info = await call(d.getExtensionInfo, '${TM_ID}'); } catch (e) { return JSON.stringify({ installed: false }); }
        out.installed = !!info;
        if (info && 'userScriptsAccess' in info) {
            if (!info.userScriptsAccess) { try { await call(d.updateExtensionConfiguration, { extensionId: '${TM_ID}', userScriptsAccess: true }); } catch (e) { out.err = String(e.message || e); } }
            try { out.allowed = !!(await call(d.getExtensionInfo, '${TM_ID}')).userScriptsAccess; } catch (e) { /* ignore */ }
        } else {
            try { await call(d.updateProfileConfiguration, { inDeveloperMode: true }); out.allowed = true; out.dev = true; } catch (e) { out.err = String(e.message || e); }
        }
        return JSON.stringify(out);
    })()`;
    const r = JSON.parse((await evalInNewTab(g, 'chrome://extensions/?id=' + TM_ID, expr)) || '{}');
    if (!r.installed) throw Error(`${g.id}: ยังไม่มี Tampermonkey`);
    if (!r.allowed) throw Error(`${g.id}: เปิด Allow User Scripts ไม่สำเร็จ${r.err ? ' (' + r.err + ')' : ''} — กดเปิดเองที่หน้าตั้งค่า Tampermonkey`);
    say(`✅ ${g.id}: เปิด ${r.dev ? 'โหมดนักพัฒนา (Chrome รุ่นเก่า)' : 'Allow User Scripts'} ให้ Tampermonkey แล้ว`);
    return 'ok';
}
// ตรวจอย่างเดียว (ไม่เปลี่ยนอะไร): มี Tampermonkey ไหม / เปิดอยู่ไหม / อนุญาตสคริปต์ผู้ใช้แล้วหรือยัง
async function extStatus(g) {
    const expr = `(async () => {
        const d = chrome.developerPrivate;
        const call = (fn, ...a) => new Promise((res, rej) => { try { const r = fn.call(d, ...a, (v) => { const e = chrome.runtime && chrome.runtime.lastError; if (e) rej(Error(e.message)); else res(v); }); if (r && r.then) r.then(res, rej); } catch (e) { rej(e); } });
        let i = null; try { i = await call(d.getExtensionInfo, '${TM_ID}'); } catch (e) { return JSON.stringify({ installed: false }); }
        if (!i) return JSON.stringify({ installed: false });
        let allowed = null;
        if ('userScriptsAccess' in i) allowed = !!i.userScriptsAccess;
        else { try { allowed = !!(await call(d.getProfileConfiguration)).inDeveloperMode; } catch (e) { /* ignore */ } }
        return JSON.stringify({ installed: true, enabled: i.state === 'ENABLED', allowed, version: i.version || '' });
    })()`;
    const r = JSON.parse((await evalInNewTab(g, 'chrome://extensions/', expr, 1200)) || '{}');
    const info = S.groups[g.id] || (S.groups[g.id] = {});
    info.ext = Object.assign({}, r, { at: Date.now() });
    if (r.installed) info.tm = true;
    return r;
}
// 🧹 แท็บที่โปรแกรมเปิดให้ (ร้านค้า / หน้าตั้งค่าส่วนขยาย) → ปิดเองเมื่อทำขั้นนั้นเสร็จ · หน้าต้อนรับที่ Tampermonkey เปิดเองหลังติดตั้งก็ปิดให้ด้วย
async function closeTab(g, tid) { if (tid) await jget(g.debugPort, `/json/close/${tid}`).catch(() => {}); }
const TM_WELCOME = /^https?:\/\/(www\.)?tampermonkey\.net\/(installed|changelog|first|index\.php\?.*\b(updated|installed)=)/i;
async function closeTmWelcome(g) {
    const list = await jget(g.debugPort, '/json/list').catch(() => []);
    for (const t of list) if (t.type === 'page' && TM_WELCOME.test(t.url || '')) await closeTab(g, t.id);
}
function closeWhen(g, tid, cond, ms, every = 3000) {      // เฝ้าเบื้องหลัง: เงื่อนไขเป็นจริง → ปิดแท็บ (เลิกเฝ้าเมื่อผู้ใช้ปิดแท็บเอง / หมดเวลา)
    (async () => {
        const end = Date.now() + ms;
        while (Date.now() < end) {
            await sleep(every);
            const list = await jget(g.debugPort, '/json/list').catch(() => null); if (!list || !list.some((x) => x.id === tid)) return;
            try { if (await cond()) { await sleep(800); await closeTab(g, tid); await closeTmWelcome(g); return; } } catch (e) { /* ignore */ }
        }
    })();
}
async function waitFor(fn, ms, every) {
    const end = Date.now() + ms;
    while (Date.now() < end) { try { const v = await fn(); if (v) return v; } catch (e) { /* ignore */ } await sleep(every); }
    return null;
}
const gameUrlFor = (g) => `${String(CFG.gameUrl).replace(/#.*$/, '')}#aeth=${encodeURIComponent(g.id)}`;      // สคริปต์อ่าน #aeth= แล้วรู้ว่าอยู่ Chrome กลุ่มไหน
// สคริปต์ในเกมส่ง "hello" มาตอนเปิดหน้าเกม (ก่อนล็อกอินก็ส่ง) → รู้ว่ากลุ่มนี้ติดตั้งสคริปต์แล้ว รุ่นไหน
const scriptOk = (g, since) => { const sc = (S.groups[g.id] || {}).script; return sc && sc.at >= since ? sc : null; };
async function reloadGames(g) {
    for (const t of ((S.groups[g.id] || {}).targets || []).filter(isGame)) { await cdp(t.webSocketDebuggerUrl, (send) => send('Page.reload', { ignoreCache: true })).catch(() => {}); }
}
// 🧰 เตรียม Chrome ก่อนเข้าเกม: Tampermonkey → Allow User Scripts → (เข้าเกม) → สคริปต์ตอบ/ติดตั้งหรืออัปเดตสคริปต์
S.prep = {};
function stepSet(g, k, state, msg) {
    const p = S.prep[g.id] || (S.prep[g.id] = { steps: {} });
    p.steps[k] = state;
    if (msg && msg !== p.msg) { p.msg = msg; say(`🧰 ${g.id}: ${msg}`); }
}
// 📋 คัดลอกสคริปต์ใน Tampermonkey จากโปรไฟล์ที่ติดตั้งแล้ว → โปรไฟล์อื่น (ไม่ต้องกด Install ทีละ Chrome)
//    คัดลอกเฉพาะที่เก็บข้อมูลของ Tampermonkey (สคริปต์ + ค่าที่สคริปต์เก็บ) · โปรไฟล์ปลายทางต้องมี Tampermonkey อยู่แล้ว
//    ต้องปิด Chrome ทั้งต้นทางและปลายทางก่อน (ไฟล์ถูกล็อกตอนเปิด) → ปิดให้เอง แล้วเปิดคืนตัวที่เปิดอยู่เดิม · ของเดิมสำรองไว้ใน backup
const TM_DATA = ['Local Extension Settings/' + TM_ID, 'Sync Extension Settings/' + TM_ID, `IndexedDB/chrome-extension_${TM_ID}_0.indexeddb.leveldb`, `IndexedDB/chrome-extension_${TM_ID}_0.indexeddb.blob`];
const tmInstalledOnDisk = (g) => fs.existsSync(path.join(g.dir, 'Default', 'Extensions', TM_ID));
const tmHasData = (g) => fs.existsSync(path.join(g.dir, 'Default', TM_DATA[0]));
let cloning = false;
async function tmClone(from, toIds) {
    if (cloning) throw Error('กำลังคัดลอกอยู่');
    const src = groupOf(from); if (!src) throw Error('ไม่พบโปรไฟล์ต้นทาง');
    if (!tmHasData(src)) throw Error(`${src.id} ยังไม่มี Tampermonkey/สคริปต์ — ติดตั้งในโปรไฟล์นี้ก่อน 1 ครั้ง`);
    const dst = (toIds && toIds.length ? toIds.map(groupOf) : CFG.groups).filter((g) => g && g.id !== src.id && g.dir);
    const ok = dst.filter(tmInstalledOnDisk), noTm = dst.filter((g) => !tmInstalledOnDisk(g));
    if (!ok.length) throw Error(noTm.length ? `โปรไฟล์ปลายทางยังไม่มี Tampermonkey (${noTm.map((g) => g.id).join(', ')}) — ติดตั้ง Tampermonkey ก่อน` : 'ไม่มีโปรไฟล์ปลายทาง');
    cloning = true;
    try {
        const all = [src, ...ok], wasOn = all.filter((g) => { const i = S.groups[g.id] || {}; return i.running || i.debug; });
        if (wasOn.some((g) => (S.groups[g.id] || {}).outside)) throw Error('มี Chrome ที่เปิดจากทางลัดเดิม (โปรแกรมปิดให้ไม่ได้) — ปิดเองก่อน');
        if (wasOn.length) {
            say(`📋 ปิด Chrome ${wasOn.map((g) => g.id).join(', ')} ชั่วคราวเพื่อคัดลอกสคริปต์…`);
            for (const g of wasOn) await stopGroup(g).catch(() => {});
            const off = await waitFor(() => wasOn.every((g) => { const i = S.groups[g.id] || {}; return !i.running && !i.debug; }), 60000, 1000);
            if (!off) throw Error('ปิด Chrome ไม่หมดภายใน 1 นาที — ปิดเองแล้วลองใหม่');
            await sleep(2500);
        }
        const stamp = Date.now(), done = [];
        for (const g of ok) {
            const bdir = path.join(ROOT, 'backup', `tm-${g.id}-${stamp}`);
            for (const rel of TM_DATA) {
                const a = path.join(src.dir, 'Default', rel), b = path.join(g.dir, 'Default', rel);
                if (fs.existsSync(b)) { fs.mkdirSync(path.dirname(path.join(bdir, rel)), { recursive: true }); fs.cpSync(b, path.join(bdir, rel), { recursive: true }); fs.rmSync(b, { recursive: true, force: true }); }
                if (fs.existsSync(a)) { fs.mkdirSync(path.dirname(b), { recursive: true }); fs.cpSync(a, b, { recursive: true, filter: (f) => path.basename(f) !== 'LOCK' }); }
            }
            done.push(g.id);
        }
        say(`📋 คัดลอกสคริปต์จาก ${src.id} → ${done.join(', ')} แล้ว${noTm.length ? ` · ข้าม ${noTm.map((g) => g.id).join(', ')} (ยังไม่มี Tampermonkey)` : ''} · ของเดิมอยู่ใน backup`);
        if (wasOn.length) (async () => { for (const g of wasOn) { try { await startGroup(g); } catch (e) { say('❌ ' + e.message); } await sleep(Math.max(1, +CFG.startGapSec || 5) * 1000); } })();
        return { done, skip: noTm.map((g) => g.id), reopened: wasOn.map((g) => g.id) };
    } finally { cloning = false; }
}
async function prepGroup(g, openGame) {
    if (S.prep[g.id] && S.prep[g.id].running) return;
    S.prep[g.id] = { running: true, go: false, done: false, failed: false, msg: '', steps: { chrome: 'doing', tm: 'wait', allow: 'wait', script: 'wait' } };
    const P = S.prep[g.id];
    try {
        stepSet(g, 'chrome', 'doing', 'รอ Chrome พร้อม…');
        if (!(await waitFor(() => jget(g.debugPort, '/json/version'), 40000, 1000))) throw Error('Chrome ไม่ตอบภายใน 40 วิ');
        stepSet(g, 'chrome', 'ok');
        // 1) Tampermonkey
        stepSet(g, 'tm', 'doing', 'ตรวจ Tampermonkey…');
        let st = await extStatus(g);
        if (!st.installed) {
            const pol = S.policy.user || S.policy.machine;
            stepSet(g, 'tm', 'doing', pol ? 'รอ Chrome ติดตั้ง Tampermonkey ตามนโยบาย…' : 'ยังไม่มี Tampermonkey — กด "เพิ่มใน Chrome" ในหน้าร้านค้าที่เปิดขึ้นมา');
            const storeTab = pol ? '' : await openTab(g, TM_STORE);
            // รอดูจากรายการแท็บ/ตัวทำงานของ Chrome (เห็น Tampermonkey ทันทีที่ติดตั้ง) — ไม่ต้องเปิดหน้า chrome://extensions ซ้ำ ๆ
            const got = await waitFor(() => (S.groups[g.id] || {}).tm === true, 600000, 2000);
            await sleep(1500); await closeTab(g, storeTab); await closeTmWelcome(g);      // ติดตั้งเสร็จ → ปิดหน้าร้านค้า + หน้าต้อนรับ
            st = got ? await waitFor(async () => { const s = await extStatus(g); return s.installed ? s : null; }, 30000, 3000) : null;
            if (!st) throw Error('รอติดตั้ง Tampermonkey นานเกิน 10 นาที');
        }
        stepSet(g, 'tm', 'ok', `มี Tampermonkey แล้ว${st.version ? ' (v' + st.version + ')' : ''}`);
        // 2) Allow User Scripts
        if (!st.allowed) {
            stepSet(g, 'allow', 'doing', 'ยังไม่ได้เปิด Allow User Scripts…');
            if (CFG.autoAllow) { try { await allowUserScripts(g); } catch (e) { say('⚠️ ' + e.message); } st = await extStatus(g); }
            if (!st.allowed) {
                stepSet(g, 'allow', 'doing', 'เปิดสวิตช์ "Allow User Scripts" ในหน้าตั้งค่า Tampermonkey ที่เปิดขึ้นมา');
                const extTab = await openTab(g, 'chrome://extensions/?id=' + TM_ID);
                st = await waitFor(async () => { const s = await extStatus(g); return s.allowed ? s : null; }, 600000, 8000);
                await closeTab(g, extTab);      // เปิดสวิตช์แล้ว → ปิดหน้าตั้งค่า
                if (!st) throw Error('รอเปิด Allow User Scripts นานเกิน 10 นาที');
            }
        }
        stepSet(g, 'allow', 'ok', 'Allow User Scripts เปิดแล้ว');
        // 3) สคริปต์: เข้าเกม → รอสคริปต์ตอบ
        const si = scriptInfo();
        let since = Date.now();
        stepSet(g, 'script', 'doing', 'เข้าหน้าเกม แล้วรอสคริปต์ตอบ…');
        if (openGame) P.go = true;      // หน้าเตรียมความพร้อมพาเข้าเกมเอง
        else if (!((S.groups[g.id] || {}).targets || []).some(isGame)) await openTab(g, gameUrlFor(g));
        else { await reloadGames(g); }
        let sc = await waitFor(() => scriptOk(g, since), 45000, 1000);
        if (sc && sc.ld && si && verNum(sc.v) < verNum(si.version)) {      // มีตัวโหลดแล้วแต่หน้าเกมยังรันชุดเก่า → รีโหลดก็ได้ชุดใหม่
            stepSet(g, 'script', 'doing', `มีสคริปต์ใหม่ v${si.version} — รีโหลดหน้าเกมเพื่ออัปเดต…`);
            since = Date.now(); await reloadGames(g);
            sc = (await waitFor(() => scriptOk(g, since), 45000, 1000)) || sc;
        }
        if (!sc || !sc.ld) {      // ยังไม่มีสคริปต์ หรือยังเป็นแบบเก่า (ไม่อัปเดตเอง) → ติดตั้งตัวโหลดครั้งเดียว
            if (!si) throw Error('ไม่พบไฟล์สคริปต์ (*.user.js) ในโฟลเดอร์โปรแกรม');
            stepSet(g, 'script', 'doing', sc ? 'เปลี่ยนเป็นแบบอัปเดตอัตโนมัติ — กด "Update" ในหน้าของ Tampermonkey ที่เปิดขึ้นมา (ครั้งเดียว หลังจากนี้อัปเดตเองตอนรีโหลดเกม)' : 'ยังไม่มีสคริปต์ — กด "Install" ในหน้าของ Tampermonkey ที่เปิดขึ้นมา (ครั้งเดียว หลังจากนี้อัปเดตเองตอนรีโหลดเกม)');
            const tid = await openTab(g, `http://127.0.0.1:${CFG.port}/aetherack.user.js?t=${Date.now()}`);
            await waitFor(async () => !(await jget(g.debugPort, '/json/list')).some((x) => x.id === tid), 600000, 3000);      // Tampermonkey ปิดแท็บเองเมื่อกดติดตั้ง
            await sleep(1500); await closeTmWelcome(g); since = Date.now(); await reloadGames(g);
            sc = await waitFor(() => scriptOk(g, since), 60000, 1000);
            if (!sc) throw Error('ติดตั้งสคริปต์แล้วแต่สคริปต์ยังไม่ตอบ — ลองรีโหลดหน้าเกม');
        }
        stepSet(g, 'script', 'ok', `สคริปต์ v${sc.v} ทำงานแล้ว${sc.ld ? ' (อัปเดตเองตอนรีโหลดเกม)' : ''}`);
        P.done = true; P.msg = '✅ พร้อมแล้ว'; say(`✅ ${g.id}: พร้อมใช้งาน`);
    } catch (e) {
        P.failed = true; P.msg = '❌ ' + e.message; say(`❌ ${g.id}: ${e.message}`);
        for (const k of Object.keys(P.steps)) if (P.steps[k] === 'doing') P.steps[k] = 'fail';
    } finally { P.running = false; P.go = true; }      // ล้มเหลวก็พาเข้าเกมอยู่ดี (เล่นเองได้)
}
setInterval(() => { policyScan().catch(() => {}); }, 60000);
setTimeout(() => { policyScan().catch(() => {}); }, 1500);
async function eachRunning(fn) {
    const res = [];
    for (const g of CFG.groups) { if (!(S.groups[g.id] || {}).debug) continue; try { res.push({ id: g.id, ok: true, r: await fn(g) }); } catch (e) { res.push({ id: g.id, ok: false, err: e.message }); say('❌ ' + e.message); } }
    if (!res.length) throw Error('ยังไม่มี Chrome ที่เปิดจากโปรแกรมนี้');
    return res;
}

// ---------------------------------------------------------------
// HTTP (127.0.0.1 เท่านั้น)
// ---------------------------------------------------------------
function body(req, max = 2e6) { return new Promise((res, rej) => { let d = ''; req.on('data', (c) => { d += c; if (d.length > max) { rej(Error('too big')); req.destroy(); } }); req.on('end', () => { try { res(d ? JSON.parse(d) : {}); } catch (e) { rej(Error('bad json')); } }); }); }
function send(res, code, obj) { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); }
const publicGroups = () => CFG.groups.map((g) => { const i = S.groups[g.id] || {}; return { id: g.id, name: g.name, proxy: proxyPlain(g.proxy), proxyAuth: !!(g.proxy && proxyCreds(g)), proxyRaw: g.proxy, dir: g.dir, debugPort: g.debugPort, running: !!i.running, debug: !!i.debug, outside: !!i.outside, ram: i.ram || 0, procs: i.procs || 0, games: (i.targets || []).filter(isGame).length, max: maxOf(g), maxScreens: g.maxScreens || '', tm: i.tm === undefined ? null : i.tm, ext: i.ext || null, script: i.script || null, prep: S.prep[g.id] || null }; });

const server = http.createServer(async (req, res) => {
    try {
        // กันเว็บอื่นยิงเข้ามา: Host ต้องเป็น 127.0.0.1/localhost และ API ต้องมี header X-Aeth (เว็บทั่วไปส่ง header นี้ข้ามโดเมนไม่ได้)
        const host = String(req.headers.host || '');
        if (!new RegExp(`^(127\\.0\\.0\\.1|localhost):${CFG.port}$`).test(host)) { res.writeHead(403); res.end(); return; }
        const url = new URL(req.url, 'http://127.0.0.1');
        if (/^\/aetherack\.(user|meta|core)\.js$/.test(url.pathname)) {      // user/meta = ตัวโหลด (ติดตั้งใน Tampermonkey) · core = สคริปต์ตัวจริง (ตัวโหลดดึงทุกครั้งที่เปิดหน้าเกม)
            const si = scriptInfo(); if (!si) { res.writeHead(404); res.end(); return; }
            const kind = url.pathname.split('.')[1];
            if (kind === 'core') {      // ~1 MB → บีบอัดส่ง (~200 KB) ให้ตัวโหลดโหลดทันภายในเวลาที่กำหนด แม้หลายจอโหลดพร้อมกัน
                S.coreHits = (S.coreHits || 0) + 1;
                if (/gzip/.test(String(req.headers['accept-encoding'] || ''))) {
                    if (!CORE_GZ || CORE_GZ.v !== si.version || CORE_GZ.len !== si.src.length) CORE_GZ = { v: si.version, len: si.src.length, buf: zlib.gzipSync(Buffer.from(si.src, 'utf8'), { level: 6 }) };
                    res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8', 'Content-Encoding': 'gzip', 'Content-Length': CORE_GZ.buf.length, 'Cache-Control': 'no-store' }); res.end(CORE_GZ.buf); return;
                }
            }
            res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-store' });
            res.end(kind === 'core' ? si.src : kind === 'meta' ? loaderHead(si) + '\n' : loaderSource(si)); return;
        }
        if (!url.pathname.startsWith('/api/')) {
            const f = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
            if (!/^[\w.-]+$/.test(f)) { res.writeHead(404); res.end(); return; }
            const file = path.join(PUBLIC, f);
            if (!fs.existsSync(file)) { res.writeHead(404); res.end(); return; }
            const ext = path.extname(f).toLowerCase();
            const type = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json; charset=utf-8' }[ext] || 'application/octet-stream';
            res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-store' }); fs.createReadStream(file).pipe(res); return;
        }
        if (req.headers['x-aeth'] !== '1') { send(res, 403, { ok: false, err: 'forbidden' }); return; }
        const p = url.pathname;
        let m0;

        // จากสคริปต์ในเกม: ส่งสถานะ → รับคำสั่งที่ค้าง
        if (p === '/api/peer' && req.method === 'POST') {
            const b = await body(req); const snap = b && b.snap;
            if (!snap || !snap.tab || !snap.name) { send(res, 400, { ok: false }); return; }
            const old = S.peers[snap.tab] || {};
            for (const x of Object.values(S.peers)) {      // ตัวละครเดียวกันจากหน้าเกมก่อนรีโหลด → ลบของเก่า (ย้ายกระเป๋าล่าสุดมาด้วย)
                if (x.tab !== snap.tab && x.name === snap.name) { if (S.inv[x.tab] && !S.inv[snap.tab]) S.inv[snap.tab] = S.inv[x.tab]; delete S.inv[x.tab]; delete S.peers[x.tab]; delete S.cmds[x.tab]; }
            }
            const pf = snap.pf; delete snap.pf;      // สถิติเก็บแยก (ไม่ส่งไปกับสถานะทุก 2 วิ)
            S.peers[snap.tab] = Object.assign({ maps: old.maps || [], mapInfo: old.mapInfo || null }, snap, { ts: Date.now(), group: old.group || '', targetId: old.targetId || '', aurWhy: old.aurWhy || '' });      // รายชื่อแมพส่งมาเป็นระยะ ไม่ใช่ทุกรอบ
            if (pf && typeof pf === 'object' && pf.h) { S.stats[snap.name] = Object.assign({}, pf, { name: snap.name, cls: snap.cls || '', group: S.peers[snap.tab].group || (S.stats[snap.name] || {}).group || '', at: Date.now() }); statsDirty = true; }
            const cmds = S.cmds[snap.tab] || []; delete S.cmds[snap.tab];
            send(res, 200, { ok: true, cmds: cmds.filter((c) => Date.now() - c.at < 120000) }); return;
        }
        if (p === '/api/inv' && req.method === 'POST') {      // สคริปต์ส่งของในกระเป๋ามา
            const b = await body(req); if (!b || !b.tab) { send(res, 400, { ok: false }); return; }
            if (b.pending) { S.inv[b.tab] = Object.assign({}, S.inv[b.tab] || {}, { pending: String(b.pending).slice(0, 120), pat: Date.now() }); send(res, 200, { ok: true }); return; }      // ยังไม่ว่าง (กำลังวาร์ป ฯลฯ) — ยังไม่มีข้อมูลใหม่
            const keep = S.inv[b.tab] || {};
            S.inv[b.tab] = { at: Date.now(), items: Array.isArray(b.items) ? b.items.slice(0, 400) : (b.err ? keep.items || [] : []), w: String(b.w || keep.w || ''), sl: String(b.sl || keep.sl || ''), z: String(b.z || keep.z || ''), err: String(b.err || ''), msg: String(b.msg || ''), tab: String(b.tabName || keep.tab || '') };
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/zone' && req.method === 'POST') {      // สคริปต์ส่งข้อมูลโซนของแมพมา (แผนที่ + โซน + ตัวเลือก)
            const b = await body(req, 4e6); if (!b || !b.tab) { send(res, 400, { ok: false }); return; }
            S.zone[b.tab] = { at: Date.now(), zone: b.zone || null, saved: !!b.saved, err: String(b.err || '') }; send(res, 200, { ok: true }); return;
        }
        if ((m0 = /^\/api\/zone\/([\w-]+)$/.exec(p)) && req.method === 'GET') { send(res, 200, { ok: true, z: S.zone[m0[1]] || null }); return; }
        if (p === '/api/skill' && req.method === 'POST') {      // สคริปต์ส่งรายการสกิลมา
            const b = await body(req); if (!b || !b.tab) { send(res, 400, { ok: false }); return; }
            if (b.pending) { S.skill[b.tab] = Object.assign({}, S.skill[b.tab] || {}, { pending: String(b.pending).slice(0, 120), pat: Date.now() }); send(res, 200, { ok: true }); return; }
            const keep = S.skill[b.tab] || {};
            S.skill[b.tab] = { at: Date.now(), list: Array.isArray(b.list) && (b.list.length || !keep.list) ? b.list.slice(0, 120) : keep.list || [], tabs: Array.isArray(b.tabs) && b.tabs.length ? b.tabs.slice(0, 8) : keep.tabs || [], pts: typeof b.pts === 'number' ? b.pts : -1, err: String(b.err || '').slice(0, 300), dump: String(b.dump || '').slice(0, 6000) }; skillDirty = true;
            send(res, 200, { ok: true }); return;
        }
        if ((m0 = /^\/api\/skill\/([\w-]+)$/.exec(p)) && req.method === 'GET') { send(res, 200, { ok: true, sk: S.skill[m0[1]] || null }); return; }
        if (p === '/api/askill' && req.method === 'POST') {      // สกิลที่ Auto ของเกมใช้
            const b = await body(req); if (!b || !b.tab) { send(res, 400, { ok: false }); return; }
            if (b.pending) { S.askill[b.tab] = Object.assign({}, S.askill[b.tab] || {}, { pending: String(b.pending).slice(0, 120), pat: Date.now() }); send(res, 200, { ok: true }); return; }
            S.askill[b.tab] = { at: Date.now(), list: Array.isArray(b.list) ? b.list.slice(0, 40) : [], max: +b.max || 9, err: String(b.err || '').slice(0, 300), dump: String(b.dump || '').slice(0, 6000) }; skillDirty = true;
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/autocfg' && req.method === 'POST') {      // ⚙️ ตั้งค่า Auto ทั้งหมดของเกม (ต่อสู้/มอน/เก็บของ/ยา·บัพ)
            const b = await body(req, 2e6); if (!b || !b.tab) { send(res, 400, { ok: false }); return; }
            if (b.pending) { S.acfg[b.tab] = Object.assign({}, S.acfg[b.tab] || {}, { pending: String(b.pending).slice(0, 120), pat: Date.now() }); send(res, 200, { ok: true }); return; }
            S.acfg[b.tab] = { at: Date.now(), cfg: b.cfg && typeof b.cfg === 'object' ? b.cfg : {}, opts: b.opts && typeof b.opts === 'object' ? b.opts : {}, err: String(b.err || '').slice(0, 300) };
            send(res, 200, { ok: true }); return;
        }
        if ((m0 = /^\/api\/autocfg\/([\w-]+)$/.exec(p)) && req.method === 'GET') { send(res, 200, { ok: true, ac: S.acfg[m0[1]] || null }); return; }
        if ((m0 = /^\/api\/askill\/([\w-]+)$/.exec(p)) && req.method === 'GET') { send(res, 200, { ok: true, as: S.askill[m0[1]] || null }); return; }
        if (p === '/api/junk' && req.method === 'POST') {      // สคริปต์ส่งการตั้งค่าทิ้งขยะมา
            const b = await body(req); if (!b || !b.tab) { send(res, 400, { ok: false }); return; }
            S.junk[b.tab] = { at: Date.now(), opt: b.opt || {}, shared: !!b.shared, map: b.map || {}, icons: b.icons || {}, defs: Array.isArray(b.defs) ? b.defs.slice(0, 80) : [] }; send(res, 200, { ok: true }); return;
        }
        if ((m0 = /^\/api\/junk\/([\w-]+)$/.exec(p)) && req.method === 'GET') { send(res, 200, { ok: true, jk: S.junk[m0[1]] || null }); return; }
        if (p === '/api/market' && req.method === 'POST') {
            const b = await body(req, 4e6); if (!b || !b.tab) { send(res, 400, { ok: false }); return; }
            if (b.pending) { S.mk.last[b.tab] = Object.assign({}, S.mk.last[b.tab] || {}, { pending: String(b.pending).slice(0, 120), pat: Date.now() }); send(res, 200, { ok: true }); return; }
            if (b.buy && typeof b.buy === 'object') {      // 🛒 ผลการซื้อ
                const x = b.buy, pe = S.peers[b.tab] || {}; S.mk.buys = S.mk.buys || [];
                S.mk.buys.push({ at: Date.now(), tab: b.tab, who: pe.name || b.name || '', n: String(x.n || '').slice(0, 60), seller: String(x.seller || '').slice(0, 40), total: +x.total || 0, q: +x.q || 1, ok: !!x.ok, err: String(x.err || '').slice(0, 300), claimed: +x.claimed || 0 });
                if (S.mk.buys.length > 100) S.mk.buys.splice(0, S.mk.buys.length - 100); mkDirty = true;
                say(x.claimOnly ? `📦 ${pe.name || ''} รับของจากตลาด ${+x.claimed || 0} รายการ${x.err ? ' · ' + x.err : ''}` : x.ok ? `🛒 ${pe.name || ''} ซื้อ ${x.n}${+x.q > 1 ? ' ×' + x.q : ''} จาก ${x.seller} ${(+x.total || 0).toLocaleString()} z${x.claimed ? ' · รับของแล้ว' : ''}` : `🛒 ซื้อ ${x.n} ไม่สำเร็จ: ${x.err}`);
                send(res, 200, { ok: true }); return;
            }
            S.mk.last[b.tab] = { at: Date.now(), q: String(b.q || '').slice(0, 60), n: (b.rows || []).length, info: b.info || null, err: String(b.err || '').slice(0, 300), dump: String(b.dump || '').slice(0, 6000), passive: !!b.passive, rows: Array.isArray(b.rows) ? b.rows.slice(0, 120) : [] };
            if (Array.isArray(b.rows) && b.rows.length) mkIngest(b);
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/classdata' && req.method === 'POST') {
            const b = await body(req, 6e6); if (!b || !Array.isArray(b.classes) || !b.classes.length) { send(res, 400, { ok: false }); return; }
            const cd = { at: Date.now(), classes: b.classes.slice(0, 300), skills: Array.isArray(b.skills) ? b.skills.slice(0, 3000) : [] };
            const sig = (x) => JSON.stringify([x.classes, x.skills]);
            if (!S.cd || sig(S.cd) !== sig(cd)) { const first = !S.cd; S.cd = cd; try { fs.writeFileSync(CD_FILE, JSON.stringify(cd)); } catch (e) { /* ignore */ } say(`🎓 ${first ? 'ได้' : 'อัปเดต'}ข้อมูลอาชีพจากเกม: ${cd.classes.length} อาชีพ · ${cd.skills.length} สกิล`); }
            else S.cd.at = cd.at;
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/classdata' && req.method === 'GET') { send(res, 200, { ok: true, cd: S.cd }); return; }
        if (p === '/api/market' && req.method === 'GET') {
            const items = Object.values(S.mk.items).map((it) => { const h = it.hist, a = h[h.length - 1] || [], prev = h.slice(0, -1).reverse().find((x) => x[1]) || []; return { n: it.n, ic: it.ic, at: it.at, min: a[1] || 0, auc: a[2] || 0, cnt: a[3] || 0, qty: a[4] || 0, prev: prev[1] || 0, sp: h.slice(-40).map((x) => x[1]) }; }).sort((a, c) => c.at - a.at);
            send(res, 200, { ok: true, items, buys: (S.mk.buys || []).slice(-30), watch: S.mk.watch, alerts: S.mk.alerts.slice(-50), every: S.mk.every, nextAt: S.mk.nextAt, last: S.mk.last }); return;
        }
        if (p === '/api/market/item' && req.method === 'GET') { const it = S.mk.items[mkKey(url.searchParams.get('n'))]; send(res, 200, { ok: true, it: it || null }); return; }
        if (p === '/api/stats' && req.method === 'GET') { send(res, 200, { ok: true, stats: Object.values(S.stats) }); return; }
        if (p === '/api/stats/del' && req.method === 'POST') { const b = await body(req); delete S.stats[String(b.name || '')]; statsDirty = true; send(res, 200, { ok: true }); return; }
        if (p === '/api/ramhist' && req.method === 'GET') { send(res, 200, { ok: true, hist: S.ramHist, limitGB: CFG.ramLimitGB }); return; }
        if ((m0 = /^\/api\/inv\/([\w-]+)$/.exec(p)) && req.method === 'GET') { send(res, 200, { ok: true, inv: S.inv[m0[1]] || null }); return; }
        if (p === '/api/ver' && req.method === 'GET') {      // สคริปต์ในเกมถามทุก 1 นาที: มีรุ่นใหม่ไหม + เปิดอัปเดตอัตโนมัติอยู่ไหม
            const si = scriptInfo(); send(res, 200, { ok: true, core: si ? si.version : '', auto: CFG.autoUpdate !== false }); return;
        }
        if (p === '/api/hello' && req.method === 'POST') {      // สคริปต์เปิดหน้าเกมแล้ว (ยังไม่ล็อกอินก็ได้)
            const b = await body(req); const g = groupOf(String(b.grp || ''));
            if (g) { const info = S.groups[g.id] || (S.groups[g.id] = {}); info.script = { v: String(b.v || '?').slice(0, 20), ld: String(b.ld || '').slice(0, 20), at: Date.now() }; }
            send(res, 200, { ok: true }); return;
        }
        if ((m0 = /^\/api\/prep\/([\w-]+)$/.exec(p)) && req.method === 'GET') {      // หน้าเตรียมความพร้อมถามสถานะ
            const g = groupOf(m0[1]); if (!g) { send(res, 404, { ok: false }); return; }
            send(res, 200, { ok: true, id: g.id, prep: S.prep[g.id] || null, game: gameUrlFor(g), enabled: CFG.prepOnStart !== false }); return;
        }
        if (p === '/api/state' && req.method === 'GET') {
            const si = scriptInfo();
            send(res, 200, { ok: true, v: VERSION, script: si ? { file: si.file, version: si.version } : null, groups: publicGroups(), peers: Object.values(S.peers), log: S.log.slice(-60), sys: { cpu: S.cpu.pct, memTotal: os.totalmem(), memFree: os.freemem() }, cfg: { maxPerIp: CFG.maxPerIp, gameUrl: CFG.gameUrl, chromePath: CFG.chromePath, chromeFound: findChrome(), screen: CFG.screen, startGapSec: CFG.startGapSec, port: CFG.port, proxyUser: CFG.proxyUser || '', proxyPassSet: !!CFG.proxyPass, autoAllow: !!CFG.autoAllow, prepOnStart: CFG.prepOnStart !== false, autoUpdate: CFG.autoUpdate !== false, updateUrl: CFG.updateUrl || '', autoPurge: CFG.autoPurge !== false, purgeMin: CFG.purgeMin || 20, ramGuard: CFG.ramGuard !== false, ramLimitGB: CFG.ramLimitGB || 2.5, ramCooldownMin: CFG.ramCooldownMin || 60, win: process.platform === 'win32', policy: S.policy } });
            return;
        }
        if (req.method !== 'POST') { send(res, 405, { ok: false }); return; }
        const b = await body(req, p === '/api/script/upload' ? 8e6 : p === '/api/app/upload' ? 40e6 : 2e6);
        let m;
        if ((m = /^\/api\/group\/([\w-]+)\/(start|stop|newwin)$/.exec(p))) {
            const g = groupOf(m[1]); if (!g) throw Error('ไม่พบกลุ่ม');
            if (m[2] === 'start') await startGroup(g); else if (m[2] === 'stop') await stopGroup(g); else await newGameWindow(g);
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/startall') {
            const list = CFG.groups.filter((g) => !(S.groups[g.id] || {}).running && (!b.ids || b.ids.includes(g.id)));
            (async () => { for (const g of list) { try { await startGroup(g); } catch (e) { say('❌ ' + e.message); } await new Promise((r) => setTimeout(r, Math.max(1, +CFG.startGapSec || 5) * 1000)); } })();
            send(res, 200, { ok: true, n: list.length }); return;
        }
        if (p === '/api/stopall') { for (const g of CFG.groups) if ((S.groups[g.id] || {}).debug) await stopGroup(g).catch(() => {}); send(res, 200, { ok: true }); return; }
        if (p === '/api/app/upload') {      // อัปเดตโปรแกรมจาก zip ที่ลากมาวาง
            const buf = Buffer.from(String(b.b64 || ''), 'base64'); if (buf.length < 100) throw Error('ไม่ได้รับไฟล์');
            const v = applyAppZip(buf); send(res, 200, { ok: true, v }); setTimeout(restartSelf, 500); return;
        }
        if (p === '/api/app/check') { const r = await checkUpdate(); send(res, 200, Object.assign({ ok: true, cur: VERSION }, r)); return; }
        if (p === '/api/app/update') {      // โหลดจากลิงก์ → ตรวจ SHA-256 → ติดตั้ง → รีสตาร์ท
            const r = await checkUpdate(); if (!r.newer && !b.force) throw Error(`เป็นเวอร์ชันล่าสุดแล้ว (v${VERSION})`);
            let buf = null;
            const gh = /^https:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/([^?]+)/.exec(r.url);
            if (gh) { try { buf = await httpsGet(`https://api.github.com/repos/${gh[1]}/${gh[2]}/contents/${gh[4]}?ref=${gh[3]}`, 60e6, 0, { Accept: 'application/vnd.github.raw' }); } catch (e) { buf = null; } }      // GitHub API: ไฟล์ล่าสุดทันที
            if (!buf || (r.sha256 && crypto.createHash('sha256').update(buf).digest('hex').toLowerCase() !== r.sha256.toLowerCase())) buf = await httpsGet(r.url + (r.url.includes('?') ? '&' : '?') + 't=' + Date.now());      // สำรอง: raw (กันแคชด้วย ?t=)
            if (r.sha256) { const h = crypto.createHash('sha256').update(buf).digest('hex'); if (h.toLowerCase() !== r.sha256.toLowerCase()) throw Error('SHA-256 ไม่ตรง — ไฟล์อาจเสียหรือไม่ใช่ของจริง ยกเลิกการติดตั้ง'); }
            const v = applyAppZip(buf); send(res, 200, { ok: true, v }); setTimeout(restartSelf, 500); return;
        }
        if (p === '/api/script/upload') {      // อัปโหลดสคริปต์ใหม่จากหน้า ตั้งค่า (ลากไฟล์มาวาง / เลือกไฟล์)
            const text = String(b.text || '');
            const head = /\/\/ ==UserScript==[\s\S]*?\/\/ ==\/UserScript==/.exec(text);
            if (!head) throw Error('ไม่ใช่ไฟล์สคริปต์ Tampermonkey (ไม่พบหัว ==UserScript==)');
            if (!/@name\s+Aetheria Tracker/i.test(head[0])) throw Error('ไม่ใช่สคริปต์ Aetheria Tracker / Aetherack');
            const v = (/@version\s+(\S+)/.exec(head[0]) || [])[1]; if (!v) throw Error('ไฟล์ไม่มี @version');
            const old = scriptInfo();
            const bdir = path.join(ROOT, 'backup'); fs.mkdirSync(bdir, { recursive: true });
            for (const f of fs.readdirSync(ROOT)) if (/\.user\.js$/i.test(f)) fs.renameSync(path.join(ROOT, f), path.join(bdir, `${Date.now()}-${f}`));      // เก็บของเดิมไว้ใน backup/ (ย้อนกลับได้)
            fs.writeFileSync(path.join(ROOT, 'aetherack.user.js'), text);
            say(`⬆️ อัปโหลดสคริปต์ v${v}${old ? ` (เดิม v${old.version} เก็บไว้ใน backup)` : ''}`);
            send(res, 200, { ok: true, v, old: old ? old.version : '' }); return;
        }
        if (p === '/api/market/scan') {      // ค้นหาในตลาดตอนนี้ (ตัวละครที่เลือก หรือเลือกให้เอง)
            const pe = mkPickPeer(String(b.tab || '')); if (!pe) throw Error('ไม่มีตัวละครออนไลน์ที่ใช้สคริปต์ 5.72.0 ขึ้นไป');
            S.mk.lastUse = S.mk.lastUse || {}; S.mk.lastUse[pe.tab] = Date.now();
            queue(pe.tab, 'mkscan', { q: String(b.q || '').slice(0, 60), pages: Math.max(1, Math.min(5, +b.pages || 1)) }); send(res, 200, { ok: true, tab: pe.tab, name: pe.name }); return;
        }
        if (p === '/api/market/claim') {      // 📦 รับของทั้งหมดในแท็บ รับของ
            const pe = mkPickPeer(String(b.tab || '')); if (!pe || (b.tab && pe.tab !== String(b.tab))) throw Error('ตัวละครที่เลือกไม่ออนไลน์');
            if (verNum(pe.v || '0') < verNum('5.92.0')) throw Error(`${pe.name} ใช้สคริปต์ v${pe.v} — ต้อง 5.92.0 ขึ้นไป (รีโหลดเกม)`);
            queue(pe.tab, 'mkclaim', {}); send(res, 200, { ok: true, tab: pe.tab, name: pe.name }); return;
        }
        if (p === '/api/market/buy') {      // 🛒 ซื้อรายการที่เลือก (ตัวละครที่ระบุ) — ยืนยันใน Manager แล้ว
            const pe = mkPickPeer(String(b.tab || '')); if (!pe || (b.tab && pe.tab !== String(b.tab))) throw Error('ตัวละครที่เลือกไม่ออนไลน์ (หรือสคริปต์เก่ากว่า 5.91.0)');
            if (verNum(pe.v || '0') < verNum('5.92.0')) throw Error(`${pe.name} ใช้สคริปต์ v${pe.v} — ต้อง 5.92.0 ขึ้นไป (รีโหลดเกม)`);
            const buy = { n: String(b.n || '').slice(0, 60), seller: String(b.seller || '').slice(0, 40), total: Math.max(0, +b.total || 0), q: Math.max(1, +b.q || 1), claim: b.claim !== false };
            if (!buy.n || !buy.seller || !buy.total) throw Error('ข้อมูลรายการไม่ครบ');
            queue(pe.tab, 'mkbuy', { buy }); send(res, 200, { ok: true, tab: pe.tab, name: pe.name }); return;
        }
        if (p === '/api/market/watch') {
            if (Array.isArray(b.watch)) S.mk.watch = b.watch.slice(0, 60).map((w) => { const old = S.mk.watch.find((x) => mkKey(x.n) === mkKey(w.n)) || {}; return { n: String(w.n || '').slice(0, 50), max: Math.max(0, +w.max || 0), on: w.on !== false, lastAlert: old.lastAlert || 0, lastPrice: old.lastPrice || 0 }; }).filter((w) => w.n);
            if (b.every) S.mk.every = Math.max(5, Math.min(240, +b.every || 15));
            if (b.clearAlerts) S.mk.alerts = [];
            S.mk.nextAt = Math.min(S.mk.nextAt || 0, Date.now() + 5000); mkDirty = true; send(res, 200, { ok: true, watch: S.mk.watch, every: S.mk.every }); return;
        }
        if (p === '/api/tmclone') { const r = await tmClone(String(b.from || ''), Array.isArray(b.to) ? b.to.map(String) : null); send(res, 200, Object.assign({ ok: true }, r)); return; }
        if (p === '/api/tmdisk') { send(res, 200, { ok: true, g: CFG.groups.map((g) => ({ id: g.id, tm: tmInstalledOnDisk(g), data: tmHasData(g), ld: !!((S.groups[g.id] || {}).script || {}).ld })) }); return; }
        if (p === '/api/updateall') {      // อัปเดตสคริปต์ทุกจอ: มีตัวโหลด → ทยอยรีโหลด · ยังเป็นแบบเก่า → เปิดหน้าติดตั้งตัวโหลด (กด Update ครั้งเดียว)
            const si = scriptInfo(); if (!si) throw Error('ไม่พบไฟล์สคริปต์ในโฟลเดอร์โปรแกรม');
            const now = Date.now(), live = Object.values(S.peers).filter((x) => now - x.ts < 60000);
            const need = live.filter((x) => x.ld && verNum(x.v) < verNum(si.version));
            need.forEach((x, i) => setTimeout(() => queue(x.tab, 'reload'), i * 3000));
            const oldG = new Set(live.filter((x) => !x.ld && x.group).map((x) => x.group)); let opened = 0;
            for (const id of oldG) { const g = groupOf(id); if (g && (S.groups[id] || {}).debug) { await openTab(g, `http://127.0.0.1:${CFG.port}/aetherack.user.js?t=${now}`).catch(() => {}); opened++; } }
            say(`⬆️ อัปเดตทั้งหมดเป็น v${si.version}: รีโหลด ${need.length} จอ${opened ? ` · เปิดหน้าติดตั้งตัวโหลด ${opened} Chrome (กด Update)` : ''}`);
            send(res, 200, { ok: true, n: need.length, opened, v: si.version, latest: live.length - need.length - live.filter((x) => !x.ld).length }); return;
        }
        if (p === '/api/quit') {      // ปิดโปรแกรม (เปิดผ่าน .exe ไม่มีหน้าต่างดำให้ปิด) — Chrome ที่เปิดอยู่ยังเล่นต่อได้ แต่กลุ่มที่ใช้รหัสพร็อกซีจะออกเน็ตไม่ได้จนกว่าจะเปิดโปรแกรมใหม่
            say('⏻ ปิดโปรแกรม'); send(res, 200, { ok: true });
            setTimeout(() => process.exit(0), 300); return;
        }
        if (p === '/api/focusall' || p === '/api/minall') {      // ดึงทุกจอเกมขึ้นมา / ย่อทุกจอ (ไม่เปลี่ยนขนาด-ตำแหน่ง)
            let n = 0;
            for (const g of CFG.groups) {
                const info = S.groups[g.id]; if (!info || !info.debug) continue;
                const games = (await jget(g.debugPort, '/json/list').catch(() => [])).filter(isGame);
                for (const t of games) { try { if (p === '/api/focusall') await focusTarget(g, t.id); else await minimizeTarget(g, t.id); n++; } catch (e) { /* ignore */ } }
            }
            if (!n) throw Error('ไม่มีจอเกมที่เปิดจากโปรแกรม');
            say(p === '/api/focusall' ? `🖥️ ดึงจอเกมขึ้นมา ${n} จอ` : `➖ ย่อจอเกม ${n} จอ`); send(res, 200, { ok: true, n }); return;
        }
        if (p === '/api/arrange') { await arrangeAll(b && b.w ? b : null); send(res, 200, { ok: true }); return; }
        // เปิดหน้าให้ผู้ใช้กดเองในทุก Chrome (หรือเฉพาะกลุ่ม): ร้านค้า Tampermonkey / หน้ารายละเอียดส่วนขยาย (สวิตช์ Allow User Scripts) / หน้าติดตั้งสคริปต์
        if ((m = /^\/api\/setup\/(tm|ext|script)$/.exec(p))) {
            if (m[1] === 'script' && !scriptInfo()) throw Error('ไม่พบไฟล์สคริปต์ (*.user.js) ในโฟลเดอร์โปรแกรม');
            const url = m[1] === 'tm' ? TM_STORE : m[1] === 'ext' ? 'chrome://extensions/?id=' + TM_ID : `http://127.0.0.1:${CFG.port}/aetherack.user.js?t=${Date.now()}`;
            const pick = (g) => !b.group || b.group === g.id;
            const r = await eachRunning(async (g) => {
                if (!pick(g)) return 'skip'; if (m[1] === 'tm' && (S.groups[g.id] || {}).tm) return 'skip';
                if (m[1] === 'ext' && CFG.autoAllow) { await allowUserScripts(g); return 'auto'; }
                const tid = await openTab(g, url);
                if (m[1] === 'tm') closeWhen(g, tid, () => (S.groups[g.id] || {}).tm === true, 600000);
                else if (m[1] === 'ext') closeWhen(g, tid, async () => (await extStatus(g)).allowed, 600000, 8000);
                else setTimeout(() => closeTmWelcome(g).catch(() => {}), 30000);      // หน้าติดตั้งสคริปต์ Tampermonkey ปิดเองหลังกด Install
                return 'open';
            });
            const n = r.filter((x) => x.r === 'open' || x.r === 'auto').length;
            say({ tm: `🧩 เปิดหน้าติดตั้ง Tampermonkey ใน ${n} Chrome`, ext: `🧩 เปิดหน้าตั้งค่า Tampermonkey ใน ${n} Chrome — เปิดสวิตช์ Allow User Scripts`, script: `⬆️ เปิดหน้าติดตั้งสคริปต์ v${scriptInfo().version} ใน ${n} Chrome — กด ติดตั้ง/อัปเดต` }[m[1]]);
            send(res, 200, { ok: true, n }); return;
        }
        if ((m = /^\/api\/group\/([\w-]+)\/(prep|check)$/.exec(p))) {
            const g = groupOf(m[1]); if (!g) throw Error('ไม่พบกลุ่ม');
            if (!(S.groups[g.id] || {}).debug) throw Error(`${g.id} ยังไม่ได้เปิดจากโปรแกรม`);
            if (m[2] === 'check') {      // ตรวจ + ดึงจอเกมของโปรไฟล์นี้ขึ้นมา (แท็บที่ซ่อน/ย่ออยู่ Chrome จะหน่วงสคริปต์ ทำให้ไม่ส่งเวอร์ชันมา)
                await extStatus(g).catch(() => {});
                const tg = (await jget(g.debugPort, '/json/list').catch(() => [])).filter(isGame);
                for (const t of tg) await focusTarget(g, t.id).catch(() => {});
                const info = S.groups[g.id] || {}; if (info.script) info.script.at = 0;      // รอเวอร์ชันใหม่จากสคริปต์
                send(res, 200, { ok: true, n: tg.length }); return;
            }
            prepGroup(g, false).catch(() => {}); send(res, 200, { ok: true }); return;
        }
        if (p === '/api/group/add') {      // เพิ่มโปรไฟล์ (Chrome/IP) จากหน้าหลัก
            const id = String(b.id || '').trim(); if (!/^[\w-]{1,20}$/.test(id)) throw Error('ชื่อโปรไฟล์ใช้ตัวอังกฤษ/ตัวเลข ไม่เกิน 20 ตัว');
            if (groupOf(id)) throw Error(`มีโปรไฟล์ ${id} อยู่แล้ว`);
            let proxy = String(b.proxy || '').trim();
            if (proxy && !/^\w+:\/\//.test(proxy)) proxy = 'http://' + (proxy.includes(':') ? proxy : proxy + ':50100');      // ใส่แค่ IP ได้ (พอร์ต 50100 ตาม Proxy-Seller)
            if (proxy && !/^(https?|socks5?):\/\/([^\s/@]+@)?[^\s/@]+$/.test(proxy)) throw Error('พร็อกซีต้องเป็น IP หรือ http://IP:พอร์ต');
            const used = new Set(CFG.groups.map((g) => g.debugPort)); let port = 9301; while (used.has(port)) port++;
            CFG.groups.push({ id, name: String(b.name || id).trim() || id, proxy, dir: `C:\\Chrome${id}`, debugPort: port, maxScreens: Math.max(0, Math.min(20, parseInt(b.maxScreens, 10) || 0)) || undefined });
            saveConfig(CFG); relaysSync(); say(`➕ เพิ่มโปรไฟล์ ${id}${proxy ? ' (' + proxyPlain(proxy).replace(/^https?:\/\//, '') + ')' : ' (เน็ตบ้าน)'}`);
            send(res, 200, { ok: true }); return;
        }
        if (p === '/api/checkall') { await eachRunning((g) => extStatus(g)); send(res, 200, { ok: true }); return; }
        if ((m = /^\/api\/setup\/(policy|unpolicy)$/.exec(p))) { await policySet(b.scope === 'machine' ? 'machine' : 'user', m[1] === 'policy'); send(res, 200, { ok: true }); return; }
        if ((m = /^\/api\/peer\/([\w-]+)\/cmd$/.exec(p))) {
            const pe = S.peers[m[1]]; if (!pe) throw Error('ไม่พบตัวละคร');
            const ex = {};
            if (b.map) ex.map = String(b.map).slice(0, 80);
            if (b.idx !== undefined) { ex.idx = +b.idx || 0; ex.ic = String(b.ic || '').slice(0, 300); ex.n = String(b.n || '').slice(0, 80); }
            if (Array.isArray(b.plan)) ex.plan = b.plan.slice(0, 6).map((r) => ({ s: String(r.s || '').slice(0, 4), t: +r.t || 0 }));
            if (typeof b.on === 'boolean') ex.on = b.on;
            const rects = (a) => a.slice(0, 60).map((z) => (Array.isArray(z) ? z.slice(0, 4).map((v) => Math.max(0, Math.floor(+v) || 0)) : [0, 0, 0, 0]));
            if (Array.isArray(b.zones)) ex.zones = rects(b.zones);
            if (Array.isArray(b.ban)) ex.ban = rects(b.ban);
            if (Array.isArray(b.spots)) ex.spots = b.spots.slice(0, 40).map((q) => (Array.isArray(q) ? [Math.floor(+q[0]) || 0, Math.floor(+q[1]) || 0] : [0, 0]));
            if (Array.isArray(b.skplan)) ex.plan = b.skplan.slice(0, 40).map((r) => ({ n: String(r.n || '').slice(0, 40), t: Math.max(0, Math.min(99, +r.t || 0)), c: String(r.c || '').slice(0, 24) }));
            if (Array.isArray(b.names)) ex.names = b.names.slice(0, 9).map((x) => String(x).slice(0, 40));
            if (b.wmax !== undefined) ex.wmax = Math.max(50, Math.min(100, +b.wmax || 90));
            const flat = (o, depth) => { const r = {}; for (const [k, v] of Object.entries(o || {}).slice(0, 400)) { if (!/^[^\x00-\x1f<>]{1,40}$/.test(k) || k === '__proto__' || k === 'constructor') continue; if (typeof v === 'boolean' || typeof v === 'number') r[k] = v; else if (typeof v === 'string') r[k] = v.slice(0, 60); else if (v === null) r[k] = null; else if (depth < 2 && v && typeof v === 'object') r[k] = flat(v, depth + 1); } return r; };
            if (b.jopt && typeof b.jopt === 'object') ex.opt = flat(b.jopt, 0);
            if (b.jmap && typeof b.jmap === 'object') ex.map = flat(b.jmap, 0);
            if (b.jmapReplace && typeof b.jmapReplace === 'object') ex.mapReplace = flat(b.jmapReplace, 0);
            if (typeof b.jshared === 'boolean') ex.shared = b.jshared;
            if (Array.isArray(b.items)) ex.items = b.items.slice(0, 60).map((x) => ({ idx: +x.idx || 0, ic: String(x.ic || '').slice(0, 300), n: String(x.n || '').slice(0, 80) }));
            if (b.acfg && typeof b.acfg === 'object') {      // ตั้งค่า Auto: รับเฉพาะคีย์ที่รู้จัก + ชนิดข้อมูลถูก
                const A = b.acfg, c = {}, bool = ['basicAttack', 'buffParty', 'acceptParty', 'autoQuiver', 'autoRevive', 'defendOthers', 'flyWing', 'pickupLoot'], num = ['autoReviveMax', 'flyWingIdleSeconds', 'flyWingMobs', 'hpPercent', 'spPercent', 'healPartyPercent'], lists = ['monsters', 'lootTypes', 'buffItems', 'hpItems', 'spItems'];
                for (const k of bool) if (typeof A[k] === 'boolean') c[k] = A[k];
                for (const k of num) if (A[k] !== undefined && isFinite(+A[k])) c[k] = +A[k];
                for (const k of lists) if (Array.isArray(A[k])) c[k] = A[k].slice(0, 20).map((x) => String(x).slice(0, 60));
                if (A.huntRadiusTiles === 'all' || isFinite(+A.huntRadiusTiles)) c.huntRadiusTiles = A.huntRadiusTiles === 'all' ? 'all' : +A.huntRadiusTiles;
                if (A.lootWhen === 'clear' || A.lootWhen === 'first') c.lootWhen = A.lootWhen;
                ex.cfg = c;
            }
            if (b.job !== undefined) ex.job = b.job && b.job.n ? { n: String(b.job.n).slice(0, 30), th: String(b.job.th || '').slice(0, 30), id: String(b.job.id || '').slice(0, 30) } : null;
            if (Array.isArray(b.keep)) ex.keep = b.keep.slice(0, 100).map((x) => String(x || '').slice(0, 50)).filter(Boolean);
            if (Array.isArray(b.danger)) ex.danger = b.danger.slice(0, 60).map((x) => +x || 0);
            if (b.opt && typeof b.opt === 'object') { ex.opt = {}; for (const [k, v] of Object.entries(b.opt).slice(0, 30)) if (/^\w{1,20}$/.test(k) && (typeof v === 'boolean' || typeof v === 'number')) ex.opt[k] = v; }
            await peerCmd(pe, String(b.cmd || ''), Object.keys(ex).length ? ex : null); send(res, 200, { ok: true }); return;
        }
        if (p === '/api/all/cmd') {
            const cmd = String(b.cmd || ''); if (!SCRIPT_CMDS.has(cmd)) throw Error('คำสั่งนี้สั่งทั้งหมดไม่ได้');
            const list = Object.values(S.peers).filter((x) => Date.now() - x.ts < 30000 && (!b.group || x.group === b.group));
            list.forEach((x, i) => { if (cmd === 'reload') setTimeout(() => queue(x.tab, cmd), i * 2500); else queue(x.tab, cmd); });      // รีโหลดทยอยทีละจอ
            say(`📣 สั่ง "${cmd}" ${list.length} ตัว${b.group ? ' ใน ' + b.group : ''}`);
            send(res, 200, { ok: true, n: list.length }); return;
        }
        if (p === '/api/config') {
            const next = Object.assign({}, CFG);
            for (const k of ['chromePath', 'gameUrl', 'bypass', 'perfFlags', 'proxyUser', 'updateUrl']) if (typeof b[k] === 'string') next[k] = b[k].trim();
            if (next.updateUrl && !/^https?:\/\//.test(next.updateUrl)) throw Error('ลิงก์ตรวจอัปเดตต้องขึ้นต้นด้วย https://');
            if (typeof b.proxyPass === 'string' && b.proxyPass !== '********') next.proxyPass = b.proxyPass;
            for (const k of ['autoAllow', 'prepOnStart', 'autoUpdate', 'autoPurge', 'ramGuard']) if (typeof b[k] === 'boolean') next[k] = b[k];
            if (b.purgeMin !== undefined) next.purgeMin = Math.max(5, Math.min(240, +b.purgeMin || 20));
            if (b.ramLimitGB !== undefined) next.ramLimitGB = Math.max(0.5, Math.min(16, +b.ramLimitGB || 2.5));
            if (b.ramCooldownMin !== undefined) next.ramCooldownMin = Math.max(10, Math.min(720, +b.ramCooldownMin || 60));      // ช่องรหัสแสดง ******** = ไม่เปลี่ยน
            for (const k of ['maxPerIp', 'startGapSec']) if (b[k] !== undefined) next[k] = Math.max(1, Math.min(50, +b[k] || 1));
            if (b.screen) next.screen = { width: +b.screen.width || 1920, height: +b.screen.height || 1040, cols: +b.screen.cols || 4 };
            if (Array.isArray(b.groups)) {
                const ids = new Set(), ports = new Set();
                next.groups = b.groups.map((g) => ({ id: String(g.id || '').trim(), name: String(g.name || g.id || '').trim(), proxy: String(g.proxy || '').trim(), dir: String(g.dir || '').trim(), debugPort: +g.debugPort, maxScreens: Math.max(0, Math.min(20, parseInt(g.maxScreens, 10) || 0)) || undefined }))
                    .filter((g) => g.id && g.dir);
                for (const g of next.groups) {
                    if (!/^[\w-]+$/.test(g.id)) throw Error(`ชื่อกลุ่ม "${g.id}" ใช้ได้แค่ตัวอังกฤษ/ตัวเลข`);
                    if (ids.has(g.id)) throw Error(`ชื่อกลุ่ม ${g.id} ซ้ำ`); ids.add(g.id);
                    if (!(g.debugPort >= 1024 && g.debugPort <= 65000) || ports.has(g.debugPort)) throw Error(`พอร์ตของ ${g.id} ไม่ถูกต้องหรือซ้ำ`); ports.add(g.debugPort);
                    if (g.proxy && !/^(https?|socks5?):\/\/([^\s/@]+@)?[^\s/@]+$/.test(g.proxy)) throw Error(`พร็อกซีของ ${g.id} ต้องเป็นแบบ http://IP:พอร์ต`);
                }
            }
            CFG = next; saveConfig(CFG); relaysSync(); say('💾 บันทึกการตั้งค่าแล้ว');
            send(res, 200, { ok: true }); return;
        }
        send(res, 404, { ok: false, err: 'not found' });
    } catch (e) {
        send(res, 400, { ok: false, err: e && e.message ? e.message : String(e) });
    }
});
// ---------------------------------------------------------------
// 🔄 อัปเดตตัวโปรแกรม: ไฟล์ zip (ลากวาง หรือโหลดจากลิงก์ manifest) → ตรวจ → สำรองของเดิม → แตกทับ → รีสตาร์ทตัวเอง
//    ไม่แตะ config.json / peers.json / backup · Chrome ที่เปิดอยู่เล่นต่อได้ (ต่อกลับเองหลังรีสตาร์ท)
// ---------------------------------------------------------------
function unzip(buf) {      // อ่าน zip แบบไม่ใช้แพ็กเกจเสริม (เก็บตรง / deflate)
    let e = buf.length - 22; while (e >= 0 && buf.readUInt32LE(e) !== 0x06054b50) e--;
    if (e < 0) throw Error('ไม่ใช่ไฟล์ zip');
    const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const out = [];
    for (let k = 0; k < n; k++) {
        if (buf.readUInt32LE(p) !== 0x02014b50) throw Error('ไฟล์ zip เสีย');
        const method = buf.readUInt16LE(p + 10), csize = buf.readUInt32LE(p + 20), nlen = buf.readUInt16LE(p + 28), xlen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), loff = buf.readUInt32LE(p + 42);
        const name = buf.slice(p + 46, p + 46 + nlen).toString('utf8'); p += 46 + nlen + xlen + clen;
        if (name.endsWith('/')) continue;
        const start = loff + 30 + buf.readUInt16LE(loff + 26) + buf.readUInt16LE(loff + 28), raw = buf.slice(start, start + csize);
        if (method !== 0 && method !== 8) throw Error('zip ใช้วิธีบีบอัดที่ไม่รองรับ');
        out.push({ name: name.replace(/\\/g, '/'), data: method === 0 ? raw : zlib.inflateRawSync(raw) });
    }
    return out;
}
const KEEP = /^(config\.json|config\.default\.json|peers\.json|stats\.json|skills\.json|market\.json|classdata\.json|manager\.log|backup\/.*)$/i;
function applyAppZip(buf) {
    const files = unzip(buf);
    const srv = files.find((f) => /(^|\/)server\.js$/.test(f.name)); if (!srv) throw Error('ใน zip ไม่มี server.js — ไม่ใช่ไฟล์ Aetherack Manager');
    const prefix = srv.name.slice(0, srv.name.length - 'server.js'.length);
    const v = (/const VERSION = '([^']+)'/.exec(srv.data.toString('utf8')) || [])[1]; if (!v) throw Error('อ่านเวอร์ชันจาก server.js ไม่ได้');
    const list = files.filter((f) => f.name.startsWith(prefix)).map((f) => ({ rel: f.name.slice(prefix.length), data: f.data }))
        .filter((f) => f.rel && !KEEP.test(f.rel) && !f.rel.split('/').some((x) => x === '..' || x === ''));
    const bdir = path.join(ROOT, 'backup', `app-${VERSION}-${Date.now()}`);
    for (const f of list) {      // สำรองไฟล์เดิมก่อนทับ
        const dst = path.join(ROOT, f.rel);
        if (fs.existsSync(dst)) { const b = path.join(bdir, f.rel); fs.mkdirSync(path.dirname(b), { recursive: true }); try { fs.copyFileSync(dst, b); } catch (e) { /* ignore */ } }
    }
    for (const f of list) { const dst = path.join(ROOT, f.rel); fs.mkdirSync(path.dirname(dst), { recursive: true }); fs.writeFileSync(dst, f.data); }
    say(`🔄 ติดตั้งโปรแกรม v${v} แล้ว (${list.length} ไฟล์ · ของเดิมเก็บไว้ใน backup) — รีสตาร์ท…`);
    return v;
}
function restartSelf() {
    for (const r of RELAYS.values()) { try { r.server.close(); } catch (e) { /* ignore */ } }
    server.close();
    let out = 'ignore'; try { out = fs.openSync(path.join(ROOT, 'manager.log'), 'a'); } catch (e) { /* ignore */ }
    spawn(process.execPath, [path.join(ROOT, 'server.js'), '--restarted'], { cwd: ROOT, detached: true, stdio: ['ignore', out, out], windowsHide: true }).unref();
    setTimeout(() => process.exit(0), 400);
}
function httpsGet(url, max = 60e6, hops = 0, hdr) {      // โหลดไฟล์ (ตามลิงก์ย้ายได้)
    return new Promise((resolve, reject) => {
        const mod = url.startsWith('https:') ? require('node:https') : http;
        mod.get(url, { headers: Object.assign({ 'User-Agent': 'AetherackManager/' + VERSION }, hdr || {}), timeout: 30000 }, (r) => {
            if (r.statusCode >= 300 && r.statusCode < 400 && r.headers.location && hops < 5) { r.resume(); resolve(httpsGet(new URL(r.headers.location, url).href, max, hops + 1, hdr)); return; }
            if (r.statusCode !== 200) { r.resume(); reject(Error('HTTP ' + r.statusCode)); return; }
            const ch = []; let n = 0;
            r.on('data', (c) => { n += c.length; if (n > max) { r.destroy(); reject(Error('ไฟล์ใหญ่เกิน')); } else ch.push(c); });
            r.on('end', () => resolve(Buffer.concat(ch))); r.on('error', reject);
        }).on('error', reject).on('timeout', function () { this.destroy(Error('หมดเวลา')); });
    });
}
async function checkUpdate() {
    const src = CFG.updateUrl || UPDATE_URL;
    let m = null;
    const gh = /^https:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/(.+)$/.exec(src);
    if (gh) {      // GitHub: ถาม API ก่อน (ได้ค่าล่าสุดทันที ไม่ติดแคช ~5 นาทีของ raw) · ไม่ได้ค่อยใช้ raw
        try { m = JSON.parse((await httpsGet(`https://api.github.com/repos/${gh[1]}/${gh[2]}/contents/${gh[4]}?ref=${gh[3]}`, 1e6, 0, { Accept: 'application/vnd.github.raw' })).toString('utf8')); } catch (e) { m = null; }
    }
    if (!m || !m.version) m = JSON.parse((await httpsGet(src + (src.includes('?') ? '&' : '?') + 't=' + Date.now(), 1e6)).toString('utf8'));
    if (!m || !m.version || !m.url) throw Error('ไฟล์ manifest ไม่ถูกต้อง (ต้องมี version และ url)');
    return { version: String(m.version), url: new URL(String(m.url), src).href,      // url ใน manifest เป็นชื่อไฟล์เฉย ๆ ได้ (อยู่โฟลเดอร์เดียวกับ manifest)
         sha256: String(m.sha256 || ''), notes: String(m.notes || ''), newer: verNum(m.version) > verNum(VERSION) };
}
function openAppWindow(u) {      // หน้ารวมเป็นหน้าต่างแอปแยก (มีไอคอนของโปรแกรม) · ไม่มี Chrome → เบราว์เซอร์ปกติ
    if (process.platform !== 'win32' || process.argv.includes('--no-open')) return;
    const exe = findChrome();
    if (exe) spawn(exe, [`--app=${u}`, `--user-data-dir=${path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'AetherackManager', 'app-window')}`, '--window-size=1400,900', '--no-first-run', '--no-default-browser-check'], { detached: true, stdio: 'ignore' }).unref();
    else spawn('cmd', ['/c', 'start', '', u], { detached: true, stdio: 'ignore', windowsHide: true }).unref();
}
// เปิดโปรแกรมซ้ำ: ตัวที่ค้างอยู่เป็นเวอร์ชันเก่ากว่า (เช่น แตก zip ทับตอนโปรแกรมยังเปิด) → สั่งตัวเก่าปิด แล้วรันตัวใหม่แทน · เวอร์ชันเดียวกัน → เปิดหน้ารวมให้
function takeOver() {
    const ask = (method, p) => new Promise((resolve) => {
        const r = http.request({ host: '127.0.0.1', port: CFG.port, method, path: p, headers: { 'X-Aeth': '1', 'Content-Type': 'application/json' }, timeout: 4000 }, (x) => { let d = ''; x.on('data', (c) => d += c); x.on('end', () => { try { resolve(JSON.parse(d)); } catch (er) { resolve(null); } }); });
        r.on('error', () => resolve(null)).on('timeout', () => r.destroy()); r.end(method === 'POST' ? '{}' : undefined);
    });
    ask('GET', '/api/state').then(async (st) => {
        if (st && st.v && verNum(st.v) < verNum(VERSION)) {
            console.error(`ตัวเก่า v${st.v} เปิดค้างอยู่ — ปิดแล้วเปิด v${VERSION} แทน`);
            await ask('POST', '/api/quit');
            spawn(process.execPath, [path.join(ROOT, 'server.js'), '--takeover'], { cwd: ROOT, detached: true, stdio: 'inherit', windowsHide: true }).unref();
            setTimeout(() => process.exit(0), 300); return;
        }
        console.error(`โปรแกรมเปิดอยู่แล้ว — เปิดหน้ารวมให้แทน`); openAppWindow(`http://127.0.0.1:${CFG.port}/`); setTimeout(() => process.exit(0), 1500);
    });
}
let bindTry = 0;
server.on('error', (e) => {
    if (e.code === 'EADDRINUSE' && (process.argv.includes('--restarted') || process.argv.includes('--takeover')) && bindTry++ < 20) { setTimeout(() => server.listen(CFG.port, '127.0.0.1'), 500); return; }      // รีสตาร์ทหลังอัปเดต: รอตัวเก่าปิดพอร์ต
    if (e.code === 'EADDRINUSE') { takeOver(); return; }
    console.error(e.message); process.exit(1);
});
setTimeout(async () => {      // เปิดโปรแกรมแล้วตรวจ Chrome ที่เปิดค้างอยู่ 1 รอบ (Tampermonkey / Allow User Scripts) ให้ตารางสถานะมีข้อมูล
    for (const g of CFG.groups) { const i = S.groups[g.id] || {}; if (i.debug && !i.ext) await extStatus(g).catch(() => {}); }
}, 6000);
server.listen(CFG.port, '127.0.0.1', () => {
    relaysSync();      // Chrome ที่เปิดค้างไว้จากรอบก่อนยังชี้มาที่ตัวกลาง → เปิดตัวกลางรอไว้เลย (หลังได้พอร์ตหลักแล้ว = ไม่ได้เปิดซ้อน)
    const u = `http://127.0.0.1:${CFG.port}/`;
    say(`✅ Aetherack Manager v${VERSION} พร้อมใช้งาน: ${u}`);
    if (!findChrome()) say('⚠️ ไม่พบ chrome.exe — ใส่ที่อยู่ในหน้า ตั้งค่า');
    if (!process.argv.includes('--restarted')) openAppWindow(u);      // รีสตาร์ทหลังอัปเดต: หน้ารวมเดิมต่อกลับเอง
});
